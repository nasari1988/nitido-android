#!/usr/bin/env bash
# DreamLite's instruction reader (Qwen3-VL-2B) as int8 ONNX parts for the phone's CPU, step 1 (measure there).
# No secrets; weights from dl/dreamlite-mobile (fixed commit and hashes).
set -euo pipefail
cd "$(dirname "$0")/.."
M=dl/dreamlite-mobile
bash ci/dreamlite_get.sh
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" "torchvision==0.21.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.43.0" "transformers==5.23.0" "accelerate" "safetensors" "pillow" "numpy<2" "onnx==1.17.0" "onnxruntime==1.22.0"
rm -rf out; mkdir -p out
.venv/bin/python -I ci/qwenvl_export.py "$M" ci/testdata/old/a.png out
rm -rf out/f32
( cd out && for f in qvl_*; do echo "$f $(stat -c %s "$f")"; done ) > out/files.txt
printf 'name=Lector de DreamLite (prueba)\nversion=1\nsource=carlofkl/DreamLite-mobile@6695c3f\nlicense=CC BY-NC 4.0\n' > out/info.txt
cat out/files.txt
ls -la out
