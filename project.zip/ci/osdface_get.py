"""
Caras con OSDFace (jkwang28/OSDFace, CVPR 2025; weights: OSDFace Non-Commercial Academic Research
License 1.0, used here for the user's family photos, non-commercial): fetches the authors' three
files from their Google Drive folder, checks their fixed sha256 and turns them into safetensors.

  associate_2.ckpt                  -> dl/osd_vq.safetensors       (the VQ encoder, without its decoder)
  embedding_change_weights.pth      -> dl/osd_embed.safetensors    (two 1x1 convolutions, 512 -> 1024)
  pytorch_lora_weights.safetensors  -> dl/osd_lora.safetensors     (already safetensors: only checked)

The two pickle files are never run: torch.load(weights_only=True) (torch >= 2.6) only rebuilds
tensors; any other name inside them (training state, settings) is given an empty stand-in class that
runs nothing, so only the tensors come out. No keys or tokens are used anywhere here.

usage: osdface_get.py fetch <dir>     download only (needs network)
       osdface_get.py convert <dir>   check sha256 and convert (no network needed)
"""
import hashlib
import os
import re
import sys

FOLDER = "https://drive.google.com/drive/folders/1Nci6KufB8t2Uj-6tobrw3S7kkfQUTLHV"
FILES = ["associate_2.ckpt", "embedding_change_weights.pth", "pytorch_lora_weights.safetensors"]
# fixed fingerprints (ci/osdface.sha256); a first run without them prints them and stops
PINS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "osdface.sha256")


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def fetch(d):
    import gdown
    os.makedirs(d, exist_ok=True)
    got = gdown.download_folder(FOLDER, output=d, quiet=False, use_cookies=False)
    print("bajado:", got, flush=True)
    for f in FILES:
        hits = [os.path.join(r, x) for r, _, fs in os.walk(d) for x in fs if x == f]
        if not hits:
            raise SystemExit(f"no llegó {f} (la carpeta tiene: {[x for _, _, fs in os.walk(d) for x in fs]})")
        if hits[0] != os.path.join(d, f):
            os.replace(hits[0], os.path.join(d, f))


def safe_load(path):
    """torch.load with weights_only=True; unknown names become stand-ins that run nothing."""
    import torch
    stubs = []
    for _ in range(60):
        try:
            with torch.serialization.safe_globals(stubs):
                return torch.load(path, map_location="cpu", weights_only=True)
        except Exception as e:  # noqa: BLE001
            m = re.search(r"GLOBAL ([\w.]+)\.(\w+)", str(e))
            if not m:
                raise
            mod, name = m.group(1), m.group(2)
            print(f"  {os.path.basename(path)}: {mod}.{name} -> marcador vacío (no se ejecuta)", flush=True)

            def _init(self, *a, **k):
                pass

            def _setstate(self, state):
                self.__dict__["_state"] = state

            # a plain dict that also takes list items: whatever the pickle builds into it stays data
            cls = type(name, (dict,), {"__init__": _init, "__setstate__": _setstate, "__module__": mod,
                                       "append": lambda self, x: None, "extend": lambda self, x: None})
            cls.__qualname__ = name
            stubs.append(cls)
    raise SystemExit(f"{path}: demasiados nombres desconocidos")


def tensors(obj, prefix=""):
    import torch
    if isinstance(obj, torch.Tensor):
        return {prefix: obj.contiguous()}
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(tensors(v, f"{prefix}.{k}" if prefix else str(k)))
    return out


def convert(d):
    from safetensors.torch import save_file
    have = {f: sha256(os.path.join(d, f)) for f in FILES}
    for f, h in have.items():
        print(f"{h}  {f}", flush=True)
    if not os.path.exists(PINS):
        raise SystemExit("faltan las huellas fijas (ci/osdface.sha256): copia las de arriba y vuelve a correr")
    pins = dict(reversed(l.split()) for l in open(PINS) if l.strip())
    for f, h in have.items():
        if pins.get(f) != h:
            raise SystemExit(f"{f} no es el archivo revisado ({h} en vez de {pins.get(f)})")
    print("huellas: correctas", flush=True)

    ck = safe_load(os.path.join(d, "associate_2.ckpt"))
    sd = ck["state_dict"] if isinstance(ck, dict) and "state_dict" in ck else ck
    vq = {k[len("vqvae_LQ."):]: v for k, v in tensors(sd).items()
          if k.startswith("vqvae_LQ.") and not k.startswith("vqvae_LQ.decoder")}
    if not vq:
        raise SystemExit("associate_2.ckpt: no trae el codificador vqvae_LQ")
    save_file(vq, os.path.join(d, "osd_vq.safetensors"))
    print(f"osd_vq.safetensors: {len(vq)} tensores", flush=True)

    em = tensors(safe_load(os.path.join(d, "embedding_change_weights.pth")))
    save_file(em, os.path.join(d, "osd_embed.safetensors"))
    print(f"osd_embed.safetensors: {sorted(em)}", flush=True)

    os.replace(os.path.join(d, "pytorch_lora_weights.safetensors"), os.path.join(d, "osd_lora.safetensors"))
    for f in ("associate_2.ckpt", "embedding_change_weights.pth"):
        os.remove(os.path.join(d, f))   # from here on only safetensors


if __name__ == "__main__":
    {"fetch": fetch, "convert": convert}[sys.argv[1]](sys.argv[2])
