"""
✦ Realismo (Restaurar): PiSA-SR (csslc/PiSA-SR, Apache-2.0) on Stable Diffusion 2.1-base, for the
phone's NPU. One step: the photo's latent minus the UNet's prediction is the restored latent.

  latent = VAE.encode(photo).mean * sf                  -> pisa_enc  (512x512 RGB -1..1 -> 1x4x64x64)
  pred   = UNet(latent, t=1, text "")  (both LoRAs in)  -> pisa_unet (1x4x64x64 -> 1x4x64x64)
  photo' = VAE.decode((latent - s*pred) / sf)           -> pisa_dec  (1x4x64x64 -> 512x512 RGB -1..1)

s = 1 is the authors' default (pixel + semantic LoRA); the app's "intensidad" scales it. The text is
always empty, so its embedding is computed here and kept inside the UNet graph.

The weights (pisa/pisa_sr.pkl, the authors' file, given by the user) are checked first: the pickle
is read without running it and may only name the 3 functions of a plain state dict; then
torch.load(weights_only=True) with torch >= 2.6. The LoRAs are put in with peft exactly as the
authors' PiSASR_eval does (pixel LoRA merged, then the semantic one merged on top).

usage: pisa_export.py <pisa_sr.pkl> <out dir> <sample photos dir>
out: pisa_{enc,unet,dec}.onnx, calib_pisa_{enc,unet,dec}/list.txt, pisa_parts.txt, check/*.jpg
"""
import os
import pickletools
import sys
import zipfile

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

T = 512           # pixels per piece
L = T // 8        # latent per piece
ALLOWED = {("collections", "OrderedDict"), ("torch._utils", "_rebuild_tensor_v2"), ("torch", "FloatStorage")}
BASES = ["stabilityai/stable-diffusion-2-1-base", "Manojb/stable-diffusion-2-1-base"]


def check_pickle(path):
    z = zipfile.ZipFile(path)
    pk = [n for n in z.namelist() if n.endswith(".pkl")]
    used, strs = set(), []
    for op, arg, _ in pickletools.genops(z.read(pk[0])):
        if op.name in ("SHORT_BINUNICODE", "BINUNICODE", "UNICODE"):
            strs.append(arg)
        elif op.name == "STACK_GLOBAL":
            used.add(tuple(strs[-2:]))
        elif op.name == "GLOBAL":
            used.add(tuple(arg.split(" ", 1)))
        elif op.name in ("INST", "OBJ", "EXT1", "EXT2", "EXT4"):
            raise SystemExit(f"pisa_sr.pkl tiene una instrucción no permitida: {op.name}")
    if used - ALLOWED:
        raise SystemExit(f"pisa_sr.pkl llama funciones no permitidas: {sorted(used - ALLOWED)}")
    print("pesos revisados: solo", sorted(used), flush=True)


def load_base():
    from diffusers import AutoencoderKL, UNet2DConditionModel
    from transformers import AutoTokenizer, CLIPTextModel
    last = None
    for repo in BASES:
        try:
            tok = AutoTokenizer.from_pretrained(repo, subfolder="tokenizer")
            te = CLIPTextModel.from_pretrained(repo, subfolder="text_encoder")
            vae = AutoencoderKL.from_pretrained(repo, subfolder="vae")
            unet = UNet2DConditionModel.from_pretrained(repo, subfolder="unet")
            print("modelo base:", repo, flush=True)
            return tok, te, vae, unet
        except Exception as e:  # noqa: BLE001
            print(f"no se pudo usar {repo}: {e}", flush=True)
            last = e
    raise SystemExit(f"sin modelo base SD 2.1: {last}")


def merge_loras(unet, sd):
    """The authors' order: pixel LoRA added and merged, then the semantic LoRA added and merged."""
    from peft import LoraConfig
    w = sd["state_dict_unet"]
    for kind in ("pix", "sem"):
        names = []
        for part in ("encoder", "decoder", "others"):
            mods = sd[f"unet_lora_{part}_modules_{kind}"]
            name = f"default_{part}_{kind}"
            unet.add_adapter(LoraConfig(r=sd[f"lora_rank_unet_{kind}"], init_lora_weights="gaussian", target_modules=mods), adapter_name=name)
            names.append(name)
        n = 0
        for pname, p in unet.named_parameters():
            if "lora" in pname and kind in pname:
                p.data.copy_(w[pname]); n += 1
        print(f"LoRA {kind}: {n} tensores de {sum(1 for k in w if kind in k)}", flush=True)
        unet.set_adapters(names, [1.0] * len(names))   # all three parts active, like the authors
        merge_active(unet)
    return unet


def merge_active(unet):
    """Merge every active LoRA into its base layer and drop the LoRA modules (peft merge_and_unload)."""
    from peft.tuners.lora import LoraLayer
    for name, mod in list(unet.named_modules()):
        if isinstance(mod, LoraLayer):
            mod.merge()
    # unload: replace each LoRA wrapper by its base layer
    for name, mod in list(unet.named_modules()):
        if isinstance(mod, LoraLayer):
            parent = unet.get_submodule(name.rsplit(".", 1)[0]) if "." in name else unet
            setattr(parent, name.rsplit(".", 1)[-1], mod.get_base_layer())
    if hasattr(unet, "peft_config"):
        del unet.peft_config
    unet._hf_peft_config_loaded = False


class Enc(torch.nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, image):
        return self.vae.encode(image).latent_dist.mode() * self.vae.config.scaling_factor


class Unet(torch.nn.Module):
    def __init__(self, unet, ehs):
        super().__init__()
        self.unet = unet
        self.register_buffer("ehs", ehs)
        self.register_buffer("t", torch.tensor([1], dtype=torch.long))

    def forward(self, latent):
        return self.unet(latent, self.t, encoder_hidden_states=self.ehs).sample


class Dec(torch.nn.Module):
    def __init__(self, vae):
        super().__init__()
        self.vae = vae

    def forward(self, latent):
        return self.vae.decode(latent / self.vae.config.scaling_factor).sample.clamp(-1, 1)


def adain(out, ref):
    """The authors' color fix: each channel's mean and spread taken from the input."""
    o = out.reshape(3, -1); r = ref.reshape(3, -1)
    o = (o - o.mean(1, keepdims=True)) / (o.std(1, keepdims=True) + 1e-5) * r.std(1, keepdims=True) + r.mean(1, keepdims=True)
    return o.reshape(out.shape)


def pieces(img, n):
    """Up to n 512x512 pieces from a photo (scaled so its short side is 512..768)."""
    w, h = img.size
    k = max(T / min(w, h), min(1.0, 768 / min(w, h)))
    img = img.resize((max(T, int(w * k)), max(T, int(h * k))), Image.BICUBIC)
    a = np.asarray(img.convert("RGB")).astype(np.float32) / 127.5 - 1
    H, W = a.shape[:2]
    out = []
    for (y, x) in [(0, 0), (H - T, W - T), ((H - T) // 2, (W - T) // 2), (0, W - T)][:n]:
        out.append(torch.from_numpy(a[y:y + T, x:x + T]).permute(2, 0, 1)[None].contiguous())
    return out


def main():
    pkl, out, photos = sys.argv[1:4]
    os.makedirs(out, exist_ok=True)
    check_pickle(pkl)
    sd = torch.load(pkl, map_location="cpu", weights_only=True)
    print("claves:", [k for k in sd if k != "state_dict_unet"], flush=True)
    tok, te, vae, unet = load_base()
    vae.eval(); unet.eval(); te.eval()
    with torch.no_grad():
        ids = tok([""], max_length=tok.model_max_length, padding="max_length", truncation=True, return_tensors="pt").input_ids
        ehs = te(ids)[0].float()
    del te
    unet = merge_loras(unet, sd).eval()
    enc, un, dec = Enc(vae).eval(), Unet(unet, ehs).eval(), Dec(vae).eval()

    # the sample photos: pieces through the float model (the result to look at, and the calibration)
    files = sorted(os.path.join(r, f) for r, _, fs in os.walk(photos) for f in fs if f.lower().endswith((".png", ".jpg", ".jpeg")))
    tiles = []
    for f in files:
        tiles += pieces(Image.open(f), 1)
    tiles = tiles[:12]
    print(f"{len(tiles)} piezas de {len(files)} fotos", flush=True)
    cdir = {n: os.path.join(out, f"calib_pisa_{n}") for n in ("enc", "unet", "dec")}
    for d in cdir.values():
        os.makedirs(d, exist_ok=True)
    lists = {n: [] for n in cdir}
    chk = os.path.join(out, "check"); os.makedirs(chk, exist_ok=True)
    with torch.no_grad():
        for i, x in enumerate(tiles):
            z = enc(x)
            pred = un(z)
            zr = z - pred
            y = dec(zr)
            y = adain(y, x).clamp(-1, 1)
            for n, t, key in (("enc", x, "image"), ("unet", z, "latent"), ("dec", zr, "latent")):
                p = os.path.join(cdir[n], f"{i:02d}.raw")
                t.numpy().astype(np.float32).tofile(p)
                lists[n].append(f"{key}:={os.path.abspath(p)}")
            # also some with a weaker step (the app's intensity), so the decoder's ranges cover them
            if i % 3 == 0:
                p = os.path.join(cdir["dec"], f"{i:02d}h.raw")
                (z - 0.5 * pred).numpy().astype(np.float32).tofile(p)
                lists["dec"].append(f"latent:={os.path.abspath(p)}")
            both = torch.cat([x, y], 3)[0].permute(1, 2, 0).numpy()
            Image.fromarray(((both + 1) * 127.5).clip(0, 255).astype(np.uint8)).save(os.path.join(chk, f"pisa_{i:02d}.jpg"), quality=88)
    for n in lists:
        open(os.path.join(cdir[n], "list.txt"), "w").write("\n".join(lists[n]) + "\n")

    import onnx
    import onnxruntime as ort
    done = []
    for n, m, x, iname, oname in (("enc", enc, tiles[0], "image", "latent"),
                                  ("unet", un, enc(tiles[0]).detach(), "latent", "pred"),
                                  ("dec", dec, enc(tiles[0]).detach(), "latent", "image")):
        name = f"pisa_{n}"
        tmp = os.path.join(out, "tmp_" + name); os.makedirs(tmp, exist_ok=True)
        with torch.no_grad():
            ref = m(x)
            torch.onnx.export(m, (x,), os.path.join(tmp, "m.onnx"), input_names=[iname], output_names=[oname],
                              opset_version=17, do_constant_folding=True)
        mo = onnx.load(os.path.join(tmp, "m.onnx"), load_external_data=True)
        dst = os.path.join(out, name + ".onnx")
        onnx.save(mo, dst, save_as_external_data=True, all_tensors_to_one_file=True, location=name + ".onnx.data")
        del mo
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
        got = ort.InferenceSession(dst, providers=["CPUExecutionProvider"]).run(None, {iname: x.numpy()})[0]
        print(f"{name}: ONNX contra PyTorch, diferencia máxima {float(np.abs(got - ref.numpy()).max()):.5f}", flush=True)
        done.append(name)
    open(os.path.join(out, "pisa_parts.txt"), "w").write("\n".join(done) + "\n")
    print("PiSA-SR exportado:", done, flush=True)


if __name__ == "__main__":
    main()
