#!/usr/bin/env bash
# DreamLite-mobile's editor for the phone (Editar › paso 1).  ci/dreamlite_npu_build.sh [WxH]
# -> ./out: dl_unet[_WxH] for the NPU, dl_vae_enc/dec.onnx, tokenizer files, test data, files.txt
# No secrets. Weights CC BY-NC 4.0 (ByteDance), fixed commit and sha256 (ci/dreamlite_get.sh), safetensors only.
set -euo pipefail
cd "$(dirname "$0")/.."
SIZE="${1:-1024x1024}"; W="${SIZE%x*}"; H="${SIZE#*x}"
M=dl/dreamlite-mobile
bash ci/dreamlite_get.sh
echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" "torchvision==0.21.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.43.0" "transformers==5.23.0" "accelerate" "safetensors" "pillow" "numpy<2" "onnx==1.17.0"
echo "::endgroup::"

echo "::group::DreamLite en el servidor y exportación ($SIZE)"
rm -rf onnx out; mkdir -p onnx out
free -h | head -2
.venv/bin/python -I ci/dreamlite_npu_export.py "$M" ci/testdata/old onnx "$W" "$H"
rm -rf dl/dreamlite-mobile/text_encoder
echo "::endgroup::"

TAG=""; [ "$SIZE" = "1024x1024" ] || TAG="_$SIZE"
N="dl_unet$TAG"
source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
echo "::group::$N para la NPU"
NPU_SYM=0 NPU_PER_ROW=1 bash ci/npu_build.sh "$N" "onnx/$N.onnx" "onnx/calib_$N/list.txt" \
  || { echo "::error::$N no compiló para la NPU"; exit 1; }
echo "::endgroup::"
cp onnx/dl_test* out/
[ -n "$TAG" ] || cp onnx/dl_vae_enc.onnx onnx/dl_vae_dec.onnx onnx/dl_tok_vocab.json onnx/dl_tok_merges.txt out/
rm -rf out/qnn_runtime
for f in out/*; do
  if [ "$(stat -c %s "$f")" -gt 1900000000 ]; then split -b 1800M -d -a 2 "$f" "$f.split"; rm "$f"; fi
done
(cd out && for f in *; do [ "$f" = files.txt ] || echo "$f $(stat -c %s "$f")"; done > ../files.list && mv ../files.list files.txt)
cat out/files.txt
