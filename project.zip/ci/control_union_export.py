"""
ControlNet Union ProMax for SDXL (xinsir/controlnet-union-sdxl-1.0, Apache-2.0) for the phone's NPU,
fixed to two guides at once: the pose (control type 0) and the depth (type 1). The pose keeps where
arms, legs and head go; the depth keeps the body's volume (waist, hips), so a redrawn garment does
not change the figure.

As with the pose ControlNet, only the part that feeds the UNet's skip connections is exported: time,
text and control-type embedding, conv_in, both guides' encoders and their fusion (the union's small
transformer), the down blocks and their zero convolutions -> d0..d8. The control types are fixed
inside the graph (constants), so the phone feeds just the two pictures.

Also exported: Depth Anything V2 Small (Apache-2.0) as ONNX for the phone's processor, 518x518, to
make the depth picture from the user's photo; and it makes the calibration depth pictures here.

usage: control_union_export.py <union dir> <depth dir> <sdxl base dir> <photos dir> <out> <W> <H>
-> <out>/control_union[_WxH].onnx (+.data), calib_control_union[_WxH]/list.txt, depth_small.onnx
"""
import glob
import math
import os
import sys

import numpy as np
import torch
from PIL import Image, ImageDraw

un_dir, depth_dir, base_dir, photos, out, W, H = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], int(sys.argv[6]), int(sys.argv[7])
TAG = "" if (W, H) == (1024, 1024) else f"_{W}x{H}"
NAME = "control_union" + TAG
os.makedirs(out, exist_ok=True)
torch.set_grad_enabled(False)

# ---- the pose drawing (the same as the app's PoseImage.kt) ----
LIMBS = [(2, 3), (2, 6), (3, 4), (4, 5), (6, 7), (7, 8), (2, 9), (9, 10), (10, 11), (2, 12), (12, 13),
         (13, 14), (2, 1), (1, 15), (15, 17), (1, 16), (16, 18)]
COLORS = [(255, 0, 0), (255, 85, 0), (255, 170, 0), (255, 255, 0), (170, 255, 0), (85, 255, 0), (0, 255, 0),
          (0, 255, 85), (0, 255, 170), (0, 255, 255), (0, 170, 255), (0, 85, 255), (0, 0, 255), (85, 0, 255),
          (170, 0, 255), (255, 0, 255), (255, 0, 170), (255, 0, 85)]


def draw_pose(kps, w, h):
    img = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(img)
    ratio = 1.0 if max(w, h) < 500 else 2.0 if max(w, h) < 1000 else 3.0
    stick = 4 * ratio
    for (a, b), c in zip(LIMBS, COLORS):
        p, q = kps[a - 1], kps[b - 1]
        if p is None or q is None:
            continue
        x1, y1, x2, y2 = p[0] * w, p[1] * h, q[0] * w, q[1] * h
        L = math.hypot(x2 - x1, y2 - y1) / 2
        ang = math.atan2(y2 - y1, x2 - x1)
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        pts = []
        for k in range(36):
            t = 2 * math.pi * k / 36
            ex, ey = L * math.cos(t), stick * math.sin(t)
            pts.append((mx + ex * math.cos(ang) - ey * math.sin(ang), my + ex * math.sin(ang) + ey * math.cos(ang)))
        d.polygon(pts, fill=tuple(int(v * 0.6) for v in c))
    for p, c in zip(kps, COLORS):
        if p is None:
            continue
        r = 4 * ratio
        d.ellipse([p[0] * w - r, p[1] * h - r, p[0] * w + r, p[1] * h + r], fill=c)
    return img


POSES = [
    [(.50, .14), (.50, .24), (.40, .25), (.36, .40), (.35, .54), (.60, .25), (.64, .40), (.65, .54), (.44, .52),
     (.43, .71), (.43, .90), (.56, .52), (.57, .71), (.57, .90), (.48, .12), (.52, .12), (.45, .13), (.55, .13)],
    [(.48, .16), (.49, .26), (.39, .27), (.30, .18), (.27, .07), (.59, .27), (.66, .38), (.70, .50), (.43, .55),
     (.40, .73), (.38, .92), (.55, .55), (.58, .73), (.60, .92), (.46, .14), (.50, .14), None, (.53, .15)],
    [(.52, .20), (.51, .30), (.42, .31), (.40, .46), (.47, .56), (.60, .31), (.63, .46), (.56, .56), (.44, .60),
     (.30, .64), (.32, .86), (.56, .60), (.44, .66), (.47, .88), (.50, .18), (.54, .18), (.47, .19), None],
    [(.55, .15), (.53, .25), (.45, .26), (.44, .40), (.50, .50), (.61, .25), (.66, .38), (.72, .46), (.47, .53),
     (.52, .70), (.47, .89), (.58, .53), (.62, .70), (.70, .86), (.53, .13), (.57, .13), None, (.60, .14)],
]

files = sorted(glob.glob(os.path.join(photos, "*.png")) + glob.glob(os.path.join(photos, "*.jpg")))[:4]


def fit(im, w, h):
    k = max(w / im.width, h / im.height)
    im = im.resize((max(w, round(im.width * k)), max(h, round(im.height * k))), Image.LANCZOS)
    l, t = (im.width - w) // 2, (im.height - h) // 2
    return im.crop((l, t, l + w, t + h))


# ---- the depth reader: export it for the phone and make the calibration depth pictures ----
from transformers import AutoModelForDepthEstimation

print("Depth Anything V2 Small", flush=True)
dm = AutoModelForDepthEstimation.from_pretrained(depth_dir, torch_dtype=torch.float32).eval()
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


class Depth(torch.nn.Module):
    """pixels 0..1 [1,3,518,518] -> depth 0..1 [1,1,518,518], near = 1 (what the ControlNet was trained on)."""
    def __init__(self, m):
        super().__init__()
        self.m = m

    def forward(self, pixels):
        d = self.m(pixel_values=(pixels - MEAN) / STD).predicted_depth[:, None]
        lo = d.amin(dim=(2, 3), keepdim=True)
        hi = d.amax(dim=(2, 3), keepdim=True)
        return (d - lo) / (hi - lo + 1e-6)


dmod = Depth(dm).eval()
x518 = torch.rand(1, 3, 518, 518)
torch.onnx.export(dmod, (x518,), os.path.join(out, "depth_small.onnx"), input_names=["pixels"], output_names=["depth"],
                  opset_version=17, do_constant_folding=True)
import onnxruntime as ort
y = ort.InferenceSession(os.path.join(out, "depth_small.onnx"), providers=["CPUExecutionProvider"]).run(None, {"pixels": x518.numpy()})[0]
print(f"profundidad ONNX contra PyTorch: diferencia {float(np.abs(y - dmod(x518).numpy()).max()):.5f} · salida {y.shape}", flush=True)


def depth_of(im):
    x = torch.from_numpy(np.asarray(im.resize((518, 518), Image.BICUBIC)).astype(np.float32) / 255).permute(2, 0, 1)[None]
    d = dmod(x)[0, 0].numpy()
    g = Image.fromarray((d * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC)
    return Image.merge("RGB", (g, g, g))


depths = [depth_of(fit(Image.open(f).convert("RGB"), W, H)) for f in files]
if depths:
    depths[0].save(os.path.join(out, f"depth_example{TAG}.png"))
del dm, dmod

print(f"ControlNet Union ProMax · pose + profundidad · {W}x{H}", flush=True)
from diffusers import AutoencoderKL, EulerDiscreteScheduler
from diffusers.models.controlnets.controlnet_union import ControlNetUnionModel
from transformers import CLIPTextModel, CLIPTextModelWithProjection, CLIPTokenizer

tok1 = CLIPTokenizer.from_pretrained(base_dir, subfolder="tokenizer")
tok2 = CLIPTokenizer.from_pretrained(base_dir, subfolder="tokenizer_2")
te1 = CLIPTextModel.from_pretrained(base_dir, subfolder="text_encoder", torch_dtype=torch.float32).eval()
te2 = CLIPTextModelWithProjection.from_pretrained(base_dir, subfolder="text_encoder_2", torch_dtype=torch.float32).eval()


def encode(text):
    ids1 = tok1(text, padding="max_length", max_length=77, truncation=True, return_tensors="pt").input_ids
    ids2 = tok2(text, padding="max_length", max_length=77, truncation=True, return_tensors="pt").input_ids
    o1 = te1(ids1, output_hidden_states=True)
    o2 = te2(ids2, output_hidden_states=True)
    return torch.cat([o1.hidden_states[-2], o2.hidden_states[-2]], -1).float(), o2.text_embeds.float()


prompts = ["one-piece swimsuit, fabric texture, photo, realistic, natural light",
           "red evening dress, photo, realistic, highly detailed",
           "denim jacket and jeans, photo, realistic, sharp focus",
           "sportswear, photo, realistic, natural light"]
texts = [encode(p) for p in prompts]
free = encode("blurry, deformed, bad anatomy, extra limbs, worst quality, low quality")
del te1, te2
vae = AutoencoderKL.from_pretrained(base_dir, subfolder="vae", torch_dtype=torch.float32).eval()
sched = EulerDiscreteScheduler.from_pretrained(base_dir, subfolder="scheduler")
ab = sched.alphas_cumprod
latents = []
for f in files:
    im = fit(Image.open(f).convert("RGB"), W, H)
    x = torch.from_numpy(np.asarray(im).astype(np.float32) / 127.5 - 1).permute(2, 0, 1)[None]
    latents.append(vae.encode(x).latent_dist.mean * vae.config.scaling_factor)
del vae
time_ids = torch.tensor([[H, W, 0, 0, H, W]], dtype=torch.float32)
gen = torch.Generator().manual_seed(7)
steps = [874, 749, 624, 499, 374, 249]


def pic(im):
    return torch.from_numpy(np.asarray(im).astype(np.float32) / 255).permute(2, 0, 1)[None]


samples = []
for i, x0 in enumerate(latents):
    for j, ts in enumerate(steps[i % 2::2]):
        a = ab[ts]
        xt = (a.sqrt() * x0 + (1 - a).sqrt() * torch.randn(x0.shape, generator=gen)).float()
        ehs, pooled = free if (i + j) % 2 else texts[i % len(texts)]
        samples.append({"sample": xt, "timestep": torch.tensor([float(ts)]), "encoder_hidden_states": ehs,
                        "text_embeds": pooled, "time_ids": time_ids,
                        "cond_pose": pic(draw_pose(POSES[(i + j) % len(POSES)], W, H)), "cond_depth": pic(depths[i])})
print("muestras de calibración:", len(samples), flush=True)

cn = ControlNetUnionModel.from_pretrained(un_dir, torch_dtype=torch.float32).eval()
print("ControlNet Union:", sum(p.numel() for p in cn.parameters()) / 1e9, "mil millones de pesos ·",
      cn.config.num_control_type, "tipos de control", flush=True)
TYPES = [0, 1]   # pose, depth
ctype = torch.zeros(1, cn.config.num_control_type)
for t in TYPES:
    ctype[0, t] = 1


class Down(torch.nn.Module):
    def __init__(self, c):
        super().__init__()
        self.c = c
        self.register_buffer("ctype", ctype.clone())

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids, cond_pose, cond_depth):
        c = self.c
        t_emb = c.time_proj(timestep.reshape(-1)).to(sample.dtype)
        emb = c.time_embedding(t_emb)
        te = c.add_time_proj(time_ids.flatten()).reshape((text_embeds.shape[0], -1))
        aug = c.add_embedding(torch.cat([text_embeds, te], -1))
        ce = c.control_type_proj(self.ctype.flatten()).reshape((t_emb.shape[0], -1))
        emb = emb + c.control_add_embedding(ce) + aug
        sample = c.conv_in(sample)
        inputs, conds = [], []
        for cond, idx in ((cond_pose, TYPES[0]), (cond_depth, TYPES[1])):
            condition = c.controlnet_cond_embedding(cond)
            inputs.append((torch.mean(condition, dim=(2, 3)) + c.task_embedding[idx]).unsqueeze(1))
            conds.append(condition)
        inputs.append(torch.mean(sample, dim=(2, 3)).unsqueeze(1))
        x = torch.cat(inputs, dim=1)
        for layer in c.transformer_layes:
            x = layer(x)
        fuser = sample * 0.0
        for k, condition in enumerate(conds):
            fuser = fuser + condition + c.spatial_ch_projs(x[:, k]).unsqueeze(-1).unsqueeze(-1)
        h = sample + fuser
        res = (h,)
        for blk in c.down_blocks:
            if getattr(blk, "has_cross_attention", False):
                h, r = blk(hidden_states=h, temb=emb, encoder_hidden_states=encoder_hidden_states)
            else:
                h, r = blk(hidden_states=h, temb=emb)
            res += r
        return tuple(z(r) for r, z in zip(res, c.controlnet_down_blocks))


m = Down(cn).eval()
INS = ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids", "cond_pose", "cond_depth"]
OUTS = [f"d{i}" for i in range(9)]
x = samples[0]
mine = m(*[x[n] for n in INS])
ref, _mid = cn(x["sample"], x["timestep"], encoder_hidden_states=x["encoder_hidden_states"],
               controlnet_cond=[x["cond_pose"], x["cond_depth"]], control_type=ctype, control_type_idx=TYPES,
               added_cond_kwargs={"text_embeds": x["text_embeds"], "time_ids": x["time_ids"]}, return_dict=False)
diff = max(float((a - b).abs().max()) for a, b in zip(mine, ref))
print(f"parte de bajada contra el ControlNet completo: diferencia máxima {diff:.6f}", flush=True)
if len(mine) != 9 or diff > 1e-3:
    raise SystemExit("La parte exportada no da lo mismo que el ControlNet; no se publica nada")
for i, r in enumerate(mine):
    print(f"  d{i}: {list(r.shape)} · desv. {float(r.std()):.4f}", flush=True)

cdir = os.path.join(out, "calib_" + NAME)
os.makedirs(cdir, exist_ok=True)
lines = []
for k, s in enumerate(samples):
    items = []
    for n in INS:
        f = os.path.join(cdir, f"{k:02d}_{n}.raw")
        s[n].numpy().astype(np.float32).tofile(f)
        items.append(f"{n}:={os.path.abspath(f)}")
    lines.append(" ".join(items))
open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")

import onnx
tmp = os.path.join(out, "tmp_" + NAME)
os.makedirs(tmp, exist_ok=True)
torch.onnx.export(m, tuple(x[n] for n in INS), os.path.join(tmp, "m.onnx"), input_names=INS, output_names=OUTS,
                  opset_version=17, do_constant_folding=True)
del cn, m
mo = onnx.load(os.path.join(tmp, "m.onnx"), load_external_data=True)
n = sum(int(np.prod(t.dims)) for t in mo.graph.initializer)
onnx.save(mo, os.path.join(out, NAME + ".onnx"), save_as_external_data=True, all_tensors_to_one_file=True, location=NAME + ".onnx.data")
import json
import shutil
shutil.rmtree(tmp, ignore_errors=True)
print(f"{NAME}: {n / 1e9:.2f} mil millones de pesos exportados", flush=True)
stats = {o: {"mean": float(r.mean()), "std": float(r.std()), "shape": list(r.shape)} for o, r in zip(OUTS, mine)}
json.dump({"size": [W, H], "types": ["pose", "depth"], "outputs": stats}, open(os.path.join(out, NAME + "_ref.json"), "w"))
