"""
Mejorar video › Limpiar: RealBasicVSR split into 4 parts the phone runs frame by frame, each with
fixed sizes for the NPU, for a landscape (640×360) and a portrait (360×640) low-res frame:

  rb_clean{tag}  lr (1,3,H,W) 0..1                         -> lrc (1,3,H,W)    the image cleaning
  rb_flow{tag}   a, b (1,3,H,W)                            -> flow (1,2,H,W)   SPyNet: how b moved to a
  rb_back{tag}   lrc, prop (1,64,H,W), flow                -> feat (1,64,H,W)  one backward step
  rb_fwd{tag}    lrc, prop, flow, back (1,64,H,W)          -> feat, img (1,3,4H,4W)  forward step + picture

The phone: clean every frame, flows between neighbours, backward over a block of frames (keeping
each frame's feature), then forward frame by frame making the pictures. Same maths as the network
(rbvsr_export.py), with the warp grid as constants (no Range ops) for the NPU.

Calibration: the float model on test clips (pans over the test photos, compressed like a phone
video), every part's real inputs at every step. Checks ONNX against PyTorch.

usage: rbvsr_npu.py <weights.pth> <out dir> <photos dir>
"""
import os
import sys

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rbvsr_export as R   # noqa: E402

SIZES = [(640, 360), (360, 640)]   # low-res W×H (the picture comes out 4× bigger)
FRAMES = 12


class Warp(nn.Module):
    """flow_warp with the pixel grid as constants (the same result, no Range ops)."""
    def __init__(self, h, w, padding="zeros"):
        super().__init__()
        gy, gx = torch.meshgrid(torch.arange(h, dtype=torch.float32), torch.arange(w, dtype=torch.float32), indexing="ij")
        self.register_buffer("gx", (2.0 * gx / max(w - 1, 1) - 1.0)[None])
        self.register_buffer("gy", (2.0 * gy / max(h - 1, 1) - 1.0)[None])
        self.sx = 2.0 / max(w - 1, 1); self.sy = 2.0 / max(h - 1, 1)
        self.padding = padding

    def forward(self, x, flow):
        grid = torch.stack((self.gx + flow[:, 0] * self.sx, self.gy + flow[:, 1] * self.sy), dim=3)
        return F.grid_sample(x, grid, mode="bilinear", padding_mode=self.padding, align_corners=True)


class Flow(nn.Module):
    """SPyNet at a fixed size, with constant grids at each of its 6 levels."""
    def __init__(self, spy, h, w):
        super().__init__()
        self.spy = spy
        self.h, self.w = h, w
        self.hu = h if h % 32 == 0 else 32 * (h // 32 + 1)
        self.wu = w if w % 32 == 0 else 32 * (w // 32 + 1)
        self.warps = nn.ModuleList([Warp(self.hu >> (5 - lv), self.wu >> (5 - lv), "border") for lv in range(6)])

    def forward(self, a, b):
        s = self.spy
        a = F.interpolate(a, size=(self.hu, self.wu), mode="bilinear", align_corners=False)
        b = F.interpolate(b, size=(self.hu, self.wu), mode="bilinear", align_corners=False)
        ra = [(a - s.mean) / s.std]; rb = [(b - s.mean) / s.std]
        for _ in range(5):
            ra.append(F.avg_pool2d(ra[-1], 2, 2)); rb.append(F.avg_pool2d(rb[-1], 2, 2))
        ra = ra[::-1]; rb = rb[::-1]
        flow = torch.zeros(1, 2, self.hu // 32, self.wu // 32)
        for lv in range(6):
            up = flow if lv == 0 else F.interpolate(flow, scale_factor=2, mode="bilinear", align_corners=True) * 2.0
            flow = up + s.basic_module[lv](torch.cat([ra[lv], self.warps[lv](rb[lv], up), up], 1))
        flow = F.interpolate(flow, size=(self.h, self.w), mode="bilinear", align_corners=False)
        return torch.cat([flow[:, :1] * (self.w / self.wu), flow[:, 1:] * (self.h / self.hu)], 1)


class Clean(nn.Module):
    def __init__(self, net):
        super().__init__(); self.c = net.image_cleaning

    def forward(self, lr):
        return lr + self.c(lr)


class Back(nn.Module):
    def __init__(self, bv, h, w):
        super().__init__(); self.r = bv.backward_resblocks; self.warp = Warp(h, w)

    def forward(self, lrc, prop, flow):
        return self.r(torch.cat([lrc, self.warp(prop, flow)], 1))


class Fwd(nn.Module):
    def __init__(self, bv, h, w):
        super().__init__(); self.bv = bv; self.warp = Warp(h, w)

    def forward(self, lrc, prop, flow, back):
        feat = self.bv.forward_resblocks(torch.cat([lrc, self.warp(prop, flow)], 1))
        return feat, self.bv.upsample(back, feat, lrc).clamp(0, 1)


def clip_frames(photo, w, h, n=FRAMES, crf=34):
    """A slow pan over a photo at w×h, compressed hard (H.264), decoded back."""
    out = f"/tmp/rbclip_{os.path.basename(photo)}_{w}x{h}.mp4"
    frames = R.make_clip(photo, out, w=w, h=h, frames=n, crf=crf)
    return [torch.from_numpy(f).float().div(255).permute(2, 0, 1)[None] for f in frames]


def main():
    pth, out, photos = sys.argv[1:4]
    os.makedirs(out, exist_ok=True)
    R.check_pickle(pth)
    sd = torch.load(pth, map_location="cpu", weights_only=True); sd = sd.get("state_dict", sd)
    net = R.RealBasicVSR().eval()
    net.load_state_dict({k[10:]: v for k, v in sd.items() if k.startswith("generator.")}, strict=True)
    bv = net.basicvsr
    files = sorted(os.path.join(r, f) for r, _, fs in os.walk(photos) for f in fs if f.lower().endswith(".png"))
    torch.set_num_threads(os.cpu_count() or 4)
    import onnx
    import onnxruntime as ort
    names = []
    for (W, H) in SIZES:
        tag = f"_{W}x{H}"
        parts = {"rb_clean": Clean(net).eval(), "rb_flow": Flow(bv.spynet, H, W).eval(),
                 "rb_back": Back(bv, H, W).eval(), "rb_fwd": Fwd(bv, H, W).eval()}
        calib = {k: [] for k in parts}
        # the float model, step by step like the phone, on 3 clips; every part's inputs kept
        with torch.no_grad():
            for f in files[:3]:
                lrs = clip_frames(f, W, H)
                lrc = [parts["rb_clean"](x) for x in lrs]
                for x in lrs[::3]: calib["rb_clean"].append((x,))
                T = len(lrc)
                fb = [parts["rb_flow"](lrc[k], lrc[k + 1]) for k in range(T - 1)]
                ff = [parts["rb_flow"](lrc[k + 1], lrc[k]) for k in range(T - 1)]
                for k in range(0, T - 1, 3): calib["rb_flow"].append((lrc[k], lrc[k + 1])); calib["rb_flow"].append((lrc[k + 1], lrc[k]))
                feats = [None] * T
                prop = torch.zeros(1, 64, H, W); zero = torch.zeros(1, 2, H, W)
                for i in range(T - 1, -1, -1):
                    fl = fb[i] if i < T - 1 else zero
                    if i % 3 == 0: calib["rb_back"].append((lrc[i], prop, fl))
                    prop = parts["rb_back"](lrc[i], prop, fl); feats[i] = prop
                prop = torch.zeros(1, 64, H, W)
                outs = []
                for i in range(T):
                    fl = ff[i - 1] if i > 0 else zero
                    if i % 3 == 1: calib["rb_fwd"].append((lrc[i], prop, fl, feats[i]))
                    prop, img = parts["rb_fwd"](lrc[i], prop, fl, feats[i])
                    outs.append(img)
                # the split version must give the network's own result
                ref = net.basicvsr(torch.stack([c[0] for c in lrc])[None])[0].clamp(0, 1)
                d = max(float((outs[i][0] - ref[i]).abs().max()) for i in range(T))
                print(f"{os.path.basename(f)} {W}×{H}: piezas contra la red entera, diferencia máxima {d:.5f}", flush=True)
                if d > 1e-3:
                    raise SystemExit("las piezas no dan lo mismo que la red")
        for n, m in parts.items():
            name = n + tag
            ins = {"rb_clean": ["lr"], "rb_flow": ["a", "b"], "rb_back": ["lrc", "prop", "flow"], "rb_fwd": ["lrc", "prop", "flow", "back"]}[n]
            outs_ = {"rb_clean": ["lrc"], "rb_flow": ["flow"], "rb_back": ["feat"], "rb_fwd": ["feat", "img"]}[n]
            cdir = os.path.join(out, f"calib_{name}"); os.makedirs(cdir, exist_ok=True)
            lines = []
            for j, sample in enumerate(calib[n]):
                parts_ = []
                for iname, t in zip(ins, sample):
                    p = os.path.join(cdir, f"{j:02d}_{iname}.raw")
                    t.numpy().astype(np.float32).tofile(p)
                    parts_.append(f"{iname}:={os.path.abspath(p)}")
                lines.append(" ".join(parts_))
            open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")
            dst = os.path.join(out, name + ".onnx")
            x = calib[n][0]
            with torch.no_grad():
                ref = m(*x)
                torch.onnx.export(m, x, dst, input_names=ins, output_names=outs_, opset_version=17, do_constant_folding=True)
            onnx.checker.check_model(dst)
            got = ort.InferenceSession(dst, providers=["CPUExecutionProvider"]).run(None, {k: v.numpy() for k, v in zip(ins, x)})
            refs = ref if isinstance(ref, tuple) else (ref,)
            d = max(float(np.abs(g - r.numpy()).max()) for g, r in zip(got, refs))
            print(f"{name}: ONNX contra PyTorch {d:.5f} · {len(calib[n])} muestras de calibración · {os.path.getsize(dst) / 1e6:.1f} MB", flush=True)
            names.append(name)
    open(os.path.join(out, "rb_parts.txt"), "w").write("\n".join(names) + "\n")
    print("listo:", names, flush=True)


if __name__ == "__main__":
    main()
