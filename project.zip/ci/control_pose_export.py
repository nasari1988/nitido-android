"""
Pose ControlNet for SDXL (xinsir/controlnet-openpose-sdxl-1.0, Apache-2.0) for the phone's NPU.

Only the part that feeds the UNet's skip connections is exported: time/text embedding, conv_in, the
pose image's encoder, the down blocks and their zero convolutions -> d0..d8 (added by the app to the
UNet's s0..s8). The mid block is left out: the phone's UNet has no place to add it (its part 2 runs
the mid block and the first up layers together), and the down residuals carry most of the pose.

Calibration without running the whole SDXL (it does not fit next to the ControlNet in the server's
memory): real photos encoded by the SDXL VAE, noised to the steps an edit uses; real prompts read by
SDXL's text encoders (guided and free); pose skeletons drawn the way the app draws them.

usage: control_pose_export.py <controlnet dir> <sdxl base dir> <photos dir> <out> <W> <H>
-> <out>/control_pose[_WxH].onnx (+.data), calib_control_pose[_WxH]/list.txt
"""
import glob
import math
import os
import sys

import numpy as np
import torch
from PIL import Image, ImageDraw

cn_dir, base_dir, photos, out, W, H = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5]), int(sys.argv[6])
TAG = "" if (W, H) == (1024, 1024) else f"_{W}x{H}"
NAME = "control_pose" + TAG
os.makedirs(out, exist_ok=True)
torch.set_grad_enabled(False)

# ---- the pose drawing (the same as the app's PoseImage.kt; xinsir's thicker lines) ----
LIMBS = [(2, 3), (2, 6), (3, 4), (4, 5), (6, 7), (7, 8), (2, 9), (9, 10), (10, 11), (2, 12), (12, 13),
         (13, 14), (2, 1), (1, 15), (15, 17), (1, 16), (16, 18)]
COLORS = [(255, 0, 0), (255, 85, 0), (255, 170, 0), (255, 255, 0), (170, 255, 0), (85, 255, 0), (0, 255, 0),
          (0, 255, 85), (0, 255, 170), (0, 255, 255), (0, 170, 255), (0, 85, 255), (0, 0, 255), (85, 0, 255),
          (170, 0, 255), (255, 0, 255), (255, 0, 170), (255, 0, 85)]


def draw_pose(kps, w, h):
    """kps: 18 (x, y) in 0..1 or None (OpenPose order). Black picture, coloured limbs and joints."""
    img = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(img)
    ratio = 1.0 if max(w, h) < 500 else 2.0 if max(w, h) < 1000 else 3.0
    stick = 4 * ratio
    for (a, b), c in zip(LIMBS, COLORS):
        p, q = kps[a - 1], kps[b - 1]
        if p is None or q is None:
            continue
        x1, y1, x2, y2 = p[0] * w, p[1] * h, q[0] * w, q[1] * h
        L = math.hypot(x2 - x1, y2 - y1) / 2
        ang = math.atan2(y2 - y1, x2 - x1)
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        pts = []
        for k in range(36):
            t = 2 * math.pi * k / 36
            ex, ey = L * math.cos(t), stick * math.sin(t)
            pts.append((mx + ex * math.cos(ang) - ey * math.sin(ang), my + ex * math.sin(ang) + ey * math.cos(ang)))
        d.polygon(pts, fill=tuple(int(v * 0.6) for v in c))
    for p, c in zip(kps, COLORS):
        if p is None:
            continue
        r = 4 * ratio
        d.ellipse([p[0] * w - r, p[1] * h - r, p[0] * w + r, p[1] * h + r], fill=c)
    return img


# a few everyday poses (nose, neck, r-shoulder, r-elbow, r-wrist, l-shoulder, l-elbow, l-wrist, r-hip,
# r-knee, r-ankle, l-hip, l-knee, l-ankle, r-eye, l-eye, r-ear, l-ear), x/y in 0..1
POSES = [
    [(.50, .14), (.50, .24), (.40, .25), (.36, .40), (.35, .54), (.60, .25), (.64, .40), (.65, .54), (.44, .52),
     (.43, .71), (.43, .90), (.56, .52), (.57, .71), (.57, .90), (.48, .12), (.52, .12), (.45, .13), (.55, .13)],
    [(.48, .16), (.49, .26), (.39, .27), (.30, .18), (.27, .07), (.59, .27), (.66, .38), (.70, .50), (.43, .55),
     (.40, .73), (.38, .92), (.55, .55), (.58, .73), (.60, .92), (.46, .14), (.50, .14), None, (.53, .15)],
    [(.52, .20), (.51, .30), (.42, .31), (.40, .46), (.47, .56), (.60, .31), (.63, .46), (.56, .56), (.44, .60),
     (.30, .64), (.32, .86), (.56, .60), (.44, .66), (.47, .88), (.50, .18), (.54, .18), (.47, .19), None],
    [(.55, .15), (.53, .25), (.45, .26), (.44, .40), (.50, .50), (.61, .25), (.66, .38), (.72, .46), (.47, .53),
     (.52, .70), (.47, .89), (.58, .53), (.62, .70), (.70, .86), (.53, .13), (.57, .13), None, (.60, .14)],
]

print(f"ControlNet de pose · {W}x{H}", flush=True)
from diffusers import AutoencoderKL, ControlNetModel, EulerDiscreteScheduler
from transformers import CLIPTextModel, CLIPTextModelWithProjection, CLIPTokenizer

# ---- calibration inputs ----
tok1 = CLIPTokenizer.from_pretrained(base_dir, subfolder="tokenizer")
tok2 = CLIPTokenizer.from_pretrained(base_dir, subfolder="tokenizer_2")
te1 = CLIPTextModel.from_pretrained(base_dir, subfolder="text_encoder", torch_dtype=torch.float32).eval()
te2 = CLIPTextModelWithProjection.from_pretrained(base_dir, subfolder="text_encoder_2", torch_dtype=torch.float32).eval()


def encode(text):
    ids1 = tok1(text, padding="max_length", max_length=77, truncation=True, return_tensors="pt").input_ids
    ids2 = tok2(text, padding="max_length", max_length=77, truncation=True, return_tensors="pt").input_ids
    o1 = te1(ids1, output_hidden_states=True)
    o2 = te2(ids2, output_hidden_states=True)
    ehs = torch.cat([o1.hidden_states[-2], o2.hidden_states[-2]], -1)
    return ehs.float(), o2.text_embeds.float()


prompts = ["sportswear, photo, realistic, natural light, highly detailed, sharp focus",
           "red evening dress, photo, realistic, natural light, highly detailed",
           "denim jacket and jeans, photo, realistic, highly detailed, sharp focus",
           "summer floral dress, photo, realistic, natural light, sharp focus"]
neg = "blurry, deformed, bad anatomy, extra limbs, worst quality, low quality"
texts = [encode(p) for p in prompts]
free = encode(neg)
del te1, te2
vae = AutoencoderKL.from_pretrained(base_dir, subfolder="vae", torch_dtype=torch.float32).eval()
sched = EulerDiscreteScheduler.from_pretrained(base_dir, subfolder="scheduler")
ab = sched.alphas_cumprod
files = sorted(glob.glob(os.path.join(photos, "*.png")) + glob.glob(os.path.join(photos, "*.jpg")))[:4]
latents = []
for f in files:
    im = Image.open(f).convert("RGB")
    k = max(W / im.width, H / im.height)
    im = im.resize((max(W, round(im.width * k)), max(H, round(im.height * k))), Image.LANCZOS)
    l, t = (im.width - W) // 2, (im.height - H) // 2
    im = im.crop((l, t, l + W, t + H))
    x = torch.from_numpy(np.asarray(im).astype(np.float32) / 127.5 - 1).permute(2, 0, 1)[None]
    latents.append(vae.encode(x).latent_dist.mean * vae.config.scaling_factor)
del vae
print("fotos codificadas:", len(latents), flush=True)
time_ids = torch.tensor([[H, W, 0, 0, H, W]], dtype=torch.float32)
gen = torch.Generator().manual_seed(7)
steps = [874, 749, 624, 499, 374, 249]
samples = []
for i, x0 in enumerate(latents):
    for j, ts in enumerate(steps[i % 2::2]):
        a = ab[ts]
        eps = torch.randn(x0.shape, generator=gen)
        xt = (a.sqrt() * x0 + (1 - a).sqrt() * eps).float()
        ehs, pooled = free if (i + j) % 2 else texts[i % len(texts)]
        cond = draw_pose(POSES[(i + j) % len(POSES)], W, H)
        c = torch.from_numpy(np.asarray(cond).astype(np.float32) / 255).permute(2, 0, 1)[None]
        samples.append({"sample": xt, "timestep": torch.tensor([float(ts)]), "encoder_hidden_states": ehs,
                        "text_embeds": pooled, "time_ids": time_ids, "controlnet_cond": c})
draw_pose(POSES[0], W, H).save(os.path.join(out, f"pose_example{TAG}.png"))
print("muestras de calibración:", len(samples), flush=True)

# ---- the model and the part the phone uses ----
cn = ControlNetModel.from_pretrained(cn_dir, torch_dtype=torch.float32).eval()
print("ControlNet:", sum(p.numel() for p in cn.parameters()) / 1e9, "mil millones de pesos", flush=True)


class Down(torch.nn.Module):
    def __init__(self, c):
        super().__init__()
        self.c = c

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids, controlnet_cond):
        c = self.c
        t_emb = c.time_proj(timestep.reshape(-1)).to(sample.dtype)
        emb = c.time_embedding(t_emb)
        te = c.add_time_proj(time_ids.flatten()).reshape((text_embeds.shape[0], -1))
        emb = emb + c.add_embedding(torch.cat([text_embeds, te], -1))
        h = c.conv_in(sample) + c.controlnet_cond_embedding(controlnet_cond)
        res = (h,)
        for blk in c.down_blocks:
            if getattr(blk, "has_cross_attention", False):
                h, r = blk(hidden_states=h, temb=emb, encoder_hidden_states=encoder_hidden_states)
            else:
                h, r = blk(hidden_states=h, temb=emb)
            res += r
        return tuple(z(r) for r, z in zip(res, c.controlnet_down_blocks))


m = Down(cn).eval()
INS = ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids", "controlnet_cond"]
OUTS = [f"d{i}" for i in range(9)]
x = samples[0]
mine = m(*[x[n] for n in INS])
ref, _mid = cn(x["sample"], x["timestep"], encoder_hidden_states=x["encoder_hidden_states"], controlnet_cond=x["controlnet_cond"],
               added_cond_kwargs={"text_embeds": x["text_embeds"], "time_ids": x["time_ids"]}, return_dict=False)
diff = max(float((a - b).abs().max()) for a, b in zip(mine, ref))
print(f"parte de bajada contra el ControlNet completo: diferencia máxima {diff:.6f}", flush=True)
if len(mine) != 9 or diff > 1e-3:
    raise SystemExit("La parte exportada no da lo mismo que el ControlNet; no se publica nada")
for i, r in enumerate(mine):
    print(f"  d{i}: {list(r.shape)} · desv. {float(r.std()):.4f}", flush=True)

cdir = os.path.join(out, "calib_" + NAME)
os.makedirs(cdir, exist_ok=True)
lines = []
for k, s in enumerate(samples):
    items = []
    for n in INS:
        f = os.path.join(cdir, f"{k:02d}_{n}.raw")
        s[n].numpy().astype(np.float32).tofile(f)
        items.append(f"{n}:={os.path.abspath(f)}")
    lines.append(" ".join(items))
open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")

import onnx
tmp = os.path.join(out, "tmp_" + NAME)
os.makedirs(tmp, exist_ok=True)
torch.onnx.export(m, tuple(x[n] for n in INS), os.path.join(tmp, "m.onnx"), input_names=INS, output_names=OUTS,
                  opset_version=17, do_constant_folding=True)
del cn, m
mo = onnx.load(os.path.join(tmp, "m.onnx"), load_external_data=True)
n = sum(int(np.prod(t.dims)) for t in mo.graph.initializer)
onnx.save(mo, os.path.join(out, NAME + ".onnx"), save_as_external_data=True, all_tensors_to_one_file=True, location=NAME + ".onnx.data")
import shutil
shutil.rmtree(tmp, ignore_errors=True)
print(f"{NAME}: {n / 1e9:.2f} mil millones de pesos exportados", flush=True)

# a reference for the app's self-test: inputs and the expected outputs' mean and spread
import json
ref_in = {nm: x[nm].numpy().astype(np.float32).ravel().tolist()[:0] for nm in INS}
stats = {o: {"mean": float(r.mean()), "std": float(r.std()), "shape": list(r.shape)} for o, r in zip(OUTS, mine)}
json.dump({"size": [W, H], "outputs": stats}, open(os.path.join(out, NAME + "_ref.json"), "w"))
