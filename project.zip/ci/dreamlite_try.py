"""
DreamLite (ByteDance, 2026; weights CC BY-NC 4.0) on the server, before porting it to the phone:
edits the sample photos with a few instructions so its quality can be judged by eye.
Uses the released diffusers library (pinned) and the safetensors weights (no pickles) at a fixed commit.

usage: dreamlite_try.py <model dir> <photos dir> <out dir>
"""
import os, sys, time
import torch
from PIL import Image, ImageDraw
from diffusers import DreamLiteMobilePipeline

model, photos, out = sys.argv[1:4]
os.makedirs(out, exist_ok=True)
torch.set_num_threads(os.cpu_count() or 4)
t0 = time.time()
pipe = DreamLiteMobilePipeline.from_pretrained(model, torch_dtype=torch.float32)
print(f"cargado en {time.time() - t0:.0f} s", flush=True)

EDITS = [
    ("a.png", "give him a red baseball cap"),
    ("b.png", "make it winter with snow falling"),
    ("c.png", "change his clothes to a blue suit"),
    ("e.png", "make the umbrella yellow"),
    ("g.png", "change the pink flowers to white daisies"),
    ("h.png", "make him smile"),
]

def fit(im, long=1024):
    k = long / max(im.size)
    w = max(16, int(im.width * k) // 16 * 16); h = max(16, int(im.height * k) // 16 * 16)
    return im.resize((w, h), Image.LANCZOS)

for f, prompt in EDITS:
    src = fit(Image.open(os.path.join(photos, f)).convert("RGB"))
    t = time.time()
    g = torch.Generator().manual_seed(7)
    res = pipe(prompt=prompt, image=src, num_inference_steps=4, generator=g).images[0]
    dt = time.time() - t
    print(f"{f}: «{prompt}» → {res.size} en {dt:.0f} s (CPU del servidor)", flush=True)
    res = res.resize(src.size)
    sheet = Image.new("RGB", (src.width * 2 + 10, src.height + 40), "white")
    sheet.paste(src, (0, 40)); sheet.paste(res, (src.width + 10, 40))
    d = ImageDraw.Draw(sheet)
    d.text((8, 12), "original", fill="black"); d.text((src.width + 18, 12), f"DreamLite: {prompt}", fill="black")
    sheet.save(os.path.join(out, f"dreamlite_{os.path.splitext(f)[0]}.jpg"), quality=90)
