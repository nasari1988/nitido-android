"""
NPU (Qualcomm Hexagon) version of a model's UNet.

The phone runs it with ONNX Runtime's QNN execution provider, which compiles it for the exact NPU
of the phone the first time (and keeps the result). Here we only:
  1. export the UNet to ONNX (height/width free; the app fixes them per format),
  2. store its weights in 16 bits; the NPU computes in fp16.
(Quantizing to 8 bits needs a calibration pass that doesn't fit in the CI runner's memory.)

Output: out/unet_npu.onnx + out/unet_npu.onnx.data, plus info.txt (npu=1).
"""
import gc
import os
import shutil

import numpy as np
import torch

PROMPTS = [
    "portrait photo of a woman in a garden, natural light, detailed skin",
    "an old man smiling, close-up, film photo",
    "a city street at night with neon lights, rain, cinematic",
    "a mountain lake at sunrise, landscape photography",
    "a cute dog sitting on a sofa, indoor photo",
    "a bowl of fruit on a wooden table, still life",
]
NEG = "blurry, lowres, bad anatomy, watermark"


def run(pipe, arch, in_ch, out, steps=8):
    sdxl = arch == "sdxl"
    sizes = [(1024, 1024), (832, 1216), (1216, 832)] if sdxl else [(512, 512), (512, 768), (768, 512)]
    if sdxl:
        s0 = {"sample": np.random.randn(2, in_ch, 128, 128).astype(np.float32),
              "timestep": np.array([500], dtype=np.int32),
              "encoder_hidden_states": np.random.randn(2, 77, 2048).astype(np.float32),
              "text_embeds": np.random.randn(2, 1280).astype(np.float32),
              "time_ids": np.array([[1024., 1024., 0., 0., 1024., 1024.]] * 2, dtype=np.float32)}
    else:
        s0 = {"sample": np.random.randn(2, in_ch, 64, 64).astype(np.float32),
              "timestep": np.array([500], dtype=np.int32),
              "encoder_hidden_states": np.random.randn(2, 77, 768).astype(np.float32)}
    samples = [s0]

    # ---- export (fp32, free height/width) ----
    class Unet(torch.nn.Module):
        def __init__(self, u):
            super().__init__()
            self.u = u

        def forward(self, sample, timestep, encoder_hidden_states):
            return self.u(sample, timestep, encoder_hidden_states, return_dict=False)[0]

    class UnetXL(torch.nn.Module):
        def __init__(self, u):
            super().__init__()
            self.u = u

        def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids):
            return self.u(sample, timestep, encoder_hidden_states,
                          added_cond_kwargs={"text_embeds": text_embeds, "time_ids": time_ids}, return_dict=False)[0]

    tmp = os.path.join(out, "npu_fp32")
    os.makedirs(tmp, exist_ok=True)
    fp32 = os.path.join(tmp, "unet.onnx")
    spatial = {"sample": {2: "h", 3: "w"}, "out_sample": {2: "h", 3: "w"}}
    s0 = samples[0]
    if sdxl:
        mod = UnetXL(pipe.unet)
        args = tuple(torch.from_numpy(s0[k]) for k in ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"])
        names = ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"]
    else:
        mod = Unet(pipe.unet)
        args = tuple(torch.from_numpy(s0[k]) for k in ["sample", "timestep", "encoder_hidden_states"])
        names = ["sample", "timestep", "encoder_hidden_states"]
    with torch.no_grad():
        torch.onnx.export(mod.eval(), args, fp32, input_names=names, output_names=["out_sample"],
                          opset_version=17, do_constant_folding=True, dynamic_axes=spatial)
    pipe.unet = None
    del mod
    gc.collect()
    print("UNet exportada", flush=True)

    # gather the scattered external weight files into one, so the quantizer handles them well
    import onnx
    m = onnx.load(fp32, load_external_data=True)
    for f in os.listdir(tmp):
        os.remove(os.path.join(tmp, f))
    onnx.save(m, fp32, save_as_external_data=True, all_tensors_to_one_file=True, location="unet.onnx.data")
    del m
    gc.collect()

    # ---- 16-bit weights for the NPU (it computes in fp16; inputs/outputs stay fp32) ----
    from onnxconverter_common import float16
    m = onnx.load(fp32, load_external_data=True)
    m16 = float16.convert_float_to_float16(m, keep_io_types=True, disable_shape_infer=True)
    del m
    gc.collect()
    dst = os.path.join(out, "unet_npu.onnx")
    onnx.save(m16, dst, save_as_external_data=True, all_tensors_to_one_file=True, location="unet_npu.onnx.data")
    del m16
    shutil.rmtree(tmp, ignore_errors=True)
    print("archivos:", sorted(os.listdir(out)), flush=True)

    with open(os.path.join(out, "info.txt"), "a") as fh:
        fh.write("npu=1\n")
        fh.write("npu_precision=fp16\n")
        fh.write("npu_sizes=%s\n" % ",".join(f"{w}x{hh}" for w, hh in sizes))
    print("NPU listo", flush=True)
