"""
NPU (Qualcomm Hexagon) version of a model's UNet.

For each NPU size (square, vertical, horizontal): calibration samples from real generations and
the UNet exported to ONNX (fp32, fixed size). ci/npu_qnn.sh then quantizes (W8A16) and compiles
each one for the phone's NPU with Qualcomm's kit.

Output: out/unet_npu{tag}.onnx(+.data), out/calib{tag}/, out/npu_list.txt, info.txt (npu=1).
"""
import gc
import os
import shutil

import numpy as np
import torch

PROMPTS = [
    "portrait photo of a woman in a garden, natural light, detailed skin",
    "an old man smiling, close-up, film photo",
    "a city street at night with neon lights, rain, cinematic",
    "a mountain lake at sunrise, landscape photography",
    "a cute dog sitting on a sofa, indoor photo",
    "a bowl of fruit on a wooden table, still life",
]
NEG = "blurry, lowres, bad anatomy, watermark"


# NPU sizes (width, height) -> file tag. The square keeps the original names (older app versions).
SD_SIZES = [(512, 512, ""), (512, 768, "_512x768"), (768, 512, "_768x512")]


def calibrate(pipe, w, h, n, cdir):
    """Real UNet inputs while generating a few pictures at this size (for the 8/16-bit integers)."""
    calls = []

    def hook(_m, args, kwargs):
        smp = kwargs.get("sample", args[0] if args else None)
        t = kwargs.get("timestep", args[1] if len(args) > 1 else None)
        e = kwargs.get("encoder_hidden_states", args[2] if len(args) > 2 else None)
        calls.append({"sample": smp.detach().float().numpy().copy(),
                      "timestep": np.array([float(t.reshape(-1)[0])], dtype=np.float32),
                      "encoder_hidden_states": e.detach().float().numpy().copy()})
    hk = pipe.unet.register_forward_pre_hook(hook, with_kwargs=True)
    finals = []
    prompts = ["portrait photo of a woman in a garden, natural light", "an old man smiling, film photo",
               "city street at night, neon lights, rain", "mountain lake at sunrise, landscape",
               "a dog on a sofa, indoor photo", "red dress, full body, outdoor fashion photo"]
    base = pipe.scheduler.config
    with torch.no_grad():
        for i, pr in enumerate(prompts):
            # half "trailing" (starts at t=999 like the app), half "leading" (ends near t=1): the
            # integers then cover the whole schedule
            sp = "trailing" if i % 2 == 0 else "leading"
            pipe.scheduler = type(pipe.scheduler).from_config(base, timestep_spacing=sp)
            print(f"calibración {w}x{h} {i + 1}/{len(prompts)}", flush=True)
            r = pipe(pr, negative_prompt="blurry, lowres", width=w, height=h, num_inference_steps=10,
                     guidance_scale=7.0, generator=torch.Generator().manual_seed(100 + i), output_type="latent")
            # the finished picture's latent: calibration for the VAE decoder on the NPU
            finals.append((r.images / pipe.vae.config.scaling_factor).detach().float().numpy().copy())
    hk.remove()
    pipe.scheduler = type(pipe.scheduler).from_config(base)
    # n samples spread over the timesteps, including the first (t=999) and the last: Qualcomm's
    # quantizer keeps every layer's activations per sample (attention maps ~1-2 GB each)
    order = sorted(range(len(calls)), key=lambda k: calls[k]["timestep"][0])
    pick = sorted({order[int(round(x))] for x in np.linspace(0, len(order) - 1, n)})
    print("pasos de calibración:", [float(calls[k]["timestep"][0]) for k in pick], flush=True)
    os.makedirs(cdir, exist_ok=True)
    lines = []
    for j, k in enumerate(pick):
        parts = []
        for key in ["sample", "timestep", "encoder_hidden_states"]:
            f = os.path.join(cdir, f"{j:03d}_{key}.raw")
            calls[k][key].astype(np.float32).tofile(f)
            parts.append(f"{key}:={os.path.abspath(f)}")
        lines.append(" ".join(parts))
    open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")
    return finals


def vae_decoder(pipe, w, h, tag, finals, out):
    """The VAE decoder at this size for the NPU (fixed size, fp32: the server quantizes it to W8A16),
    with the finished pictures' latents as calibration. Out: vae_npu{tag}.onnx + calib_vae{tag}/."""
    if os.environ.get("NPU_VAE", "1") != "1":
        return

    class Dec(torch.nn.Module):
        def __init__(self, v):
            super().__init__()
            self.v = v

        def forward(self, latent_sample):
            return self.v.decode(latent_sample, return_dict=False)[0]

    dst = os.path.join(out, f"vae_npu{tag}.onnx")
    z = torch.from_numpy(finals[0])
    with torch.no_grad():
        ref = pipe.vae.decode(z, return_dict=False)[0]
        torch.onnx.export(Dec(pipe.vae).float().eval(), (z,), dst, input_names=["latent_sample"], output_names=["sample"],
                          opset_version=17, do_constant_folding=True)
    import onnxruntime as ort
    y = ort.InferenceSession(dst, providers=["CPUExecutionProvider"]).run(None, {"latent_sample": finals[0]})[0]
    print(f"VAE {w}x{h}: salida {y.shape}, diferencia con PyTorch {float(np.abs(y - ref.numpy()).max()):.4f}", flush=True)
    cdir = os.path.join(out, "calib_vae" + tag)
    os.makedirs(cdir, exist_ok=True)
    lines = []
    # 4 pictures: the quantizer keeps every layer of every sample in memory (the decoder's are big)
    for j, f in enumerate(finals[:4]):
        p = os.path.join(cdir, f"{j:03d}_latent_sample.raw")
        f.astype(np.float32).tofile(p)
        lines.append(f"latent_sample:={os.path.abspath(p)}")
    open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")


def run(pipe, arch, in_ch, out, steps=8):
    if arch == "sdxl":
        raise SystemExit("NPU: por ahora solo modelos SD 1.5")

    class Unet(torch.nn.Module):
        def __init__(self, u):
            super().__init__()
            self.u = u

        def forward(self, sample, timestep, encoder_hidden_states):
            # timestep comes as float (NPU inputs are quantized from float)
            return self.u(sample, timestep, encoder_hidden_states, return_dict=False)[0]

    import onnx
    only = os.environ.get("NPU_SIZES", "")   # e.g. "512x768" to make just some sizes
    sizes = [s for s in SD_SIZES if not only or f"{s[0]}x{s[1]}" in only.split(",")]
    todo = []
    for w, h, tag in sizes:
        # rectangles have 1.5x the tokens: their attention maps are 2.25x bigger, so fewer samples fit
        finals = calibrate(pipe, w, h, 8 if w == h else 5, os.path.join(out, "calib" + tag))
        vae_decoder(pipe, w, h, tag, finals, out)
        tmp = os.path.join(out, "npu_fp32")
        os.makedirs(tmp, exist_ok=True)
        fp32 = os.path.join(tmp, "unet.onnx")
        args = (torch.randn(2, in_ch, h // 8, w // 8), torch.tensor([500.0]), torch.randn(2, 77, 768))
        with torch.no_grad():
            torch.onnx.export(Unet(pipe.unet).eval(), args, fp32, input_names=["sample", "timestep", "encoder_hidden_states"],
                              output_names=["out_sample"], opset_version=17, do_constant_folding=True)
        # one weights file next to the model; fp32 (Qualcomm's quantizer makes the integers)
        m = onnx.load(fp32, load_external_data=True)
        dst = os.path.join(out, f"unet_npu{tag}.onnx")
        onnx.save(m, dst, save_as_external_data=True, all_tensors_to_one_file=True, location=f"unet_npu{tag}.onnx.data")
        del m
        gc.collect()
        shutil.rmtree(tmp, ignore_errors=True)
        check(dst, in_ch, h // 8, w // 8)
        todo.append(f"{tag or '-'} {w} {h}")
        print("UNet exportada", w, h, flush=True)
    open(os.path.join(out, "npu_list.txt"), "w").write("\n".join(todo) + "\n")
    print("archivos:", sorted(os.listdir(out)), flush=True)
    with open(os.path.join(out, "info.txt"), "a") as fh:
        fh.write("npu=1\n")
        fh.write("npu_precision=w8a16\n")
        fh.write("npu_sizes=%s\n" % ",".join(f"{w}x{h}" for w, h, _ in sizes))
    print("NPU listo", flush=True)


# Inputs that ONNX requires in float32 even inside an fp16 model.
FP32_INPUTS = {"Resize": (1, 2), "Upsample": (1,), "Range": (), "ConstantOfShape": ()}


def fix_fp32_params(m):
    """The fp16 converter also turns Resize's roi/scales constants into fp16, which is invalid."""
    import onnx
    from onnx import numpy_helper
    producers = {o: n for n in m.graph.node for o in n.output}
    inits = {t.name: t for t in m.graph.initializer}
    fixed = 0
    for n in m.graph.node:
        for i in FP32_INPUTS.get(n.op_type, ()):
            if i >= len(n.input) or not n.input[i]:
                continue
            name = n.input[i]
            if name in inits and inits[name].data_type == onnx.TensorProto.FLOAT16:
                arr = numpy_helper.to_array(inits[name]).astype(np.float32)
                inits[name].CopyFrom(numpy_helper.from_array(arr, name))
                fixed += 1
                continue
            p = producers.get(name)
            if p is None:
                continue
            if p.op_type == "Constant":
                for a in p.attribute:
                    if a.name == "value" and a.t.data_type == onnx.TensorProto.FLOAT16:
                        arr = numpy_helper.to_array(a.t).astype(np.float32)
                        a.t.CopyFrom(numpy_helper.from_array(arr, a.t.name))
                        fixed += 1
            elif p.op_type == "Cast":
                for a in p.attribute:
                    if a.name == "to" and a.i == onnx.TensorProto.FLOAT16:
                        a.i = onnx.TensorProto.FLOAT
                        fixed += 1
    print("parámetros devueltos a fp32:", fixed, flush=True)


def check(path, in_ch, h, w):
    """Load and run the model once on the CPU, so a broken file is never published."""
    import onnxruntime as ort
    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    sess = ort.InferenceSession(path, so, providers=["CPUExecutionProvider"])
    feeds = {"sample": np.random.randn(2, in_ch, h, w).astype(np.float32),
             "timestep": np.array([500.0], dtype=np.float32),
             "encoder_hidden_states": np.random.randn(2, 77, 768).astype(np.float32)}
    out = sess.run(None, feeds)[0]
    if out.shape != (2, 4, h, w) or not np.isfinite(out).all():
        raise SystemExit(f"La UNet para NPU no pasó la prueba: forma {out.shape}, finitos={np.isfinite(out).all()}")
    print("prueba en CPU correcta:", out.shape, float(np.abs(out).mean()), flush=True)
    del sess
    gc.collect()
