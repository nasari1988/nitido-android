"""
NPU (Qualcomm Hexagon) version of a model's UNet.

The phone runs it with ONNX Runtime's QNN execution provider, which compiles it for the exact NPU
of the phone the first time (and keeps the result). Here we only:
  1. record real UNet inputs while generating a few pictures (calibration),
  2. export the UNet to ONNX (height/width free; the app fixes them per format),
  3. quantize it to the NPU's format: 8-bit weights, 16-bit activations (QDQ).

Output: out/unet_npu.onnx + out/unet_npu.onnx.data, plus info.txt (npu=1).
"""
import gc
import os
import shutil

import numpy as np
import torch

PROMPTS = [
    "portrait photo of a woman in a garden, natural light, detailed skin",
    "an old man smiling, close-up, film photo",
    "a city street at night with neon lights, rain, cinematic",
    "a mountain lake at sunrise, landscape photography",
    "a cute dog sitting on a sofa, indoor photo",
    "a bowl of fruit on a wooden table, still life",
]
NEG = "blurry, lowres, bad anatomy, watermark"


def run(pipe, arch, in_ch, out, steps=8):
    sdxl = arch == "sdxl"
    sizes = [(1024, 1024), (832, 1216)] if sdxl else [(512, 512), (512, 768), (768, 512)]
    samples = []

    def hook(_mod, args, kwargs):
        sample = kwargs.get("sample", args[0] if args else None)
        t = kwargs.get("timestep", args[1] if len(args) > 1 else None)
        emb = kwargs.get("encoder_hidden_states", args[2] if len(args) > 2 else None)
        d = {
            "sample": sample.detach().float().numpy().copy(),
            "timestep": np.array([int(float(t.reshape(-1)[0]))], dtype=np.int32),
            "encoder_hidden_states": emb.detach().float().numpy().copy(),
        }
        if sdxl:
            ac = kwargs["added_cond_kwargs"]
            d["text_embeds"] = ac["text_embeds"].detach().float().numpy().copy()
            d["time_ids"] = ac["time_ids"].detach().float().numpy().copy()
        # keep a few steps per picture, spread over the schedule
        samples.append(d)

    h = pipe.unet.register_forward_pre_hook(hook, with_kwargs=True)
    n_pics = 3 if sdxl else 4
    with torch.no_grad():
        for i in range(n_pics):
            w, hh = sizes[i % len(sizes)]
            g = torch.Generator().manual_seed(1000 + i)
            print(f"calibración {i + 1}/{n_pics}: {w}x{hh}", flush=True)
            pipe(PROMPTS[i % len(PROMPTS)], negative_prompt=NEG, width=w, height=hh,
                 num_inference_steps=steps, guidance_scale=7.0 if not sdxl else 5.0,
                 generator=g, output_type="latent")
    h.remove()
    # every 2nd step is plenty and keeps memory down
    samples = samples[::2]
    print("muestras de calibración:", len(samples), flush=True)

    # ---- export (fp32, free height/width) ----
    class Unet(torch.nn.Module):
        def __init__(self, u):
            super().__init__()
            self.u = u

        def forward(self, sample, timestep, encoder_hidden_states):
            return self.u(sample, timestep, encoder_hidden_states, return_dict=False)[0]

    class UnetXL(torch.nn.Module):
        def __init__(self, u):
            super().__init__()
            self.u = u

        def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids):
            return self.u(sample, timestep, encoder_hidden_states,
                          added_cond_kwargs={"text_embeds": text_embeds, "time_ids": time_ids}, return_dict=False)[0]

    tmp = os.path.join(out, "npu_fp32")
    os.makedirs(tmp, exist_ok=True)
    fp32 = os.path.join(tmp, "unet.onnx")
    spatial = {"sample": {2: "h", 3: "w"}, "out_sample": {2: "h", 3: "w"}}
    s0 = samples[0]
    if sdxl:
        mod = UnetXL(pipe.unet)
        args = tuple(torch.from_numpy(s0[k]) for k in ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"])
        names = ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"]
    else:
        mod = Unet(pipe.unet)
        args = tuple(torch.from_numpy(s0[k]) for k in ["sample", "timestep", "encoder_hidden_states"])
        names = ["sample", "timestep", "encoder_hidden_states"]
    with torch.no_grad():
        torch.onnx.export(mod.eval(), args, fp32, input_names=names, output_names=["out_sample"],
                          opset_version=17, do_constant_folding=True, dynamic_axes=spatial)
    pipe.unet = None
    del mod
    gc.collect()
    print("UNet exportada", flush=True)

    # gather the scattered external weight files into one, so the quantizer handles them well
    import onnx
    m = onnx.load(fp32, load_external_data=True)
    for f in os.listdir(tmp):
        os.remove(os.path.join(tmp, f))
    onnx.save(m, fp32, save_as_external_data=True, all_tensors_to_one_file=True, location="unet.onnx.data")
    del m
    gc.collect()

    # ---- quantize for the NPU (W8A16 QDQ) ----
    from onnxruntime.quantization import CalibrationDataReader, QuantType, quantize
    from onnxruntime.quantization.execution_providers.qnn import get_qnn_qdq_config, qnn_preprocess_model

    pre = os.path.join(tmp, "unet_pre.onnx")
    changed = qnn_preprocess_model(fp32, pre, save_as_external_data=True, all_tensors_to_one_file=True,
                                   external_data_location="unet_pre.onnx.data")
    src = pre if changed else fp32
    print("preprocesado:", changed, flush=True)

    class Reader(CalibrationDataReader):
        def __init__(self, data):
            self.it = iter(data)

        def get_next(self):
            return next(self.it, None)

    cfg = get_qnn_qdq_config(src, Reader(samples), activation_type=QuantType.QUInt16,
                             weight_type=QuantType.QUInt8, per_channel=False)
    cfg.use_external_data_format = True
    # don't keep every layer's outputs for all samples in memory: fold them in one sample at a time
    cfg.extra_options = dict(cfg.extra_options or {})
    cfg.extra_options["CalibMaxIntermediateOutputs"] = 1
    dst = os.path.join(out, "unet_npu.onnx")
    quantize(src, dst, cfg)
    shutil.rmtree(tmp, ignore_errors=True)
    # the quantizer names the weight file after the model; make sure it's the expected one
    print("archivos:", sorted(os.listdir(out)), flush=True)

    with open(os.path.join(out, "info.txt"), "a") as fh:
        fh.write("npu=1\n")
        fh.write("npu_sizes=%s\n" % ",".join(f"{w}x{hh}" for w, hh in sizes))
    print("NPU listo", flush=True)
