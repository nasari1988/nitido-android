"""
Integer ranges of the square NPU UNet, made reusable for another picture size.

The quantizer dumps them before applying the NPU's own rules (for example, the inputs of 16-bit
MatMuls must be symmetric), so handing them back as they are breaks the compile. The ranges that
touch those layers are left out: the quantizer recomputes them (with its rules) from the size's
own calibration samples, and everything else keeps the square's well-sampled ranges.
usage: npu_overrides.py <square encodings.json> <model.onnx> <out.json>
"""
import json
import sys

import onnx

src, model, out = sys.argv[1:4]
enc = json.load(open(src))
m = onnx.load(model, load_external_data=False)
skip = set()
for n in m.graph.node:
    if n.op_type in ("MatMul", "Gemm", "Einsum"):
        skip.update(i for i in n.input if i)
        skip.update(n.output)
    if n.op_type in ("Softmax", "LayerNormalization", "InstanceNormalization", "GroupNormalization"):
        skip.update(n.output)
act = enc.get("activation_encodings", {})
kept = {k: v for k, v in act.items() if k not in skip}
enc["activation_encodings"] = kept
json.dump(enc, open(out, "w"))
print(f"rangos del cuadro: {len(kept)} de {len(act)} activaciones (sin {len(act) - len(kept)} ligadas a MatMul/normalización)")
