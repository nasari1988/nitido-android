#!/usr/bin/env bash
# Compiles the restoration models Colorear (rest_color) and Rayones (rest_lama) for the phone's NPU,
# like the UNet: ONNX -> DLC -> W8A16 (8-bit weights, 16-bit activations; this NPU has no fp16)
# -> HTP context binary + a tiny EPContext ONNX that ONNX Runtime's QNN provider loads.
#   out/<name>.npu.bin, out/<name>.npu_ctx.onnx, out/<name>.npu_ctx.onnx.json (scale/offset of in/out)
# usage: ci/npu_restore.sh   (after export_restore.py wrote onnx/<name>.onnx)
set -uo pipefail
cd "$(dirname "$0")/.."

echo "::group::Fotos de calibración"
.venv/bin/pip install --quiet scikit-image || true
.venv/bin/python ci/npu_calib_restore.py onnx || { echo "::warning::sin fotos de calibración: sin versión NPU"; exit 0; }
echo "::endgroup::"

source ci/qnn_sdk.sh || { echo "::warning::sin kit de Qualcomm: sin versión NPU"; exit 0; }
mkdir -p qnn/f out

# (rest_color also compiles, but on this NPU it took 7 s against 3.8 s on the CPU: not published)
for n in ${NPU_RESTORE_MODELS:-rest_lama}; do
  [ -e "onnx/$n.onnx" ] && [ -e "onnx/calib_$n/list.txt" ] || continue
  echo "::group::$n para la NPU"
  ok=1
  cat > qnn/htp_config_$n.json <<EOF
{
  "graphs": [{ "graph_names": ["$n"], "O": 3, "vtcm_mb": 0 }],
  "devices": [{ "dsp_arch": "$DSP_ARCH", "cores": [{ "core_id": 0, "perf_profile": "burst", "rpc_control_latency": 100 }] }]
}
EOF
  cat > qnn/htp_ext_$n.json <<EOF
{ "backend_extensions": { "shared_library_path": "$LIB/libQnnHtpNetRunExtensions.so", "config_file_path": "$PWD/qnn/htp_config_$n.json" } }
EOF
  # MatMuls between two activations need a symmetric range on their second input (HTP rule)
  OVR=()
  if .venv/bin/python ci/npu_matmul_sym.py "onnx/$n.onnx" "onnx/calib_$n/list.txt" "qnn/sym_$n.json"; then
    OVR=(--quantization_overrides "qnn/sym_$n.json")
  fi
  "$PY" "$BIN/qairt-converter" --input_network "onnx/$n.onnx" --output_path "qnn/f/$n.dlc" "${OVR[@]}" || ok=0
  [ $ok = 1 ] && { "$PY" "$BIN/qairt-quantizer" --input_dlc "qnn/f/$n.dlc" --input_list "onnx/calib_$n/list.txt" \
      --output_dlc "qnn/$n.dlc" --act_bitwidth 16 --weights_bitwidth 8 --bias_bitwidth 32 --use_per_channel_quantization || ok=0; }
  [ $ok = 1 ] && { "$BIN/qnn-context-binary-generator" --backend "$LIB/libQnnHtp.so" --model "$LIB/libQnnModelDlc.so" \
      --dlc_path "qnn/$n.dlc" --binary_file "$n.npu" --output_dir out --config_file "qnn/htp_ext_$n.json" || ok=0; }
  if [ $ok = 1 ]; then
    "$BIN/qnn-context-binary-utility" --context_binary "out/$n.npu.bin" --json_file "qnn/ctx_$n.json"
    "$PY" ci/npu_epctx.py "qnn/ctx_$n.json" "out/$n.npu_ctx.onnx" "$n.npu.bin" "$QV" || ok=0
  fi
  if [ $ok = 1 ]; then ls -la out/$n.npu*; else echo "::warning::$n no se pudo compilar para la NPU"; rm -f out/$n.npu*; fi
  rm -f "qnn/f/$n.dlc" "qnn/$n.dlc"
  echo "::endgroup::"
done
exit 0
