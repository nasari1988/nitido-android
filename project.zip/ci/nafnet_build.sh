#!/usr/bin/env bash
# Restaurar › Enfocar and Quitar ruido on the NPU: NAFNet width 32 (GoPro: blur, SIDD: noise),
# in ./out as rest_deblur.npu.* and rest_denoise.npu.* for the restoration pack.
# No secrets; the weights come from a Hugging Face copy of the authors' files, sha256 fixed (the same
# hashes on two independent copies), checked before loading.
set -euo pipefail
cd "$(dirname "$0")/.."
BASE=https://huggingface.co/nyanko7/nafnet-models/resolve/08e8c701eb662688cccda3bf3074e90e902bcd3b
mkdir -p dl
curl -fsSL --retry 3 -o dl/nafnet_gopro32.pth "$BASE/NAFNet-GoPro-width32.pth"
curl -fsSL --retry 3 -o dl/nafnet_sidd32.pth "$BASE/NAFNet-SIDD-width32.pth"
sha256sum -c - <<SUMS || { echo "::error::los pesos no son los archivos revisados"; exit 1; }
19394e6155d12ef6371d1d57496f87f0ec88f92bdffa27c0792690722d5d1a5c  dl/nafnet_gopro32.pth
89c70e808d1783b6c07911306e106aaf0d4f7f3da8c61078b99ff7f8929a26f4  dl/nafnet_sidd32.pth
SUMS

echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "onnx==1.17.0" "onnxruntime==1.22.0" "numpy<2" pillow
echo "::endgroup::"

echo "::group::NAFNet: revisar pesos, probar con fotos y exportar"
rm -rf onnx out; mkdir -p onnx out
.venv/bin/python -I ci/nafnet_export.py dl/nafnet_gopro32.pth dl/nafnet_sidd32.pth onnx ci/testdata/old
cp onnx/check_*.jpg out/ 2>/dev/null || true
echo "::endgroup::"

NPU_RESTORE_MODELS="rest_deblur rest_denoise" bash ci/npu_restore.sh
for n in rest_deblur rest_denoise; do
  for s in npu.bin npu_ctx.onnx npu_ctx.onnx.json; do
    [ -s "out/$n.$s" ] || { echo "::error::falta out/$n.$s"; exit 1; }
  done
done
ls -la out
