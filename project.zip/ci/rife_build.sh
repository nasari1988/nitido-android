#!/usr/bin/env bash
# "Más fluido": RIFE 4.25 for the app (float ONNX for the CPU + W8A16 for the NPU), in ./out.
# Runs without any secret: it only reads rife/flownet.pkl (checked, fixed sha256) from the repo.
set -euo pipefail
cd "$(dirname "$0")/.."
PKL=rife/flownet.pkl
SHA=6615790efd627772917205db291f51cd392528a157ecbb2ecaeec3bff8eb6de2
echo "$SHA  $PKL" | sha256sum -c - || { echo "::error::flownet.pkl no es el archivo revisado"; exit 1; }

echo "::group::Python"
source ci/venv.sh
# torch 2.6 or newer: weights_only=True of earlier versions could be bypassed (CVE-2025-32434)
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "onnx==1.17.0" "onnxruntime==1.22.0" "numpy<2"
echo "::endgroup::"

echo "::group::Exportar RIFE"
rm -rf onnx out; mkdir -p onnx out
.venv/bin/python ci/rife_export.py "$PKL" onnx
cp onnx/rife_*.onnx out/
echo "::endgroup::"

source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
for n in $(cat onnx/rife_sizes.txt); do
  echo "::group::$n para la NPU"
  if NPU_SYM=0 bash ci/npu_build.sh "$n" "onnx/$n.onnx" "onnx/calib_$n/list.txt"; then
    echo "$n: NPU lista"
  else
    echo "::warning::$n no compiló para la NPU (la app usará la CPU)"
    rm -f "out/$n.bin" "out/${n}_ctx.onnx" "out/${n}_ctx.onnx.json"
  fi
  echo "::endgroup::"
done
printf "mode=fluido\nversion=1\nmodel=rife-4.25\nsizes=%s\n" "$(paste -sd, onnx/rife_sizes.txt)" > out/info.txt
(cd out && for f in *; do [ "$f" = files.txt ] || echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
