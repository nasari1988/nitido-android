#!/usr/bin/env bash
# Caras con OSDFace for the phone's NPU, in ./out: osd_vq and osd_unet (the VAE pieces are Realismo's,
# already on the phone) and osd_codebook.bin. No keys or tokens. The authors' weights come from their
# Google Drive folder, are checked against fixed sha256 (ci/osdface.sha256) and turned into
# safetensors without network; from then on only safetensors are read.
set -euo pipefail
cd "$(dirname "$0")/.."
OSD_COMMIT=36114e227583d9ec06be047dede166112327e696   # jkwang28/OSDFace, the code that goes with the weights

echo "::group::Memoria extra (swap)"
SWAPDIR=/mnt; [ -w /mnt ] || SWAPDIR=/
sudo fallocate -l 24G "$SWAPDIR/swapfile_nitido" && sudo chmod 600 "$SWAPDIR/swapfile_nitido" && sudo mkswap "$SWAPDIR/swapfile_nitido" && sudo swapon "$SWAPDIR/swapfile_nitido" || true
echo "::endgroup::"
echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.30.3" "transformers==4.44.2" "huggingface_hub==0.25.2" "accelerate==0.34.2" \
  "safetensors==0.4.5" "onnx==1.17.0" "onnxruntime==1.22.0" "numpy<2" "pillow" "opencv-python-headless==4.10.0.84" "gdown==5.2.0"
echo "::endgroup::"

echo "::group::Código de OSDFace ($OSD_COMMIT)"
rm -rf osdface_code
git clone -q https://github.com/jkwang28/OSDFace osdface_code
git -C osdface_code checkout -q "$OSD_COMMIT"
echo "::endgroup::"

echo "::group::Pesos de OSDFace"
rm -rf dl/osdface; mkdir -p dl/osdface
.venv/bin/python ci/osdface_get.py fetch dl/osdface
ls -la dl/osdface
# the check and the conversion run with no network at all (the pickle files are only read)
if sudo -n true 2>/dev/null && command -v unshare >/dev/null; then
  sudo unshare -n -- "$PWD/.venv/bin/python" ci/osdface_get.py convert dl/osdface
  sudo chown -R "$(id -u):$(id -g)" dl/osdface
else
  .venv/bin/python ci/osdface_get.py convert dl/osdface
fi
ls -la dl/osdface
echo "::endgroup::"

echo "::group::Exportar OSDFace"
rm -rf onnx out; mkdir -p onnx out
.venv/bin/python ci/osdface_export.py osdface_code dl/osdface onnx ci/testdata
echo "::endgroup::"

source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
for n in $(cat onnx/osd_parts.txt); do
  echo "::group::$n para la NPU"
  SYM=1; [ "$n" = osd_unet ] && SYM=0
  NPU_SYM=$SYM NPU_PER_ROW=1 bash ci/npu_build.sh "$n" "onnx/$n.onnx" "onnx/calib_$n/list.txt" \
    || { echo "::error::$n no compiló para la NPU"; exit 1; }
  rm -f "onnx/$n.onnx" "onnx/$n.onnx.data"
  echo "::endgroup::"
done
cp onnx/osd_codebook.bin out/
for f in onnx/check/*.jpg; do cp "$f" "out/check_$(basename "$f")"; done
printf "mode=caras\nversion=1\nmodel=osdface\nnpu=1\ntile=512\nuses=pisa_enc,pisa_dec\nlicense=OSDFace Non-Commercial Academic Research License 1.0\n" > out/info.txt
(cd out && for f in *; do case "$f" in files.txt|check_*) continue ;; esac; echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
