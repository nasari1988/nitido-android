"""
Calibration pictures for the restoration models' NPU versions (W8A16 needs real-looking inputs to
pick its integer ranges). Uses the sample photos that come with scikit-image, prepared exactly as
the app prepares its input.
  rest_color: [1,3,512,512] gray (Lab L with a = b = 0, back in sRGB), 0..1
  rest_lama:  [1,4,512,512] RGB 0..1 + mask (1 = to fill) of random strokes and spots
usage: npu_calib_restore.py <onnx dir>   -> <onnx dir>/calib_<name>/list.txt + .raw files
"""
import os
import sys

import numpy as np
import onnx
from skimage import color, data, transform

out = sys.argv[1]
NAMES = ["astronaut", "coffee", "chelsea", "rocket", "cat", "immunohistochemistry", "hubble_deep_field", "retina",
         "camera", "brick", "grass", "gravel"]
rng = np.random.default_rng(7)


def photos():
    for n in NAMES:
        try:
            im = getattr(data, n)()
        except Exception as e:  # noqa: BLE001
            print("sin foto", n, e)
            continue
        if im.ndim == 2:
            im = np.stack([im] * 3, -1)
        im = im[..., :3].astype(np.float32)
        if im.max() > 1.5:
            im /= 255.0
        h, w = im.shape[:2]
        s = min(h, w)
        y0 = (h - s) // 2; x0 = (w - s) // 2
        yield n, transform.resize(im[y0:y0 + s, x0:x0 + s], (512, 512), anti_aliasing=True).astype(np.float32)


def gray(im):
    lab = color.rgb2lab(im)
    lab[..., 1:] = 0
    return np.clip(color.lab2rgb(lab), 0, 1).astype(np.float32)


def strokes():
    m = np.zeros((512, 512), np.float32)
    yy, xx = np.mgrid[0:512, 0:512]
    for _ in range(rng.integers(3, 9)):
        # a thin scratch: a line of random width
        x1, y1, x2, y2 = rng.integers(0, 512, 4)
        wdt = rng.integers(2, 10)
        d = np.abs((y2 - y1) * xx - (x2 - x1) * yy + x2 * y1 - y2 * x1) / max(1.0, np.hypot(y2 - y1, x2 - x1))
        inside = (np.minimum(x1, x2) - wdt <= xx) & (xx <= np.maximum(x1, x2) + wdt) & \
                 (np.minimum(y1, y2) - wdt <= yy) & (yy <= np.maximum(y1, y2) + wdt)
        m[(d < wdt) & inside] = 1
    for _ in range(rng.integers(1, 5)):
        cx, cy, r = rng.integers(0, 512), rng.integers(0, 512), rng.integers(5, 40)
        m[(xx - cx) ** 2 + (yy - cy) ** 2 < r * r] = 1
    return m


def write(name, samples):
    d = os.path.join(out, "calib_" + name)
    os.makedirs(d, exist_ok=True)
    inp = onnx.load(os.path.join(out, name + ".onnx"), load_external_data=False).graph.input[0].name
    lines = []
    for i, x in enumerate(samples):
        f = os.path.join(d, f"{i:02d}.raw")
        x.astype(np.float32).tofile(f)
        lines.append(f"{inp}:={os.path.abspath(f)}")
    open(os.path.join(d, "list.txt"), "w").write("\n".join(lines) + "\n")
    print(name, len(lines), "muestras, entrada", inp)


pics = list(photos())
print("fotos:", [n for n, _ in pics])
if os.path.exists(os.path.join(out, "rest_color.onnx")):
    write("rest_color", [gray(im).transpose(2, 0, 1)[None] for _, im in pics[:8]])
if os.path.exists(os.path.join(out, "rest_lama.onnx")):
    write("rest_lama", [np.concatenate([im.transpose(2, 0, 1), strokes()[None]], 0)[None] for _, im in pics[:8]])
