"""
Calibration pictures for the restoration models' NPU versions (W8A16 needs real-looking inputs to
pick its integer ranges). Uses the sample photos that come with scikit-image, prepared exactly as
the app prepares its input.
  rest_color: [1,3,512,512] gray (Lab L with a = b = 0, back in sRGB), 0..1
  rest_lama:  [1,4,512,512] RGB 0..1 + mask (1 = to fill) of random strokes and spots
  rest_denoise / rest_deblur: [1,3,256,256] RGB 0..1 pieces (with grain / out of focus, as old photos)
  rest_faces: [1,4,512,512] RGB -1..1 + fidelity weight (0.3..1) as 4th channel
usage: npu_calib_restore.py <onnx dir>   -> <onnx dir>/calib_<name>/list.txt + .raw files
"""
import os
import sys

import numpy as np
import onnx
from skimage import color, data, filters, transform

out = sys.argv[1]
NAMES = ["astronaut", "coffee", "chelsea", "rocket", "cat", "immunohistochemistry", "hubble_deep_field", "retina",
         "camera", "brick", "grass", "gravel"]
rng = np.random.default_rng(7)


def photos():
    for n in NAMES:
        try:
            im = getattr(data, n)()
        except Exception as e:  # noqa: BLE001
            print("sin foto", n, e)
            continue
        if im.ndim == 2:
            im = np.stack([im] * 3, -1)
        im = im[..., :3].astype(np.float32)
        if im.max() > 1.5:
            im /= 255.0
        h, w = im.shape[:2]
        s = min(h, w)
        y0 = (h - s) // 2; x0 = (w - s) // 2
        yield n, transform.resize(im[y0:y0 + s, x0:x0 + s], (512, 512), anti_aliasing=True).astype(np.float32)


def gray(im):
    lab = color.rgb2lab(im)
    lab[..., 1:] = 0
    return np.clip(color.lab2rgb(lab), 0, 1).astype(np.float32)


def strokes():
    m = np.zeros((512, 512), np.float32)
    yy, xx = np.mgrid[0:512, 0:512]
    for _ in range(rng.integers(3, 9)):
        # a thin scratch: a line of random width
        x1, y1, x2, y2 = rng.integers(0, 512, 4)
        wdt = rng.integers(2, 10)
        d = np.abs((y2 - y1) * xx - (x2 - x1) * yy + x2 * y1 - y2 * x1) / max(1.0, np.hypot(y2 - y1, x2 - x1))
        inside = (np.minimum(x1, x2) - wdt <= xx) & (xx <= np.maximum(x1, x2) + wdt) & \
                 (np.minimum(y1, y2) - wdt <= yy) & (yy <= np.maximum(y1, y2) + wdt)
        m[(d < wdt) & inside] = 1
    for _ in range(rng.integers(1, 5)):
        cx, cy, r = rng.integers(0, 512), rng.integers(0, 512), rng.integers(5, 40)
        m[(xx - cx) ** 2 + (yy - cy) ** 2 < r * r] = 1
    return m


def write(name, samples):
    d = os.path.join(out, "calib_" + name)
    os.makedirs(d, exist_ok=True)
    inp = onnx.load(os.path.join(out, name + ".onnx"), load_external_data=False).graph.input[0].name
    lines = []
    for i, x in enumerate(samples):
        f = os.path.join(d, f"{i:02d}.raw")
        x.astype(np.float32).tofile(f)
        lines.append(f"{inp}:={os.path.abspath(f)}")
    open(os.path.join(d, "list.txt"), "w").write("\n".join(lines) + "\n")
    print(name, len(lines), "muestras, entrada", inp)


pics = list(photos())
print("fotos:", [n for n, _ in pics])
if os.path.exists(os.path.join(out, "rest_color.onnx")):
    write("rest_color", [gray(im).transpose(2, 0, 1)[None] for _, im in pics[:8]])
if os.path.exists(os.path.join(out, "rest_lama.onnx")):
    # old photos are mostly sepia or black and white, with big stains: calibrate on those too
    def sepia(im):
        g = gray(im)[..., :1]
        return np.clip(np.concatenate([g * 1.07, g * 0.93, g * 0.74], -1) + 0.03, 0, 1).astype(np.float32)

    def stains():
        m = strokes()
        yy, xx = np.mgrid[0:512, 0:512]
        for _ in range(rng.integers(1, 3)):
            cx, cy, r = rng.integers(60, 452), rng.integers(60, 452), rng.integers(40, 90)
            m[(xx - cx) ** 2 + (yy - cy) ** 2 < r * r] = 1
        return m

    looks = [lambda x: x, sepia, gray]
    write("rest_lama", [np.concatenate([looks[i % 3](im).transpose(2, 0, 1), (stains() if i % 2 else strokes())[None]], 0)[None]
                        for i, (_, im) in enumerate(pics[:10])])


def piece(im, k):
    """A 256 piece of the 512 picture (one of the corners or the center)."""
    y, x = [(0, 0), (0, 256), (256, 0), (256, 256), (128, 128)][k % 5]
    return im[y:y + 256, x:x + 256]


def grainy(im):
    return np.clip(im + rng.normal(0, rng.uniform(0.02, 0.08), im.shape), 0, 1).astype(np.float32)


def blurry(im):
    return np.clip(filters.gaussian(im, sigma=rng.uniform(1.0, 3.0), channel_axis=-1), 0, 1).astype(np.float32)


def chw(im):
    return im.transpose(2, 0, 1)[None]


if os.path.exists(os.path.join(out, "rest_denoise.onnx")):
    write("rest_denoise", [chw(grainy(piece(im, i))) for i, (_, im) in enumerate(pics[:8])])
if os.path.exists(os.path.join(out, "rest_deblur.onnx")):
    write("rest_deblur", [chw(blurry(piece(im, i + 2))) for i, (_, im) in enumerate(pics[:5])])
if os.path.exists(os.path.join(out, "rest_faces.onnx")):
    # faces as the app sends them (aligned crop, 512): the astronaut's face at a few sizes and
    # lights, plus two other pictures so the ranges aren't only skin
    face = data.astronaut()[20:240, 140:340].astype(np.float32) / 255.0
    sams = []
    for i, (z, g) in enumerate([(1.0, 1.0), (0.9, 0.8), (1.1, 1.2), (1.0, 0.6), (0.95, 1.0), (1.05, 0.9)]):
        f = transform.resize(face, (512, 512), anti_aliasing=True)
        if z != 1.0:
            c = int(512 * min(z, 1 / z)) // 2 * 2
            o = (512 - c) // 2
            f = transform.resize(f[o:o + c, o:o + c], (512, 512)) if z > 1 else np.pad(transform.resize(f, (c, c)), ((o, 512 - c - o), (o, 512 - c - o), (0, 0)), mode="edge")
        f = np.clip(f ** g, 0, 1)
        if i % 2:
            f = gray(f)
        sams.append(f)
    sams = sams[:5] + [pics[1][1]]
    write("rest_faces", [np.concatenate([chw(f)[0] * 2 - 1, np.full((1, 512, 512), 0.3 + 0.7 * (i % 4) / 3, np.float32)], 0)[None]
                         for i, f in enumerate(sams)])
