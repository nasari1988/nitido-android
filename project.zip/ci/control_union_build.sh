#!/usr/bin/env bash
# ControlNet Union ProMax (pose + depth) for SDXL on the phone's NPU, and the depth reader the phone
# uses to make the depth picture (Editar: the redrawn body keeps its pose and its volume).
#   ci/control_union_build.sh [WxH]      (default 1024x1024)
# -> ./out/control_union[_WxH].bin, _ctx.onnx, _ctx.onnx.json, depth_small.onnx, files.txt
# No secrets. Weights: xinsir/controlnet-union-sdxl-1.0 (ProMax file, Apache-2.0) and
# depth-anything/Depth-Anything-V2-Small-hf (Apache-2.0), fixed revisions and sha256, safetensors only.
# SDXL base 1.0 (fixed revision) gives only the text readers and the VAE for the calibration data.
set -euo pipefail
cd "$(dirname "$0")/.."
SIZE="${1:-1024x1024}"; W="${SIZE%x*}"; H="${SIZE#*x}"
CN_REV=801a4a3fa3d4c936f4feea95b98607bc6726f80c
DEPTH_REV=5426e4f0f36572d16453bbda7a8389317b1bef99
BASE_REV=462165984030d82259a11f4367a4eed129e94a7b
mkdir -p dl/control_union dl/depth_small dl/sdxl_base
CN=https://huggingface.co/xinsir/controlnet-union-sdxl-1.0/resolve/$CN_REV
curl -fsSL --retry 3 -o dl/control_union/config.json "$CN/config_promax.json"
curl -fsSL --retry 3 -o dl/control_union/diffusion_pytorch_model.safetensors "$CN/diffusion_pytorch_model_promax.safetensors"
DP=https://huggingface.co/depth-anything/Depth-Anything-V2-Small-hf/resolve/$DEPTH_REV
curl -fsSL --retry 3 -o dl/depth_small/config.json "$DP/config.json"
curl -fsSL --retry 3 -o dl/depth_small/model.safetensors "$DP/model.safetensors"
sha256sum -c - <<SUMS || { echo "::error::los pesos no son los revisados"; exit 1; }
9fae2e50cb431bfcbe05822b59ec2228df545ef27f711dea8949e9f4ed9f7cdc  dl/control_union/diffusion_pytorch_model.safetensors
3152477ce0d8d6978d76b995120de97cb5b928701fd0f817769f59e249a16b70  dl/depth_small/model.safetensors
SUMS

echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.32.2" "transformers==4.46.3" "huggingface_hub==0.26.5" \
  "onnx==1.16.2" "onnxruntime==1.19.2" "safetensors==0.4.5" "accelerate==1.1.1" "numpy<2" pillow
# SDXL base: only tokenizers, text readers, VAE and scheduler (safetensors), for calibration data
.venv/bin/python -I - "$BASE_REV" <<'PY'
import sys
from huggingface_hub import snapshot_download
snapshot_download("stabilityai/stable-diffusion-xl-base-1.0", revision=sys.argv[1], local_dir="dl/sdxl_base",
                  allow_patterns=["model_index.json", "scheduler/*", "tokenizer/*", "tokenizer_2/*",
                                  "text_encoder/config.json", "text_encoder/model.safetensors",
                                  "text_encoder_2/config.json", "text_encoder_2/model.safetensors",
                                  "vae/config.json", "vae/diffusion_pytorch_model.safetensors"])
PY
echo "::endgroup::"

echo "::group::Exportar ControlNet Union y profundidad ($SIZE)"
rm -rf onnx out; mkdir -p onnx out
free -h | head -2
.venv/bin/python -I ci/control_union_export.py dl/control_union dl/depth_small dl/sdxl_base ci/testdata/old onnx "$W" "$H"
rm -rf dl/sdxl_base
echo "::endgroup::"

TAG=""; [ "$SIZE" = "1024x1024" ] || TAG="_$SIZE"
N="control_union$TAG"
source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
echo "::group::$N para la NPU"
free -h | head -2
NPU_SYM=0 NPU_PER_ROW=1 bash ci/npu_build.sh "$N" "onnx/$N.onnx" "onnx/calib_$N/list.txt" \
  || { echo "::error::$N no compiló para la NPU"; exit 1; }
echo "::endgroup::"
cp onnx/${N}_ref.json onnx/depth_example*.png onnx/depth_small.onnx out/ 2>/dev/null || true
rm -rf out/qnn_runtime
for f in out/*; do
  if [ "$(stat -c %s "$f")" -gt 1900000000 ]; then split -b 1800M -d -a 2 "$f" "$f.split"; rm "$f"; fi
done
(cd out && for f in *; do [ "$f" = files.txt ] || echo "$f $(stat -c %s "$f")"; done > ../files.list && mv ../files.list files.txt)
cat out/files.txt
