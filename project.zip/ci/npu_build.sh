#!/usr/bin/env bash
# One ONNX model -> the phone's NPU (W8A16, like the UNet): DLC, quantized with a calibration list,
# compiled to an HTP context binary, wrapped in an EPContext ONNX for ONNX Runtime's QNN provider.
#   ci/npu_build.sh <name> <model.onnx> <calib list.txt> [extra qairt-quantizer args...]
#   -> out/<name>.bin, out/<name>_ctx.onnx, out/<name>_ctx.onnx.json      (exit 1 if it failed)
# Needs the SDK environment (source ci/qnn_sdk.sh first). The graph is named <name>.
set -uo pipefail
N=$1; M=$2; L=$3; shift 3
mkdir -p qnn/f out
cat > "qnn/htp_config_$N.json" <<EOF
{
  "graphs": [{ "graph_names": ["$N"], "O": 3, "vtcm_mb": 0 }],
  "devices": [{ "dsp_arch": "$DSP_ARCH", "cores": [{ "core_id": 0, "perf_profile": "burst", "rpc_control_latency": 100 }] }]
}
EOF
cat > "qnn/htp_ext_$N.json" <<EOF
{ "backend_extensions": { "shared_library_path": "$LIB/libQnnHtpNetRunExtensions.so", "config_file_path": "$PWD/qnn/htp_config_$N.json" } }
EOF
t0=$(date +%s)
OVR=()
if [ "${NPU_SYM:-1}" = "1" ] && .venv/bin/python ci/npu_matmul_sym.py "$M" "$L" "qnn/sym_$N.json"; then
  OVR=(--quantization_overrides "qnn/sym_$N.json")
fi
"$PY" "$BIN/qairt-converter" --input_network "$M" --output_path "qnn/f/$N.dlc" "${OVR[@]}" || exit 1
echo "$N: convertido en $(( $(date +%s) - t0 )) s"
"$PY" "$BIN/qairt-quantizer" --input_dlc "qnn/f/$N.dlc" --input_list "$L" --output_dlc "qnn/$N.dlc" \
  --act_bitwidth 16 --weights_bitwidth 8 --bias_bitwidth 32 --use_per_channel_quantization "$@" || exit 1
rm -f "qnn/f/$N.dlc"
echo "$N: cuantizado en $(( $(date +%s) - t0 )) s"
if ! "$BIN/qnn-context-binary-generator" --backend "$LIB/libQnnHtp.so" --model "$LIB/libQnnModelDlc.so" \
    --dlc_path "qnn/$N.dlc" --binary_file "$N" --output_dir out --config_file "qnn/htp_ext_$N.json"; then
  echo "reintento $N con optimización 2"
  sed -i 's/"O": 3/"O": 2/' "qnn/htp_config_$N.json"
  "$BIN/qnn-context-binary-generator" --backend "$LIB/libQnnHtp.so" --model "$LIB/libQnnModelDlc.so" \
    --dlc_path "qnn/$N.dlc" --binary_file "$N" --output_dir out --config_file "qnn/htp_ext_$N.json" || exit 1
fi
rm -f "qnn/$N.dlc"
"$BIN/qnn-context-binary-utility" --context_binary "out/$N.bin" --json_file "qnn/ctx_$N.json"
"$PY" ci/npu_epctx.py "qnn/ctx_$N.json" "out/${N}_ctx.onnx" "$N.bin" "$QV" || exit 1
echo "$N: listo en $(( $(date +%s) - t0 )) s ($(du -h "out/$N.bin" | cut -f1))"
ls -la "out/$N"*
