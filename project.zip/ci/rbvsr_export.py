"""
Mejorar video › Limpiar (prueba): RealBasicVSR (Chan et al., CVPR 2022; weights by OpenMMLab).
Step 1, on the computer only: the network rewritten here (no OpenMMLab code is run), the authors'
weights checked and loaded, and a test clip restored, to look at before / after frames and to
know the work per frame before making the phone version.

The weights file is a pickle: it is read without running it and may only name the functions of a
plain state dict; then torch.load(weights_only=True) with torch >= 2.6.

usage: rbvsr_export.py <weights.pth> <out dir> <sample photos dir>
"""
import os
import pickletools
import subprocess
import sys
import time
import zipfile

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

ALLOWED = {("collections", "OrderedDict"), ("torch._utils", "_rebuild_tensor_v2"), ("torch._utils", "_rebuild_parameter"),
           ("torch", "FloatStorage"), ("torch", "LongStorage"), ("torch", "HalfStorage"), ("torch", "IntStorage")}


def check_pickle(path):
    """Every function the pickle would call, without calling any; only a plain state dict may pass.
    Zip format: data.pkl. Legacy format: several pickles in a row (magic, protocol, info, the
    object, the storage keys) followed by raw data; each one is read up to its STOP."""
    import io
    if zipfile.is_zipfile(path):
        z = zipfile.ZipFile(path)
        streams = [(io.BytesIO(z.read(n)), 1) for n in z.namelist() if n.endswith(".pkl")]
    else:
        streams = [(open(path, "rb"), 5)]
    used = set()
    ops = 0
    for f, count in streams:
        for _ in range(count):
            strs = []
            for op, arg, _ in pickletools.genops(f):
                ops += 1
                if op.name in ("SHORT_BINUNICODE", "BINUNICODE", "UNICODE"):
                    strs.append(arg)
                elif op.name == "STACK_GLOBAL":
                    used.add(tuple(strs[-2:]))
                elif op.name == "GLOBAL":
                    used.add(tuple(arg.split(" ", 1)))
                elif op.name in ("INST", "OBJ", "EXT1", "EXT2", "EXT4"):
                    raise SystemExit(f"pesos: instrucción no permitida {op.name}")
    bad = used - ALLOWED
    if bad:
        raise SystemExit(f"pesos: llaman funciones no permitidas {sorted(bad)}")
    if not used:
        raise SystemExit("pesos: no se encontró ninguna función; el archivo no se leyó completo")
    print(f"pesos revisados ({ops} instrucciones): solo", sorted(used), flush=True)


# ───────── the network, written from the paper / OpenMMLab's description ─────────

def flow_warp(x, flow, padding_mode="zeros"):
    """x (n,c,h,w) moved by flow (n,2,h,w) in pixels (x, y); bilinear, align_corners=True."""
    n, _, h, w = x.shape
    gy, gx = torch.meshgrid(torch.arange(h, dtype=x.dtype), torch.arange(w, dtype=x.dtype), indexing="ij")
    fx = gx[None] + flow[:, 0]
    fy = gy[None] + flow[:, 1]
    grid = torch.stack((2.0 * fx / max(w - 1, 1) - 1.0, 2.0 * fy / max(h - 1, 1) - 1.0), dim=3)
    return F.grid_sample(x, grid, mode="bilinear", padding_mode=padding_mode, align_corners=True)


class ResBlock(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.conv1 = nn.Conv2d(c, c, 3, 1, 1)
        self.conv2 = nn.Conv2d(c, c, 3, 1, 1)

    def forward(self, x):
        return x + self.conv2(F.relu(self.conv1(x)))


class ResBlocksIn(nn.Module):
    """conv in→c, LeakyReLU 0.1, n residual blocks (keys main.0 / main.2.k)."""
    def __init__(self, cin, c, n):
        super().__init__()
        self.main = nn.Sequential(nn.Conv2d(cin, c, 3, 1, 1), nn.LeakyReLU(0.1), nn.Sequential(*[ResBlock(c) for _ in range(n)]))

    def forward(self, x):
        return self.main(x)


class ConvAct(nn.Module):
    def __init__(self, cin, cout, act):
        super().__init__()
        self.conv = nn.Conv2d(cin, cout, 7, 1, 3)
        self.act = act

    def forward(self, x):
        x = self.conv(x)
        return F.relu(x) if self.act else x


class SpyLevel(nn.Module):
    def __init__(self):
        super().__init__()
        self.basic_module = nn.Sequential(ConvAct(8, 32, True), ConvAct(32, 64, True), ConvAct(64, 32, True),
                                          ConvAct(32, 16, True), ConvAct(16, 2, False))

    def forward(self, x):
        return self.basic_module(x)


class SPyNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.basic_module = nn.ModuleList([SpyLevel() for _ in range(6)])
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def compute_flow(self, ref, supp):
        n, _, h, w = ref.shape
        ref = [(ref - self.mean) / self.std]
        supp = [(supp - self.mean) / self.std]
        for _ in range(5):
            ref.append(F.avg_pool2d(ref[-1], 2, 2, count_include_pad=False))
            supp.append(F.avg_pool2d(supp[-1], 2, 2, count_include_pad=False))
        ref = ref[::-1]; supp = supp[::-1]
        flow = ref[0].new_zeros(n, 2, h // 32, w // 32)
        for lv in range(len(ref)):
            up = flow if lv == 0 else F.interpolate(flow, scale_factor=2, mode="bilinear", align_corners=True) * 2.0
            flow = up + self.basic_module[lv](torch.cat([ref[lv], flow_warp(supp[lv], up, "border"), up], 1))
        return flow

    def forward(self, ref, supp):
        h, w = ref.shape[2:4]
        wu = w if w % 32 == 0 else 32 * (w // 32 + 1)
        hu = h if h % 32 == 0 else 32 * (h // 32 + 1)
        ref = F.interpolate(ref, size=(hu, wu), mode="bilinear", align_corners=False)
        supp = F.interpolate(supp, size=(hu, wu), mode="bilinear", align_corners=False)
        flow = F.interpolate(self.compute_flow(ref, supp), size=(h, w), mode="bilinear", align_corners=False)
        return torch.stack((flow[:, 0] * (w / wu), flow[:, 1] * (h / hu)), 1)


class PixelShufflePack(nn.Module):
    def __init__(self, cin, cout, s, k):
        super().__init__()
        self.s = s
        self.upsample_conv = nn.Conv2d(cin, cout * s * s, k, 1, (k - 1) // 2)

    def forward(self, x):
        return F.pixel_shuffle(self.upsample_conv(x), self.s)


class BasicVSR(nn.Module):
    def __init__(self, c=64, n=20):
        super().__init__()
        self.spynet = SPyNet()
        self.backward_resblocks = ResBlocksIn(c + 3, c, n)
        self.forward_resblocks = ResBlocksIn(c + 3, c, n)
        self.fusion = nn.Conv2d(2 * c, c, 1, 1, 0)
        self.upsample1 = PixelShufflePack(c, c, 2, 3)
        self.upsample2 = PixelShufflePack(c, 64, 2, 3)
        self.conv_hr = nn.Conv2d(64, 64, 3, 1, 1)
        self.conv_last = nn.Conv2d(64, 3, 3, 1, 1)
        self.c = c

    def upsample(self, back, fwd, lr):
        """One frame's picture from its two features (the phone's last part)."""
        a = lambda x: F.leaky_relu(x, 0.1)
        out = a(self.fusion(torch.cat([back, fwd], 1)))
        out = a(self.upsample1(out))
        out = a(self.upsample2(out))
        out = a(self.conv_hr(out))
        out = self.conv_last(out)
        return out + F.interpolate(lr, scale_factor=4, mode="bilinear", align_corners=False)

    def forward(self, lrs):
        n, t, c, h, w = lrs.shape
        l1 = lrs[:, :-1].reshape(-1, c, h, w); l2 = lrs[:, 1:].reshape(-1, c, h, w)
        # one pair at a time (the same result; all pairs at once needs several GB)
        fb = torch.cat([self.spynet(l1[k:k + 1], l2[k:k + 1]) for k in range(l1.shape[0])]).view(n, t - 1, 2, h, w)
        ff = torch.cat([self.spynet(l2[k:k + 1], l1[k:k + 1]) for k in range(l1.shape[0])]).view(n, t - 1, 2, h, w)
        feats = []
        prop = lrs.new_zeros(n, self.c, h, w)
        for i in range(t - 1, -1, -1):
            if i < t - 1:
                prop = flow_warp(prop, fb[:, i])
            prop = self.backward_resblocks(torch.cat([lrs[:, i], prop], 1))
            feats.append(prop)
        feats = feats[::-1]
        prop = torch.zeros_like(prop)
        outs = []
        for i in range(t):
            if i > 0:
                prop = flow_warp(prop, ff[:, i - 1])
            prop = self.forward_resblocks(torch.cat([lrs[:, i], prop], 1))
            outs.append(self.upsample(feats[i], prop, lrs[:, i]))
        return torch.stack(outs, 1)


class RealBasicVSR(nn.Module):
    def __init__(self):
        super().__init__()
        self.image_cleaning = nn.Sequential(ResBlocksIn(3, 64, 20), nn.Conv2d(64, 3, 3, 1, 1))
        self.basicvsr = BasicVSR(64, 20)

    def clean(self, lqs):
        n, t, c, h, w = lqs.shape
        for k in range(3):   # the authors' dynamic refinement: again while the change is large
            x = lqs.reshape(-1, c, h, w)
            res = self.image_cleaning(x)
            lqs = (x + res).view(n, t, c, h, w)
            m = float(res.abs().mean())
            if m < 1.0:
                break
        return lqs, k + 1, m

    def forward(self, lqs):
        lqs, _, _ = self.clean(lqs)
        return self.basicvsr(lqs)


# ───────── test clips ─────────

def ffmpeg():
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def make_clip(photo, out_mp4, w=640, h=360, frames=16, crf=36):
    """A slow pan over a photo, compressed hard (H.264, like a WhatsApp video)."""
    img = Image.open(photo).convert("RGB")
    k = max(w * 1.6 / img.width, h * 1.2 / img.height)
    img = img.resize((int(img.width * k), int(img.height * k)), Image.BICUBIC)
    tmp = out_mp4 + "_f"
    os.makedirs(tmp, exist_ok=True)
    for i in range(frames):
        x = int((img.width - w) * i / (frames - 1) * 0.5)
        y = int((img.height - h) * 0.3)
        img.crop((x, y, x + w, y + h)).save(f"{tmp}/{i:03d}.png")
    subprocess.run([ffmpeg(), "-loglevel", "error", "-y", "-framerate", "24", "-i", f"{tmp}/%03d.png",
                    "-c:v", "libx264", "-crf", str(crf), "-pix_fmt", "yuv420p", out_mp4], check=True)
    dec = out_mp4 + "_d"
    os.makedirs(dec, exist_ok=True)
    subprocess.run([ffmpeg(), "-loglevel", "error", "-y", "-i", out_mp4, f"{dec}/%03d.png"], check=True)
    return [np.asarray(Image.open(f"{dec}/{f}").convert("RGB")) for f in sorted(os.listdir(dec))]


def main():
    pth, out, photos = sys.argv[1:4]
    os.makedirs(out, exist_ok=True)
    check_pickle(pth)
    ck = torch.load(pth, map_location="cpu", weights_only=True)
    sd = ck.get("state_dict", ck)
    gen = {k[len("generator."):]: v for k, v in sd.items() if k.startswith("generator.")}
    if not gen:
        gen = dict(sd)
    print("claves en el archivo:", len(sd), "· del generador:", len(gen), flush=True)
    net = RealBasicVSR().eval()
    miss, extra = net.load_state_dict(gen, strict=False)
    print("faltan", miss[:8], len(miss), "· sobran", extra[:8], len(extra), flush=True)
    if miss:
        raise SystemExit("faltan pesos: la red no coincide")
    print("parámetros:", sum(p.numel() for p in net.parameters()) / 1e6, "M", flush=True)

    chk = os.path.join(out, "check"); os.makedirs(chk, exist_ok=True)
    files = sorted(os.path.join(r, f) for r, _, fs in os.walk(photos) for f in fs if f.lower().endswith(".png"))[:3]
    torch.set_num_threads(os.cpu_count() or 4)
    for j, f in enumerate(files):
        frames = make_clip(f, os.path.join(out, f"clip{j}.mp4"))
        lq = torch.from_numpy(np.stack(frames)).float().div(255).permute(0, 3, 1, 2)[None]   # 1,t,3,h,w
        t0 = time.time()
        with torch.no_grad():
            cl, rounds, m = net.clean(lq)
            hr = net.basicvsr(cl).clamp(0, 1)
        dt = time.time() - t0
        T, H, W = lq.shape[1], lq.shape[3], lq.shape[4]
        print(f"clip {j}: {T} cuadros {W}×{H} → {W*4}×{H*4} en {dt:.1f} s ({dt / T:.2f} s por cuadro en la CPU) · limpieza {rounds} vuelta(s), cambio medio {m:.3f}", flush=True)
        # the middle frame: input enlarged plainly | RealBasicVSR (both at 1080p, what the app keeps)
        i = T // 2
        a = Image.fromarray(frames[i]).resize((1920, 1080), Image.BICUBIC)
        b = Image.fromarray((hr[0, i].permute(1, 2, 0).numpy() * 255 + 0.5).astype(np.uint8)).resize((1920, 1080), Image.LANCZOS)
        both = Image.new("RGB", (1920, 1080))
        both.paste(a.crop((0, 0, 960, 1080)), (0, 0)); both.paste(b.crop((960, 0, 1920, 1080)), (960, 0))
        both.save(os.path.join(chk, f"rbvsr_{j}_mitad.jpg"), quality=90)
        # a zoomed crop side by side (detail)
        cx, cy = 700, 300
        za = a.crop((cx, cy, cx + 480, cy + 480)).resize((720, 720), Image.NEAREST)
        zb = b.crop((cx, cy, cx + 480, cy + 480)).resize((720, 720), Image.NEAREST)
        z = Image.new("RGB", (1440, 720)); z.paste(za, (0, 0)); z.paste(zb, (720, 0))
        z.save(os.path.join(chk, f"rbvsr_{j}_zoom.jpg"), quality=90)
        # temporal steadiness: mean change between consecutive output frames vs. the input's
        d_in = float(np.mean([np.abs(frames[k + 1].astype(np.float32) - frames[k]).mean() for k in range(T - 1)]))
        o = (hr[0].numpy() * 255)
        d_out = float(np.mean([np.abs(o[k + 1] - o[k]).mean() for k in range(T - 1)]))
        print(f"  cambio entre cuadros: entrada {d_in:.2f} · salida {d_out:.2f} (similar = sin parpadeo extra)", flush=True)
    print("listo", flush=True)


if __name__ == "__main__":
    main()
