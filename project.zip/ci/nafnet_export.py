"""
Restaurar › Enfocar and Quitar ruido for the phone's NPU: NAFNet (Chen et al., "Simple Baselines
for Image Restoration", ECCV 2022; Megvii, MIT license), width 32:
  rest_deblur  <- NAFNet-GoPro-width32 (motion / focus blur)
  rest_denoise <- NAFNet-SIDD-width32  (real camera noise / grain)
The network is written here from the paper (no NAFNet / BasicSR code is run). The weights are
pickles: read first without running them (only the functions of a plain state dict may appear),
then torch.load(weights_only=True) with torch >= 2.6, and loaded strictly (every name and shape
must match this network).

Checks before exporting, on the sample photos: blurring / adding grain and then restoring must get
clearly closer to the original (PSNR up), or the export stops.

Exports [1,3,256,256] RGB 0..1 -> [1,3,256,256] (the app's tile, the size NAFNet was trained on),
as onnx/rest_deblur.onnx and onnx/rest_denoise.onnx, for ci/npu_restore.sh.

usage: nafnet_export.py <GoPro .pth> <SIDD .pth> <out dir> <sample photos dir>
"""
import io
import os
import pickletools
import sys
import zipfile

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

ALLOWED = {("collections", "OrderedDict"), ("torch._utils", "_rebuild_tensor_v2"), ("torch._utils", "_rebuild_parameter"),
           ("torch", "FloatStorage"), ("torch", "LongStorage"), ("torch", "HalfStorage"), ("torch", "IntStorage")}


def check_pickle(path):
    """Every function the pickle would call, without calling any; only a plain state dict may pass."""
    if zipfile.is_zipfile(path):
        z = zipfile.ZipFile(path)
        streams = [(io.BytesIO(z.read(n)), 1) for n in z.namelist() if n.endswith(".pkl")]
    else:
        streams = [(open(path, "rb"), 5)]
    used = set()
    ops = 0
    for f, count in streams:
        for _ in range(count):
            strs = []
            for op, arg, _ in pickletools.genops(f):
                ops += 1
                if op.name in ("SHORT_BINUNICODE", "BINUNICODE", "UNICODE"):
                    strs.append(arg)
                elif op.name == "STACK_GLOBAL":
                    used.add(tuple(strs[-2:]))
                elif op.name == "GLOBAL":
                    used.add(tuple(arg.split(" ", 1)))
                elif op.name in ("INST", "OBJ", "EXT1", "EXT2", "EXT4"):
                    raise SystemExit(f"pesos: instrucción no permitida {op.name}")
    bad = used - ALLOWED
    if bad:
        raise SystemExit(f"pesos: llaman funciones no permitidas {sorted(bad)}")
    if not used:
        raise SystemExit("pesos: no se encontró ninguna función; el archivo no se leyó completo")
    print(f"{os.path.basename(path)} revisado ({ops} instrucciones): solo", sorted(used), flush=True)


# ---------------- the network (from the paper) ----------------

class LayerNorm2d(nn.Module):
    """LayerNorm over the channels of each pixel."""
    def __init__(self, c, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(c))
        self.bias = nn.Parameter(torch.zeros(c))
        self.eps = eps

    def forward(self, x):
        mu = x.mean(1, keepdim=True)
        d = x - mu
        var = (d * d).mean(1, keepdim=True)
        y = d / torch.sqrt(var + self.eps)
        return self.weight.view(1, -1, 1, 1) * y + self.bias.view(1, -1, 1, 1)


class SimpleGate(nn.Module):
    def forward(self, x):
        a, b = x.chunk(2, dim=1)
        return a * b


class NAFBlock(nn.Module):
    def __init__(self, c):
        super().__init__()
        dw = c * 2
        self.conv1 = nn.Conv2d(c, dw, 1)
        self.conv2 = nn.Conv2d(dw, dw, 3, padding=1, groups=dw)
        self.conv3 = nn.Conv2d(dw // 2, c, 1)
        # simplified channel attention: global average, 1×1 conv, multiply
        self.sca = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(dw // 2, dw // 2, 1))
        self.sg = SimpleGate()
        ffn = c * 2
        self.conv4 = nn.Conv2d(c, ffn, 1)
        self.conv5 = nn.Conv2d(ffn // 2, c, 1)
        self.norm1 = LayerNorm2d(c)
        self.norm2 = LayerNorm2d(c)
        self.beta = nn.Parameter(torch.zeros(1, c, 1, 1))
        self.gamma = nn.Parameter(torch.zeros(1, c, 1, 1))

    def forward(self, inp):
        x = self.conv2(self.conv1(self.norm1(inp)))
        x = self.sg(x)
        x = x * self.sca(x)
        y = inp + self.conv3(x) * self.beta
        x = self.conv5(self.sg(self.conv4(self.norm2(y))))
        return y + x * self.gamma


class NAFNet(nn.Module):
    def __init__(self, width, enc, middle, dec):
        super().__init__()
        self.intro = nn.Conv2d(3, width, 3, padding=1)
        self.ending = nn.Conv2d(width, 3, 3, padding=1)
        self.encoders = nn.ModuleList()
        self.decoders = nn.ModuleList()
        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()
        c = width
        for n in enc:
            self.encoders.append(nn.Sequential(*[NAFBlock(c) for _ in range(n)]))
            self.downs.append(nn.Conv2d(c, 2 * c, 2, 2))
            c *= 2
        self.middle_blks = nn.Sequential(*[NAFBlock(c) for _ in range(middle)])
        for n in dec:
            self.ups.append(nn.Sequential(nn.Conv2d(c, c * 2, 1, bias=False), nn.PixelShuffle(2)))
            c //= 2
            self.decoders.append(nn.Sequential(*[NAFBlock(c) for _ in range(n)]))
        self.pad = 2 ** len(enc)

    def forward(self, inp):
        x = self.intro(inp)
        skips = []
        for e, d in zip(self.encoders, self.downs):
            x = e(x)
            skips.append(x)
            x = d(x)
        x = self.middle_blks(x)
        for dcd, up, s in zip(self.decoders, self.ups, skips[::-1]):
            x = dcd(up(x) + s)
        return self.ending(x) + inp


CONFIGS = {
    "rest_deblur": dict(width=32, enc=[1, 1, 1, 28], middle=1, dec=[1, 1, 1, 1]),    # GoPro
    "rest_denoise": dict(width=32, enc=[2, 2, 4, 8], middle=12, dec=[2, 2, 2, 2]),   # SIDD
}


def load(name, path):
    check_pickle(path)
    sd = torch.load(path, map_location="cpu", weights_only=True)
    if isinstance(sd, dict) and "params" in sd:
        sd = sd["params"]
    net = NAFNet(**CONFIGS[name]).eval()
    missing, extra = net.load_state_dict(sd, strict=True), None
    n = sum(p.numel() for p in net.parameters())
    print(f"{name}: {len(sd)} tensores cargados (todos los nombres y tamaños coinciden) · {n / 1e6:.1f} M parámetros", flush=True)
    return net


# ---------------- checks on real photos ----------------

def photos(d):
    out = []
    for f in sorted(os.listdir(d)):
        if f.lower().endswith((".png", ".jpg", ".jpeg")):
            im = np.asarray(Image.open(os.path.join(d, f)).convert("RGB"), np.float32) / 255.0
            h, w = im.shape[:2]
            y, x = (h - 256) // 2, (w - 256) // 2
            if h >= 256 and w >= 256:
                out.append((f, im[y:y + 256, x:x + 256]))
    return out


def psnr(a, b):
    return float(10 * np.log10(1.0 / max(1e-10, np.mean((a - b) ** 2))))


def gauss_blur(im, sigma):
    r = int(3 * sigma + 0.5)
    k = np.exp(-np.arange(-r, r + 1) ** 2 / (2 * sigma * sigma)); k /= k.sum()
    t = torch.from_numpy(im.transpose(2, 0, 1)[None]).float()
    kh = torch.tensor(k, dtype=torch.float32).view(1, 1, 1, -1).repeat(3, 1, 1, 1)
    t = F.conv2d(F.pad(t, (r, r, 0, 0), mode="reflect"), kh, groups=3)
    t = F.conv2d(F.pad(t, (0, 0, r, r), mode="reflect"), kh.transpose(2, 3), groups=3)
    return t[0].numpy().transpose(1, 2, 0)


def motion_blur(im, n):
    t = torch.from_numpy(im.transpose(2, 0, 1)[None]).float()
    k = torch.full((3, 1, 1, n), 1.0 / n)
    t = F.conv2d(F.pad(t, (n // 2, n - 1 - n // 2, 0, 0), mode="reflect"), k, groups=3)
    return t[0].numpy().transpose(1, 2, 0)


def run(net, im):
    with torch.no_grad():
        y = net(torch.from_numpy(im.transpose(2, 0, 1)[None].copy()).float())
    return np.clip(y[0].numpy().transpose(1, 2, 0), 0, 1)


def check(name, net, pics):
    rng = np.random.default_rng(3)
    gains = []
    for f, im in pics:
        if name == "rest_deblur":
            bad = np.clip(motion_blur(im, 9) if len(gains) % 2 else gauss_blur(im, 1.6), 0, 1)
        else:
            bad = np.clip(im + rng.normal(0, 0.06, im.shape), 0, 1).astype(np.float32)
        fixed = run(net, bad.astype(np.float32))
        g = psnr(fixed, im) - psnr(bad, im)
        gains.append(g)
        print(f"  {name} {f}: dañada {psnr(bad, im):.2f} dB → arreglada {psnr(fixed, im):.2f} dB ({g:+.2f})", flush=True)
        Image.fromarray((np.concatenate([bad, fixed, im], 1) * 255 + 0.5).astype(np.uint8)).save(
            os.path.join(OUT, f"check_{name}_{os.path.splitext(f)[0]}.jpg"), quality=90)
    m = float(np.mean(gains))
    print(f"{name}: mejora media {m:+.2f} dB", flush=True)
    if m < 1.0:
        raise SystemExit(f"{name}: no mejora las fotos ({m:+.2f} dB): pesos o red equivocados")


def export(name, net):
    x = torch.rand(1, 3, 256, 256)
    path = os.path.join(OUT, name + ".onnx")
    torch.onnx.export(net, x, path, input_names=["input"], output_names=["output"], opset_version=17, do_constant_folding=True)
    import onnxruntime as ort
    s = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
    a = s.run(None, {"input": x.numpy()})[0]
    with torch.no_grad():
        b = net(x).numpy()
    err = float(np.abs(a - b).max())
    print(f"{name}.onnx: diferencia máx con PyTorch {err:.2e}", flush=True)
    if err > 1e-3:
        raise SystemExit(f"{name}: el ONNX no coincide")


if __name__ == "__main__":
    gopro, sidd, OUT, samples = sys.argv[1:5]
    os.makedirs(OUT, exist_ok=True)
    torch.set_num_threads(os.cpu_count() or 4)
    pics = photos(samples)
    print("fotos de prueba:", [f for f, _ in pics], flush=True)
    for name, path in (("rest_deblur", gopro), ("rest_denoise", sidd)):
        net = load(name, path)
        check(name, net, pics)
        export(name, net)
