#!/usr/bin/env bash
# libc++ for the QAIRT tools when Ubuntu's package servers don't answer: the same packages from
# LLVM's official apt server (apt.llvm.org), unpacked (not installed) into /usr/local/lib.
set -u
ldconfig -p 2>/dev/null | grep -q 'libc++.so.1 ' && { echo "libc++ ya está"; exit 0; }
CODE="$(. /etc/os-release; echo "${VERSION_CODENAME:-noble}")"
BASE="https://apt.llvm.org/$CODE"
IDX="$BASE/dists/llvm-toolchain-$CODE-18/main/binary-amd64/Packages.gz"
T="$(mktemp -d)"
for i in 1 2 3; do curl -fsSL --retry 3 -o "$T/P.gz" "$IDX" && break; echo "apt.llvm.org sin respuesta, reintento $i"; sleep 10; done
[ -s "$T/P.gz" ] || { echo "no se pudo bajar el índice de apt.llvm.org"; exit 1; }
gunzip -c "$T/P.gz" > "$T/P"
for pkg in libc++1-18 libc++abi1-18 libunwind-18; do
  f="$(awk -v p="$pkg" '$1=="Package:"{ok=($2==p)} ok&&$1=="Filename:"{print $2; exit}' "$T/P")"
  sha="$(awk -v p="$pkg" '$1=="Package:"{ok=($2==p)} ok&&$1=="SHA256:"{print $2; exit}' "$T/P")"
  [ -n "$f" ] || { echo "apt.llvm.org no tiene $pkg"; exit 1; }
  curl -fsSL --retry 3 -o "$T/$pkg.deb" "$BASE/$f" || { echo "no se pudo bajar $pkg"; exit 1; }
  echo "$sha  $T/$pkg.deb" | sha256sum -c --quiet || { echo "$pkg: sha256 no coincide"; exit 1; }
  dpkg-deb -x "$T/$pkg.deb" "$T/x"
  echo "  $pkg: $(basename "$f")"
done
# the packages' links are relative (../llvm-18/lib/...): copy the real files they point to
find "$T/x" -name 'lib*.so*' \( -type f -o -type l \) | while read -r f; do
  [ -e "$f" ] && sudo cp -fL "$f" /usr/local/lib/
done
ls -la /usr/local/lib | grep -E 'libc\+\+|libunwind' || true
sudo ldconfig
rm -rf "$T"
ldconfig -p | grep -q 'libc++.so.1 ' && echo "libc++ de apt.llvm.org listo" || { echo "libc++ sigue sin aparecer"; exit 1; }
