#!/usr/bin/env bash
# DreamLite on the server with the sample photos (no secrets): out/dreamlite_*.jpg to look at.
set -euo pipefail
cd "$(dirname "$0")/.."
REV=6695c3f4be230f0493fa5dbf78be3bc4d3bb2ab4   # the repo's "diffusers" branch
B=https://huggingface.co/carlofkl/DreamLite-mobile/resolve/$REV
M=dl/dreamlite-mobile
for f in model_index.json scheduler/scheduler_config.json \
         text_encoder/config.json text_encoder/generation_config.json text_encoder/model.safetensors \
         unet/config.json unet/diffusion_pytorch_model.safetensors vae/config.json vae/diffusion_pytorch_model.safetensors \
         processor/added_tokens.json processor/chat_template.jinja processor/merges.txt processor/preprocessor_config.json \
         processor/special_tokens_map.json processor/tokenizer.json processor/tokenizer_config.json processor/video_preprocessor_config.json processor/vocab.json \
         tokenizer/added_tokens.json tokenizer/chat_template.jinja tokenizer/merges.txt tokenizer/special_tokens_map.json \
         tokenizer/tokenizer.json tokenizer/tokenizer_config.json tokenizer/vocab.json; do
  mkdir -p "$M/$(dirname "$f")"
  curl -fsSL --retry 3 -o "$M/$f" "$B/$f"
done
( cd "$M" && sha256sum -c - ) <<SUMS || { echo "::error::los pesos no son los revisados"; exit 1; }
7de1838c87a5349b016c26a1c3f7d2bc400a3d485f95ef39a7059ffd734977a0  text_encoder/model.safetensors
d3b46c229731e4c0c967176fdead58dd24bd3c29132c7f1c2204442cfeb99dc7  unet/diffusion_pytorch_model.safetensors
e175c3284b8514a2ecb1a70f004b0b09320decd6842e77dfebbdb5dbbdf0312b  vae/diffusion_pytorch_model.safetensors
SUMS
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" "torchvision==0.21.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.43.0" "transformers==5.23.0" "accelerate" "safetensors" "pillow" "numpy<2"
rm -rf out; mkdir -p out
.venv/bin/python -I ci/dreamlite_try.py "$M" ci/testdata/old out
ls -la out
