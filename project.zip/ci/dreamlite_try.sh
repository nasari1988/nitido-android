#!/usr/bin/env bash
# DreamLite on the server with the sample photos (no secrets): out/dreamlite_*.jpg to look at.
set -euo pipefail
cd "$(dirname "$0")/.."
M=dl/dreamlite-mobile
bash ci/dreamlite_get.sh
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" "torchvision==0.21.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.43.0" "transformers==5.23.0" "accelerate" "safetensors" "pillow" "numpy<2"
rm -rf out; mkdir -p out
.venv/bin/python -I ci/dreamlite_try.py "$M" ci/testdata/old out
ls -la out
