#!/usr/bin/env bash
# Mejorar video › Limpiar (prueba): RealBasicVSR on the computer, before / after frames in ./out.
# No secrets; the weights come from OpenMMLab's download server, checked before anything reads them.
set -euo pipefail
cd "$(dirname "$0")/.."
URL=https://download.openmmlab.com/mmediting/restorers/real_basicvsr/realbasicvsr_c64b20_1x30x8_lr5e-5_150k_reds_20211104-52f77c2c.pth
mkdir -p dl out
# its own empty folder; read only by the checked loader
curl -fsSL --retry 3 -o dl/rbvsr.pth "$URL"
SHA=$(sha256sum dl/rbvsr.pth | cut -d' ' -f1)
echo "sha256 $SHA · $(stat -c %s dl/rbvsr.pth) bytes"
# OpenMMLab names files with the first 8 characters of their sha256
case "$SHA" in 52f77c2c*) echo "huella coincide con el nombre del archivo";; *) echo "::error::la huella no coincide con el nombre ($SHA)"; exit 1;; esac
if [ -n "${RBVSR_SHA:-}" ] && [ "$SHA" != "$RBVSR_SHA" ]; then echo "::error::sha256 distinto del fijado"; exit 1; fi

echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "numpy<2" pillow
echo "::endgroup::"

.venv/bin/python -I ci/rbvsr_export.py dl/rbvsr.pth onnx ci/testdata/old
mkdir -p out
for f in onnx/check/*.jpg; do cp "$f" "out/check_$(basename "$f")"; done
printf "mode=prueba\nmodel=realbasicvsr\nsha256=%s\n" "$SHA" > out/info.txt
ls -la out
