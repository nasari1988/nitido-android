#!/usr/bin/env bash
# ✦ Realismo: PiSA-SR (SD 2.1-base + its two LoRAs) for the phone's NPU, in ./out. No secrets:
# reads pisa/pisa_sr.pkl (the authors' file, checked, fixed sha256) and SD 2.1-base from Hugging Face.
set -euo pipefail
cd "$(dirname "$0")/.."
PKL=pisa/pisa_sr.pkl
echo "13502f7bde5e4e585f84f24c3d904d9c848e068bf89f984046fe87da81a391f6  $PKL" | sha256sum -c - || { echo "::error::pisa_sr.pkl no es el archivo revisado"; exit 1; }

echo "::group::Memoria extra (swap)"
SWAPDIR=/mnt; [ -w /mnt ] || SWAPDIR=/
sudo fallocate -l 24G "$SWAPDIR/swapfile" && sudo chmod 600 "$SWAPDIR/swapfile" && sudo mkswap "$SWAPDIR/swapfile" && sudo swapon "$SWAPDIR/swapfile" || true
echo "::endgroup::"
echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.30.3" "transformers==4.44.2" "huggingface_hub==0.25.2" "accelerate==0.34.2" \
  "peft==0.12.0" "safetensors==0.4.5" "onnx==1.17.0" "onnxruntime==1.22.0" "numpy<2" "pillow"
echo "::endgroup::"

echo "::group::Exportar PiSA-SR"
rm -rf onnx out; mkdir -p onnx out
.venv/bin/python ci/pisa_export.py "$PKL" onnx ci/testdata
echo "::endgroup::"

source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
for n in $(cat onnx/pisa_parts.txt); do
  echo "::group::$n para la NPU"
  SYM=1; [ "$n" = pisa_unet ] && SYM=0
  NPU_SYM=$SYM NPU_PER_ROW=1 bash ci/npu_build.sh "$n" "onnx/$n.onnx" "onnx/calib_$n/list.txt" \
    || { echo "::error::$n no compiló para la NPU"; exit 1; }
  rm -f "onnx/$n.onnx" "onnx/$n.onnx.data"
  echo "::endgroup::"
done
for f in onnx/check/*.jpg; do cp "$f" "out/check_$(basename "$f")"; done
printf "mode=realismo\nversion=1\nmodel=pisa-sr\nnpu=1\ntile=512\n" > out/info.txt
(cd out && for f in *; do case "$f" in files.txt|check_*) continue ;; esac; echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
