"""
"Más fluido" for video: RIFE 4.25 (hzwer/Practical-RIFE, MIT) makes the frame between two frames.
The network runs at a fixed small size on the phone (NPU, or CPU as a fallback) and gives the
motion (flow, 4 channels: to frame 0 and to frame 1) and the blend mask; the app warps the
full-size frames with them.

The weights are the official flownet.pkl, kept in the repo after checking it (rife/flownet.pkl).
They are only read as numbers: first the pickle is disassembled (nothing runs) and every function
it names must be one of the 3 a plain state dict uses; then torch.load(weights_only=True), with a
torch >= 2.6 (earlier ones had CVE-2025-32434).

The network below is the inference part of IFNet_HDv3 (4.25), written again here (timestep fixed
at 0.5, no training branches), with the same layer names so the weights load as they are.

usage: rife_export.py <flownet.pkl> <out dir>
out: rife_{W}x{H}.onnx (float, CPU) and calib_rife_{W}x{H}/list.txt for each size, rife_sizes.txt
"""
import os
import pickletools
import sys
import zipfile

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

SIZES = [(1024, 576), (576, 1024), (704, 704)]   # landscape, portrait, square; multiples of 64
SCALES = [16, 8, 4, 2, 1]
ALLOWED = {("collections", "OrderedDict"), ("torch._utils", "_rebuild_tensor_v2"), ("torch", "FloatStorage"),
           ("torch", "HalfStorage"), ("torch._utils", "_rebuild_parameter")}


def check_pickle(path):
    """Lists what the pickle would call, without running it; anything else stops the conversion."""
    z = zipfile.ZipFile(path)
    pk = [n for n in z.namelist() if n.endswith(".pkl")]
    if len(pk) != 1:
        raise SystemExit(f"flownet.pkl no tiene la forma esperada: {pk}")
    strs, used = [], set()
    for op, arg, _ in pickletools.genops(z.read(pk[0])):
        if op.name in ("SHORT_BINUNICODE", "BINUNICODE", "UNICODE"):
            strs.append(arg)
        elif op.name == "STACK_GLOBAL":
            used.add(tuple(strs[-2:]))
        elif op.name == "GLOBAL":
            used.add(tuple(arg.split(" ", 1)))
        elif op.name in ("INST", "OBJ", "EXT1", "EXT2", "EXT4"):
            raise SystemExit(f"flownet.pkl contiene una instrucción no permitida: {op.name}")
    bad = used - ALLOWED
    if bad:
        raise SystemExit(f"flownet.pkl llama funciones no permitidas: {sorted(bad)}")
    print("pesos revisados: solo llama", sorted(used), flush=True)


def warp(img, flow):
    """Moves img by flow (pixels), bilinear, edges repeated (as RIFE's warplayer)."""
    n, _, h, w = img.shape
    gx = torch.linspace(-1.0, 1.0, w).view(1, 1, 1, w).expand(n, 1, h, w)
    gy = torch.linspace(-1.0, 1.0, h).view(1, 1, h, 1).expand(n, 1, h, w)
    fx = flow[:, 0:1] / ((w - 1.0) / 2.0)
    fy = flow[:, 1:2] / ((h - 1.0) / 2.0)
    grid = torch.cat([gx + fx, gy + fy], 1).permute(0, 2, 3, 1)
    return F.grid_sample(img, grid, mode="bilinear", padding_mode="border", align_corners=True)


def conv(i, o, k=3, s=1, p=1):
    return nn.Sequential(nn.Conv2d(i, o, k, s, p, bias=True), nn.LeakyReLU(0.2, True))


class Head(nn.Module):
    def __init__(self):
        super().__init__()
        self.cnn0 = nn.Conv2d(3, 16, 3, 2, 1)
        self.cnn1 = nn.Conv2d(16, 16, 3, 1, 1)
        self.cnn2 = nn.Conv2d(16, 16, 3, 1, 1)
        self.cnn3 = nn.ConvTranspose2d(16, 4, 4, 2, 1)
        self.relu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        x = self.relu(self.cnn0(x))
        x = self.relu(self.cnn1(x))
        x = self.relu(self.cnn2(x))
        return self.cnn3(x)


class ResConv(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.conv = nn.Conv2d(c, c, 3, 1, 1)
        self.beta = nn.Parameter(torch.ones((1, c, 1, 1)))
        self.relu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        return self.relu(self.conv(x) * self.beta + x)


class IFBlock(nn.Module):
    def __init__(self, cin, c):
        super().__init__()
        self.conv0 = nn.Sequential(conv(cin, c // 2, 3, 2, 1), conv(c // 2, c, 3, 2, 1))
        self.convblock = nn.Sequential(*[ResConv(c) for _ in range(8)])
        self.lastconv = nn.Sequential(nn.ConvTranspose2d(c, 4 * 13, 4, 2, 1), nn.PixelShuffle(2))

    def forward(self, x, flow, scale):
        if scale != 1:
            x = F.interpolate(x, scale_factor=1.0 / scale, mode="bilinear", align_corners=False)
        if flow is not None:
            if scale != 1:
                flow = F.interpolate(flow, scale_factor=1.0 / scale, mode="bilinear", align_corners=False) / scale
            x = torch.cat((x, flow), 1)
        tmp = self.lastconv(self.convblock(self.conv0(x)))
        if scale != 1:
            tmp = F.interpolate(tmp, scale_factor=scale, mode="bilinear", align_corners=False)
        return tmp[:, :4] * scale, tmp[:, 4:5], tmp[:, 5:]


class IFNet(nn.Module):
    """img0, img1: (1,3,H,W) in 0..1 -> flow (1,4,H,W) in pixels, mask (1,1,H,W) 0..1 (weight of frame 0)."""

    def __init__(self):
        super().__init__()
        self.block0 = IFBlock(7 + 8, 192)
        self.block1 = IFBlock(8 + 4 + 8 + 8, 128)
        self.block2 = IFBlock(8 + 4 + 8 + 8, 96)
        self.block3 = IFBlock(8 + 4 + 8 + 8, 64)
        self.block4 = IFBlock(8 + 4 + 8 + 8, 32)
        self.encode = Head()

    def forward(self, img0, img1):
        t = img0[:, :1] * 0 + 0.5
        f0, f1 = self.encode(img0), self.encode(img1)
        blocks = [self.block0, self.block1, self.block2, self.block3, self.block4]
        flow = mask = feat = None
        w0, w1 = img0, img1
        for i, b in enumerate(blocks):
            if flow is None:
                flow, mask, feat = b(torch.cat((img0, img1, f0, f1, t), 1), None, SCALES[i])
            else:
                wf0, wf1 = warp(f0, flow[:, :2]), warp(f1, flow[:, 2:4])
                fd, mask, feat = b(torch.cat((w0, w1, wf0, wf1, t, mask, feat), 1), flow, SCALES[i])
                flow = flow + fd
            w0, w1 = warp(img0, flow[:, :2]), warp(img1, flow[:, 2:4])
        return flow, torch.sigmoid(mask)


def middle(img0, img1, flow, mask):
    return warp(img0, flow[:, :2]) * mask + warp(img1, flow[:, 2:4]) * (1 - mask)


def scene(w, h, seed):
    """A made-up picture with detail at every scale, and the same picture moved (calibration and test)."""
    g = torch.Generator().manual_seed(seed)
    img = torch.zeros(1, 3, h, w)
    for s in (4, 8, 16, 32, 64):
        n = torch.rand(1, 3, max(2, h // s), max(2, w // s), generator=g)
        img += F.interpolate(n, size=(h, w), mode="bicubic", align_corners=False) * (s / 124.0)
    yy, xx = torch.meshgrid(torch.arange(h), torch.arange(w), indexing="ij")
    for _ in range(12):   # shapes with hard edges
        cx, cy = float(torch.rand(1, generator=g)) * w, float(torch.rand(1, generator=g)) * h
        r = 10 + float(torch.rand(1, generator=g)) * min(w, h) / 6
        col = torch.rand(3, 1, 1, generator=g)
        m = (((xx - cx) ** 2 + (yy - cy) ** 2) < r * r).float()
        img[0] = img[0] * (1 - m) + col * m
    img = img.clamp(0, 1)
    dx, dy = (float(torch.rand(1, generator=g)) - 0.5) * 48, (float(torch.rand(1, generator=g)) - 0.5) * 24
    full = torch.full((1, 2, h, w), 0.0)
    full[:, 0], full[:, 1] = dx, dy
    img1 = warp(img, full)          # the second frame: everything moved by (dx, dy)
    mid = warp(img, full * 0.5)     # what the middle frame should be
    return img, img1, mid


def psnr(a, b):
    return float(10 * torch.log10(1.0 / ((a - b) ** 2).mean().clamp_min(1e-10)))


def main():
    pkl, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    check_pickle(pkl)
    sd = torch.load(pkl, map_location="cpu", weights_only=True)
    sd = {k.replace("module.", ""): v for k, v in sd.items() if "teacher" not in k and "caltime" not in k}
    net = IFNet().eval()
    missing, extra = net.load_state_dict(sd, strict=False)
    print(f"pesos: {sum(v.numel() for v in sd.values()) / 1e6:.2f} millones · faltan {missing} · sobran {extra}", flush=True)
    if missing:
        raise SystemExit("faltan pesos")

    import onnx
    import onnxruntime as ort
    done = []
    for w, h in SIZES:
        name = f"rife_{w}x{h}"
        # quality check: the middle frame against the real one, and against a plain blend
        with torch.no_grad():
            got, blend = [], []
            for k in range(3):
                a, b, mid = scene(w, h, 900 + k)
                fl, mk = net(a, b)
                got.append(psnr(middle(a, b, fl, mk), mid))
                blend.append(psnr((a + b) / 2, mid))
        print(f"{name}: cuadro intermedio {np.mean(got):.1f} dB (mezcla simple {np.mean(blend):.1f} dB)", flush=True)
        if np.mean(got) < np.mean(blend) + 3:
            raise SystemExit(f"{name}: RIFE no mejora a la mezcla simple; algo no cargó bien")
        a, b, _ = scene(w, h, 1)
        path = os.path.join(out, name + ".onnx")
        with torch.no_grad():
            torch.onnx.export(net, (a, b), path, input_names=["img0", "img1"], output_names=["flow", "mask"],
                              opset_version=17, do_constant_folding=True, dynamo=False)
        mo_ = onnx.shape_inference.infer_shapes(onnx.load(path))
        onnx.checker.check_model(mo_)
        types = {v.name: v.type.tensor_type.elem_type for v in list(mo_.graph.value_info) + list(mo_.graph.input)}
        gs = [n for n in mo_.graph.node if n.op_type == "GridSample"]
        print(f"{name}: {len(gs)} GridSample · opset {[o.version for o in mo_.opset_import]} · tipos de entrada",
              sorted({(types.get(n.input[0]), types.get(n.input[1])) for n in gs}),
              "· atributos", [(a.name, a.s or a.i) for a in gs[0].attribute], "· ORT", ort.__version__, flush=True)
        s = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
        fo, mo = s.run(None, {"img0": a.numpy(), "img1": b.numpy()})
        with torch.no_grad():
            ft, mt = net(a, b)
        d = max(float(np.abs(fo - ft.numpy()).max()), float(np.abs(mo - mt.numpy()).max()))
        print(f"{name}: ONNX contra PyTorch, diferencia máxima {d:.5f} · {os.path.getsize(path) / 1e6:.1f} MB", flush=True)
        if d > 1e-2:
            raise SystemExit(f"{name}: el ONNX no da lo mismo")
        cdir = os.path.join(out, "calib_" + name)
        os.makedirs(cdir, exist_ok=True)
        lines = []
        for k in range(8):
            a, b, _ = scene(w, h, 100 + k)
            if k % 2:
                a, b = b, a
            fa, fb = os.path.join(cdir, f"{k}_img0.raw"), os.path.join(cdir, f"{k}_img1.raw")
            a.numpy().astype(np.float32).tofile(fa)
            b.numpy().astype(np.float32).tofile(fb)
            lines.append(f"img0:={os.path.abspath(fa)} img1:={os.path.abspath(fb)}")
        open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")
        done.append(name)
    open(os.path.join(out, "rife_sizes.txt"), "w").write("\n".join(done) + "\n")
    print("RIFE exportado:", done, flush=True)


if __name__ == "__main__":
    main()
