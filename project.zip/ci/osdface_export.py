"""
Caras con OSDFace for the phone's NPU. One step on Stable Diffusion 2.1-base (like Realismo/PiSA-SR,
whose VAE pieces pisa_enc and pisa_dec are the same network and are reused by the app):

  latent = VAE.encode(face).mode * sf                         -> pisa_enc (already on the phone)
  h      = VQ encoder(face)                                   -> osd_vq   (1x3x512x512 -1..1 -> 1x512x16x16)
  zq     = 77 nearest codebook entries, no repeats            -> the app, on the CPU (osd_codebook.bin)
  x0     = (latent - sqrt(1-a) * UNet(latent, 399, E(zq))) / sqrt(a)
                                                              -> osd_unet (latent 1x4x64x64, zq 1x77x512)
  face'  = VAE.decode(x0 / sf)                                -> pisa_dec (already on the phone)

E is the authors' embedding change (two 1x1 convolutions, 512 -> 1024), inside osd_unet. The UNet is
SD 2.1-base with the authors' LoRA merged (rank 16, alpha 16), as their infer.py --merge_lora.
Only safetensors are read (osdface_get.py made them). The model code is the authors' (their repo at
a fixed commit, given as the first argument).

usage: osdface_export.py <OSDFace code dir> <weights dir> <out dir> <sample photos dir>
out: osd_vq.onnx, osd_unet.onnx, calib_osd_{vq,unet}/list.txt, osd_parts.txt, osd_codebook.bin,
     check/osdface_*.jpg (face in, face out with the float model)
"""
import os
import sys
from types import SimpleNamespace

import numpy as np
import torch
from PIL import Image
from safetensors.torch import load_file

T = 512
BASES = ["stabilityai/stable-diffusion-2-1-base", "Manojb/stable-diffusion-2-1-base"]
STEP = 399


def load_base():
    from diffusers import AutoencoderKL, DDIMScheduler, UNet2DConditionModel
    last = None
    for repo in BASES:
        try:
            vae = AutoencoderKL.from_pretrained(repo, subfolder="vae")
            unet = UNet2DConditionModel.from_pretrained(repo, subfolder="unet")
            sch = DDIMScheduler.from_pretrained(repo, subfolder="scheduler")
            print("modelo base:", repo, flush=True)
            return vae, unet, sch
        except Exception as e:  # noqa: BLE001
            print(f"no se pudo usar {repo}: {e}", flush=True)
            last = e
    raise SystemExit(f"sin modelo base SD 2.1: {last}")


def merge_lora(unet, lora, rank=16, alpha=16.0):
    """The authors' merge_Unet: W += (alpha/rank) * B @ A for every LoRA pair."""
    k = alpha / rank
    sd = unet.state_dict()
    done, n = set(), 0
    for key in lora:
        if "lora_A" in key:
            a, b = lora[key], lora[key.replace("lora_A", "lora_B")]
            uk = key.replace(".lora_A.weight", ".weight").replace("unet.", "")
            if a.ndim == 4:
                d = (b.view(b.shape[0], -1) @ a.view(a.shape[0], -1)).view(sd[uk].shape)
            else:
                d = b @ a
            sd[uk] = sd[uk] + k * d
            done.update([key, key.replace("lora_A", "lora_B")]); n += 1
        elif "lora.up.weight" in key:
            up, down = lora[key], lora[key.replace("lora.up.weight", "lora.down.weight")]
            uk = key.replace(".lora.up.weight", ".weight").replace("unet.", "")
            sd[uk] = sd[uk] + k * (up @ down)
            done.update([key, key.replace("lora.up.weight", "lora.down.weight")]); n += 1
    left = [x for x in lora if x not in done]
    if left:
        raise SystemExit(f"LoRA: {len(left)} tensores sin usar, p. ej. {left[:3]}")
    unet.load_state_dict(sd)
    print(f"LoRA unida: {n} capas", flush=True)
    return unet


class Vq(torch.nn.Module):
    """The VQ encoder up to the features compared with the codebook (as the authors' forward)."""
    def __init__(self, enc):
        super().__init__()
        self.enc = enc

    def forward(self, image):
        x = (image - 0.5) / 0.5          # the authors' own step, on an image already in -1..1
        hs, _ = self.enc.encoder(x)
        return self.enc.quant_conv(hs["out"])


def pick(h, codebook, n_min=77):
    """The authors' quantize.inference: each position's nearest code, positions sorted by that
    distance, the first n_min different codes, in that order."""
    z = h.permute(0, 2, 3, 1).reshape(-1, h.shape[1])
    d = (z ** 2).sum(1, keepdim=True) + (codebook ** 2).sum(1) - 2 * z @ codebook.t()
    mv, mi = d.min(1)
    order = torch.argsort(mv)
    seen, sel = set(), []
    for i in mi[order].tolist():
        if i not in seen:
            seen.add(i); sel.append(i)
        if len(sel) >= n_min:
            break
    zq = torch.zeros(1, n_min, codebook.shape[1])
    zq[0, :len(sel)] = codebook[sel]
    return zq


class UnetX0(torch.nn.Module):
    def __init__(self, unet, embed, a):
        super().__init__()
        self.unet, self.embed = unet, embed
        self.register_buffer("t", torch.tensor([STEP], dtype=torch.long))
        self.sa, self.sb = float(a ** 0.5), float((1 - a) ** 0.5)

    def forward(self, latent, zq):
        e = self.embed(zq)
        pred = self.unet(latent, self.t, encoder_hidden_states=e).sample
        return (latent - self.sb * pred) / self.sa


def faces(photos, n=12):
    """Faces from the sample old photos (OpenCV's own detector, no downloaded weights), cut square
    around each face like the app's 512 template (eyes a bit above the middle), as -1..1 tensors."""
    import cv2
    det = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    out = []
    files = sorted(os.path.join(r, f) for r, _, fs in os.walk(photos) for f in fs if f.lower().endswith((".png", ".jpg", ".jpeg")))
    for f in files:
        img = Image.open(f).convert("RGB")
        g = cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2GRAY)
        for (x, y, w, h) in det.detectMultiScale(g, 1.1, 5, minSize=(24, 24)):
            side = 2.0 * w; cx = x + w / 2; cy = y + h * 0.55
            box = (int(cx - side / 2), int(cy - side / 2), int(cx + side / 2), int(cy + side / 2))
            face = img.crop(box).resize((T, T), Image.BICUBIC)
            a = np.asarray(face).astype(np.float32) / 127.5 - 1
            out.append(torch.from_numpy(a).permute(2, 0, 1)[None].contiguous())
            if len(out) >= n:
                return out
    return out


def main():
    code, wdir, out, photos = sys.argv[1:5]
    sys.path.insert(0, code)
    from lq_embed.inference import TwoLayerConv1x1
    from lq_embed.vqvae import VQVAEencoder
    os.makedirs(out, exist_ok=True)

    args = SimpleNamespace(cat_prompt_embedding=False, use_att_pool=False, use_pos_embedding=False, learnable_pos_emb=False)
    vqm = VQVAEencoder(args=args, n_embed=1024, embed_dim=512, ch=64, out_ch=3, ch_mult=(1, 2, 2, 2, 4, 8),
                       num_res_blocks=2, attn_resolutions=[16], dropout=0.0, in_channels=3, resolution=512,
                       z_channels=512, double_z=False, enable_mid=True, head_size=1, n_min=77)
    miss, extra = vqm.load_state_dict(load_file(os.path.join(wdir, "osd_vq.safetensors")), strict=False)
    miss = [m for m in miss if not m.startswith("quantize.pos_embedding")]
    print(f"VQ: faltan {len(miss)} {miss[:5]} · sobran {len(extra)} {extra[:5]}", flush=True)
    if miss:
        raise SystemExit("el codificador VQ no cargó completo")
    vqm.eval()
    codebook = vqm.quantize.embedding.weight.detach().float()
    codebook.numpy().astype(np.float32).tofile(os.path.join(out, "osd_codebook.bin"))
    print(f"diccionario: {tuple(codebook.shape)} -> osd_codebook.bin", flush=True)

    embed = TwoLayerConv1x1(512, 1024)
    embed.load_state_dict(load_file(os.path.join(wdir, "osd_embed.safetensors")))
    embed.eval()

    vae, unet, sch = load_base()
    unet = merge_lora(unet, load_file(os.path.join(wdir, "osd_lora.safetensors"))).eval()
    vae.eval()
    a = float(sch.alphas_cumprod[STEP])
    print(f"paso {STEP}: alpha acumulada {a:.6f}", flush=True)
    vq, un = Vq(vqm).eval(), UnetX0(unet, embed, a).eval()
    sf = vae.config.scaling_factor

    tiles = faces(photos)
    print(f"{len(tiles)} caras de muestra", flush=True)
    if len(tiles) < 4:
        raise SystemExit("muy pocas caras para calibrar")
    cdir = {n: os.path.join(out, f"calib_osd_{n}") for n in ("vq", "unet")}
    for d in cdir.values():
        os.makedirs(d, exist_ok=True)
    lists = {n: [] for n in cdir}
    chk = os.path.join(out, "check"); os.makedirs(chk, exist_ok=True)
    with torch.no_grad():
        for i, x in enumerate(tiles):
            h = vq(x)
            zq = pick(h, codebook)
            lat = vae.encode(x).latent_dist.mode() * sf
            x0 = un(lat, zq)
            y = vae.decode(x0 / sf).sample.clamp(-1, 1)
            px = os.path.join(cdir["vq"], f"{i:02d}.raw"); x.numpy().astype(np.float32).tofile(px)
            lists["vq"].append(f"image:={os.path.abspath(px)}")
            pl = os.path.join(cdir["unet"], f"{i:02d}_l.raw"); lat.numpy().astype(np.float32).tofile(pl)
            pz = os.path.join(cdir["unet"], f"{i:02d}_z.raw"); zq.numpy().astype(np.float32).tofile(pz)
            lists["unet"].append(f"latent:={os.path.abspath(pl)} zq:={os.path.abspath(pz)}")
            both = torch.cat([x, y], 3)[0].permute(1, 2, 0).numpy()
            Image.fromarray(((both + 1) * 127.5).clip(0, 255).astype(np.uint8)).save(os.path.join(chk, f"osdface_{i:02d}.jpg"), quality=88)
    for n in lists:
        open(os.path.join(cdir[n], "list.txt"), "w").write("\n".join(lists[n]) + "\n")

    import shutil
    import onnx
    import onnxruntime as ort
    x = tiles[0]
    with torch.no_grad():
        lat0 = vae.encode(x).latent_dist.mode() * sf
        zq0 = pick(vq(x), codebook)
    done = []
    for name, m, inputs, names, oname in (("osd_vq", vq, (x,), ["image"], "h"),
                                          ("osd_unet", un, (lat0, zq0), ["latent", "zq"], "x0")):
        tmp = os.path.join(out, "tmp_" + name); os.makedirs(tmp, exist_ok=True)
        with torch.no_grad():
            ref = m(*inputs)
            torch.onnx.export(m, inputs, os.path.join(tmp, "m.onnx"), input_names=names, output_names=[oname],
                              opset_version=17, do_constant_folding=True)
        mo = onnx.load(os.path.join(tmp, "m.onnx"), load_external_data=True)
        dst = os.path.join(out, name + ".onnx")
        onnx.save(mo, dst, save_as_external_data=True, all_tensors_to_one_file=True, location=name + ".onnx.data")
        del mo
        shutil.rmtree(tmp, ignore_errors=True)
        got = ort.InferenceSession(dst, providers=["CPUExecutionProvider"]).run(
            None, {k: v.numpy() for k, v in zip(names, inputs)})[0]
        print(f"{name}: ONNX contra PyTorch, diferencia máxima {float(np.abs(got - ref.numpy()).max()):.5f}", flush=True)
        done.append(name)
    open(os.path.join(out, "osd_parts.txt"), "w").write("\n".join(done) + "\n")
    print("OSDFace exportado:", done, flush=True)


if __name__ == "__main__":
    main()
