#!/usr/bin/env bash
# Converts one model to MNN and leaves the files to publish in ./out
# usage: ci/convert_model.sh <model_id> [model link] [8|16] [lora link] [lora weight]
set -euo pipefail
cd "$(dirname "$0")/.."
ID="$1"
LINK="${2:-}"
export PRECISION="${3:-8}"
LORA="${4:-}"
LORA_W="${5:-0.8}"

if [ "$ID" = "restauracion" ]; then
  # Not a Stable Diffusion model: the pack of old-photo restoration models.
  echo "::group::Python"
  source ci/venv.sh
  .venv/bin/pip install --quiet "torch==2.4.1" "torchvision==0.19.1" --index-url https://download.pytorch.org/whl/cpu
  .venv/bin/pip install --quiet "onnx==1.16.2" "numpy<2" "einops" "safetensors" "timm" "huggingface_hub==0.25.2"
  .venv/bin/pip install --quiet "onnxsim" "ml_dtypes" "onnxruntime" || echo "onnxsim no disponible"
  .venv/bin/pip install --quiet "spandrel==0.4.1" "spandrel_extra_arches==0.2.0" \
    || .venv/bin/pip install --quiet spandrel spandrel_extra_arches
  echo "::endgroup::"
  echo "::group::Convertidor MNN"
  rm -rf mnn
  git clone -q --depth 1 --branch 3.4.0 https://github.com/alibaba/MNN.git mnn
  cmake -S mnn -B mnn/build-host -DCMAKE_BUILD_TYPE=Release -DMNN_BUILD_CONVERTER=ON -DCMAKE_POLICY_VERSION_MINIMUM=3.10
  cmake --build mnn/build-host --target MNNConvert -j"$(nproc)"
  echo "::endgroup::"
  echo "::group::Exportar modelos de restauración"
  # the link field may name only some models (e.g. "rest_deblur"); the rest stay as published
  ONLY=""; case "$LINK" in rest_*) ONLY="$LINK" ;; esac
  .venv/bin/python ci/export_restore.py onnx "$ONLY"
  echo "::endgroup::"
  echo "::group::Convertir a MNN"
  mkdir -p out
  for f in onnx/*.onnx; do
    case "$f" in *.alt.onnx) continue ;; esac
    n=$(basename "$f" .onnx)
    ok=0
    # simplified model first, then the plain export; if the optimizer crashes, fewer optimizations
    for src in "$f" "onnx/$n.alt.onnx"; do
      [ -e "$src" ] || continue
      for opts in "--fp16" "--fp16 --optimizeLevel 0"; do
        echo "-- $n: $(basename "$src") $opts"
        if mnn/build-host/MNNConvert -f ONNX --modelFile "$src" --MNNModel "out/$n.mnn" --bizCode MNN $opts; then ok=1; break 2; fi
      done
    done
    [ $ok = 1 ] || { echo "::warning::MNN no pudo convertir $n"; rm -f "out/$n.mnn"; }
  done
  ls out/*.mnn >/dev/null
  # the same models compiled for the phone's NPU (W8A16 context binaries, like the UNet)
  bash ci/npu_restore.sh || echo "::warning::sin versiones NPU de restauración"
  printf "mode=restore\nversion=2\n" > out/info.txt
  # the scratch detector's test pictures: published to look at, not for the app (not in files.txt)
  for f in onnx/scratch_check/*.jpg; do [ -e "$f" ] && cp "$f" "out/check_scratch_$(basename "$f")"; done
  (cd out && for f in *; do case "$f" in files.txt|check_*) continue ;; esac; echo "$f $(stat -c %s "$f")"; done > files.txt)
  if [ -n "$ONLY" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
    # keep the models already published that weren't rebuilt this time
    curl -fsSL "https://github.com/$GITHUB_REPOSITORY/releases/download/modelo-restauracion/files.txt" -o old_files.txt || true
    if [ -s old_files.txt ]; then
      while read -r name size; do
        # (the float .npu.onnx of the first try don't run on this NPU: not kept)
        case "$name" in *.npu.onnx|rest_color.npu*|rest_deblur.npu*|rest_faces.npu*) continue ;; esac
        [ -n "$name" ] && [ ! -e "out/$name" ] && echo "$name $size" >> out/files.txt
      done < old_files.txt
    fi
  fi
  cat out/files.txt
  echo "::endgroup::"
  exit 0
fi

echo "::group::Memoria extra (swap)"
# SDXL needs ~14 GB of RAM to export; the runner has 16 GB, so add swap.
SWAPDIR=/mnt; [ -w /mnt ] || SWAPDIR=/
SWAPGB=20; [ "$PRECISION" = "npu" ] && SWAPGB=40   # the NPU quantizer keeps every calibration activation
sudo fallocate -l ${SWAPGB}G "$SWAPDIR/swapfile_nitido" && sudo chmod 600 "$SWAPDIR/swapfile_nitido" && sudo mkswap "$SWAPDIR/swapfile_nitido" && sudo swapon "$SWAPDIR/swapfile_nitido" || echo "no se pudo crear swap"
free -h; df -h / /mnt || true
echo "::endgroup::"

echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.4.1" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.30.3" "transformers==4.44.2" "huggingface_hub==0.25.2" \
  "onnx==1.16.2" "safetensors==0.4.5" "accelerate==0.34.2" "peft==0.12.0" "omegaconf" "numpy<2"
echo "::endgroup::"

if [ "$PRECISION" = "npu" ]; then
  # NPU (Qualcomm Hexagon) UNet only: the app keeps using the normal model's text encoder and VAE.
  echo "::group::Exportar $ID para la NPU"
  .venv/bin/pip install --quiet "onnxruntime==1.19.2"
  rm -rf onnx out
  NPU=1 NPU_ID="$ID" .venv/bin/python ci/export_model.py "$ID" onnx "$LINK" "$LORA" "$LORA_W"
  echo "::endgroup::"
  # compile it for the NPU here, with Qualcomm's kit; the phone only loads the result
  if [ -e onnx/sdxl_parts.txt ]; then
    # SDXL (experimental): its UNet in parts, each its own graph; a run may build only some parts
    # (NPU_PARTS) and the release keeps the ones built before
    source ci/qnn_sdk.sh
    export BIN LIB PY QV DSP_ARCH SOC_ID   # npu_build.sh runs as its own process
    mkdir -p out
    for n in $(cat onnx/sdxl_parts.txt); do
      echo "::group::$n para la NPU"
      free -h | head -2
      SYM="${NPU_SYM:-0}"; case "$n" in vae_*) SYM=1 ;; esac   # the decoder's attention needs the symmetric ranges
      NPU_SYM="$SYM" NPU_PER_ROW="${NPU_PER_ROW:-1}" bash ci/npu_build.sh "$n" "onnx/$n.onnx" "onnx/calib_$n/list.txt" \
        || { echo "::warning::$n no compiló para la NPU"; rm -f "out/$n.bin" "out/${n}_ctx.onnx" "out/${n}_ctx.onnx.json"; }
      rm -f "onnx/$n.onnx" "onnx/$n.onnx.data"
      echo "::endgroup::"
    done
    cp onnx/sdxl_ref*.json onnx/sdxl_ref_in*.bin out/ 2>/dev/null || true   # the app's self-test example
  else
    bash ci/npu_qnn.sh
  fi
  echo "::group::Archivos NPU"
  mv onnx/info.txt out/
  sed -i "s/^npu_precision=.*/npu_precision=w8a16/" out/info.txt
  printf "npu_format=ctx\nnpu_qnn=2.42.0.251225\n" >> out/info.txt
  rm -rf out/qnn_runtime   # the app keeps the QNN 2.42 libraries of ONNX Runtime
  ls -la out
  for f in out/*; do
    if [ "$(stat -c %s "$f")" -gt 1900000000 ]; then
      split -b 1800M -d -a 2 "$f" "$f.split"
      rm "$f"
    fi
  done
  (cd out && for f in *; do [ "$f" = files.txt ] || echo "$f $(stat -c %s "$f")"; done > files.txt)
  if [ -e onnx/sdxl_parts.txt ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
    # keep the parts published by earlier runs
    curl -fsSL "https://github.com/$GITHUB_REPOSITORY/releases/download/modelo-$ID/files.txt" -o old_files.txt || true
    if [ -s old_files.txt ]; then
      while read -r name size; do
        if [ -n "$name" ] && [ ! -e "out/$name" ]; then echo "$name $size" >> out/files.txt; fi
      done < old_files.txt
    fi
  fi
  cat out/files.txt
  echo "::endgroup::"
  exit 0
fi

echo "::group::Convertidor MNN"
rm -rf mnn
git clone -q --depth 1 --branch 3.4.0 https://github.com/alibaba/MNN.git mnn
patch -p1 -N -d mnn < ci/mnn_attention.patch || grep -q "Nitido: no mask" mnn/source/backend/cpu/CPUAttention.cpp
cmake -S mnn -B mnn/build-host -DCMAKE_BUILD_TYPE=Release -DMNN_BUILD_CONVERTER=ON -DCMAKE_POLICY_VERSION_MINIMUM=3.10 \
  -DMNN_BUILD_SHARED_LIBS=OFF -DMNN_SEP_BUILD=OFF -DMNN_SUPPORT_TRANSFORMER_FUSE=ON -DMNN_LOW_MEMORY=ON
cmake --build mnn/build-host --target MNNConvert MNN -j"$(nproc)"
# checks each converted UNet by running it, like the app does
g++ -O2 -std=c++17 ci/mnn_check.cpp -Imnn/include -Lmnn/build-host -Wl,--whole-archive -lMNN -Wl,--no-whole-archive -lpthread -ldl -o mnn_check
echo "::endgroup::"

echo "::group::Exportar $ID a ONNX"
# a name ending in "-fijo" converts at a fixed 512x512 (speed comparison)
case "$ID" in *-fijo) export STATIC=1;; esac
.venv/bin/python ci/export_model.py "$ID" onnx "$LINK" "$LORA" "$LORA_W"
df -h .
echo "::endgroup::"

ARCH=$(grep '^arch=' onnx/info.txt | cut -d= -f2)
if [ "$ARCH" = "sdxl" ] && [ "$PRECISION" = "16" ]; then
  echo "SDXL en 16 bits no cabe bien en la memoria del teléfono: se convierte en 8 bits."
  PRECISION=8
  sed -i 's/^precision=.*/precision=8/' onnx/info.txt
fi
if [ "$PRECISION" = "16" ]; then QUANT="--fp16"; else QUANT="--weightQuantBits=8"; fi
echo "Arquitectura: $ARCH · Precisión: $PRECISION bits"

echo "::group::Convertir a MNN"
mkdir -p out
for m in text_encoder unet vae_decoder vae_encoder; do
  # a name ending in "-nf" converts without the fused attention (to test MNN's fused ops)
  FUSE="--transformerFuse"; case "$ID" in *-nf) FUSE="";; esac
  mnn/build-host/MNNConvert -f ONNX --modelFile "onnx/$m/model.onnx" --MNNModel "out/$m.mnn" \
    --bizCode MNN --saveExternalData=1 $QUANT $FUSE
  rm -rf "onnx/$m"
  test -s "out/$m.mnn"
done
cp onnx/vocab.json onnx/merges.txt onnx/info.txt out/
if [ "$ARCH" = "sd15" ]; then
  echo "Probando la UNet convertida (cuadro, vertical, horizontal)…"
  MODE=$(grep '^mode=' out/info.txt | cut -d= -f2)
  SIZES="64 64 96 64 64 96"; [ "${STATIC:-0}" = "1" ] && SIZES="64 64"
  if ! (cd out && ../mnn_check unet.mnn "$MODE" sd15 $SIZES); then
    echo "::group::Dónde falló"
    sudo apt-get install -y -qq gdb >/dev/null 2>&1 || true
    (cd out && gdb -batch -ex run -ex bt --args ../mnn_check unet.mnn "$MODE" sd15 64 64 2>&1 | grep -v "^\[New Thread\|^\[Thread" | tail -30) || true
    echo "::endgroup::"
    echo "::error::La UNet convertida no pasó la prueba; no se publica."
    exit 1
  fi
fi
# GitHub allows at most 2 GB per file: cut bigger ones into pieces; the app joins them again.
for f in out/*; do
  if [ "$(stat -c %s "$f")" -gt 1900000000 ]; then
    split -b 1800M -d -a 2 "$f" "$f.split"
    rm "$f"
  fi
done
(cd out && for f in *; do [ "$f" = files.txt ] || echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
echo "::endgroup::"
