#!/usr/bin/env bash
# Converts one model to MNN and leaves the files to publish in ./out
# usage: ci/convert_model.sh <model_id>
set -euo pipefail
cd "$(dirname "$0")/.."
ID="$1"

echo "::group::Python"
python3 -m venv .venv
.venv/bin/pip install --quiet "torch==2.4.1" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.30.3" "transformers==4.44.2" "huggingface_hub==0.25.2" \
  "onnx==1.16.2" "safetensors==0.4.5" "accelerate==0.34.2" "omegaconf" "numpy<2"
echo "::endgroup::"

echo "::group::Convertidor MNN"
rm -rf mnn
git clone -q --depth 1 --branch 3.4.0 https://github.com/alibaba/MNN.git mnn
cmake -S mnn -B mnn/build-host -DCMAKE_BUILD_TYPE=Release -DMNN_BUILD_CONVERTER=ON -DCMAKE_POLICY_VERSION_MINIMUM=3.10
cmake --build mnn/build-host --target MNNConvert -j"$(nproc)"
echo "::endgroup::"

echo "::group::Exportar $ID a ONNX"
.venv/bin/python ci/export_model.py "$ID" onnx
rm -rf ~/.cache/huggingface
df -h .
echo "::endgroup::"

echo "::group::Convertir a MNN"
mkdir -p out
for m in text_encoder unet vae_decoder vae_encoder; do
  mnn/build-host/MNNConvert -f ONNX --modelFile "onnx/$m/model.onnx" --MNNModel "out/$m.mnn" \
    --bizCode MNN --saveExternalData=1 --weightQuantBits=8 --transformerFuse
  rm -rf "onnx/$m"
  test -s "out/$m.mnn"
done
cp onnx/vocab.json onnx/merges.txt out/
(cd out && for f in *; do [ "$f" = files.txt ] || echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
echo "::endgroup::"
