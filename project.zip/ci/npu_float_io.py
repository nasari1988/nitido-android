"""
Makes a quantized (QDQ) ONNX model take and give float pictures.

Qualcomm's 8-bit AI Hub models may have integer inputs/outputs (the picture already turned into
uint8). The app sends floats 0..1, so here an integer input gets a QuantizeLinear in front (with
the scale and zero point of the DequantizeLinear that reads it) and an integer output gets a
DequantizeLinear after it. ONNX Runtime's QNN provider folds these into the NPU graph.
usage: npu_float_io.py <model.onnx>   (rewritten in place, weights file kept)
"""
import os
import sys

import onnx
from onnx import TensorProto, helper

path = sys.argv[1]
m = onnx.load(path, load_external_data=False)
g = m.graph
INT = {TensorProto.UINT8, TensorProto.INT8, TensorProto.UINT16, TensorProto.INT16}


def show(tag):
    for v in list(g.input) + list(g.output):
        t = v.type.tensor_type
        print(tag, v.name, TensorProto.DataType.Name(t.elem_type), [d.dim_value or d.dim_param for d in t.shape.dim])


show("antes")
changed = False
for inp in list(g.input):
    t = inp.type.tensor_type
    if t.elem_type not in INT:
        continue
    users = [n for n in g.node if inp.name in n.input and n.op_type == "DequantizeLinear"]
    if not users:
        print("entrada entera sin DequantizeLinear:", inp.name)
        continue
    dq = users[0]
    new = inp.name + "_float"
    g.node.insert(0, helper.make_node("QuantizeLinear", [new, dq.input[1], dq.input[2] if len(dq.input) > 2 else ""],
                                      [inp.name], name=new + "_q"))
    g.input.remove(inp)
    g.input.append(helper.make_tensor_value_info(new, TensorProto.FLOAT, [d.dim_value for d in t.shape.dim]))
    changed = True
for out in list(g.output):
    t = out.type.tensor_type
    if t.elem_type not in INT:
        continue
    prod = [n for n in g.node if out.name in n.output and n.op_type == "QuantizeLinear"]
    if not prod:
        print("salida entera sin QuantizeLinear:", out.name)
        continue
    q = prod[0]
    new = out.name + "_float"
    g.node.append(helper.make_node("DequantizeLinear", [out.name, q.input[1], q.input[2] if len(q.input) > 2 else ""],
                                   [new], name=new + "_dq"))
    g.output.remove(out)
    g.output.append(helper.make_tensor_value_info(new, TensorProto.FLOAT, [d.dim_value for d in t.shape.dim]))
    changed = True
if changed:
    onnx.save(m, path)   # external weights stay in their own file (not loaded, not rewritten)
show("después")
print("modificado" if changed else "ya era de entrada y salida float")
