"""
SDXL's UNet for the phone's NPU (experimental), in 4 parts: 2.6 billion weights don't fit the NPU
as one graph. The parts run one after the other in every step, passing on what the next needs:

  p1  time/text embedding + conv_in + down blocks 0-2  -> emb, h, s0..s8 (the 9 skip tensors)
  p2  mid block + up block 0, first two layers (uses s8, s7)
  p3  up block 0, last layer + its upsampler + up block 1 (+ upsampler) (uses s6..s3)
  p4  up block 2 + the output layers (uses s2..s0)

Only the square size (1024x1024, batch 1: guided and free passes run one after the other) for now. Calibration comes from real generations.
Before anything is written, the 4 parts chained are compared with the original UNet.

Output (in <out>): sdxl_p{i}.onnx (+.onnx.data), calib_sdxl_p{i}/list.txt, sdxl_parts.txt
Env: NPU_PARTS="1,2,3,4" (which parts to export; default all).
"""
import gc
import os
import shutil

import numpy as np
import torch

W = H = 1024
SKIPS = [f"s{i}" for i in range(9)]


def up_layers(blk, h, skips, emb, ehs, first, last, upsample):
    """Layers [first, last) of an up block (resnet on h + a skip, then attention), and its upsampler."""
    for i in range(first, last):
        h = torch.cat([h, skips.pop()], 1)
        h = blk.resnets[i](h, emb)
        if getattr(blk, "attentions", None) is not None:
            h = blk.attentions[i](h, encoder_hidden_states=ehs, return_dict=False)[0]
    if upsample and getattr(blk, "upsamplers", None):
        for up in blk.upsamplers:
            h = up(h)
    return h


class P1(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids):
        u = self.u
        t_emb = u.get_time_embed(sample=sample, timestep=timestep)
        emb = u.time_embedding(t_emb, None)
        aug = u.get_aug_embed(emb=emb, encoder_hidden_states=encoder_hidden_states,
                              added_cond_kwargs={"text_embeds": text_embeds, "time_ids": time_ids})
        emb = emb + aug
        h = u.conv_in(sample)
        res = (h,)
        for blk in u.down_blocks:
            if getattr(blk, "has_cross_attention", False):
                h, r = blk(hidden_states=h, temb=emb, encoder_hidden_states=encoder_hidden_states)
            else:
                h, r = blk(hidden_states=h, temb=emb)
            res += r
        return (emb, h) + res


class P2(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, h, emb, encoder_hidden_states, s7, s8):
        u = self.u
        h = u.mid_block(h, emb, encoder_hidden_states=encoder_hidden_states)
        return up_layers(u.up_blocks[0], h, [s7, s8], emb, encoder_hidden_states, 0, 2, False)


class P3(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, h, emb, encoder_hidden_states, s3, s4, s5, s6):
        u = self.u
        h = up_layers(u.up_blocks[0], h, [s6], emb, encoder_hidden_states, 2, 3, True)
        return up_layers(u.up_blocks[1], h, [s3, s4, s5], emb, encoder_hidden_states, 0, 3, True)


class P4(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, h, emb, s0, s1, s2):
        u = self.u
        h = up_layers(u.up_blocks[2], h, [s0, s1, s2], emb, None, 0, 3, False)
        if u.conv_norm_out is not None:
            h = u.conv_act(u.conv_norm_out(h))
        return u.conv_out(h)


PARTS = {
    1: (P1, ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"], ["emb", "h"] + SKIPS),
    2: (P2, ["h", "emb", "encoder_hidden_states", "s7", "s8"], ["h_out"]),
    3: (P3, ["h", "emb", "encoder_hidden_states", "s3", "s4", "s5", "s6"], ["h_out"]),
    4: (P4, ["h", "emb", "s0", "s1", "s2"], ["out_sample"]),
}


def chain(u, x):
    """The 4 parts one after the other; returns every part's inputs and the final output."""
    p1 = P1(u)(x["sample"], x["timestep"], x["encoder_hidden_states"], x["text_embeds"], x["time_ids"])
    emb, h = p1[0], p1[1]
    s = list(p1[2:])
    ins = {1: dict(x)}
    ins[2] = {"h": h, "emb": emb, "encoder_hidden_states": x["encoder_hidden_states"], "s7": s[7], "s8": s[8]}
    h = P2(u)(**ins[2])
    ins[3] = {"h": h, "emb": emb, "encoder_hidden_states": x["encoder_hidden_states"], "s3": s[3], "s4": s[4], "s5": s[5], "s6": s[6]}
    h = P3(u)(**ins[3])
    ins[4] = {"h": h, "emb": emb, "s0": s[0], "s1": s[1], "s2": s[2]}
    return ins, P4(u)(**ins[4])


def quality_check(pipe, out):
    """
    Does the NPU's precision ruin SDXL? The same picture made on the computer 3 ways: the original
    UNet, its weights at 8 bits per channel (as the NPU keeps them), and that plus every layer's
    output rounded to 16 bits within ranges measured on 4 calibration steps (as the NPU runs it).
    Writes check/float.png, check/w8.png, check/w8a16.png and check/all.jpg (side by side).
    """
    from PIL import Image
    u = pipe.unet.eval()
    cdir = os.path.join(out, "check")
    os.makedirs(cdir, exist_ok=True)
    leaves = [(n, m) for n, m in u.named_modules() if len(list(m.children())) == 0]
    print(f"capas medidas: {len(leaves)}", flush=True)

    # 1. ranges of every layer's output on 4 of the UNet calls of a calibration picture (like the real calibration)
    rng = {}
    state = {"call": 0, "take": False}
    keep = {0, 2, 3, 5}

    def pre(_m, _a):
        state["take"] = state["call"] in keep
        state["call"] += 1
    hp = u.register_forward_pre_hook(pre)

    def rec(name):
        def f(_m, _i, o):
            if state["take"] and torch.is_tensor(o):
                lo, hi = float(o.min()), float(o.max())
                a, b = rng.get(name, (lo, hi))
                rng[name] = (min(a, lo), max(b, hi))
        return f
    hs = [m.register_forward_hook(rec(n)) for n, m in leaves]
    with torch.no_grad():
        pipe("portrait photo of a woman in a garden, natural light", negative_prompt="blurry, lowres", width=W, height=H,
             num_inference_steps=6, guidance_scale=2.0, generator=torch.Generator().manual_seed(200), output_type="latent")
    for h in hs:
        h.remove()
    hp.remove()
    print(f"rangos medidos: {len(rng)} capas", flush=True)

    prompt = "a red sports car parked on a city street at sunset, photo"   # not one of the calibration pictures

    def make(tag):
        with torch.no_grad():
            img = pipe(prompt, negative_prompt="blurry, lowres", width=W, height=H, num_inference_steps=6,
                       guidance_scale=2.0, generator=torch.Generator().manual_seed(7)).images[0]
        img.save(os.path.join(cdir, tag + ".png"))
        print("imagen", tag, flush=True)
        return img

    a = make("float")
    # 2. weights at 8 bits, symmetric, one scale per output channel
    with torch.no_grad():
        nq = 0
        for _n, m in leaves:
            w = getattr(m, "weight", None)
            if isinstance(m, (torch.nn.Conv2d, torch.nn.Linear)) and w is not None:
                flat = w.view(w.shape[0], -1)
                sc = flat.abs().amax(1).clamp_min(1e-12) / 127.0
                q = torch.round(flat / sc[:, None]).clamp(-127, 127) * sc[:, None]
                w.copy_(q.view_as(w))
                nq += 1
    print(f"pesos a 8 bits: {nq} capas", flush=True)
    b = make("w8")
    # 3. plus each layer's output at 16 bits within its measured range (values outside it are cut)

    def a16(name):
        lo, hi = rng[name]
        step = max(hi - lo, 1e-8) / 65535.0

        def f(_m, _i, o):
            if torch.is_tensor(o):
                return torch.round((o.clamp(lo, hi) - lo) / step) * step + lo
        return f
    hs = [m.register_forward_hook(a16(n)) for n, m in leaves if n in rng]
    c = make("w8a16")
    for h in hs:
        h.remove()
    side = Image.new("RGB", (W * 3 // 2, H // 2))
    for i, im in enumerate([a, b, c]):
        side.paste(im.resize((W // 2, H // 2)), (i * W // 2, 0))
    side.save(os.path.join(cdir, "all.jpg"), quality=85)
    print("prueba de calidad lista: original | pesos 8 bits | pesos 8 + salidas 16 bits", flush=True)


def run(pipe, out):
    if os.environ.get("NPU_SDXL_CHECK") == "1":
        quality_check(pipe, out)
        return
    parts = [int(p) for p in (os.environ.get("NPU_PARTS") or "1,2,3,4").split(",") if p.strip()]
    u = pipe.unet.eval()
    print("SDXL para la NPU · partes", parts, flush=True)

    # calibration: real UNet inputs while making a few pictures (Lightning: few steps)
    calls = []

    def hook(_m, args, kwargs):
        smp = kwargs.get("sample", args[0] if args else None)
        t = kwargs.get("timestep", args[1] if len(args) > 1 else None)
        ac = kwargs.get("added_cond_kwargs") or {}
        calls.append({"sample": smp.detach().float().clone(),
                      "timestep": torch.tensor([float(t.reshape(-1)[0])], dtype=torch.float32),
                      "encoder_hidden_states": kwargs["encoder_hidden_states"].detach().float().clone(),
                      "text_embeds": ac["text_embeds"].detach().float().clone(),
                      "time_ids": ac["time_ids"].detach().float().clone()})
    hk = u.register_forward_pre_hook(hook, with_kwargs=True)
    prompts = ["portrait photo of a woman in a garden, natural light", "city street at night, neon lights, rain",
               "mountain lake at sunrise, landscape photography"]
    with torch.no_grad():
        for i, pr in enumerate(prompts):
            print(f"calibración {i + 1}/{len(prompts)}", flush=True)
            pipe(pr, negative_prompt="blurry, lowres", width=W, height=H, num_inference_steps=6, guidance_scale=2.0,
                 generator=torch.Generator().manual_seed(200 + i), output_type="latent")
    hk.remove()
    calls = [c for c in calls if c["sample"].shape[0] == 2]
    pick2 = [calls[int(round(k))] for k in np.linspace(0, len(calls) - 1, min(4, len(calls)))]
    # batch 1 (the phone runs the guided and the free pass one after the other): half the memory in
    # the quantizer, which ran out of it at 1024x1024 with batch 2; alternate guided/free samples
    pick = [{k: (v[j:j + 1] if k != "timestep" else v) for k, v in c.items()} for i, c in enumerate(pick2) for j in [i % 2]]
    print("muestras de calibración:", len(pick), "de", len(calls), "· pasos",
          [float(c["timestep"][0]) for c in pick], flush=True)

    # every part's inputs for those samples, and the check: the chain must give the UNet's result
    with torch.no_grad():
        per_part = {p: [] for p in PARTS}
        for k, x in enumerate(pick):
            ins, y = chain(u, x)
            for p in PARTS:
                per_part[p].append({n: v.detach().float().numpy().copy() for n, v in ins[p].items()})
            if k == 0:
                ref = u(x["sample"], x["timestep"], encoder_hidden_states=x["encoder_hidden_states"],
                        added_cond_kwargs={"text_embeds": x["text_embeds"], "time_ids": x["time_ids"]}, return_dict=False)[0]
                d = float((y - ref).abs().max())
                print(f"4 partes contra la UNet completa: diferencia máxima {d:.6f}", flush=True)
                if d > 1e-2:
                    raise SystemExit("Las partes no dan lo mismo que la UNet; no se publica nada")
    del calls
    gc.collect()

    import onnx
    done = []
    for p in parts:
        cls, inames, onames = PARTS[p]
        name = f"sdxl_p{p}"
        cdir = os.path.join(out, "calib_" + name)
        os.makedirs(cdir, exist_ok=True)
        lines = []
        for k, feeds in enumerate(per_part[p]):
            items = []
            for n in inames:
                f = os.path.join(cdir, f"{k:02d}_{n}.raw")
                feeds[n].astype(np.float32).tofile(f)
                items.append(f"{n}:={os.path.abspath(f)}")
            lines.append(" ".join(items))
        open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")
        args = tuple(torch.from_numpy(per_part[p][0][n]) for n in inames)
        tmp = os.path.join(out, "tmp_" + name)
        os.makedirs(tmp, exist_ok=True)
        with torch.no_grad():
            torch.onnx.export(cls(u).eval(), args, os.path.join(tmp, "m.onnx"), input_names=inames, output_names=onames,
                              opset_version=17, do_constant_folding=True)
        m = onnx.load(os.path.join(tmp, "m.onnx"), load_external_data=True)
        nparams = sum(int(np.prod(t.dims)) for t in m.graph.initializer)
        dst = os.path.join(out, name + ".onnx")
        onnx.save(m, dst, save_as_external_data=True, all_tensors_to_one_file=True, location=name + ".onnx.data")
        del m
        gc.collect()
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"{name}: {nparams / 1e9:.2f} mil millones de pesos · entradas {inames} · salidas {len(onames)}", flush=True)
        done.append(name)
    open(os.path.join(out, "sdxl_parts.txt"), "w").write("\n".join(done) + "\n")
    with open(os.path.join(out, "info.txt"), "a") as fh:
        fh.write("npu=1\nnpu_precision=w8a16\nnpu_sizes=1024x1024\nnpu_parts=4\n")
    print("SDXL NPU exportado:", done, flush=True)
