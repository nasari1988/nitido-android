// Checks a converted UNet the way the app runs it: MNN Express Module, shapes free, CPU.
// usage: mnn_check <unet.mnn> <mode 0|1|2> <sd15|sdxl> [lat_h lat_w ...]
// Exits 1 if loading or running fails or the output has NaN/Inf.
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/ExecutorScope.hpp>
#include <MNN/expr/Module.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <random>
#include <string>
#include <vector>

using namespace MNN;
using namespace MNN::Express;

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    if (argc < 4) { fprintf(stderr, "usage\n"); return 2; }
    std::string path = argv[1];
    int mode = atoi(argv[2]);
    bool sdxl = std::string(argv[3]) == "sdxl";
    std::vector<std::pair<int, int>> sizes;
    for (int i = 4; i + 1 < argc; i += 2) sizes.push_back({atoi(argv[i]), atoi(argv[i + 1])});
    if (sizes.empty()) sizes.push_back({64, 64});

    BackendConfig bc;
    bc.memory = BackendConfig::Memory_Low;
    bc.precision = BackendConfig::Precision_Low;
    ScheduleConfig cfg;
    cfg.type = MNN_FORWARD_CPU;
    cfg.numThread = 4;
    cfg.backendConfig = &bc;
    auto exe = ExecutorScope::Current();
    exe->lazyEval = false;
    exe->setGlobalExecutorConfig(cfg.type, bc, cfg.numThread);
    std::shared_ptr<Executor::RuntimeManager> rt(Executor::RuntimeManager::createRuntimeManager(cfg));
    rt->setHint(Interpreter::DYNAMIC_QUANT_OPTIONS, 2);

    Module::Config mc;
    mc.shapeMutable = true;
    std::vector<std::string> in = sdxl
        ? std::vector<std::string>{"sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"}
        : std::vector<std::string>{"sample", "timestep", "encoder_hidden_states"};
    std::shared_ptr<Module> m(Module::load(in, {"out_sample"}, path.c_str(), rt, &mc));
    if (!m) { printf("FALLO: no se pudo cargar %s\n", path.c_str()); return 1; }
    printf("cargado %s\n", path.c_str());

    int b = mode == 1 ? 3 : 2;
    int c = mode == 1 ? 8 : mode == 2 ? 9 : 4;
    int d = sdxl ? 2048 : 768;
    std::mt19937 rng(1);
    std::normal_distribution<float> nd(0.f, 1.f);
    for (auto [h, w] : sizes) {
        auto s = _Input({b, c, h, w}, NCHW, halide_type_of<float>());
        auto t = _Input({1}, NCHW, halide_type_of<int>());
        auto e = _Input({b, 77, d}, NCHW, halide_type_of<float>());
        float* sp = s->writeMap<float>();
        for (int i = 0; i < b * c * h * w; i++) sp[i] = nd(rng);
        t->writeMap<int>()[0] = 500;
        float* ep = e->writeMap<float>();
        for (int i = 0; i < b * 77 * d; i++) ep[i] = nd(rng) * 0.5f;
        std::vector<VARP> args{s, t, e};
        if (sdxl) {
            auto te = _Input({b, 1280}, NCHW, halide_type_of<float>());
            float* tp = te->writeMap<float>();
            for (int i = 0; i < b * 1280; i++) tp[i] = nd(rng) * 0.5f;
            auto ti = _Input({b, 6}, NCHW, halide_type_of<float>());
            float* ip = ti->writeMap<float>();
            const float tv[6] = {(float)h * 8, (float)w * 8, 0.f, 0.f, (float)h * 8, (float)w * 8};
            for (int r = 0; r < b; r++) for (int k = 0; k < 6; k++) ip[r * 6 + k] = tv[k];
            args.push_back(te);
            args.push_back(ti);
        }
        auto outs = m->onForward(args);
        if (outs.empty()) { printf("FALLO: sin salida en %dx%d\n", h * 8, w * 8); return 1; }
        auto o = _Convert(outs[0], NCHW);
        const float* op = o->readMap<float>();
        auto info = o->getInfo();
        if (!op || !info) { printf("FALLO: salida vacía en %dx%d\n", h * 8, w * 8); return 1; }
        size_t n = info->size;
        double sum = 0;
        size_t bad = 0;
        for (size_t i = 0; i < n; i++) { if (!std::isfinite(op[i])) bad++; else sum += std::fabs(op[i]); }
        printf("%dx%d: %zu valores, media |x| %.4f, malos %zu\n", w * 8, h * 8, n, sum / n, bad);
        if (bad || n != (size_t)b * 4 * h * w) { printf("FALLO: salida inválida\n"); return 1; }
    }
    printf("UNet correcta\n");
    return 0;
}
