"""
Step 2 of ci/qwenvl_export.py, in its own process (memory): int8 weights for the reader's parts, the int8
chain checked against the full model, then a DreamLite edit with the int8 reader next to the full one.

usage: qwenvl_quant.py <dreamlite-mobile dir> <sample photo> <out dir>
"""
import json, os, sys, time
import numpy as np

model_dir, sample, OUT = sys.argv[1:4]
TMP = os.path.join(OUT, "f32")
meta = json.load(open(os.path.join(OUT, "qvl_test.json")))
P0, DROP, H = meta["image_start"], meta["drop"], meta["hidden"]

import onnx, collections
import onnxruntime as ort
from onnxruntime.quantization.matmul_nbits_quantizer import MatMulNBitsQuantizer

def describe(m, tag):
    ops = collections.Counter(n.op_type for n in m.graph.node)
    inits = {i.name: int(np.prod(i.dims)) for i in m.graph.initializer}
    mm_w = sum(inits.get(n.input[1], 0) for n in m.graph.node if n.op_type == "MatMul" and len(n.input) > 1)
    print(f"  {tag}: {sum(inits.values()) / 1e6:.0f} M números guardados, {mm_w / 1e6:.0f} M en MatMul · "
          + ", ".join(f"{k} {v}" for k, v in ops.most_common(8)), flush=True)

for n in ["qvl_vision"] + [f"qvl_text_{k}" for k in range(4)]:
    src = os.path.join(TMP, n + ".onnx")
    m = onnx.load(src)
    describe(m, n + " (float)")
    # weight-only int4, blocks of 128, int8 math on the phone: the usual way to run LLMs on a CPU
    q = MatMulNBitsQuantizer(m, block_size=128, is_symmetric=True, accuracy_level=4)
    q.process()
    describe(q.model.model, n + " (int4)")
    q.model.save_model_to_file(os.path.join(OUT, n + ".onnx"), use_external_data_format=False)
    del m, q
    print(f"int4 {n}: {os.path.getsize(os.path.join(OUT, n + '.onnx')) / 1e6:.0f} MB", flush=True)

emb = np.fromfile(os.path.join(OUT, "qvl_embed.f16"), dtype=np.float16).reshape(-1, H)
px = np.load(os.path.join(TMP, "px.npy")); ids = np.load(os.path.join(TMP, "ids.npy")); pos = np.load(os.path.join(TMP, "pos.npy"))
ref = np.load(os.path.join(TMP, "ref.npy"))
so = ort.SessionOptions(); so.intra_op_num_threads = os.cpu_count() or 4
s = ort.InferenceSession(os.path.join(OUT, "qvl_vision.onnx"), so, providers=["CPUExecutionProvider"])
t = time.time(); im, dp = s.run(None, {"pixels": px}); tv = time.time() - t
h = emb[ids[0]].astype(np.float32)[None]
h[0, P0:P0 + 256] = im
tt = 0.0
for k in range(4):
    s = ort.InferenceSession(os.path.join(OUT, f"qvl_text_{k}.onnx"), so, providers=["CPUExecutionProvider"])
    feed = {"hidden": h, "pos": pos}
    if k == 0: feed["deep"] = dp
    t = time.time(); h = s.run(None, feed)[0]; tt += time.time() - t
h8 = h[0]
cos = (h8 * ref).sum(1) / (np.linalg.norm(h8, axis=1) * np.linalg.norm(ref, axis=1) + 1e-9)
c = float(cos[DROP:].mean())
print(f"int4 contra el modelo completo: parecido medio {c:.4f}, mínimo {cos[DROP:].min():.4f} "
      f"(foto {tv:.1f} s, texto {tt:.1f} s en la CPU del servidor)", flush=True)
meta["cos_server"] = c
json.dump(meta, open(os.path.join(OUT, "qvl_test.json"), "w"))
if c < 0.97:
    raise SystemExit("el lector en int4 se aleja demasiado del original")
del s

import torch
from PIL import Image
from diffusers import DreamLiteMobilePipeline
torch.set_num_threads(os.cpu_count() or 4)
pipe = DreamLiteMobilePipeline.from_pretrained(model_dir, torch_dtype=torch.float32)
orig_encode = pipe.encode_prompt
L = h8.shape[0]
def int8_encode(mode, prompts, device, dtype, image=None, **kw):
    return torch.from_numpy(h8[DROP:].copy())[None].to(dtype), torch.ones((1, L - DROP), dtype=torch.long)
instruction = meta["instruction"]
src = Image.open(sample).convert("RGB")
k = 1024 / max(src.size); src = src.resize((int(src.width * k) // 16 * 16, int(src.height * k) // 16 * 16), Image.LANCZOS)
a = pipe(prompt=instruction, image=src, num_inference_steps=4, generator=torch.Generator().manual_seed(7)).images[0]
pipe.encode_prompt = int8_encode
b = pipe(prompt=instruction, image=src, num_inference_steps=4, generator=torch.Generator().manual_seed(7)).images[0]
sheet = Image.new("RGB", (src.width * 3 + 20, src.height), "white")
sheet.paste(src, (0, 0)); sheet.paste(a.resize(src.size), (src.width + 10, 0)); sheet.paste(b.resize(src.size), (2 * src.width + 20, 0))
sheet.save(os.path.join(OUT, "qvl_check_a.jpg"), quality=88)
print("comparación guardada: original · lector completo · lector int8", flush=True)
