#!/usr/bin/env bash
# Mejorar video › Limpiar: RealBasicVSR for the phone's NPU (4 parts × 2 sizes), in ./out.
# No secrets; the weights come from OpenMMLab's server, sha256 fixed, checked before loading.
set -euo pipefail
cd "$(dirname "$0")/.."
URL=https://download.openmmlab.com/mmediting/restorers/real_basicvsr/realbasicvsr_c64b20_1x30x8_lr5e-5_150k_reds_20211104-52f77c2c.pth
SHA=52f77c2c835aaa3fe675b3959b2f85010a6c6f63f77f7e279394646e55a4e376
mkdir -p dl
curl -fsSL --retry 3 -o dl/rbvsr.pth "$URL"
echo "$SHA  dl/rbvsr.pth" | sha256sum -c - || { echo "::error::los pesos no son el archivo revisado"; exit 1; }

echo "::group::Memoria extra (swap)"
SWAPDIR=/mnt; [ -w /mnt ] || SWAPDIR=/
sudo fallocate -l 24G "$SWAPDIR/swapfile" && sudo chmod 600 "$SWAPDIR/swapfile" && sudo mkswap "$SWAPDIR/swapfile" && sudo swapon "$SWAPDIR/swapfile" || true
echo "::endgroup::"
echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "onnx==1.17.0" "onnxruntime==1.22.0" "numpy<2" pillow "imageio-ffmpeg==0.5.1"
echo "::endgroup::"

echo "::group::Exportar RealBasicVSR en piezas"
rm -rf onnx out; mkdir -p onnx out
.venv/bin/python -I ci/rbvsr_npu.py dl/rbvsr.pth onnx ci/testdata/old
echo "::endgroup::"

source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
for n in $(cat onnx/rb_parts.txt); do
  echo "::group::$n para la NPU"
  if NPU_SYM=0 NPU_PER_ROW=0 bash ci/npu_build.sh "$n" "onnx/$n.onnx" "onnx/calib_$n/list.txt"; then
    echo "$n: NPU lista"
  else
    echo "::error::$n no compiló para la NPU"
  fi
  rm -rf "onnx/$n.onnx" "onnx/calib_$n" qnn/*.dlc
  echo "::endgroup::"
done
printf "mode=limpiar\nversion=1\nmodel=realbasicvsr\nnpu=1\nsizes=640x360,360x640\nsha256=%s\n" "$SHA" > out/info.txt
(cd out && for f in *; do case "$f" in files.txt|check_*) continue ;; esac; echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
