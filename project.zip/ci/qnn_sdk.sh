#!/usr/bin/env bash
# Sets up Qualcomm QAIRT SDK (same version as the phone runtime). Sourced by npu_restore.sh.

# Same QNN version as the runtime ONNX Runtime 1.29 ships (com.qualcomm.qti:qnn-runtime 2.42.0):
# with a newer runtime, ONNX Runtime's device setup is rejected (QNN_DEVICE_ERROR_INVALID_CONFIG)
QV=2.42.0.251225
# Local Dream runs the "8 Gen 2" build (Hexagon v73, SoC id 43) on the Snapdragon 8s Gen 4
SOC_ID="${QNN_SOC_ID:-43}"
DSP_ARCH="${QNN_DSP_ARCH:-v73}"

echo "::group::Kit de Qualcomm (QAIRT $QV)"
if [ ! -d qairt_sdk ]; then
  for i in 1 2 3 4 5; do
    curl -fL --retry 5 --retry-delay 5 -o qairt.zip \
      "https://softwarecenter.qualcomm.com/api/download/software/sdks/Qualcomm_AI_Runtime_Community/All/$QV/v$QV.zip" && break
    echo "descarga interrumpida, reintento $i"; sleep 10
  done
  unzip -q qairt.zip -d qairt_sdk
  rm -f qairt.zip
fi
export QNN_SDK_ROOT="$(ls -d qairt_sdk/qairt/* | head -1)"
echo "SDK: $QNN_SDK_ROOT"
ls "$QNN_SDK_ROOT/bin/x86_64-linux-clang" | head -50
# the SDK's Python tools are built for Python 3.10 and link against libpython3.10.so
if ! ls /usr/lib/x86_64-linux-gnu/libpython3.10.so.1.0 >/dev/null 2>&1; then
  sudo add-apt-repository -y ppa:deadsnakes/ppa >/dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3.10 python3.10-venv python3.10-dev libpython3.10 >/dev/null
fi
# the SDK's tools are built with LLVM's C++ runtime (libc++, libc++abi, libunwind)
for p in libc++1 libc++abi1 libunwind-18 libc++1-18 libc++abi1-18 libunwind8; do
  sudo apt-get install -y -qq "$p" >/dev/null 2>&1 || echo "sin paquete $p"
done
[ -f "$QNN_SDK_ROOT/bin/check-linux-dependency.sh" ] && (yes | sudo bash "$QNN_SDK_ROOT/bin/check-linux-dependency.sh" >/dev/null 2>&1 || true)
# list anything still missing for the converter's native module
for so in $(find "$QNN_SDK_ROOT/lib/python" -name "libDlModelToolsPy310*.so" | head -3) "$QNN_SDK_ROOT/lib/x86_64-linux-clang/libQnnHtp.so"; do
  echo "== $so"; LD_LIBRARY_PATH="$QNN_SDK_ROOT/lib/x86_64-linux-clang:/usr/lib/llvm-18/lib" ldd "$so" | grep "not found" || echo "todo encontrado"
done
rm -rf .venvq
python3.10 -m venv .venvq
.venvq/bin/python -m pip install -q --upgrade pip
.venvq/bin/python -m pip install -q "numpy==1.26.4" "onnx==1.16.1" "protobuf==3.20.3" pyyaml packaging pandas
export PYTHONPATH="$QNN_SDK_ROOT/lib/python"
export LD_LIBRARY_PATH="$QNN_SDK_ROOT/lib/x86_64-linux-clang:/usr/lib/llvm-18/lib:${LD_LIBRARY_PATH:-}"
BIN="$QNN_SDK_ROOT/bin/x86_64-linux-clang"
LIB="$QNN_SDK_ROOT/lib/x86_64-linux-clang"
PY=$PWD/.venvq/bin/python
echo "::endgroup::"

