#!/usr/bin/env bash
# Builds Nítido on GitHub Actions. Called from .github/workflows/build.yml.
set -euo pipefail

echo "::group::Modelo Real-ESRGAN"
URL="https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/real_esrgan_general_x4v3/releases/v0.46.0/real_esrgan_general_x4v3-tflite-float.zip"
curl -fL --retry 3 -o model.zip "$URL"
unzip -o -q model.zip -d model
f=$(find model -name '*.tflite' | head -1)
test -n "$f"
mkdir -p app/src/main/assets
cp "$f" app/src/main/assets/realesrgan_x4.tflite
echo "::endgroup::"

bash ci/native.sh

echo "::group::APK"
gradle assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk Nitido.apk
echo "::endgroup::"
