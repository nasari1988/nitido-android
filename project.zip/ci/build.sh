#!/usr/bin/env bash
# Builds Nítido on GitHub Actions. Called from .github/workflows/build.yml.
set -euo pipefail

echo "::group::Modelo Real-ESRGAN"
URL="https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/real_esrgan_general_x4v3/releases/v0.46.0/real_esrgan_general_x4v3-tflite-float.zip"
curl -fL --retry 3 -o model.zip "$URL"
unzip -o -q model.zip -d model
f=$(find model -name '*.tflite' | head -1)
test -n "$f"
mkdir -p app/src/main/assets
cp "$f" app/src/main/assets/realesrgan_x4.tflite

# Real-ESRGAN x4plus (more detail, slower)
curl -fL --retry 3 -o x4plus.zip "https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/real_esrgan_x4plus/releases/v0.65.0/real_esrgan_x4plus-tflite-float.zip"
unzip -o -q x4plus.zip -d x4plus
f=$(find x4plus -name '*.tflite' | head -1)
test -n "$f"
cp "$f" app/src/main/assets/realesrgan_x4plus.tflite

# Qualcomm's own 8-bit versions of both, for the real NPU (Hexagon) through ONNX Runtime's QNN
# provider; the app compiles them on the phone the first time (small models). Optional: without
# them Mejorar's NPU option falls back to the GPU.
for pair in "x4v3 real_esrgan_general_x4v3" "x4plus real_esrgan_x4plus"; do
  set -- $pair
  rm -rf "npu_$1" && mkdir -p "npu_$1"
  if curl -fL --retry 3 -o "npu_$1.zip" "https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/$2/releases/v0.65.0/$2-onnx-w8a8.zip"; then
    unzip -o -q "npu_$1.zip" -d "npu_$1"
    echo "contenido de $2-onnx-w8a8:"; find "npu_$1" -type f | head -20
    m=$(find "npu_$1" -name '*.onnx' | head -1)
    if [ -n "$m" ]; then
      cat "$(dirname "$m")/metadata.json" 2>/dev/null | head -c 2000; echo
      # integer picture in/out -> float in/out (the app sends 0..1 floats)
      python3 -m pip install -q onnx >/dev/null 2>&1 || pip3 install -q --break-system-packages onnx >/dev/null 2>&1 || true
      python3 ci/npu_float_io.py "$m" || echo "no se pudo revisar la entrada/salida de $m"
      mkdir -p "app/src/main/assets/npu/$1"
      cp "$(dirname "$m")"/* "app/src/main/assets/npu/$1/"
      ls -la "app/src/main/assets/npu/$1"
    fi
  else
    echo "sin versión NPU de $2"
  fi
done

# NAFNet (GoPro) to remove blur and camera shake
curl -fL --retry 3 -o app/src/main/assets/nafnet_deblur.tflite \
  "https://huggingface.co/litert-community/NAFNet-GoPro-width32-LiteRT/resolve/main/nafnet_fp16.tflite"

# MediaPipe: tap-to-select (Magic Touch) and hair / skin / clothes segmentation. Optional:
# if a download fails the app still builds and those buttons explain they are missing.
curl -fL --retry 3 -o app/src/main/assets/magic_touch.tflite \
  "https://storage.googleapis.com/mediapipe-models/interactive_segmenter/magic_touch/float32/1/magic_touch.tflite" \
  || rm -f app/src/main/assets/magic_touch.tflite
curl -fL --retry 3 -o app/src/main/assets/selfie_multiclass.tflite \
  "https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/latest/selfie_multiclass_256x256.tflite" \
  || rm -f app/src/main/assets/selfie_multiclass.tflite
ls -la app/src/main/assets
echo "::endgroup::"

bash ci/native.sh

echo "::group::Bibliotecas de la NPU (QNN 2.51)"
# Same version the NPU models are compiled with (published by "Convertir modelo"). If they are not
# there yet, the app keeps the QNN libraries that come with ONNX Runtime.
R=https://github.com/nasari1988/nitido-android/releases/download/qnn-runtime-2.51
mkdir -p qnn251
# disabled: ONNX Runtime 1.29 only works with its own QNN 2.42 (models are compiled with 2.42 too)
ok=0
if false; then
for f in libQnnHtp.so libQnnSystem.so libQnnHtpV73Stub.so libQnnHtpV75Stub.so libQnnHtpV79Stub.so \
         libQnnHtpV73Skel.so libQnnHtpV75Skel.so libQnnHtpV79Skel.so; do
  curl -fsL --retry 3 -o "qnn251/$f" "$R/$f" || { ok=0; break; }
done
fi
if [ "$ok" = 1 ]; then
  mkdir -p app/src/main/jniLibs/arm64-v8a app/src/main/qnnskel/qnn
  cp qnn251/libQnnHtp.so qnn251/libQnnSystem.so qnn251/libQnnHtpV7*Stub.so app/src/main/jniLibs/arm64-v8a/
  cp qnn251/*Skel.so app/src/main/qnnskel/qnn/
  touch app/src/main/qnnskel/.qnn251
  echo "usando QNN 2.51"
else
  echo "QNN 2.51 aún no publicado: se usan las de ONNX Runtime"
fi
ls -la qnn251 || true
echo "::endgroup::"

echo "::group::APK"
gradle assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk Nitido.apk
echo "::endgroup::"
