#!/usr/bin/env bash
# Builds Nítido on GitHub Actions. Called from .github/workflows/build.yml.
set -euo pipefail

echo "::group::Modelo Real-ESRGAN"
URL="https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/real_esrgan_general_x4v3/releases/v0.46.0/real_esrgan_general_x4v3-tflite-float.zip"
curl -fL --retry 3 -o model.zip "$URL"
unzip -o -q model.zip -d model
f=$(find model -name '*.tflite' | head -1)
test -n "$f"
mkdir -p app/src/main/assets
cp "$f" app/src/main/assets/realesrgan_x4.tflite
echo "::endgroup::"

echo "::group::Motor Stable Diffusion (MNN 3.4.0)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-}}"
test -d "$NDK"
git clone -q --depth 1 --branch 3.4.0 https://github.com/alibaba/MNN.git mnn
# MNN 3.4.0 forgets <cstdint> in the diffusion tokenizer
sed -i 's/#include <vector>/#include <cstdint>\n#include <vector>/' mnn/transformers/diffusion/engine/src/tokenizer.hpp
cmake -S mnn -B mnn/build-android \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_STL=c++_static -DANDROID_PLATFORM=android-29 \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.10 -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
  -DMNN_BUILD_FOR_ANDROID_COMMAND=ON -DMNN_USE_LOGCAT=OFF \
  -DMNN_BUILD_SHARED_LIBS=OFF -DMNN_SEP_BUILD=OFF -DMNN_ARM82=ON \
  -DMNN_LOW_MEMORY=ON -DMNN_SUPPORT_TRANSFORMER_FUSE=ON -DMNN_OPENCL=ON \
  -DMNN_BUILD_DIFFUSION=ON -DMNN_BUILD_LLM=ON -DMNN_BUILD_OPENCV=ON -DMNN_IMGCODECS=ON
cmake --build mnn/build-android --target MNN -j"$(nproc)"
ls -la mnn/build-android/*.a
mkdir -p app/src/main/jniLibs/arm64-v8a
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
"$TC/aarch64-linux-android29-clang++" -shared -fPIC -O2 -std=c++17 \
  app/src/main/cpp/sd_jni.cpp \
  -Imnn/include -Imnn/transformers/diffusion/engine/include -Imnn/tools/cv/include \
  -Wl,--whole-archive mnn/build-android/libMNN.a -Wl,--no-whole-archive \
  -static-libstdc++ -llog -landroid -lnativewindow -ldl -lm \
  -Wl,--no-undefined -Wl,-z,max-page-size=16384 -Wl,--gc-sections \
  -o app/src/main/jniLibs/arm64-v8a/libsdjni.so
"$TC/llvm-strip" --strip-unneeded app/src/main/jniLibs/arm64-v8a/libsdjni.so
ls -la app/src/main/jniLibs/arm64-v8a
echo "::endgroup::"

echo "::group::APK"
gradle assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/app-release.apk Nitido.apk
echo "::endgroup::"
