"""
DreamLite-mobile (ByteDance; weights CC BY-NC 4.0) for the phone: the editing UNet for the NPU, the tiny
VAE (TAESDXL) for the processor, the tokenizer files and test data.

The phone already has the instruction reader (Qwen3-VL, release modelo-lector-dreamlite). This adds the
rest of the edit: [photo latents | noise] side by side -> UNet x4 (flow matching, no CFG) -> decode.

Calibration and reference come from the real pipeline run on the server's CPU (diffusers, pinned).

usage: dreamlite_npu_export.py <model dir> <photos dir> <out> <W> <H>
-> <out>/dl_unet[_WxH].onnx (+.data), calib_dl_unet[_WxH]/list.txt,
   dl_vae_enc.onnx, dl_vae_dec.onnx, dl_tok_vocab.json, dl_tok_merges.txt, dl_test[_WxH].json/.f16/.png
"""
import glob
import json
import math
import os
import shutil
import sys
import time

import numpy as np
import torch
from PIL import Image

model_dir, photos, out, W, H = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5])
TAG = "" if (W, H) == (1024, 1024) else f"_{W}x{H}"
NAME = "dl_unet" + TAG
LMAX = 352                    # instruction tokens after the template's first 64 (image 256 + ~90 of text)
os.makedirs(out, exist_ok=True)
torch.set_grad_enabled(False)
torch.set_num_threads(os.cpu_count() or 4)

from diffusers import DreamLiteMobilePipeline
t0 = time.time()
pipe = DreamLiteMobilePipeline.from_pretrained(model_dir, torch_dtype=torch.float32)
print(f"DreamLite cargado en {time.time() - t0:.0f} s · {W}x{H}", flush=True)
unet = pipe.unet.eval()

# ---- capture what the UNet sees during real edits ----
cap = []
orig_forward = unet.forward


def spy(sample, timestep, encoder_hidden_states=None, encoder_attention_mask=None, added_cond_kwargs=None, **kw):
    o = orig_forward(sample, timestep, encoder_hidden_states=encoder_hidden_states,
                     encoder_attention_mask=encoder_attention_mask, added_cond_kwargs=added_cond_kwargs, **kw)
    cap.append({"sample": sample.clone(), "timestep": timestep.clone().float().reshape(1),
                "ehs": encoder_hidden_states.clone(), "mask": encoder_attention_mask.clone().float(),
                "time_ids": added_cond_kwargs["time_ids"].clone().float(), "out": o[0].clone()})
    return o


unet.forward = spy
EDITS = [("a.png", "give him a red baseball cap"), ("c.png", "change his clothes to a blue suit"),
         ("e.png", "make the umbrella yellow"), ("h.png", "make him smile"),
         ("b.png", "turn the dress into a red evening dress"), ("g.png", "make it winter with snow falling")]
files = {os.path.basename(f) for f in glob.glob(os.path.join(photos, "*.png"))}
EDITS = [(f, p) for f, p in EDITS if f in files] or [(sorted(files)[0], "give him a red baseball cap")]


def fit(im):
    k = max(W / im.width, H / im.height)
    im = im.resize((max(W, round(im.width * k)), max(H, round(im.height * k))), Image.LANCZOS)
    l, t = (im.width - W) // 2, (im.height - H) // 2
    return im.crop((l, t, l + W, t + H))


ref = None
for n, (f, prompt) in enumerate(EDITS):
    src = fit(Image.open(os.path.join(photos, f)).convert("RGB"))
    g = torch.Generator().manual_seed(7)
    first = len(cap)
    t = time.time()
    res = pipe(prompt=prompt, image=src, height=H, width=W, num_inference_steps=4, generator=g).images[0]
    print(f"{f}: «{prompt}» en {time.time() - t:.0f} s · {len(cap) - first} pasos", flush=True)
    if n == 0:
        ref = {"photo": src, "result": res, "prompt": prompt, "steps": cap[first:first + 4]}
        src.save(os.path.join(out, f"dl_test_in{TAG}.png"))
        res.save(os.path.join(out, f"dl_test_out{TAG}.png"))
unet.forward = orig_forward
print("pasos capturados:", len(cap), flush=True)
L = cap[0]["ehs"].shape[1]
print(f"texto para el UNet: {L} piezas (caben {LMAX}) · ehs {list(cap[0]['ehs'].shape)} · sample {list(cap[0]['sample'].shape)}", flush=True)
assert all(c["ehs"].shape[1] <= LMAX for c in cap), "una instrucción no cabe en LMAX"


def pad(c):
    e = torch.zeros(1, LMAX, c["ehs"].shape[2]); e[:, :c["ehs"].shape[1]] = c["ehs"]
    m = torch.zeros(1, LMAX); m[:, :c["mask"].shape[1]] = c["mask"]
    return e, m


# ---- the part for the NPU: fixed text length (padding masked), output cut to the edited half ----
class Edit(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, sample, timestep, ehs, mask, time_ids):
        o = self.u(sample, timestep, encoder_hidden_states=ehs, encoder_attention_mask=mask,
                   added_cond_kwargs={"time_ids": time_ids}, return_dict=False)[0]
        return o[..., : sample.shape[-1] // 2]


m = Edit(unet).eval()
c0 = cap[0]
e0, k0 = pad(c0)
mine = m(c0["sample"], c0["timestep"], e0, k0, c0["time_ids"])
want = c0["out"][..., : c0["sample"].shape[-1] // 2]
diff = float((mine - want).abs().max()); sd = float(want.std())
print(f"UNet con el texto relleno a {LMAX} contra el original: diferencia máx {diff:.5f} (desv. {sd:.3f})", flush=True)
if diff > 0.02 * sd + 1e-3:
    raise SystemExit("El relleno del texto cambia el resultado; no se publica nada")

# calibration files
INS = ["sample", "timestep", "ehs", "mask", "time_ids"]
cdir = os.path.join(out, "calib_" + NAME)
os.makedirs(cdir, exist_ok=True)
lines = []
for k, c in enumerate(cap):
    e, mk = pad(c)
    vals = {"sample": c["sample"], "timestep": c["timestep"], "ehs": e, "mask": mk, "time_ids": c["time_ids"]}
    items = []
    for nm in INS:
        p = os.path.join(cdir, f"{k:02d}_{nm}.raw")
        vals[nm].numpy().astype(np.float32).tofile(p)
        items.append(f"{nm}:={os.path.abspath(p)}")
    lines.append(" ".join(items))
open(os.path.join(cdir, "list.txt"), "w").write("\n".join(lines) + "\n")

# test data for the phone: the first edit's 4 steps (inputs and outputs), half precision
st = ref["steps"]
blob = []
meta = {"size": [W, H], "lmax": LMAX, "prompt": ref["prompt"], "steps": []}
for c in st:
    e, mk = pad(c)
    rec = {"timestep": float(c["timestep"][0]), "time_ids": c["time_ids"][0].tolist(), "valid": int(mk.sum())}
    for nm, v in (("sample", c["sample"]), ("ehs", e), ("out", c["out"][..., : c["sample"].shape[-1] // 2])):
        a = v.numpy().astype(np.float16).ravel()
        rec[nm] = [sum(len(b) for b in blob), int(a.size)]
        blob.append(a)
    meta["steps"].append(rec)
np.concatenate(blob).tofile(os.path.join(out, f"dl_test{TAG}.f16"))
sched = pipe.scheduler
meta["scheduler"] = {k: sched.config.get(k) for k in ("shift", "base_shift", "max_shift", "base_image_seq_len",
                                                       "max_image_seq_len", "time_shift_type", "use_dynamic_shifting")}
meta["timesteps"] = [m_["timestep"] for m_ in meta["steps"]]

# ---- the tokenizer: files, the fixed ids around the instruction, and checks for the phone ----
tok = pipe.processor.tokenizer
tpl = pipe.prompt_template_encode_edit
pre_text = "[Edit]: A diptych with two side-by-side images of the same scene. Compared to the right side, the left one has"
head, tail = tpl.split("{}")
probe = pipe.processor(text=[tpl.format(pre_text + " give him a red baseball cap")], images=[ref["photo"].resize((512, 512))],
                       padding=True, return_tensors="pt")
full = probe["input_ids"][0].tolist()
img_id = pipe.text_encoder.config.image_token_id
P0 = full.index(img_id); NIMG = full.count(img_id)
tail_ids = tok(tail, add_special_tokens=False)["input_ids"]
instr_ids = tok(" give him a red baseball cap", add_special_tokens=False)["input_ids"]
before = full[: len(full) - len(tail_ids) - len(instr_ids)]
assert before + instr_ids + tail_ids == full, "las piezas fijas no reconstruyen la plantilla"
meta["tokens"] = {"before": before, "tail": tail_ids, "image_start": P0, "image_count": NIMG, "image_id": img_id,
                  "drop": pipe.prompt_template_encode_edit_start_idx}
checks = ["give him a red baseball cap", "turn the dress into sportswear", "make it snowy, add snow",
          "Change the 2 dogs' collars to RED!", "make the woman's hair blonde and curly", "a cat — très chic, 100%"]
meta["token_checks"] = [{"text": " " + s, "ids": tok(" " + s, add_special_tokens=False)["input_ids"]} for s in checks]
shutil.copy(os.path.join(model_dir, "processor", "vocab.json"), os.path.join(out, "dl_tok_vocab.json"))
shutil.copy(os.path.join(model_dir, "processor", "merges.txt"), os.path.join(out, "dl_tok_merges.txt"))
json.dump(meta, open(os.path.join(out, f"dl_test{TAG}.json"), "w"))
print(f"plantilla: {len(before)} piezas antes de la instrucción, foto en {P0} ({NIMG}), {len(tail_ids)} después", flush=True)

# ---- the tiny VAE (once, any size): pixels 0..1 <-> latents ----
vae = pipe.vae.eval()


class Enc(torch.nn.Module):
    def __init__(self, v):
        super().__init__(); self.v = v
    def forward(self, px):
        return self.v.encode(px * 2 - 1).latents


class Dec(torch.nn.Module):
    def __init__(self, v):
        super().__init__(); self.v = v
    def forward(self, z):
        return (self.v.decode(z, return_dict=False)[0].clamp(-1, 1) + 1) / 2


px = torch.from_numpy(np.asarray(ref["photo"], np.float32) / 255).permute(2, 0, 1)[None]
if not os.path.exists(os.path.join(out, "dl_vae_enc.onnx")):
    torch.onnx.export(Enc(vae), (px,), os.path.join(out, "dl_vae_enc.onnx"), input_names=["pixels"], output_names=["latents"],
                      dynamic_axes={"pixels": {2: "h", 3: "w"}, "latents": {2: "lh", 3: "lw"}}, opset_version=17)
    z = Enc(vae)(px)
    torch.onnx.export(Dec(vae), (z,), os.path.join(out, "dl_vae_dec.onnx"), input_names=["latents"], output_names=["pixels"],
                      dynamic_axes={"latents": {2: "lh", 3: "lw"}, "pixels": {2: "h", 3: "w"}}, opset_version=17)
    print("VAE pequeño exportado", flush=True)
del pipe

# ---- export the UNet ----
import onnx
tmp = os.path.join(out, "tmp_" + NAME)
os.makedirs(tmp, exist_ok=True)
torch.onnx.export(m, (c0["sample"], c0["timestep"], e0, k0, c0["time_ids"]), os.path.join(tmp, "m.onnx"),
                  input_names=INS, output_names=["noise"], opset_version=17, do_constant_folding=True, dynamo=False)
mo = onnx.load(os.path.join(tmp, "m.onnx"), load_external_data=True)
npar = sum(int(np.prod(t_.dims)) for t_ in mo.graph.initializer)
onnx.save(mo, os.path.join(out, NAME + ".onnx"), save_as_external_data=True, all_tensors_to_one_file=True, location=NAME + ".onnx.data")
shutil.rmtree(tmp, ignore_errors=True)
print(f"{NAME}: {npar / 1e9:.2f} mil millones de pesos exportados", flush=True)
