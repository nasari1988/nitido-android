"""Export an SD 1.5-family model to ONNX pieces the app's MNN engine understands.

usage: export_model.py <model_id> <onnx_dir>

Pieces (all fixed 512x512):
  text_encoder/model.onnx  input_ids [2,77] int32 -> last_hidden_state, pooler_output
  unet/model.onnx          sample [2,4,64,64] (pix2pix: [3,8,64,64]), timestep [1] int32,
                           encoder_hidden_states [B,77,768] -> out_sample
  vae_decoder/model.onnx   latent_sample [1,4,64,64] -> sample
  vae_encoder/model.onnx   sample [1,3,512,512] -> latent (mean, unscaled)
plus the CLIP tokenizer files (vocab.json, merges.txt) in onnx_dir.
"""
import gc
import os
import sys

import torch
import safetensors.torch  # noqa: F401  (diffusers expects this submodule loaded)
from diffusers import (AutoencoderKL, StableDiffusionInstructPix2PixPipeline,
                       StableDiffusionPipeline)

SD15 = "stable-diffusion-v1-5/stable-diffusion-v1-5"
MODELS = {
    "dreamshaper8": dict(repo="Lykon/dreamshaper-8"),
    "realistic": dict(repo="SG161222/Realistic_Vision_V5.1_noVAE", vae="stabilityai/sd-vae-ft-mse"),
    "anime": dict(single="https://huggingface.co/Lykon/AnyLoRA/blob/main/AAM_Anylora_AnimeMix.safetensors"),
    "pix2pix": dict(repo="timbrooks/instruct-pix2pix", pix2pix=True),
}

model_id, out = sys.argv[1], sys.argv[2]
cfg = MODELS[model_id]
os.makedirs(out, exist_ok=True)
f32 = torch.float32


def load():
    if cfg.get("single"):
        return StableDiffusionPipeline.from_single_file(
            cfg["single"], config=SD15, torch_dtype=f32, load_safety_checker=False)
    cls = StableDiffusionInstructPix2PixPipeline if cfg.get("pix2pix") else StableDiffusionPipeline
    try:
        return cls.from_pretrained(cfg["repo"], torch_dtype=f32, safety_checker=None, requires_safety_checker=False)
    except Exception as e:  # some repos only ship fp16 weights
        print("retrying with fp16 variant:", e)
        return cls.from_pretrained(cfg["repo"], variant="fp16", torch_dtype=f32,
                                   safety_checker=None, requires_safety_checker=False)


pipe = load()
if cfg.get("vae"):
    pipe.vae = AutoencoderKL.from_pretrained(cfg["vae"], torch_dtype=f32)
pipe.to("cpu")
pipe.tokenizer.save_pretrained(out)


def export(module, args, name, inputs, outputs):
    path = os.path.join(out, name, "model.onnx")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with torch.no_grad():
        torch.onnx.export(module.eval(), args, path, input_names=inputs, output_names=outputs,
                          opset_version=17, do_constant_folding=True)
    print("exported", path)


# text encoder
class TextEncoder(torch.nn.Module):
    def __init__(self, te):
        super().__init__()
        self.te = te

    def forward(self, input_ids):
        o = self.te(input_ids.to(torch.int64))
        return o.last_hidden_state, o.pooler_output


ids = torch.zeros(2, 77, dtype=torch.int32)
export(TextEncoder(pipe.text_encoder), (ids,), "text_encoder", ["input_ids"], ["last_hidden_state", "pooler_output"])
pipe.text_encoder = None
gc.collect()


# unet
class Unet(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, sample, timestep, encoder_hidden_states):
        return self.u(sample, timestep, encoder_hidden_states, return_dict=False)[0]


b, c = (3, 8) if cfg.get("pix2pix") else (2, 4)
export(Unet(pipe.unet),
       (torch.randn(b, c, 64, 64), torch.tensor([500], dtype=torch.int32), torch.randn(b, 77, 768)),
       "unet", ["sample", "timestep", "encoder_hidden_states"], ["out_sample"])
pipe.unet = None
gc.collect()

# UNet is > 2GB, so torch writes many external tensor files; collate them into one.
import onnx  # noqa: E402
import shutil  # noqa: E402
unet_path = os.path.join(out, "unet", "model.onnx")
m = onnx.load(unet_path)
shutil.rmtree(os.path.dirname(unet_path))
os.makedirs(os.path.dirname(unet_path))
onnx.save_model(m, unet_path, save_as_external_data=True, all_tensors_to_one_file=True,
                location="weights.pb", convert_attribute=False)
del m
gc.collect()


# vae
class Decoder(torch.nn.Module):
    def __init__(self, v):
        super().__init__()
        self.v = v

    def forward(self, latent_sample):
        return self.v.decode(latent_sample, return_dict=False)[0]


class Encoder(torch.nn.Module):
    def __init__(self, v):
        super().__init__()
        self.encoder = v.encoder
        self.quant_conv = v.quant_conv

    def forward(self, sample):
        return self.quant_conv(self.encoder(sample))[:, :4]


export(Decoder(pipe.vae), (torch.randn(1, 4, 64, 64),), "vae_decoder", ["latent_sample"], ["sample"])
export(Encoder(pipe.vae), (torch.randn(1, 3, 512, 512),), "vae_encoder", ["sample"], ["latent"])
print("done")
