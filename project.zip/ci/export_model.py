"""Export a Stable Diffusion model to ONNX pieces the app's MNN engine understands.

usage: export_model.py <model_id> <onnx_dir> [model link] [lora link] [lora weight]

Supports the SD 1.5 family (incl. InstructPix2Pix) and SDXL. The architecture is detected.
With a link, any compatible model can be converted: a Hugging Face repo page
(huggingface.co/owner/name) or a single .safetensors/.ckpt file. A LoRA (Hugging Face file or
repo, or any direct download link) can be merged ("baked") into the model at a given weight.

Pieces (image size free, multiples of 64):
  SD 1.5:
    text_encoder  input_ids [2,77] int32 -> last_hidden_state [2,77,768], pooler_output
    unet          sample [2,4,h,w] (pix2pix: [3,8,h,w]), timestep [1], encoder_hidden_states -> out_sample
  SDXL:
    text_encoder  input_ids [2,77] int32 -> prompt_embeds [2,77,2048], pooled [2,1280]
    unet          sample [2,4,h,w], timestep [1], encoder_hidden_states [2,77,2048],
                  text_embeds [2,1280], time_ids [2,6] -> out_sample
  vae_decoder     latent_sample [1,4,h,w] -> sample [1,3,8h,8w]
  vae_encoder     sample [1,3,H,W] -> latent (mean, unscaled)
plus the CLIP tokenizer files (vocab.json, merges.txt) and info.txt.
"""
import gc
import json
import math
import os
import sys
import urllib.request

import torch
import torch.nn.functional as F
import safetensors.torch  # noqa: F401  (diffusers expects this submodule loaded)
from diffusers import (AutoencoderKL, StableDiffusionInstructPix2PixPipeline,
                       StableDiffusionPipeline, StableDiffusionXLPipeline)
from huggingface_hub import hf_hub_download

SD15 = "stable-diffusion-v1-5/stable-diffusion-v1-5"
SDXL = "stabilityai/stable-diffusion-xl-base-1.0"
MODELS = {
    "dreamshaper8": dict(repo="Lykon/dreamshaper-8"),
    "realistic": dict(repo="SG161222/Realistic_Vision_V5.1_noVAE", vae="stabilityai/sd-vae-ft-mse"),
    "anime": dict(single="https://huggingface.co/Lykon/AnyLoRA/blob/main/AAM_Anylora_AnimeMix.safetensors"),
    "pix2pix": dict(repo="timbrooks/instruct-pix2pix", pix2pix=True),
}


# torch's ONNX exporter can't translate scaled_dot_product_attention when a float
# `scale` is passed (as transformers' CLIP does). Swap in the plain math version,
# which exports cleanly and is numerically the same.
def _sdpa(query, key, value, attn_mask=None, dropout_p=0.0, is_causal=False, scale=None, **_):
    s = scale if scale is not None else 1.0 / math.sqrt(query.size(-1))
    w = torch.matmul(query, key.transpose(-2, -1)) * s
    if is_causal:
        L, S = query.size(-2), key.size(-2)
        causal = torch.ones(L, S, dtype=torch.bool, device=query.device).tril()
        w = w.masked_fill(~causal, float("-inf"))
    if attn_mask is not None:
        if attn_mask.dtype == torch.bool:
            w = w.masked_fill(~attn_mask, float("-inf"))
        else:
            w = w + attn_mask
    return torch.matmul(torch.softmax(w, dim=-1), value)


F.scaled_dot_product_attention = _sdpa
torch.nn.functional.scaled_dot_product_attention = _sdpa

model_id, out = sys.argv[1], sys.argv[2]
link = sys.argv[3].strip() if len(sys.argv) > 3 else ""
lora = sys.argv[4].strip() if len(sys.argv) > 4 else ""
lora_w = float(sys.argv[5]) if len(sys.argv) > 5 and sys.argv[5].strip() else 0.8
os.makedirs(out, exist_ok=True)
f32 = torch.float32


def hf_parts(url):
    """(repo, filename or None) from a Hugging Face URL."""
    path = url.split("huggingface.co/")[-1]
    p = path.split("/")
    repo = "/".join(p[:2])
    if len(p) > 4 and p[2] in ("blob", "resolve"):
        return repo, "/".join(p[4:])
    return repo, None


def fetch_file(url, dest_dir):
    """Download a single file (Hugging Face or any direct link) and return its local path."""
    url = url.split("?")[0] if "huggingface.co" in url else url
    if "huggingface.co" in url:
        repo, fname = hf_parts(url)
        return hf_hub_download(repo, fname)
    os.makedirs(dest_dir, exist_ok=True)
    path = os.path.join(dest_dir, "download.safetensors")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as r, open(path, "wb") as fh:
        while True:
            chunk = r.read(1 << 22)
            if not chunk:
                break
            fh.write(chunk)
    return path


# ---------- what to convert ----------
if link:
    url = link.split("?")[0].rstrip("/")
    if url.endswith((".safetensors", ".ckpt")) or "huggingface.co" not in url:
        cfg = dict(single=url)
    else:
        cfg = dict(repo=hf_parts(url)[0])
    # "noVAE" models ship without their color decoder; use the standard improved one
    if "novae" in url.lower():
        cfg["vae"] = "stabilityai/sd-vae-ft-mse"
else:
    cfg = dict(MODELS[model_id[:-3] if model_id.endswith("-16") else model_id])


def detect_arch():
    if cfg.get("single"):
        cfg["local"] = fetch_file(cfg["single"], "dl_model")
        if cfg["local"].endswith(".safetensors"):
            from safetensors import safe_open
            with safe_open(cfg["local"], "pt") as fh:
                keys = list(fh.keys())
            if any(k.startswith("conditioner.embedders.1") for k in keys):
                return "sdxl"
        return "sd15"
    try:
        idx = json.load(open(hf_hub_download(cfg["repo"], "model_index.json")))
        if "XL" in idx.get("_class_name", ""):
            return "sdxl"
    except Exception as e:
        print("model_index.json not readable:", e)
    return "sd15"


arch = detect_arch()
print("Arquitectura:", arch)


def load():
    if arch == "sdxl":
        if cfg.get("single"):
            return StableDiffusionXLPipeline.from_single_file(cfg["local"], config=SDXL, torch_dtype=f32)
        try:
            return StableDiffusionXLPipeline.from_pretrained(cfg["repo"], torch_dtype=f32)
        except Exception as e:
            print("retrying with fp16 variant:", e)
            return StableDiffusionXLPipeline.from_pretrained(cfg["repo"], variant="fp16", torch_dtype=f32)
    if cfg.get("single"):
        return StableDiffusionPipeline.from_single_file(
            cfg["local"], config=SD15, torch_dtype=f32, load_safety_checker=False)
    cls = StableDiffusionInstructPix2PixPipeline if cfg.get("pix2pix") else StableDiffusionPipeline
    try:
        return cls.from_pretrained(cfg["repo"], torch_dtype=f32, safety_checker=None, requires_safety_checker=False)
    except Exception as e:  # some repos only ship fp16 weights
        print("retrying with fp16 variant:", e)
        return cls.from_pretrained(cfg["repo"], variant="fp16", torch_dtype=f32,
                                   safety_checker=None, requires_safety_checker=False)


pipe = load()
in_ch = pipe.unet.config.in_channels
cross = pipe.unet.config.cross_attention_dim
if arch == "sd15" and cross != 768:
    sys.exit("Este modelo no es SD 1.5 ni SDXL (parece SD 2, SD 3, Flux u otro). No está soportado.")
if in_ch == 9:
    sys.exit("Este es un modelo de inpainting, todavía no está soportado. Elige la versión normal del modelo.")
if in_ch == 8 and arch == "sd15":
    cfg["pix2pix"] = True
elif in_ch != 4:
    sys.exit(f"Modelo no soportado (in_channels={in_ch}).")

# ---------- LoRA ----------
if lora:
    print(f"Mezclando LoRA {lora} con peso {lora_w}")
    lpath = fetch_file(lora, "dl_lora")
    pipe.load_lora_weights(os.path.dirname(lpath), weight_name=os.path.basename(lpath), adapter_name="lora")
    pipe.fuse_lora(lora_scale=lora_w)
    pipe.unload_lora_weights()

# SDXL's own VAE overflows in 16-bit (the phone's GPU math); use the fixed one.
if arch == "sdxl":
    cfg["vae"] = "madebyollin/sdxl-vae-fp16-fix"
if cfg.get("vae"):
    pipe.vae = AutoencoderKL.from_pretrained(cfg["vae"], torch_dtype=f32)
pipe.to("cpu")
pipe.tokenizer.save_pretrained(out)
# everything is in memory now; free the disk for the exported files
import shutil  # noqa: E402
shutil.rmtree(os.path.expanduser("~/.cache/huggingface"), ignore_errors=True)
shutil.rmtree("dl_model", ignore_errors=True)
shutil.rmtree("dl_lora", ignore_errors=True)
scale = pipe.vae.config.scaling_factor

with open(os.path.join(out, "info.txt"), "w") as fh:
    fh.write("mode=%d\n" % (1 if cfg.get("pix2pix") else 0))
    fh.write("dynamic=1\n")
    fh.write("arch=%s\n" % arch)
    fh.write("scale=%g\n" % scale)
    fh.write("source=%s\n" % (link or cfg.get("repo") or cfg.get("single") or model_id))
    fh.write("precision=%s\n" % os.environ.get("PRECISION", "8"))
    if lora:
        fh.write("lora=%s\n" % lora)
        fh.write("lora_weight=%g\n" % lora_w)


def export(module, args, name, inputs, outputs, dynamic_axes=None):
    path = os.path.join(out, name, "model.onnx")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with torch.no_grad():
        torch.onnx.export(module.eval(), args, path, input_names=inputs, output_names=outputs,
                          opset_version=17, do_constant_folding=True, dynamic_axes=dynamic_axes)
    print("exported", path)


# ---------- text encoder(s) ----------
class TextEncoder(torch.nn.Module):
    def __init__(self, te):
        super().__init__()
        self.te = te

    def forward(self, input_ids):
        o = self.te(input_ids.to(torch.int64))
        return o.last_hidden_state, o.pooler_output


class TextEncoderXL(torch.nn.Module):
    """Both SDXL text encoders: penultimate hidden states side by side, plus the pooled embedding."""

    def __init__(self, te1, te2):
        super().__init__()
        self.te1, self.te2 = te1, te2

    def forward(self, input_ids):
        ids = input_ids.to(torch.int64)
        h1 = self.te1(ids, output_hidden_states=True).hidden_states[-2]
        o2 = self.te2(ids, output_hidden_states=True)
        return torch.cat([h1, o2.hidden_states[-2]], dim=-1), o2.text_embeds


ids = torch.zeros(2, 77, dtype=torch.int32)
if arch == "sdxl":
    export(TextEncoderXL(pipe.text_encoder, pipe.text_encoder_2), (ids,), "text_encoder",
           ["input_ids"], ["prompt_embeds", "pooled"])
    pipe.text_encoder_2 = None
else:
    export(TextEncoder(pipe.text_encoder), (ids,), "text_encoder", ["input_ids"], ["last_hidden_state", "pooler_output"])
pipe.text_encoder = None
gc.collect()


# ---------- unet ----------
class Unet(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, sample, timestep, encoder_hidden_states):
        return self.u(sample, timestep, encoder_hidden_states, return_dict=False)[0]


class UnetXL(torch.nn.Module):
    def __init__(self, u):
        super().__init__()
        self.u = u

    def forward(self, sample, timestep, encoder_hidden_states, text_embeds, time_ids):
        return self.u(sample, timestep, encoder_hidden_states,
                      added_cond_kwargs={"text_embeds": text_embeds, "time_ids": time_ids}, return_dict=False)[0]


# height/width free so the app can make vertical and horizontal pictures
spatial = {"sample": {2: "h", 3: "w"}, "out_sample": {2: "h", 3: "w"}}
if arch == "sdxl":
    export(UnetXL(pipe.unet),
           (torch.randn(2, 4, 128, 128), torch.tensor([500], dtype=torch.int32), torch.randn(2, 77, 2048),
            torch.randn(2, 1280), torch.tensor([[1024., 1024., 0., 0., 1024., 1024.]] * 2)),
           "unet", ["sample", "timestep", "encoder_hidden_states", "text_embeds", "time_ids"], ["out_sample"], spatial)
else:
    b, c = (3, 8) if cfg.get("pix2pix") else (2, 4)
    export(Unet(pipe.unet),
           (torch.randn(b, c, 64, 64), torch.tensor([500], dtype=torch.int32), torch.randn(b, 77, 768)),
           "unet", ["sample", "timestep", "encoder_hidden_states"], ["out_sample"], spatial)
pipe.unet = None
gc.collect()
# The UNet's weights are written as many external files next to model.onnx; MNNConvert reads them as they are.


# ---------- vae ----------
class Decoder(torch.nn.Module):
    def __init__(self, v):
        super().__init__()
        self.v = v

    def forward(self, latent_sample):
        return self.v.decode(latent_sample, return_dict=False)[0]


class Encoder(torch.nn.Module):
    def __init__(self, v):
        super().__init__()
        self.encoder = v.encoder
        self.quant_conv = v.quant_conv

    def forward(self, sample):
        return self.quant_conv(self.encoder(sample))[:, :4]


export(Decoder(pipe.vae), (torch.randn(1, 4, 64, 64),), "vae_decoder", ["latent_sample"], ["sample"],
       dynamic_axes={"latent_sample": {2: "h", 3: "w"}, "sample": {2: "H", 3: "W"}})
export(Encoder(pipe.vae), (torch.randn(1, 3, 512, 512),), "vae_encoder", ["sample"], ["latent"],
       dynamic_axes={"sample": {2: "H", 3: "W"}, "latent": {2: "h", 3: "w"}})
print("done")
