#!/usr/bin/env bash
# Builds the native Stable Diffusion engine (libsdjni.so) and the VAE encoder model.
# Run automatically by Gradle before building the app when they are missing.
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf mnn

echo "::group::Motor Stable Diffusion (MNN 3.4.0)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-}}"
test -d "$NDK"
git clone -q --depth 1 --branch 3.4.0 https://github.com/alibaba/MNN.git mnn
# MNN 3.4.0 forgets <cstdint> in the diffusion tokenizer
sed -i 's/#include <vector>/#include <cstdint>\n#include <vector>/' mnn/transformers/diffusion/engine/src/tokenizer.hpp
cmake -S mnn -B mnn/build-android \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_STL=c++_static -DANDROID_PLATFORM=android-29 \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.10 -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
  -DMNN_BUILD_FOR_ANDROID_COMMAND=ON -DMNN_USE_LOGCAT=OFF \
  -DMNN_BUILD_SHARED_LIBS=OFF -DMNN_SEP_BUILD=OFF -DMNN_ARM82=ON \
  -DMNN_LOW_MEMORY=ON -DMNN_SUPPORT_TRANSFORMER_FUSE=ON -DMNN_OPENCL=ON \
  -DMNN_BUILD_DIFFUSION=ON -DMNN_BUILD_LLM=ON -DMNN_BUILD_OPENCV=ON -DMNN_IMGCODECS=ON
cmake --build mnn/build-android --target MNN -j"$(nproc)"
ls -la mnn/build-android/*.a
mkdir -p app/src/main/jniLibs/arm64-v8a
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
"$TC/aarch64-linux-android29-clang++" -shared -fPIC -O2 -std=c++17 \
  app/src/main/cpp/sd_jni.cpp \
  -Imnn/include -Imnn/transformers/diffusion/engine/include -Imnn/transformers/diffusion/engine/src -Imnn/tools/cv/include \
  -Wl,--whole-archive mnn/build-android/libMNN.a -Wl,--no-whole-archive \
  -static-libstdc++ -llog -landroid -lnativewindow -ldl -lm \
  -Wl,--no-undefined -Wl,-z,max-page-size=16384 -Wl,--gc-sections \
  -o app/src/main/jniLibs/arm64-v8a/libsdjni.so
"$TC/llvm-strip" --strip-unneeded app/src/main/jniLibs/arm64-v8a/libsdjni.so
ls -la app/src/main/jniLibs/arm64-v8a
echo "::endgroup::"

echo "::group::Codificador VAE para editar fotos (img2img)"
python3 -m venv .venv
.venv/bin/pip install --quiet "torch==2.4.1" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.30.3" "huggingface_hub==0.25.2" "onnx==1.16.2" "safetensors==0.4.5" "numpy<2"
.venv/bin/python ci/export_vae_encoder.py vae_encoder.onnx
cmake -S mnn -B mnn/build-host -DCMAKE_BUILD_TYPE=Release -DMNN_BUILD_CONVERTER=ON -DCMAKE_POLICY_VERSION_MINIMUM=3.10
cmake --build mnn/build-host --target MNNConvert -j"$(nproc)"
mnn/build-host/MNNConvert -f ONNX --modelFile vae_encoder.onnx --MNNModel app/src/main/assets/vae_encoder.mnn --bizCode MNN --weightQuantBits 8
ls -la app/src/main/assets
echo "::endgroup::"

