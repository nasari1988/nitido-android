"""
The NPU (HTP) wants the second input of a MatMul between two activations with a symmetric 16-bit
range (offset -32768); the quantizer's own calibration gives an asymmetric one and the compile fails
("has incorrect Value 0, expected equal to -32768"). This measures those tensors on the calibration
pictures with ONNX Runtime and writes quantization overrides with a symmetric range for them.
usage: npu_matmul_sym.py <model.onnx> <calib list.txt> <out overrides.json>   (exit 1: none needed)
"""
import json
import sys

import numpy as np
import onnx
import onnxruntime as ort
from onnx import helper

model_path, list_path, out_path = sys.argv[1:4]
m = onnx.load(model_path)
inits = {i.name for i in m.graph.initializer}
consts = {o for n in m.graph.node if n.op_type == "Constant" for o in n.output}
targets = sorted({n.input[1] for n in m.graph.node
                  if n.op_type == "MatMul" and n.input[1] not in inits and n.input[1] not in consts})
print("MatMul con dos activaciones:", len(targets), targets[:10])
if not targets:
    sys.exit(1)
known = {o.name for o in m.graph.output}
for t in targets:
    if t not in known:
        m.graph.output.append(helper.make_empty_tensor_value_info(t))
s = ort.InferenceSession(m.SerializeToString(), providers=["CPUExecutionProvider"])
inp = s.get_inputs()[0]
shape = [d if isinstance(d, int) else 1 for d in inp.shape]
amax = {t: 0.0 for t in targets}
for line in open(list_path):
    line = line.strip()
    if not line:
        continue
    f = line.split(":=", 1)[1].split()[0]
    x = np.fromfile(f, dtype=np.float32).reshape(shape)
    outs = s.run(targets, {inp.name: x})
    for t, y in zip(targets, outs):
        amax[t] = max(amax[t], float(np.abs(y).max()))
enc = {}
for t, a in amax.items():
    a = max(a * 1.05, 1e-4)
    e = [{"bitwidth": 16, "min": -a, "max": a, "dtype": "int", "is_symmetric": "True"}]
    # the converter may rename tensors ("/a/b.c" -> "_a_b_c"): give every spelling
    import re
    for k in {t, re.sub(r"[^A-Za-z0-9_]", "_", t), re.sub(r"[^A-Za-z0-9_]", "_", t).lstrip("_")}:
        enc[k] = e
    print(f"  {t}: ±{a:.4f}")
json.dump({"activation_encodings": enc, "param_encodings": {}}, open(out_path, "w"), indent=1)
print("rangos simétricos:", out_path)
