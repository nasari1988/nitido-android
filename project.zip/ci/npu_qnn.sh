#!/usr/bin/env bash
# Compiles the exported UNet (onnx/unet_npu.onnx, fp32, fixed size) for the phone's NPU with
# Qualcomm's QAIRT SDK, in the server: the phone then only loads the result (no compiling there).
#   out/unet_npu{tag}.bin       QNN context binary (HTP, W8A16), one per picture size
#   out/unet_npu_ctx{tag}.onnx  tiny ONNX wrapper (EPContext node) so ONNX Runtime's QNN provider loads it
#   out/qnn_runtime/       the matching runtime libraries for the app (published once as a release)
set -euo pipefail
cd "$(dirname "$0")/.."

# Same QNN version as the runtime ONNX Runtime 1.29 ships (com.qualcomm.qti:qnn-runtime 2.42.0):
# with a newer runtime, ONNX Runtime's device setup is rejected (QNN_DEVICE_ERROR_INVALID_CONFIG)
QV=2.42.0.251225
# Local Dream runs the "8 Gen 2" build (Hexagon v73, SoC id 43) on the Snapdragon 8s Gen 4
SOC_ID="${QNN_SOC_ID:-43}"
DSP_ARCH="${QNN_DSP_ARCH:-v73}"

echo "::group::Kit de Qualcomm (QAIRT $QV)"
if [ ! -d qairt_sdk ]; then
  for i in 1 2 3 4 5; do
    curl -fL --retry 5 --retry-delay 5 -o qairt.zip \
      "https://softwarecenter.qualcomm.com/api/download/software/sdks/Qualcomm_AI_Runtime_Community/All/$QV/v$QV.zip" && break
    echo "descarga interrumpida, reintento $i"; sleep 10
  done
  unzip -q qairt.zip -d qairt_sdk
  rm -f qairt.zip
fi
export QNN_SDK_ROOT="$(ls -d qairt_sdk/qairt/* | head -1)"
echo "SDK: $QNN_SDK_ROOT"
ls "$QNN_SDK_ROOT/bin/x86_64-linux-clang" | head -50
# the SDK's Python tools are built for Python 3.10 and link against libpython3.10.so
if ! ls /usr/lib/x86_64-linux-gnu/libpython3.10.so.1.0 >/dev/null 2>&1; then
  sudo add-apt-repository -y ppa:deadsnakes/ppa >/dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3.10 python3.10-venv python3.10-dev libpython3.10 >/dev/null
fi
# the SDK's tools are built with LLVM's C++ runtime (libc++, libc++abi, libunwind)
for p in libc++1 libc++abi1 libunwind-18 libc++1-18 libc++abi1-18 libunwind8; do
  sudo apt-get install -y -qq "$p" >/dev/null 2>&1 || echo "sin paquete $p"
done
[ -f "$QNN_SDK_ROOT/bin/check-linux-dependency.sh" ] && (yes | sudo bash "$QNN_SDK_ROOT/bin/check-linux-dependency.sh" >/dev/null 2>&1 || true)
# list anything still missing for the converter's native module
for so in $(find "$QNN_SDK_ROOT/lib/python" -name "libDlModelToolsPy310*.so" | head -3) "$QNN_SDK_ROOT/lib/x86_64-linux-clang/libQnnHtp.so"; do
  echo "== $so"; LD_LIBRARY_PATH="$QNN_SDK_ROOT/lib/x86_64-linux-clang:/usr/lib/llvm-18/lib" ldd "$so" | grep "not found" || echo "todo encontrado"
done
rm -rf .venvq
python3.10 -m venv .venvq
.venvq/bin/python -m pip install -q --upgrade pip
.venvq/bin/python -m pip install -q "numpy==1.26.4" "onnx==1.16.1" "protobuf==3.20.3" pyyaml packaging pandas
export PYTHONPATH="$QNN_SDK_ROOT/lib/python"
export LD_LIBRARY_PATH="$QNN_SDK_ROOT/lib/x86_64-linux-clang:/usr/lib/llvm-18/lib:${LD_LIBRARY_PATH:-}"
BIN="$QNN_SDK_ROOT/bin/x86_64-linux-clang"
LIB="$QNN_SDK_ROOT/lib/x86_64-linux-clang"
PY=$PWD/.venvq/bin/python
echo "::endgroup::"

mkdir -p qnn/f out
echo "::group::Memoria extra para cuantizar"
SW=/mnt; [ -w /mnt ] || SW=/
sudo fallocate -l 40G "$SW/swap2" && sudo chmod 600 "$SW/swap2" && sudo mkswap "$SW/swap2" >/dev/null && sudo swapon "$SW/swap2" || echo "sin swap extra"
free -h; df -h / /mnt || true
echo "::endgroup::"

# the graph is named after the DLC file ("unet"), so these HTP settings apply to it
cat > qnn/htp_config.json <<EOF
{
  "graphs": [{ "graph_names": ["unet"], "O": 3, "vtcm_mb": 0 }],
  "devices": [{ "dsp_arch": "$DSP_ARCH", "cores": [{ "core_id": 0, "perf_profile": "burst", "rpc_control_latency": 100 }] }]
}
EOF
cat > qnn/htp_ext.json <<EOF
{ "backend_extensions": { "shared_library_path": "$LIB/libQnnHtpNetRunExtensions.so", "config_file_path": "$PWD/qnn/htp_config.json" } }
EOF

# The square is calibrated with the most samples (8). Its integer ranges are then reused for the
# rectangles (same layers, only the picture size changes), which fit fewer samples in memory:
# with only 5 of their own, a few ranges came out short and pictures got small blue spots.
DUMP=()
# (a plain switch: the quantizer writes the JSON next to its output; it is picked up below)
"$PY" "$BIN/qairt-quantizer" --help 2>&1 | grep -q -- "--dump_encoding_json" && DUMP=(--dump_encoding_json)
echo "volcar rangos del cuadro: ${DUMP[*]:-no disponible}"

# Builds one size: DLC -> W8A16 -> context binary. $4=1 reuses the square's ranges.
build() {
  local TAG=$1 W=$2 H=$3 USE=$4 OVR=0
  echo "::group::ONNX → DLC ${W}x${H}"
  # Rectangles: the UNet's output range from their few calibration samples came out short and the
  # phone saw values stuck at its ends (clipped) right where the spots appear. Give the output a wide
  # fixed range (16 bits over -16..16 still steps 0.0005), the rest is calibrated as usual.
  if [ "$USE" = 1 ]; then
    printf '{"activation_encodings": {"out_sample": [{"bitwidth": 16, "min": -16.0, "max": 16.0, "dtype": "int", "is_symmetric": "False"}]}, "param_encodings": {}}\n' > qnn/enc_use.json
  fi
  if [ "$USE" = 1 ]; then
    if "$PY" "$BIN/qairt-converter" --input_network "onnx/unet_npu$TAG.onnx" --output_path qnn/f/unet.dlc \
         --quantization_overrides qnn/enc_use.json; then OVR=1; else echo "no se pudo fijar el rango de salida"; fi
  fi
  [ "$OVR" = 1 ] || "$PY" "$BIN/qairt-converter" --input_network "onnx/unet_npu$TAG.onnx" --output_path qnn/f/unet.dlc
  echo "rango de salida fijo: $OVR"
  echo "::endgroup::"

  echo "::group::Cuantizar W8A16 ${W}x${H} (pesos 8 bits, activaciones 16 bits)"
  # the Snapdragon 8s Gen 4's NPU has no fp16: it needs integer graphs, like Local Dream's
  local EXTRA=()
  [ -z "$TAG" ] && EXTRA=("${DUMP[@]}")
  "$PY" "$BIN/qairt-quantizer" --input_dlc qnn/f/unet.dlc --input_list "onnx/calib$TAG/list.txt" --output_dlc qnn/unet.dlc \
      --act_bitwidth 16 --weights_bitwidth 8 --bias_bitwidth 32 --use_per_channel_quantization "${EXTRA[@]}" || return 1
  rm -f qnn/f/unet.dlc
  if [ -z "$TAG" ] && [ ${#DUMP[@]} -gt 0 ]; then
    local E
    E=$(find qnn out . -maxdepth 2 -name "*.json" -newer qnn/htp_ext.json ! -name "htp_*" ! -name "ctx.json" ! -name "enc_*" ! -name "*.onnx.json" 2>/dev/null | head -1)
    echo "rangos guardados en: ${E:-ninguno}"
    [ -n "$E" ] && mv "$E" qnn/enc_sq.json
  fi
  echo "::endgroup::"

  echo "::group::DLC → binario de contexto ${W}x${H} ($DSP_ARCH)"
  "$BIN/qnn-context-binary-generator" --backend "$LIB/libQnnHtp.so" --model "$LIB/libQnnModelDlc.so" \
    --dlc_path qnn/unet.dlc --binary_file "unet_npu$TAG" --output_dir out --config_file qnn/htp_ext.json || return 1
  rm -f qnn/unet.dlc
  "$BIN/qnn-context-binary-utility" --context_binary "out/unet_npu$TAG.bin" --json_file qnn/ctx.json
  head -c 1500 qnn/ctx.json; echo
  "$PY" ci/npu_epctx.py qnn/ctx.json "out/unet_npu_ctx$TAG.onnx" "unet_npu$TAG.bin" "$QV"
  ls -la out
  echo "::endgroup::"
}

# one compiled graph per picture size (onnx/npu_list.txt: "<tag> <width> <height>"; tag "-" = square)
while read -r TAG W H <&3; do
  [ -n "$TAG" ] || continue
  [ "$TAG" = "-" ] && TAG=""
  USE=0; [ -n "$TAG" ] && USE=1
  if ! build "$TAG" "$W" "$H" "$USE"; then
    echo "::endgroup::"
    [ "$USE" = 1 ] || exit 1
    # the square's ranges didn't compile: this size with its own calibration only
    echo "reintento ${W}x${H} con su propia calibración"
    rm -f qnn/f/unet.dlc qnn/unet.dlc
    build "$TAG" "$W" "$H" 0 || exit 1
  fi
  rm -f "onnx/unet_npu$TAG.onnx" "onnx/unet_npu$TAG.onnx.data"
  rm -rf "onnx/calib$TAG"
done 3< onnx/npu_list.txt


echo "::group::Bibliotecas de la NPU para la app ($QV)"
mkdir -p out/qnn_runtime  # (kept for reference; the app uses the ones in ONNX Runtime)
for f in libQnnHtp.so libQnnSystem.so libQnnHtpV73Stub.so libQnnHtpV75Stub.so libQnnHtpV79Stub.so; do
  cp "$QNN_SDK_ROOT/lib/aarch64-android/$f" out/qnn_runtime/
done
for a in 73 75 79; do cp "$QNN_SDK_ROOT/lib/hexagon-v$a/unsigned/libQnnHtpV${a}Skel.so" out/qnn_runtime/; done
cp "$QNN_SDK_ROOT/LICENSE.pdf" out/qnn_runtime/ 2>/dev/null || true
ls -la out/qnn_runtime
echo "::endgroup::"
