#!/usr/bin/env bash
# Compiles the exported UNet (onnx/unet_npu.onnx, fp32, fixed size) for the phone's NPU with
# Qualcomm's QAIRT SDK, in the server: the phone then only loads the result (no compiling there).
#   out/unet_npu.bin       QNN context binary (HTP, fp16)
#   out/unet_npu_ctx.onnx  tiny ONNX wrapper (EPContext node) so ONNX Runtime's QNN provider loads it
#   out/qnn_runtime/       the matching runtime libraries for the app (published once as a release)
set -euo pipefail
cd "$(dirname "$0")/.."

QV=2.51.0.260929
# Local Dream runs the "8 Gen 2" build (Hexagon v73, SoC id 43) on the Snapdragon 8s Gen 4
SOC_ID="${QNN_SOC_ID:-43}"
DSP_ARCH="${QNN_DSP_ARCH:-v73}"

echo "::group::Kit de Qualcomm (QAIRT $QV)"
if [ ! -d qairt_sdk ]; then
  for i in 1 2 3 4 5; do
    curl -fL --retry 5 --retry-delay 5 -o qairt.zip \
      "https://softwarecenter.qualcomm.com/api/download/software/sdks/Qualcomm_AI_Runtime_Community/All/$QV/v$QV.zip" && break
    echo "descarga interrumpida, reintento $i"; sleep 10
  done
  unzip -q qairt.zip -d qairt_sdk
  rm -f qairt.zip
fi
export QNN_SDK_ROOT="$(ls -d qairt_sdk/qairt/* | head -1)"
echo "SDK: $QNN_SDK_ROOT"
ls "$QNN_SDK_ROOT/bin/x86_64-linux-clang" | head -50
# the SDK's Python tools are built for Python 3.10 and link against libpython3.10.so
if ! ls /usr/lib/x86_64-linux-gnu/libpython3.10.so.1.0 >/dev/null 2>&1; then
  sudo add-apt-repository -y ppa:deadsnakes/ppa >/dev/null
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3.10 python3.10-venv python3.10-dev libpython3.10 >/dev/null
fi
rm -rf .venvq
python3.10 -m venv .venvq
.venvq/bin/python -m pip install -q --upgrade pip
.venvq/bin/python -m pip install -q "numpy==1.26.4" "onnx==1.16.1" "protobuf==3.20.3" pyyaml packaging pandas
export PYTHONPATH="$QNN_SDK_ROOT/lib/python"
export LD_LIBRARY_PATH="$QNN_SDK_ROOT/lib/x86_64-linux-clang:${LD_LIBRARY_PATH:-}"
BIN="$QNN_SDK_ROOT/bin/x86_64-linux-clang"
LIB="$QNN_SDK_ROOT/lib/x86_64-linux-clang"
PY=$PWD/.venvq/bin/python
echo "::endgroup::"

mkdir -p qnn out
echo "::group::ONNX → DLC (fp16)"
"$PY" "$BIN/qairt-converter" --help 2>&1 | grep -i -A1 "float" | head -20 || true
if ! "$PY" "$BIN/qairt-converter" --input_network onnx/unet_npu.onnx --output_path qnn/unet.dlc --float_bitwidth 16; then
  echo "probando la otra forma del parámetro"
  "$PY" "$BIN/qairt-converter" --input_network onnx/unet_npu.onnx --output_path qnn/unet.dlc --float_bw 16
fi
ls -la qnn
rm -f onnx/unet_npu.onnx.data
echo "::endgroup::"

echo "::group::DLC → binario de contexto para la NPU ($DSP_ARCH, SoC $SOC_ID)"
cat > qnn/htp_config.json <<EOF
{
  "graphs": [{ "graph_names": ["unet"], "O": 3, "fp16_relaxed_precision": 1, "vtcm_mb": 0 }],
  "devices": [{ "soc_id": $SOC_ID, "dsp_arch": "$DSP_ARCH", "cores": [{ "core_id": 0, "perf_profile": "burst", "rpc_control_latency": 100 }] }]
}
EOF
cat > qnn/htp_ext.json <<EOF
{ "backend_extensions": { "shared_library_path": "$LIB/libQnnHtpNetRunExtensions.so", "config_file_path": "$PWD/qnn/htp_config.json" } }
EOF
"$BIN/qnn-context-binary-generator" --backend "$LIB/libQnnHtp.so" --model "$LIB/libQnnModelDlc.so" \
  --dlc_path qnn/unet.dlc --binary_file unet_npu --output_dir out --config_file qnn/htp_ext.json
ls -la out
"$BIN/qnn-context-binary-utility" --context_binary out/unet_npu.bin --json_file qnn/ctx.json
head -c 3000 qnn/ctx.json; echo
echo "::endgroup::"

echo "::group::Envoltura para ONNX Runtime"
"$PY" ci/npu_epctx.py qnn/ctx.json out/unet_npu_ctx.onnx unet_npu.bin "$QV"
echo "::endgroup::"

echo "::group::Bibliotecas de la NPU para la app ($QV)"
mkdir -p out/qnn_runtime
for f in libQnnHtp.so libQnnSystem.so libQnnHtpV73Stub.so libQnnHtpV75Stub.so libQnnHtpV79Stub.so; do
  cp "$QNN_SDK_ROOT/lib/aarch64-android/$f" out/qnn_runtime/
done
for a in 73 75 79; do cp "$QNN_SDK_ROOT/lib/hexagon-v$a/unsigned/libQnnHtpV${a}Skel.so" out/qnn_runtime/; done
cp "$QNN_SDK_ROOT/LICENSE.pdf" out/qnn_runtime/ 2>/dev/null || true
ls -la out/qnn_runtime
echo "::endgroup::"
