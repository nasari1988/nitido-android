#!/usr/bin/env bash
# Pose ControlNet for SDXL on the phone's NPU (Editar › pulir con SDXL keeps the pose).
#   ci/control_pose_build.sh [WxH]      (default 1024x1024; the sizes RealVisXL has on the NPU)
# -> ./out/control_pose[_WxH].bin, _ctx.onnx, _ctx.onnx.json, files.txt
# No secrets. Weights: xinsir/controlnet-openpose-sdxl-1.0 (Apache-2.0), fixed revision and sha256,
# safetensors only. SDXL base 1.0 (fixed revision) gives only the text readers and the VAE for the
# calibration data; nothing of it is published.
set -euo pipefail
cd "$(dirname "$0")/.."
SIZE="${1:-1024x1024}"; W="${SIZE%x*}"; H="${SIZE#*x}"
CN_REV=23f966cd5cfdd3f7729c903e243d87152162d2b7
BASE_REV=462165984030d82259a11f4367a4eed129e94a7b
mkdir -p dl/control_pose dl/sdxl_base
CN=https://huggingface.co/xinsir/controlnet-openpose-sdxl-1.0/resolve/$CN_REV
curl -fsSL --retry 3 -o dl/control_pose/config.json "$CN/config.json"
curl -fsSL --retry 3 -o dl/control_pose/diffusion_pytorch_model.safetensors "$CN/diffusion_pytorch_model.safetensors"
sha256sum -c - <<SUMS || { echo "::error::los pesos del ControlNet no son los revisados"; exit 1; }
b8524e557a7df60d081f5d4a0eb109967d107df217943bf88c2d99b9ebcc06c5  dl/control_pose/diffusion_pytorch_model.safetensors
SUMS

echo "::group::Python"
source ci/venv.sh
.venv/bin/pip install --quiet "torch==2.6.0" --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install --quiet "diffusers==0.30.3" "transformers==4.44.2" "huggingface_hub==0.25.2" \
  "onnx==1.16.2" "safetensors==0.4.5" "accelerate==0.34.2" "numpy<2" pillow
# SDXL base: only tokenizers, text readers, VAE and scheduler (safetensors), for calibration data
.venv/bin/python -I - "$BASE_REV" <<'PY'
import sys
from huggingface_hub import snapshot_download
snapshot_download("stabilityai/stable-diffusion-xl-base-1.0", revision=sys.argv[1], local_dir="dl/sdxl_base",
                  allow_patterns=["model_index.json", "scheduler/*", "tokenizer/*", "tokenizer_2/*",
                                  "text_encoder/config.json", "text_encoder/model.safetensors",
                                  "text_encoder_2/config.json", "text_encoder_2/model.safetensors",
                                  "vae/config.json", "vae/diffusion_pytorch_model.safetensors"])
PY
echo "::endgroup::"

echo "::group::Exportar el ControlNet de pose ($SIZE)"
rm -rf onnx out; mkdir -p onnx out
free -h | head -2
.venv/bin/python -I ci/control_pose_export.py dl/control_pose dl/sdxl_base ci/testdata/old onnx "$W" "$H"
rm -rf dl/sdxl_base
echo "::endgroup::"

TAG=""; [ "$SIZE" = "1024x1024" ] || TAG="_$SIZE"
N="control_pose$TAG"
source ci/qnn_sdk.sh
export BIN LIB PY QV DSP_ARCH SOC_ID
echo "::group::$N para la NPU"
free -h | head -2
NPU_SYM=0 NPU_PER_ROW=1 bash ci/npu_build.sh "$N" "onnx/$N.onnx" "onnx/calib_$N/list.txt" \
  || { echo "::error::$N no compiló para la NPU"; exit 1; }
echo "::endgroup::"
cp onnx/${N}_ref.json onnx/pose_example*.png out/ 2>/dev/null || true
rm -rf out/qnn_runtime
for f in out/*; do
  if [ "$(stat -c %s "$f")" -gt 1900000000 ]; then split -b 1800M -d -a 2 "$f" "$f.split"; rm "$f"; fi
done
(cd out && for f in *; do echo "$f $(stat -c %s "$f")"; done > files.txt)
cat out/files.txt
