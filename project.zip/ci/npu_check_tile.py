"""
Opens a converted NPU tile model with ONNX Runtime on the CPU and runs one random tile, so a
broken file shows up here instead of on the phone. usage: npu_check_tile.py <model.onnx>
"""
import sys

import numpy as np
import onnxruntime as ort

s = ort.InferenceSession(sys.argv[1], providers=["CPUExecutionProvider"])
i = s.get_inputs()[0]
o = s.get_outputs()[0]
print("entrada", i.name, i.type, i.shape, "· salida", o.name, o.type, o.shape)
x = np.random.rand(*[d if isinstance(d, int) else 1 for d in i.shape]).astype(np.float32)
y = s.run(None, {i.name: x})[0]
print("prueba en CPU: salida", y.shape, "mín %.3f máx %.3f media %.3f" % (y.min(), y.max(), y.mean()))
