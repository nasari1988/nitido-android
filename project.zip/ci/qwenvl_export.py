"""
DreamLite's instruction reader (Qwen3-VL-2B, the text_encoder of carlofkl/DreamLite-mobile) for the phone,
step 1: CPU, int8 weights, to measure time and memory there before anything else.

Exports, with transformers' own Qwen3-VL code (pinned) and the safetensors weights (no pickles):
  qvl_vision.onnx   pixels [1,3,512,512] (0..1 RGB)  -> image embeds [256,2048] + deepstack [3,256,2048]
                    (the processor's patching is done inside, so the app passes plain pixels)
  qvl_text_K.onnx   K = 0..3, 7 decoder layers each: hidden [1,L,2048] + mrope positions [3,1,L]
                    (+ deepstack and the image's place in part 0; the final norm in part 3)
  qvl_embed.f16     the token embedding table [151936,2048] in float16 (the app looks tokens up itself)
then int8 weights (onnxruntime dynamic quantization) and checks:
  each part against the full model (float), then the int8 chain against it (cosine), and a DreamLite
  edit made with the int8 reader next to one made with the full one (out/qvl_check_*.jpg).
Test data for the phone: qvl_test.json (token ids, positions, image place) + qvl_test.png (the 512 photo)
+ qvl_ref.f16 (the full model's answer) so the phone can say how close it gets.

usage: qwenvl_export.py <dreamlite-mobile dir> <sample photo> <out dir>   (then qwenvl_quant.py)
"""
import json, os, sys, time
import numpy as np
import torch
from PIL import Image

model_dir, sample, OUT = sys.argv[1:4]
os.makedirs(OUT, exist_ok=True)
torch.set_num_threads(os.cpu_count() or 4)
TMP = os.path.join(OUT, "f32"); os.makedirs(TMP, exist_ok=True)

from transformers import Qwen3VLForConditionalGeneration, Qwen3VLProcessor

t0 = time.time()
model = Qwen3VLForConditionalGeneration.from_pretrained(os.path.join(model_dir, "text_encoder"), torch_dtype=torch.float32,
                                                        attn_implementation="eager").eval()
proc = Qwen3VLProcessor.from_pretrained(os.path.join(model_dir, "processor"))
print(f"Qwen3-VL cargado en {time.time() - t0:.0f} s", flush=True)
model.requires_grad_(False)
core = model.model
vis = core.visual
lm = core.language_model
H = lm.config.hidden_size
NL = len(lm.layers)

# ---------------- the reference run (DreamLite's edit template) ----------------
TEMPLATE = ("<|im_start|>system\nDescribe the key features of the input image (color, shape, size, "
            "texture, objects, background), then explain how the user's text instruction should alter "
            "or modify the image. Generate a new image that meets the user's requirements while maintaining "
            "consistency with the original input where appropriate.<|im_end|>\n<|im_start|>user\n"
            "<|vision_start|><|image_pad|><|vision_end|>{}<|im_end|>\n<|im_start|>assistant\n")
DROP = 64
instruction = "give him a red baseball cap"
prompt = f"[Edit]: A diptych with two side-by-side images of the same scene. Compared to the right side, the left one has {instruction}"
img = Image.open(sample).convert("RGB").resize((512, 512), Image.LANCZOS)
img.save(os.path.join(OUT, "qvl_test.png"))
tk = proc(text=[TEMPLATE.format(prompt)], images=[img], padding=True, return_tensors="pt")
ids = tk["input_ids"]
L = ids.shape[1]
img_id = model.config.image_token_id
pos_img = (ids[0] == img_id).nonzero().flatten()
P0, NIMG = int(pos_img[0]), int(pos_img.numel())
assert NIMG == 256 and bool((pos_img == torch.arange(P0, P0 + 256)).all()), "las piezas de la foto no están juntas"
print(f"texto: {L} piezas, foto en {P0}..{P0 + 255}", flush=True)

cap = {}
def grab(mod, args, kwargs):
    cap["pos"] = kwargs["position_ids"].clone(); cap["emb"] = kwargs["inputs_embeds"].clone()
    cap["deep"] = [d.clone() for d in kwargs["deepstack_visual_embeds"]]
lm.register_forward_pre_hook(grab, with_kwargs=True)
with torch.no_grad():
    ref = model(**tk, output_hidden_states=True).hidden_states[-1][0]          # [L, H]
pos = cap["pos"]
if pos.shape[0] == 4: pos = pos[1:]
print("posiciones", tuple(pos.shape), "· deepstack", len(cap["deep"]), flush=True)

# ---------------- the parts ----------------
class Vision(torch.nn.Module):
    """Plain pixels -> the processor's patches (normalize, 2 equal frames, 16 px patches, 2×2 merge order) -> vision."""
    def __init__(self):
        super().__init__()
        self.register_buffer("grid", torch.tensor([[1, 32, 32]]))
    def forward(self, px):
        x = (px[0] - 0.5) / 0.5                                   # [3,512,512]
        x = torch.stack([x, x], 0)                                # [2,3,512,512]
        x = x.reshape(1, 2, 3, 16, 2, 16, 16, 2, 16)
        x = x.permute(0, 3, 6, 4, 7, 2, 1, 5, 8).reshape(1024, 3 * 2 * 16 * 16)
        o = vis(x, grid_thw=self.grid)
        return o.pooler_output, torch.stack(list(o.deepstack_features), 0)

class Text(torch.nn.Module):
    def __init__(self, a, b, first, last):
        super().__init__(); self.a, self.b, self.first, self.last = a, b, first, last
    def forward(self, h, pos, deep=None):
        n = h.shape[1]
        mask = torch.full((n, n), float("-inf")).triu(1)[None, None]
        pe = lm.rotary_emb(h, pos)
        for i in range(self.a, self.b):
            h = lm.layers[i](h, position_embeddings=pe, attention_mask=mask)
            h = h[0] if isinstance(h, tuple) else h
            if self.first and i < deep.shape[0]:
                h = torch.cat([h[:, :P0], h[:, P0:P0 + 256] + deep[i][None], h[:, P0 + 256:]], 1)
        return lm.norm(h) if self.last else h

# check the processor's patching against ours, then the parts against the reference
with torch.no_grad():
    v = Vision()
    px = torch.from_numpy(np.asarray(img, np.float32) / 255.0).permute(2, 0, 1)[None].contiguous()
    pv_ours = ((px[0] - 0.5) / 0.5)
    e_img, e_deep = v(px)
    ref_img = cap["emb"][0, P0:P0 + 256]
    print(f"foto: diferencia máx con el procesador {float((e_img - ref_img).abs().max()):.2e}", flush=True)
    assert float((e_img - ref_img).abs().max()) < 1e-3, "la foto no coincide con la del procesador"
    for i, d in enumerate(cap["deep"]):
        assert float((e_deep[i] - d).abs().max()) < 1e-3, f"deepstack {i} no coincide"
    parts = [Text(k * 7, (k + 1) * 7, k == 0, k == 3) for k in range(4)]
    h = cap["emb"]
    h = parts[0](h, pos, e_deep)
    for p in parts[1:]: h = p(h, pos)
    err = float((h[0] - ref).abs().max())
    print(f"partes del texto: diferencia máx con el modelo completo {err:.2e}", flush=True)
    assert err < 1e-2, "las partes no dan lo mismo que el modelo"

# ---------------- export ----------------
def export(mod, args, names, outs, dyn, path):
    torch.onnx.export(mod, args, path, input_names=names, output_names=outs, dynamic_axes=dyn, opset_version=17,
                      do_constant_folding=True, dynamo=False)
    print("exportado", os.path.basename(path), flush=True)

with torch.no_grad():
    export(v, (px,), ["pixels"], ["image", "deep"], None, os.path.join(TMP, "qvl_vision.onnx"))
    hx = cap["emb"]
    for k, p in enumerate(parts):
        a = (hx, pos, e_deep) if k == 0 else (hx, pos)
        names = ["hidden", "pos"] + (["deep"] if k == 0 else [])
        export(p, a, names, ["out"], {"hidden": {1: "L"}, "pos": {2: "L"}, "out": {1: "L"}}, os.path.join(TMP, f"qvl_text_{k}.onnx"))

emb = lm.embed_tokens.weight.detach().numpy().astype(np.float16)
emb.tofile(os.path.join(OUT, "qvl_embed.f16"))
print("tabla de palabras", emb.shape, flush=True)

np.save(os.path.join(TMP, "ref.npy"), ref.numpy()); np.save(os.path.join(TMP, "px.npy"), px.numpy())
np.save(os.path.join(TMP, "ids.npy"), ids.numpy()); np.save(os.path.join(TMP, "pos.npy"), pos.numpy())
ref.numpy()[DROP:].astype(np.float16).tofile(os.path.join(OUT, "qvl_ref.f16"))
json.dump({"ids": ids[0].tolist(), "pos": pos[:, 0].tolist(), "image_start": P0, "drop": DROP, "hidden": H,
           "instruction": instruction, "prompt": prompt}, open(os.path.join(OUT, "qvl_test.json"), "w"))
print("exportación lista (sigue ci/qwenvl_quant.py en otro proceso, por memoria)", flush=True)
