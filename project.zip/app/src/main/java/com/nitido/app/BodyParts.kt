package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.ByteBufferExtractor
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter
import kotlin.math.roundToInt

/**
 * The parts of the people in a photo (MediaPipe selfie multiclass, on the phone): background, hair,
 * body skin, face skin, clothes, other (accessories). One byte per pixel at [w]×[h].
 */
class BodyParts(val classes: ByteArray, val w: Int, val h: Int) {

    fun at(x: Float, y: Float): Int {
        val px = (x * (w - 1)).roundToInt().coerceIn(0, w - 1)
        val py = (y * (h - 1)).roundToInt().coerceIn(0, h - 1)
        return classes[py * w + px].toInt() and 0xFF
    }

    /** Share of the picture that is [cls]. */
    fun share(cls: Int) = classes.count { (it.toInt() and 0xFF) == cls }.toFloat() / classes.size

    companion object {
        const val BACKGROUND = 0
        const val HAIR = 1
        const val BODY_SKIN = 2
        const val FACE_SKIN = 3
        const val CLOTHES = 4
        const val OTHER = 5

        /** Null when the model is missing or no person was found. Blocking. */
        fun of(ctx: Context, photo: Bitmap): BodyParts? = try {
            val long = maxOf(photo.width, photo.height)
            val k = if (long > 768) 768f / long else 1f
            val img = (if (k < 1f) Bitmap.createScaledBitmap(photo, (photo.width * k).roundToInt(), (photo.height * k).roundToInt(), true) else photo)
                .copy(Bitmap.Config.ARGB_8888, false)
            val seg = ImageSegmenter.createFromOptions(ctx,
                ImageSegmenter.ImageSegmenterOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("selfie_multiclass.tflite").build())
                    .setRunningMode(RunningMode.IMAGE)
                    .setOutputCategoryMask(true)
                    .setOutputConfidenceMasks(false)
                    .build())
            try {
                val m = seg.segment(BitmapImageBuilder(img).build()).categoryMask().get()
                val buf = ByteBufferExtractor.extract(m); buf.rewind()
                val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
                val p = BodyParts(bytes, m.width, m.height)
                if (p.share(BACKGROUND) > 0.985f) null else p
            } finally { seg.close() }
        } catch (t: Throwable) {
            JobLog.error("Partes del cuerpo (selfie multiclass)", t); null
        }
    }
}
