package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import java.util.Locale

/**
 * Finds scratches, stains and folds by itself (Microsoft's "Bringing Old Photos Back to Life"
 * detector, from the restoration pack): a damage probability for every pixel, so the marks follow
 * each scratch's real shape. The app then turns it into Rayones' mask at the chosen sensitivity.
 */
object ScratchDetector {
    const val FILE = "rest_scratch.mnn"
    /** The photo's short side when looking for damage (the detector was trained near this scale). */
    private const val SHORT = 512
    private const val TILE = 512
    private const val OVERLAP = 64

    /** Damage probability 0..255 at the detection size [w]×[h]. */
    class Map(val prob: ByteArray, val w: Int, val h: Int)

    fun isReady(ctx: Context) = RestorePack.file(ctx, FILE) != null

    fun detect(ctx: Context, src: Bitmap, gpu: Boolean): Map? {
        val model = RestorePack.file(ctx, FILE) ?: return null
        val t0 = SystemClock.elapsedRealtime()
        val k = SHORT.toFloat() / minOf(src.width, src.height)
        val w = maxOf(16, (src.width * k).toInt()); val h = maxOf(16, (src.height * k).toInt())
        val img = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        img.getPixels(px, 0, w, 0, 0, w, h)
        if (img !== src) img.recycle()
        val acc = FloatArray(w * h); val wsum = FloatArray(w * h)
        val tile = try { MnnTile(ctx, model.absolutePath, gpu) } catch (t: Throwable) {
            if (!gpu) { JobLog.error("Detector de rayones", t); return null }
            MnnTile(ctx, model.absolutePath, false)
        }
        tile.use { m ->
            val th = m.inShape.getOrElse(2) { TILE }; val tw = m.inShape.getOrElse(3) { TILE }
            val inp = FloatArray(3 * th * tw); val out = FloatArray(th * tw)
            fun starts(len: Int, t: Int): List<Int> {
                if (len <= t) return listOf(0)
                val n = (len - OVERLAP + (t - OVERLAP) - 1) / (t - OVERLAP)
                return (0 until n).map { i -> Math.round(i.toDouble() * (len - t) / (n - 1)).toInt() }
            }
            for (y0 in starts(h, th)) for (x0 in starts(w, tw)) {
                // the piece (mirrored past the edge when the photo is smaller than a piece)
                for (y in 0 until th) for (x in 0 until tw) {
                    var sy = y0 + y; var sx = x0 + x
                    if (sy >= h) sy = maxOf(0, 2 * h - 2 - sy); if (sx >= w) sx = maxOf(0, 2 * w - 2 - sx)
                    val p = px[sy * w + sx]; val i = y * tw + x
                    inp[i] = ((p shr 16) and 0xFF) / 255f
                    inp[th * tw + i] = ((p shr 8) and 0xFF) / 255f
                    inp[2 * th * tw + i] = (p and 0xFF) / 255f
                }
                if (!m.run(inp, out)) { JobLog.notice("Detector de rayones: una pieza falló"); return null }
                for (y in 0 until th) {
                    val Y = y0 + y; if (Y >= h) break
                    // soft edges where pieces overlap
                    val wy = minOf(1f, (y + 1f) / OVERLAP, (th - y).toFloat() / OVERLAP).let { if (y0 == 0 && y < OVERLAP) 1f else it }
                    for (x in 0 until tw) {
                        val X = x0 + x; if (X >= w) break
                        val wx = minOf(1f, (x + 1f) / OVERLAP, (tw - x).toFloat() / OVERLAP).let { if (x0 == 0 && x < OVERLAP) 1f else it }
                        val k2 = maxOf(1e-3f, wy * wx)
                        acc[Y * w + X] += out[y * tw + x] * k2; wsum[Y * w + X] += k2
                    }
                }
            }
        }
        val prob = ByteArray(w * h) { i -> (acc[i] / maxOf(1e-6f, wsum[i]) * 255f + 0.5f).toInt().coerceIn(0, 255).toByte() }
        JobLog.add("Detector de rayones: ${w}×$h en ${SystemClock.elapsedRealtime() - t0} ms")
        return Map(prob, w, h)
    }

    /** Sensitivity 0..100 -> the probability a pixel needs to count as damage (60 ≈ the authors' 0.4). */
    private fun threshold(sensitivity: Int) = (0.72f - sensitivity.coerceIn(0, 100) / 100f * 0.53f)

    /**
     * The marks for Rayones at the photo's size (red, opaque where damaged) and how many separate
     * damages there are.
     */
    fun mask(map: Map, outW: Int, outH: Int, sensitivity: Int): Pair<Bitmap, Int> {
        val thr = (threshold(sensitivity) * 255).toInt()
        val on = BooleanArray(map.w * map.h) { (map.prob[it].toInt() and 0xFF) >= thr }
        val count = components(on, map.w, map.h)
        val px = IntArray(outW * outH)
        val red = (0xFF shl 24) or (0xE2 shl 16) or (0x4B shl 8) or 0x4A
        for (y in 0 until outH) {
            val my = minOf(map.h - 1, y * map.h / outH)
            for (x in 0 until outW) {
                val mx = minOf(map.w - 1, x * map.w / outW)
                if (on[my * map.w + mx]) px[y * outW + x] = red
            }
        }
        val bmp = Bitmap.createBitmap(px, outW, outH, Bitmap.Config.ARGB_8888)
        JobLog.add(String.format(Locale.US, "Rayones automático: sensibilidad %d · %d daños · %.1f %% de la foto",
            sensitivity, count, on.count { it } * 100f / on.size))
        return bmp to count
    }

    /** The photo with the marks tinted red on top (what will be repaired). */
    fun overlay(src: Bitmap, mask: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val m = if (mask.width == w && mask.height == h) mask else Bitmap.createScaledBitmap(mask, w, h, false)
        val a = IntArray(w * h); val b = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h); m.getPixels(b, 0, w, 0, 0, w, h)
        for (i in a.indices) if ((b[i] ushr 24) > 30) {
            val p = a[i]
            val r = (((p shr 16) and 0xFF) * 0.3f + 226 * 0.7f).toInt(); val g = (((p shr 8) and 0xFF) * 0.3f + 75 * 0.7f).toInt()
            val bl = ((p and 0xFF) * 0.3f + 74 * 0.7f).toInt()
            a[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Separate damaged areas (bigger than a few pixels). */
    private fun components(on: BooleanArray, w: Int, h: Int): Int {
        val seen = BooleanArray(on.size)
        val stack = IntArray(on.size)
        var n = 0
        for (s in on.indices) {
            if (!on[s] || seen[s]) continue
            var top = 0; var size = 0
            stack[top++] = s; seen[s] = true
            while (top > 0) {
                val i = stack[--top]; size++
                val x = i % w; val y = i / w
                if (x > 0 && on[i - 1] && !seen[i - 1]) { seen[i - 1] = true; stack[top++] = i - 1 }
                if (x < w - 1 && on[i + 1] && !seen[i + 1]) { seen[i + 1] = true; stack[top++] = i + 1 }
                if (y > 0 && on[i - w] && !seen[i - w]) { seen[i - w] = true; stack[top++] = i - w }
                if (y < h - 1 && on[i + w] && !seen[i + w]) { seen[i + w] = true; stack[top++] = i + w }
            }
            if (size >= 4) n++
        }
        return n
    }
}
