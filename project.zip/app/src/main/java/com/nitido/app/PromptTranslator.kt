package com.nitido.app

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Spanish → English for prompts, on the phone (Google ML Kit). The language pack (~30 MB)
 * downloads once with internet; after that it works offline. Call from a background thread.
 */
object PromptTranslator {
    private val client by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.SPANISH)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build()
        )
    }

    fun toEnglish(text: String): String {
        if (text.isBlank()) return text
        Tasks.await(client.downloadModelIfNeeded(DownloadConditions.Builder().build()))
        // Translate comma-separated pieces one by one: prompts are lists of short ideas,
        // and translating them separately keeps each idea intact.
        return text.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString(", ") { Tasks.await(client.translate(it)).trim().trimEnd('.') }
    }
}
