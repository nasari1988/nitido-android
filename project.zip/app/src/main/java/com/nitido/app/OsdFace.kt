package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Caras con OSDFace (CVPR 2025, one diffusion step on SD 2.1-base; weights: non-commercial licence)
 * on the NPU. A 512×512 face (the FFHQ template, RGB −1..1) goes:
 *   pisa_enc (Realismo's VAE encoder) -> latent
 *   osd_vq   -> features, 16×16×512 -> the 77 nearest codebook entries, no repeats (here, on the CPU)
 *   osd_unet (latent, codes) -> clean latent   (the authors' embedding change and x0 are inside)
 *   pisa_dec -> face
 * Pack "caras-osdface" (built by ci/osdface_build.sh); it needs Realismo's pack for the VAE.
 */
object OsdFace {
    const val PACK = "caras-osdface"
    const val APPROX_MB = 914
    private const val S = 512
    private const val N = S * S
    private const val L = 64
    private const val CODES = 1024
    private const val DIM = 512
    private const val POS = 256
    private const val PICK = 77

    fun isReady(ctx: Context) = Realism.isReady(ctx) && SdModel.isReady(ctx, PACK) &&
        listOf("osd_vq", "osd_unet").all { File(SdModel.dir(ctx, PACK), "${it}_ctx.onnx").exists() } &&
        File(SdModel.dir(ctx, PACK), "osd_codebook.bin").length() == 4L * CODES * DIM

    /** Realismo's pack (the VAE) if missing, then this one. */
    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) {
        if (!Realism.isReady(ctx)) Realism.download(ctx, cancelled, onProgress)
        SdModel.download(ctx, PACK, cancelled, onProgress)
    }

    /** Opens the four pieces on the NPU; null (logged) when one can't open. */
    fun open(ctx: Context): Session? {
        val t0 = SystemClock.elapsedRealtime()
        val rd = SdModel.dir(ctx, Realism.PACK); val od = SdModel.dir(ctx, PACK)
        val enc = NpuTile.openPrecompiled(ctx, File(rd, "pisa_enc_ctx.onnx"), "pisa_enc") ?: return null
        val dec = NpuTile.openPrecompiled(ctx, File(rd, "pisa_dec_ctx.onnx"), "pisa_dec") ?: run { enc.close(); return null }
        val vq = NpuTile.openPrecompiled(ctx, File(od, "osd_vq_ctx.onnx"), "osd_vq") ?: run { enc.close(); dec.close(); return null }
        val unet = try { Graph(ctx, File(od, "osd_unet_ctx.onnx")) } catch (t: Throwable) {
            JobLog.error("OSDFace: osd_unet no abrió", t); enc.close(); dec.close(); vq.close(); return null
        }
        val book = FloatArray(CODES * DIM)
        File(od, "osd_codebook.bin").inputStream().use { i ->
            val bb = ByteBuffer.wrap(i.readBytes()).order(ByteOrder.LITTLE_ENDIAN)
            bb.asFloatBuffer().get(book)
        }
        JobLog.add("OSDFace abierto en la NPU en ${SystemClock.elapsedRealtime() - t0} ms")
        return Session(enc, vq, unet, dec, book)
    }

    class Session internal constructor(
        private val enc: NpuTile, private val vq: NpuTile, private val unet: Graph, private val dec: NpuTile,
        private val book: FloatArray,
    ) : AutoCloseable {
        private val lat = FloatArray(4 * L * L)
        private val h = FloatArray(DIM * POS)
        private val zq = FloatArray(PICK * DIM)
        private val x0 = FloatArray(4 * L * L)
        private val norm = FloatArray(CODES) { k -> var s = 0f; for (c in 0 until DIM) { val v = book[k * DIM + c]; s += v * v }; s }
        var unetMs = 0L; private set

        /** [face] 3×512×512 RGB −1..1 -> the restored face in [out] (same layout). */
        fun restore(face: FloatArray, out: FloatArray): Boolean {
            if (!enc.run(face, lat)) return false
            if (!vq.run(face, h)) return false
            pick()
            val t = SystemClock.elapsedRealtime()
            if (!unet.run(lat, zq, x0)) return false
            unetMs += SystemClock.elapsedRealtime() - t
            return dec.run(x0, out)
        }

        /**
         * The authors' quantize.inference: each of the 256 positions takes its nearest code; positions
         * sorted by that distance; the first 77 different codes, in that order (zeros if fewer).
         */
        private fun pick() {
            val best = IntArray(POS); val dist = FloatArray(POS)
            val z = FloatArray(DIM)
            for (p in 0 until POS) {
                var zz = 0f
                for (c in 0 until DIM) { val v = h[c * POS + p]; z[c] = v; zz += v * v }
                var bk = 0; var bd = Float.MAX_VALUE
                for (k in 0 until CODES) {
                    var dot = 0f; val o = k * DIM
                    for (c in 0 until DIM) dot += z[c] * book[o + c]
                    val d = zz + norm[k] - 2f * dot
                    if (d < bd) { bd = d; bk = k }
                }
                best[p] = bk; dist[p] = bd
            }
            val order = (0 until POS).sortedBy { dist[it] }
            val seen = HashSet<Int>(); var n = 0
            java.util.Arrays.fill(zq, 0f)
            for (p in order) {
                val k = best[p]
                if (seen.add(k)) { System.arraycopy(book, k * DIM, zq, n * DIM, DIM); n++ }
                if (n >= PICK) break
            }
        }

        override fun close() { enc.close(); vq.close(); unet.close(); dec.close() }
    }

    /** osd_unet: two inputs (latent, zq), one output, compiled in the server (integer in/out, scales in its .json). */
    internal class Graph(ctx: Context, wrapper: File) : AutoCloseable {
        private val env = OrtEnvironment.getEnvironment()
        private val session: OrtSession
        private val q: Map<String, NpuTile.Quant>
        private val shapes: Map<String, LongArray>
        private val types: Map<String, OnnxJavaType>
        private val outName: String

        init {
            NpuUnet.prepareDsp(ctx)
            val opts = OrtSession.SessionOptions().apply {
                setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                addConfigEntry("session.disable_cpu_ep_fallback", "0")
                addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
            }
            val t0 = SystemClock.elapsedRealtime()
            session = env.createSession(wrapper.path, opts)
            q = readQuant(File(wrapper.path + ".json"))
            shapes = (session.inputInfo + session.outputInfo).mapValues { (it.value.info as TensorInfo).shape }
            types = (session.inputInfo + session.outputInfo).mapValues { (it.value.info as TensorInfo).type }
            outName = session.outputNames.first()
            JobLog.add("NPU: osd_unet abierto en ${SystemClock.elapsedRealtime() - t0} ms · " +
                types.entries.joinToString(" · ") { "${it.key} ${it.value} ${shapes[it.key]?.joinToString("×")}" + (q[it.key]?.let { s -> " (escala ${s.scale})" } ?: "") })
            for ((k, t) in types) if (t != OnnxJavaType.FLOAT && q[k] == null) { session.close(); throw IllegalStateException("$k: $t sin escala") }
        }

        fun run(latent: FloatArray, zq: FloatArray, out: FloatArray): Boolean {
            val ins = mapOf("latent" to latent, "zq" to zq).mapValues { (k, v) -> tensor(k, v) }
            try {
                NpuMeter.begin()
                session.run(ins).use { r ->
                    val o = r.get(0) as OnnxTensor
                    val qo = q[outName]
                    if (qo == null) o.floatBuffer.get(out, 0, minOf(out.size, o.floatBuffer.remaining()))
                    else {
                        val bb = o.byteBuffer.order(ByteOrder.nativeOrder())
                        if (qo.type == 0x0408 || qo.type == 0x0308) {
                            for (i in 0 until minOf(out.size, bb.remaining())) { val b = bb.get(i).toInt(); out[i] = qo.scale * ((if (qo.type == 0x0408) b and 0xFF else b) + qo.offset) }
                        } else {
                            val sb = bb.asShortBuffer()
                            for (i in 0 until minOf(out.size, sb.remaining())) { val v = sb.get(i).toInt(); out[i] = qo.scale * ((if (qo.type == 0x0416) v and 0xFFFF else v) + qo.offset) }
                        }
                    }
                }
            } finally { NpuMeter.end(); ins.values.forEach { it.close() } }
            return true
        }

        private fun tensor(name: String, data: FloatArray): OnnxTensor {
            val shape = shapes.getValue(name)
            val qq = q[name] ?: return OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)
            val inv = 1f / qq.scale
            return if (qq.type == 0x0408 || qq.type == 0x0308) {
                val bb = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
                val lo = if (qq.type == 0x0408) 0 else -128; val hi = if (qq.type == 0x0408) 255 else 127
                for (v in data) bb.put((Math.round(v * inv) - qq.offset).coerceIn(lo, hi).toByte())
                bb.rewind()
                OnnxTensor.createTensor(env, bb, shape, if (qq.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
            } else {
                val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
                val sb = bb.asShortBuffer()
                val lo = if (qq.type == 0x0416) 0 else -32768; val hi = if (qq.type == 0x0416) 65535 else 32767
                for (v in data) sb.put((Math.round(v * inv) - qq.offset).coerceIn(lo, hi).toShort())
                OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
            }
        }

        private fun readQuant(f: File): Map<String, NpuTile.Quant> = try {
            val j = org.json.JSONObject(f.readText()).optJSONObject("quant")
            if (j == null) emptyMap() else j.keys().asSequence().mapNotNull { k ->
                val o = j.getJSONObject(k)
                if (!o.has("scale")) null else k to NpuTile.Quant(o.getInt("qnn_type"), o.getDouble("scale").toFloat(), o.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }

        override fun close() { try { session.close() } catch (_: Throwable) { } }
    }
}
