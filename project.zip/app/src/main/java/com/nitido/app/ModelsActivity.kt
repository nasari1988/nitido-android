package com.nitido.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A download or update started from the Models screen. Lives outside the screen so leaving it doesn't lose it. */
object ModelsJob {
    @Volatile var id: String? = null
    @Volatile var done = 0L
    @Volatile var total = 0L
    @Volatile var error: String? = null
    @Volatile var cancel = false
}

/**
 * Every model the app uses, in one place: what is on the phone, how much space it takes, what
 * can be downloaded, and which ones have an update in GitHub.
 */
class ModelsActivity : AppCompatActivity() {

    private enum class Filter { ALL, LOCAL, UPDATES }

    private lateinit var list: LinearLayout
    private var filter = Filter.ALL
    /** Create tab: 0 SD 1.5, 1 SDXL. */
    private var tab = 0
    private var remote: List<RemoteModel> = emptyList()
    private var remoteError = false
    private var checking = false
    private var sizes = Sizes()
    private val ui = Handler(Looper.getMainLooper())

    private data class Sizes(val create: Long = 0, val restore: Long = 0, val enhance: Long = 0)

    private val bg by lazy { ContextCompat.getColor(this, R.color.bg) }
    private val card by lazy { ContextCompat.getColor(this, R.color.stage) }
    private val fg by lazy { ContextCompat.getColor(this, R.color.fg) }
    private val muted by lazy { ContextCompat.getColor(this, R.color.muted) }
    private val accent by lazy { ContextCompat.getColor(this, R.color.accent) }
    private val warn by lazy { ContextCompat.getColor(this, R.color.after) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            fitsSystemWindows = true
            addView(list)
        })
        tab = try { getSharedPreferences("nitido", MODE_PRIVATE).getInt("models_tab", 0).coerceIn(0, 2) } catch (t: Throwable) { 0 }
        render()
        refreshSizes()
        loadRemote()
    }

    override fun onResume() {
        super.onResume()
        tick()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacksAndMessages(null)
    }

    /** While a download runs, redraw twice a second so its progress shows. */
    private fun tick() {
        ui.removeCallbacksAndMessages(null)
        if (ModelsJob.id == null) return
        ui.postDelayed({ render(); tick() }, 500)
    }

    // ───────────────────────── data ─────────────────────────

    private fun refreshSizes() = BgWork.scope.launch {
        val s = withContext(Dispatchers.IO) {
            val app = applicationContext
            val create = ModelCatalog.local(app).sumOf { ModelCatalog.sizeOnPhone(app, it) }
            val restore = dirSize(File(filesDir, "models/${RestorePack.ID}"))
            val enhance = BUNDLED.sumOf { assetSize(it.first) } + FaceRestorer.modelFile(app).length()
            Sizes(create, restore, enhance)
        }
        sizes = s
        if (!isDestroyed) render()
    }

    private fun loadRemote() = BgWork.scope.launch {
        val r = withContext(Dispatchers.IO) {
            try { ModelCatalog.fetchRemote() } catch (t: Throwable) { null }
        }
        if (r == null) remoteError = true else { remote = r; remoteError = false }
        if (!isDestroyed) render()
    }

    private fun checkUpdates() {
        if (checking) return
        checking = true
        render()
        BgWork.scope.launch {
            withContext(Dispatchers.IO) { ModelUpdates.checkAll(applicationContext) }
            checking = false
            if (!isDestroyed) render()
        }
    }

    private fun dirSize(d: File): Long = if (!d.exists()) 0L else d.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun assetSize(name: String): Long = try {
        assets.openFd(name).use { it.length }
    } catch (t: Throwable) {
        try { assets.open(name).use { s -> var n = 0L; val b = ByteArray(1 shl 16); while (true) { val k = s.read(b); if (k < 0) break; n += k }; n } } catch (t2: Throwable) { 0L }
    }

    private fun updateCount(): Int {
        val ids = ModelCatalog.local(this) + (if (RestorePack.isReady(this)) listOf(RestorePack.ID) else emptyList())
        return ids.count { ModelUpdates.saved(this, it) != null }
    }

    // ───────────────────────── actions ─────────────────────────

    /** The models the running job (if any) has open: those can't be changed until it ends. */
    private fun inUse(): Set<String> {
        if (!BgWork.busy) return emptySet()
        return when (BgWork.jobTarget()) {
            GenerateActivity::class.java -> setOfNotNull(getSharedPreferences("nitido", MODE_PRIVATE).getString("model", null))
            RestoreActivity::class.java -> setOf(RestorePack.ID, getSharedPreferences("nitido", MODE_PRIVATE).getString("model", null) ?: "")
            else -> setOf(RestorePack.ID, GFPGAN)
        }
    }

    private fun download(id: String, name: String, isUpdate: Boolean, need: Long = 0L) {
        if (BgWork.downloading()) {
            toastDialog(getString(R.string.models_busy_dl, ModelCatalog.displayName(BgWork.dlId ?: ""))); return
        }
        if (id in inUse()) {
            toastDialog(getString(R.string.models_in_use, name)); return
        }
        val free = filesDir.usableSpace
        if (need > 0 && free < need + 500_000_000L) {
            toastDialog(getString(R.string.models_no_space, ModelCatalog.gb(need), ModelCatalog.gb(free))); return
        }
        ModelsJob.id = id; ModelsJob.done = 0; ModelsJob.total = 0; ModelsJob.error = null; ModelsJob.cancel = false
        val app = applicationContext
        BgWork.startDownload(app, id, getString(if (isUpdate) R.string.models_updating else R.string.notif_downloading), ModelsActivity::class.java) {
            ModelsJob.cancel = true
        }
        tick()
        BgWork.scope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    if (isUpdate) ModelUpdates.prepare(app, id)
                    when (id) {
                        GFPGAN -> FaceRestorer.download(app, { ModelsJob.cancel }) { d, t -> progress(app, name, d, t) }
                        else -> {
                            if (id != RestorePack.ID && id != "sd15" && SdModel.ALL.none { it.id == id }) SdModel.addCustom(app, id)
                            SdModel.download(app, id, { ModelsJob.cancel }) { d, t -> progress(app, name, d, t) }
                        }
                    }
                    ModelUpdates.clear(app, id)
                    null
                } catch (e: InterruptedException) { getString(R.string.models_cancelled) } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            }
            ModelsJob.id = null
            ModelsJob.error = err
            BgWork.finishDownload(app, if (err == null) getString(R.string.models_done, name) else null)
            if (!isDestroyed) {
                if (err != null) toastDialog(getString(R.string.models_failed, err))
                render(); refreshSizes()
                if (err == null) offerSwap(id)
            }
        }
    }

    private fun progress(app: android.content.Context, name: String, d: Long, t: Long) {
        ModelsJob.done = d; ModelsJob.total = t
        if (t > 0) BgWork.updateDownload(app, "$name · ${ModelCatalog.gb(d)} / ${ModelCatalog.gb(t)}", (d * 100 / t).toInt())
    }

    private fun confirmDelete(id: String, name: String) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.models_delete_title, name))
            .setMessage(R.string.models_delete_msg)
            .setNegativeButton(R.string.models_later, null)
            .setPositiveButton(R.string.models_delete) { _, _ ->
                if (id in inUse() || BgWork.dlId == id) { toastDialog(getString(R.string.models_in_use, name)); return@setPositiveButton }
                if (id == GFPGAN) FaceRestorer.modelFile(this).delete() else SdModel.delete(this, id)
                ModelUpdates.clear(this, id)
                if (getSharedPreferences("nitido", MODE_PRIVATE).getString("model", null) == id)
                    getSharedPreferences("nitido", MODE_PRIVATE).edit().remove("model").apply()
                render(); refreshSizes()
            }
            .show()
    }

    private fun confirmUpdate(id: String, name: String, u: ModelUpdates.Update) {
        val what = u.reason.split(" · ").joinToString("\n") { "• " + it.replaceFirstChar { c -> c.uppercase() } }
        val size = if (u.full) getString(R.string.models_update_full, ModelCatalog.gb(u.bytes))
                   else getString(R.string.models_update_part, ModelCatalog.gb(u.bytes))
        AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage(getString(R.string.models_update_msg, what, size))
            .setNegativeButton(R.string.models_later, null)
            .setPositiveButton(R.string.models_update_now) { _, _ -> download(id, name, true, u.bytes) }
            .show()
    }

    private fun showConvert(r: Recommendation) {
        AlertDialog.Builder(this)
            .setTitle(r.name)
            .setMessage(getString(R.string.models_convert_msg, r.id, r.link, r.precision))
            .setNegativeButton(R.string.models_later, null)
            .setNeutralButton(R.string.models_copy_link) { _, _ ->
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("link", r.link))
            }
            .setPositiveButton(R.string.models_open_github) { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ModelCatalog.CONVERT_PAGE)))
            }
            .show()
    }

    private fun toastDialog(msg: String) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton(android.R.string.ok, null).show()
    }

    // ───────────────────────── families ─────────────────────────

    /**
     * One model seen as a family: its base versions (16 or 8 bits, one of them is needed) and its
     * optional NPU accelerator. Ids: "<fam>" or "<fam>-16" = 16 bits, "<fam>-8" = 8 bits, "<fam>-npu".
     */
    private class Version(val id: String, val sixteen: Boolean, val local: Boolean, val partial: Boolean, val remote: RemoteModel?)
    private class Family(val key: String, val base: List<Version>, val npu: Version?, val rec: Recommendation?, val sdxl: Boolean, val editor: Boolean)

    private fun famKey(id: String) = id.removeSuffix("-npu").removeSuffix("-16").removeSuffix("-8")

    /** info.txt of a model on the phone, without creating its folder. */
    private fun info(id: String, key: String): String? = try {
        val f = if (id == "sd15") File(filesDir, "sd15/info.txt") else File(filesDir, "models/$id/info.txt")
        if (f.exists()) f.readLines().firstOrNull { it.startsWith("$key=") }?.substringAfter("=")?.trim() else null
    } catch (t: Throwable) { null }

    private fun families(local: List<String>): List<Family> {
        val partial = File(filesDir, "models").listFiles()?.filter {
            it.isDirectory && it.name != RestorePack.ID && it.name !in local && File(it, "files.txt").exists()
        }?.map { it.name }.orEmpty()
        val remoteById = remote.associateBy { it.id }
        val ids = (local + partial + remote.map { it.id }).filter { it != RestorePack.ID && !it.endsWith("-nf") && !it.endsWith("-fijo") }.distinct()
        val out = mutableListOf<Family>()
        for ((key, group) in ids.groupBy { famKey(it) }) {
            fun ver(id: String): Version {
                val r = remoteById[id]
                val p = info(id, "precision")
                val sixteen = when {
                    id.endsWith("-8") -> false
                    id.endsWith("-16") -> true
                    p != null -> p.startsWith("16")
                    r != null -> r.sizeBytes > 1_700_000_000L && r.sizeBytes < 3_000_000_000L
                    else -> true
                }
                return Version(id, sixteen, id in local, id in partial, r)
            }
            val base = group.filter { !it.endsWith("-npu") }.map { ver(it) }
                .filter { it.local || it.partial || it.remote == null || it.remote.sizeBytes < 5_500_000_000L }
                .sortedBy { if (it.sixteen) 0 else 1 }
            val npu = group.firstOrNull { it.endsWith("-npu") }?.let { ver(it) }
            val sdxl = base.any { info(it.id, "arch") == "sdxl" || (it.remote?.sizeBytes ?: 0) > 3_000_000_000L } ||
                ModelCatalog.displayName(key).contains("SDXL")
            val editor = key.contains("pix2pix") || key.contains("inpainting") || base.any { (info(it.id, "mode") ?: "0") != "0" }
            out += Family(key, base, npu, ModelCatalog.RECOMMENDED.firstOrNull { famKey(it.id) == key }, sdxl, editor)
        }
        // recommended models nobody converted yet (only once GitHub answered)
        if (remote.isNotEmpty()) for (r in ModelCatalog.RECOMMENDED) {
            if (out.none { it.key == famKey(r.id) }) out += Family(famKey(r.id), emptyList(), null, r, r.name.contains("SDXL"), r.id.contains("inpainting"))
        }
        return out.sortedBy { familyName(it).lowercase() }
    }

    private fun familyName(f: Family) = f.rec?.name ?: ModelCatalog.displayName(f.key)
        .removeSuffix(" · 16 bits").removeSuffix(" · 8 bits")

    private fun tabs(counts: IntArray): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(R.string.models_tab_sd15, R.string.models_tab_sdxl, R.string.models_tab_other).forEachIndexed { i, res ->
            row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = getString(res) + if (counts[i] > 0) "  ${counts[i]}" else ""
                isCheckable = true; isChecked = i == tab
                setOnClickListener {
                    tab = i
                    try { getSharedPreferences("nitido", MODE_PRIVATE).edit().putInt("models_tab", i).apply() } catch (t: Throwable) {}
                    render()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { if (i < 2) marginEnd = dp(6) })
        }
        return row
    }

    // ───────────────────────── best combination ─────────────────────────

    /** The versions of [f] on the phone that its best combination doesn't need (SD 1.5: 16 bits + NPU; SDXL: 8 bits). */
    private fun extras(f: Family): List<Version> {
        val localBase = f.base.filter { it.local }
        if (localBase.size < 2) return emptyList()
        val keep = localBase.firstOrNull { it.sixteen == !f.sdxl } ?: localBase.first()
        return localBase.filter { it !== keep }
    }

    private fun bytesOf(vs: List<Version>) = vs.sumOf { ModelCatalog.sizeOnPhone(this, it.id) }

    /** 16 bits is the better base for SD 1.5 (faster on the GPU, better color): worth getting when only 8 is here. */
    private fun better16(f: Family): Version? =
        if (f.sdxl || f.base.any { it.local && it.sixteen }) null
        else f.base.firstOrNull { it.sixteen && !it.local && it.remote != null }?.takeIf { f.base.any { b -> b.local } }

    private fun keepBest(fams: List<Family>) {
        val del = fams.flatMap { extras(it) }
        if (del.isEmpty()) return
        val busy = inUse()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.models_best_title, ModelCatalog.gb(bytesOf(del))))
            .setMessage(del.joinToString("\n") { "• " + ModelCatalog.displayName(it.id) })
            .setNegativeButton(R.string.models_later, null)
            .setPositiveButton(R.string.models_delete) { _, _ ->
                for (v in del) {
                    if (v.id in busy || BgWork.dlId == v.id) continue
                    SdModel.delete(this, v.id)
                    ModelUpdates.clear(this, v.id)
                    if (getSharedPreferences("nitido", MODE_PRIVATE).getString("model", null) == v.id)
                        getSharedPreferences("nitido", MODE_PRIVATE).edit().remove("model").apply()
                }
                render(); refreshSizes()
            }
            .show()
    }

    /** Download the 16-bit base; when it finishes, offer to delete the 8-bit one. */
    private fun switchTo16(f: Family, v16: Version) {
        val old = f.base.firstOrNull { it.local && !it.sixteen }
        if (old != null) getSharedPreferences("nitido", MODE_PRIVATE).edit().putString("swap_${v16.id}", old.id).apply()
        download(v16.id, familyName(f) + " · 16 bits", false, v16.remote?.sizeBytes ?: 0L)
    }

    private fun offerSwap(newId: String) {
        val prefs = getSharedPreferences("nitido", MODE_PRIVATE)
        val old = prefs.getString("swap_$newId", null) ?: return
        prefs.edit().remove("swap_$newId").apply()
        if (old !in ModelCatalog.local(this)) return
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.models_swap_title, ModelCatalog.displayName(old)))
            .setMessage(getString(R.string.models_swap_msg, ModelCatalog.gb(ModelCatalog.sizeOnPhone(this, old))))
            .setNegativeButton(R.string.models_swap_keep, null)
            .setPositiveButton(R.string.models_delete) { _, _ ->
                if (old !in inUse()) { SdModel.delete(this, old); ModelUpdates.clear(this, old) }
                if (prefs.getString("model", null) == old) prefs.edit().putString("model", newId).apply()
                render(); refreshSizes()
            }
            .show()
    }

    /** The card of one model: 1. base version (needed), 2. NPU accelerator (optional), state at the bottom. */
    private fun familyCard(f: Family): View {
        val job = ModelsJob.id
        val box = cardBox().apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val name = familyName(f)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(text(name, 16f, fg, bold = true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (f.editor) head.addView(pill(getString(R.string.models_tag_editor), muted))
        else if (f.npu?.local == true) head.addView(pill("NPU", accent))
        box.addView(head)
        (f.rec?.description ?: ModelCatalog.description(f.key))?.let { box.addView(text(it, 12f, muted)) }

        // 1. base
        box.addView(text(getString(R.string.models_step_base), 12f, muted), block(10))
        val haveBase = f.base.any { it.local }
        if (f.base.isEmpty()) {
            val r = f.rec!!
            box.addView(option(getString(if (r.precision.startsWith("16")) R.string.models_16 else R.string.models_8),
                getString(R.string.models_not_converted), false, getString(R.string.models_convert)) { showConvert(r) })
        }
        val extra = extras(f)
        val get16 = better16(f)
        for (v in f.base) {
            val label = getString(if (v.sixteen) R.string.models_16 else R.string.models_8)
            val tag = when {
                v in extra -> TAG_EXTRA
                v.local -> TAG_KEEP
                v === get16 -> TAG_GET
                else -> 0
            }
            val u = if (v.local) ModelUpdates.saved(this, v.id) else null
            val size = if (v.local) ModelCatalog.gb(ModelCatalog.sizeOnPhone(this, v.id)) else v.remote?.let { ModelCatalog.gb(it.sizeBytes) } ?: ""
            val hint = if (!v.local && v.sixteen && !f.sdxl) " · " + getString(R.string.models_recommended) else ""
            box.addView(when {
                job == v.id -> option(label, progressText(), false, getString(R.string.models_stop)) { ModelsJob.cancel = true }
                u != null -> option(label, "$size · " + getString(R.string.models_update_line, u.reason), true, getString(R.string.models_update), warnBtn = true, tag = tag) { confirmUpdate(v.id, "$name · $label", u) }
                v.local -> option(label, size, true, getString(R.string.models_delete), tag = tag) { confirmDelete(v.id, "$name · $label") }
                v.partial -> option(label, getString(R.string.models_incomplete), false, getString(R.string.models_continue)) { download(v.id, "$name · $label", false) }
                else -> option(label, size + hint, false, getString(R.string.models_download), tag = tag) { download(v.id, "$name · $label", false, v.remote?.sizeBytes ?: 0L) }
            })
        }
        if (extra.isNotEmpty()) {
            box.addView(text(getString(R.string.models_extra_note), 12f, muted), block(8))
            box.addView(cta(getString(R.string.models_keep_best, ModelCatalog.gb(bytesOf(extra)))) { keepBest(listOf(f)) }, block(6))
        } else if (get16 != null) {
            box.addView(text(getString(R.string.models_get16_note), 12f, muted), block(8))
            box.addView(cta(getString(R.string.models_switch16)) { switchTo16(f, get16) }, block(6))
        }

        // 2. NPU accelerator (SD 1.5; SDXL only where its experimental NPU version exists)
        if (!f.editor && (!f.sdxl || f.npu != null)) {
            box.addView(text(getString(R.string.models_step_npu), 12f, muted), block(12))
            val v = f.npu
            val label = getString(R.string.models_npu)
            box.addView(when {
                v != null && job == v.id -> option(label, progressText(), false, getString(R.string.models_stop)) { ModelsJob.cancel = true }
                v != null && v.local -> {
                    val u = ModelUpdates.saved(this, v.id)
                    val size = ModelCatalog.gb(ModelCatalog.sizeOnPhone(this, v.id))
                    if (u != null) option(label, "$size · " + getString(R.string.models_update_line, u.reason), true, getString(R.string.models_update), warnBtn = true, tag = TAG_KEEP) { confirmUpdate(v.id, "$name · NPU", u) }
                    else option(label, size, true, getString(R.string.models_delete), tag = TAG_KEEP) { confirmDelete(v.id, "$name · NPU") }
                }
                v != null && v.partial -> option(label, getString(R.string.models_incomplete), false, getString(R.string.models_continue)) { download(v.id, "$name · NPU", false) }
                v != null && !haveBase -> option(label, (v.remote?.let { ModelCatalog.gb(it.sizeBytes) + " · " } ?: "") + getString(R.string.models_need_base), false, null, onClick = null)
                v != null -> option(label, (v.remote?.let { ModelCatalog.gb(it.sizeBytes) + " · " } ?: "") + getString(if (f.sdxl) R.string.models_npu_experimental else R.string.models_npu_gain), false, getString(R.string.models_download), tag = TAG_GET) {
                    download(v.id, "$name · NPU", false, v.remote?.sizeBytes ?: 0L) }
                else -> option(label, getString(R.string.models_npu_missing), false, getString(R.string.models_ask), tag = if (haveBase) TAG_GET else 0) {
                    showConvert(Recommendation("${f.key}-npu", "$name · NPU", "", f.rec?.link ?: info(f.base.firstOrNull()?.id ?: "", "source") ?: "", "npu"))
                }
            })
        }

        // state
        val npuReady = f.npu?.local == true
        val (st, col) = when {
            !haveBase -> getString(R.string.models_state_need_base) to warn
            npuReady -> getString(R.string.models_state_gpu_npu) to accent
            else -> getString(R.string.models_state_gpu) to muted
        }
        box.addView(text(st, 12f, col), block(10))
        return box
    }

    /** One version line: selected-looking when on the phone, with its button. */
    private fun option(title: String, sub: String, on: Boolean, action: String?, warnBtn: Boolean = false, tag: Int = 0, onClick: (() -> Unit)?): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                setColor(ContextCompat.getColor(this@ModelsActivity, R.color.chip)); cornerRadius = dp(10).toFloat()
                setStroke(dp(if (on) 2 else 1), if (on) accent else ContextCompat.getColor(this@ModelsActivity, R.color.line_hi))
            }
        }
        r.addView(text(if (on) "●" else "○", 13f, if (on) accent else muted).apply { setPadding(0, 0, dp(8), 0) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tline = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tline.addView(text(title, 14f, fg, bold = on))
        when (tag) {
            TAG_KEEP -> tline.addView(pill(getString(R.string.models_tag_keep), accent), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            TAG_EXTRA -> tline.addView(pill(getString(R.string.models_tag_extra), ContextCompat.getColor(this, R.color.warn)), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            TAG_GET -> tline.addView(pill(getString(R.string.models_tag_get), warn), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        }
        col.addView(tline)
        if (sub.isNotEmpty()) col.addView(text(sub, 11f, muted))
        r.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (action != null && onClick != null) {
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.text = action; b.textSize = 12f; b.minHeight = dp(36); b.minimumHeight = dp(36)
            b.insetTop = 0; b.insetBottom = 0
            if (warnBtn) { b.backgroundTintList = android.content.res.ColorStateList.valueOf(warn); b.setTextColor(0xFF2A1F08.toInt()) }
            b.isEnabled = !(ModelsJob.id != null && action != getString(R.string.models_stop))
            b.setOnClickListener { onClick() }
            r.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        }
        return r.also { it.layoutParams = block(6) }
    }

    /** The cream main button inside a card. */
    private fun cta(label: String, onClick: () -> Unit) = MaterialButton(this).apply {
        text = label; textSize = 13f
        isEnabled = ModelsJob.id == null
        setOnClickListener { onClick() }
    }

    private fun pill(s: String, color: Int) = text(s, 11f, color, bold = true).apply {
        setPadding(dp(8), dp(2), dp(8), dp(2))
        background = GradientDrawable().apply { setColor((color and 0x00FFFFFF) or 0x33000000); cornerRadius = dp(8).toFloat() }
    }

    // ───────────────────────── drawing ─────────────────────────

    private fun render() {
        list.removeAllViews()
        header()
        storage()
        filters()

        val local = ModelCatalog.local(this)
        val job = ModelsJob.id

        // CREATE: one card per model
        val fams = families(local).filter { f ->
            when (filter) {
                Filter.ALL -> true
                Filter.LOCAL -> f.base.any { it.local || it.partial } || f.npu?.local == true
                Filter.UPDATES -> (f.base + listOfNotNull(f.npu)).any { it.local && ModelUpdates.saved(this, it.id) != null }
            }
        }
        // what can be freed in all models at once
        val allExtra = fams.flatMap { extras(it) }
        if (allExtra.isNotEmpty() && ModelsJob.id == null) {
            val b = cardBox().apply {
                setPadding(dp(14), dp(12), dp(14), dp(12))
                (background as? GradientDrawable)?.setStroke(dp(1), ContextCompat.getColor(this@ModelsActivity, R.color.warn))
            }
            b.addView(text(getString(R.string.models_free_title, ModelCatalog.gb(bytesOf(allExtra))), 15f, fg, bold = true))
            b.addView(text(getString(R.string.models_free_msg, fams.count { extras(it).isNotEmpty() }), 12f, muted), block(4))
            b.addView(cta(getString(R.string.models_keep_best_all)) { keepBest(fams) }, block(8))
            list.addView(b, block(14))
        }
        val counts = IntArray(3)
        fams.forEach { counts[if (it.sdxl) 1 else 0]++ }
        list.addView(tabs(counts), block(14))
        val showOther = tab == 2
        if (!showOther) {
            val shown = fams.filter { (if (it.sdxl) 1 else 0) == tab }
            for (f in shown) list.addView(familyCard(f), block(10))
            if (shown.isEmpty()) list.addView(note(getString(R.string.models_tab_empty)), block(8))
            if (remoteError && filter == Filter.ALL) list.addView(note(getString(R.string.models_offline)), block(4))
            return
        }

        // RESTORE
        val restoreRows = mutableListOf<View>()
        val packDir = File(filesDir, "models/${RestorePack.ID}")
        val packReady = RestorePack.isReady(this)
        val pu = if (packReady) ModelUpdates.saved(this, RestorePack.ID) else null
        if (filter != Filter.UPDATES || pu != null) {
            if (packReady || filter == Filter.ALL) {
                for ((file, label) in PACK) {
                    val f = File(packDir, file)
                    val state = if (packReady && f.exists()) ModelCatalog.mb(f.length()) else getString(R.string.models_not_downloaded)
                    restoreRows += row(label, state, null, null, null, Btn.OUTLINE, null)
                }
                val packName = getString(R.string.models_pack)
                restoreRows += when {
                    job == RestorePack.ID -> row(packName, "", progressText(), null, getString(R.string.models_stop), Btn.OUTLINE) { ModelsJob.cancel = true }
                    pu != null -> row(packName, ModelCatalog.mb(sizes.restore), getString(R.string.models_update_line, pu.reason), warn,
                        getString(R.string.models_update), Btn.WARN) { confirmUpdate(RestorePack.ID, packName, pu) }
                    packReady -> row(packName, ModelCatalog.mb(sizes.restore), getString(R.string.models_up_to_date), accent,
                        getString(R.string.models_delete), Btn.OUTLINE) { confirmDelete(RestorePack.ID, packName) }
                    else -> row(packName, getString(R.string.models_pack_size), if (packDir.exists()) getString(R.string.models_incomplete) else null, warn,
                        getString(if (packDir.exists()) R.string.models_continue else R.string.models_download), Btn.FILLED) { download(RestorePack.ID, packName, false, 530_000_000L) }
                }
            }
        }
        group(getString(R.string.models_group_restore), restoreRows)

        // ENHANCE
        val enhanceRows = mutableListOf<View>()
        if (filter != Filter.UPDATES) {
            enhanceRows += row(getString(R.string.models_bundled_enhance), getString(R.string.models_bundled), null, null, null, Btn.OUTLINE, null)
            val g = FaceRestorer.modelFile(this)
            val gName = getString(R.string.models_gfpgan)
            if (filter == Filter.ALL || g.exists()) enhanceRows += when {
                job == GFPGAN -> row(gName, "", progressText(), null, getString(R.string.models_stop), Btn.OUTLINE) { ModelsJob.cancel = true }
                g.exists() -> row(gName, ModelCatalog.mb(g.length()) + " · " + getString(R.string.models_gfpgan_note), null, null,
                    getString(R.string.models_delete), Btn.OUTLINE) { confirmDelete(GFPGAN, gName) }
                else -> row(gName, getString(R.string.models_gfpgan_off), null, null, getString(R.string.models_download), Btn.FILLED) { download(GFPGAN, gName, false, 431_000_000L) }
            }
        }
        group(getString(R.string.models_group_enhance), enhanceRows)

        // SELECTION
        if (filter != Filter.UPDATES)
            group(getString(R.string.models_group_select), listOf(row(getString(R.string.models_select_names), getString(R.string.models_select_note), null, null, null, Btn.OUTLINE, null)))
    }

    private fun progressText(): String {
        val t = ModelsJob.total
        return if (t <= 0) getString(R.string.models_starting)
        else getString(R.string.models_progress, (ModelsJob.done * 100 / t).toInt(), ModelCatalog.gb(ModelsJob.done), ModelCatalog.gb(t))
    }

    private fun header() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "←"; textSize = 18f; minWidth = 0; minimumWidth = 0
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(64), LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(text(getString(R.string.models_title), 22f, fg, bold = true).apply { setPadding(dp(12), 0, 0, 0) },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        // look for updates of what is on the phone
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
            text = if (checking) "…" else "⟳"; textSize = 20f; minWidth = 0; minimumWidth = 0
            contentDescription = getString(R.string.models_check)
            isEnabled = !checking
            setOnClickListener { checkUpdates() }
        })
        list.addView(row)
    }

    private fun storage() {
        val box = cardBox().apply { setPadding(dp(14), dp(14), dp(14), dp(14)) }
        val total = sizes.create + sizes.restore + sizes.enhance
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(text(getString(R.string.models_space), 13f, muted), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(text(ModelCatalog.gb(total), 13f, fg).apply { typeface = Typeface.MONOSPACE })
        box.addView(top)

        // bar: share of the phone's storage
        val disk = (filesDir.totalSpace).coerceAtLeast(1L)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(ContextCompat.getColor(this@ModelsActivity, R.color.bg), 4f)
            clipToOutline = true
        }
        val restoreColor = warn
        val enhanceColor = ContextCompat.getColor(this, R.color.fg2)
        for ((bytes, color) in listOf(sizes.create to accent, sizes.restore to restoreColor, sizes.enhance to enhanceColor)) {
            val w = (bytes.toDouble() / disk).toFloat().coerceAtLeast(if (bytes > 0) 0.01f else 0f)
            bar.addView(View(this).apply { setBackgroundColor(color) }, LinearLayout.LayoutParams(0, dp(8), w))
        }
        val used = (sizes.create + sizes.restore + sizes.enhance).toDouble() / disk
        bar.addView(View(this), LinearLayout.LayoutParams(0, dp(8), (1.0 - used).toFloat().coerceAtLeast(0f)))
        box.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(10) })

        val legend = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, pair) in listOf(R.string.models_group_create_short to (sizes.create to accent),
                R.string.models_group_restore_short to (sizes.restore to restoreColor),
                R.string.models_group_enhance_short to (sizes.enhance to enhanceColor))) {
            legend.addView(TextView(this).apply {
                textSize = 11f; setTextColor(muted)
                val s = android.text.SpannableString("■ ${getString(label)} ${ModelCatalog.gb(pair.first)}")
                s.setSpan(android.text.style.ForegroundColorSpan(pair.second), 0, 1, 0)
                text = s
                setPadding(0, 0, dp(14), 0)
            })
        }
        box.addView(legend, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })


        val last = ModelUpdates.lastCheck(this)
        val lastText = if (last == 0L) getString(R.string.models_never_checked) else {
            val fmt = SimpleDateFormat("d MMM HH:mm", Locale("es", "MX"))
            val n = updateCount()
            getString(R.string.models_last_check, fmt.format(Date(last)),
                if (n == 0) getString(R.string.models_all_up_to_date) else resources.getQuantityString(R.plurals.models_n_updates, n, n))
        }
        box.addView(text(if (checking) getString(R.string.models_checking) else lastText, 12f, muted), block(8))
        list.addView(box, block(14))
    }

    private fun filters() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val n = updateCount()
        for ((f, label) in listOf(Filter.ALL to getString(R.string.models_filter_all),
                Filter.LOCAL to getString(R.string.models_filter_local),
                Filter.UPDATES to (getString(R.string.models_filter_updates) + if (n > 0) " ($n)" else ""))) {
            val on = f == filter
            row.addView(text(label, 13f, if (on) ContextCompat.getColor(this@ModelsActivity, R.color.on_accent) else muted, bold = on).apply {
                setPadding(dp(12), dp(7), dp(12), dp(7))
                background = round(if (on) accent else ContextCompat.getColor(this@ModelsActivity, R.color.chip), 16f)
                setOnClickListener { filter = f; render() }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(8) })
        }
        list.addView(row, block(14))
    }

    private fun group(title: String, rows: List<View>, header: View? = null) {
        if (rows.isEmpty()) return
        list.addView(text(title, 13f, muted, bold = true), block(18))
        if (header != null) list.addView(header, block(8))
        val box = cardBox()
        rows.forEachIndexed { i, v ->
            if (i > 0) box.addView(View(this).apply { setBackgroundColor((muted and 0x00FFFFFF) or 0x22000000) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
            box.addView(v)
        }
        list.addView(box, block(8))
    }

    private enum class Btn { FILLED, OUTLINE, WARN }

    private fun row(title: String, sub: String, status: String?, statusColor: Int?, action: String?, style: Btn, onClick: (() -> Unit)?): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(title, 15f, fg, bold = true))
        if (sub.isNotEmpty()) col.addView(text(sub, 12f, muted))
        if (status != null) col.addView(text(status, 12f, statusColor ?: muted))
        r.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (action != null && onClick != null) {
            val b = if (style == Btn.OUTLINE) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
                    else MaterialButton(this)
            b.text = action
            b.textSize = 13f
            if (style == Btn.WARN) {
                b.backgroundTintList = android.content.res.ColorStateList.valueOf(warn)
                b.setTextColor(0xFF2A1D05.toInt())
            }
            val busyOther = ModelsJob.id != null && action != getString(R.string.models_stop)
            b.isEnabled = !busyOther
            b.setOnClickListener { onClick() }
            r.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        }
        return r
    }

    private fun note(s: String) = text(s, 12f, muted).apply { setPadding(dp(14), dp(10), dp(14), dp(12)) }

    private fun cardBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(card); cornerRadius = dp(12).toFloat()
            setStroke(dp(1), ContextCompat.getColor(this@ModelsActivity, R.color.line))
        }
    }

    private fun round(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r.toInt()).toFloat() }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun block(top: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val TAG_KEEP = 1
        private const val TAG_EXTRA = 2
        private const val TAG_GET = 3
        const val GFPGAN = "gfpgan"
        private val BUNDLED = listOf(
            Upscaler.MODEL_FILE to "Rápido", Upscaler.MODEL_X4PLUS to "Detalle", Upscaler.MODEL_ULTRASHARP to "Ultra nítido",
            Upscaler.MODEL_SIAX to "Natural", Upscaler.MODEL_ANIME to "Anime", Upscaler.MODEL_DEBLUR to "Desenfoque",
        )
        private val PACK = listOf(
            RestorePack.FACES to "Caras · CodeFormer",
            RestorePack.DEBLUR to "Desenfoque · Restormer",
            RestorePack.COLOR to "Colorear · DDColor",
            RestorePack.DENOISE to "Grano · SCUNet",
            RestorePack.LAMA to "Rayones · LaMa",
        )
    }
}
