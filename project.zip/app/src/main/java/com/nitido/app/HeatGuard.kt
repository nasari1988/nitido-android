package com.nitido.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import java.util.Locale

/**
 * Pauses heavy work while the phone is too hot, so it doesn't freeze or shut down (SDXL's decoding
 * reached 13 W and 95 °C). Hot = the system says "severe", its thermal headroom is nearly used up, or
 * the battery is at 44 °C; it waits until the headroom is back down / the battery at 40 °C.
 */
object HeatGuard {
    private const val HOT_C = 44f
    private const val COOL_C = 40f
    private const val HOT_HEADROOM = 0.92f
    private const val COOL_HEADROOM = 0.75f
    private var lastCheck = 0L

    private fun battery(ctx: Context): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private fun status(ctx: Context): Int =
        if (Build.VERSION.SDK_INT >= 29) ctx.getSystemService(PowerManager::class.java)?.currentThermalStatus ?: 0 else 0

    /** How close to throttling the phone will be in 10 s (1 = at the limit); NaN when unknown. */
    private fun headroom(ctx: Context): Float =
        if (Build.VERSION.SDK_INT >= 30) try { ctx.getSystemService(PowerManager::class.java)?.getThermalHeadroom(10) ?: Float.NaN } catch (t: Throwable) { Float.NaN }
        else Float.NaN

    fun isHot(ctx: Context): Boolean {
        val h = headroom(ctx)
        return status(ctx) >= PowerManager.THERMAL_STATUS_SEVERE || (h.isFinite() && h >= HOT_HEADROOM) || battery(ctx) >= HOT_C
    }

    private fun isCool(ctx: Context): Boolean {
        val h = headroom(ctx)
        return status(ctx) < PowerManager.THERMAL_STATUS_MODERATE && (!h.isFinite() || h <= COOL_HEADROOM) && battery(ctx) <= COOL_C
    }

    /** Waits while hot (checked at most every 2 s); [onWait] shows the reason. Returns the seconds paused. */
    fun waitIfHot(ctx: Context, cancelled: () -> Boolean, onWait: (String) -> Unit = {}): Long {
        val now = SystemClock.elapsedRealtime()
        if (now - lastCheck < 2000) return 0
        lastCheck = now
        if (!isHot(ctx)) return 0
        val t0 = now
        JobLog.notice("Pausa por calor: " + describe(ctx))
        paused = true
        try {
            while (!cancelled() && !isCool(ctx)) {
                onWait(describe(ctx))
                Thread.sleep(4000)
            }
        } finally { paused = false }
        val s = (SystemClock.elapsedRealtime() - t0) / 1000
        JobLog.add("Sigue después de $s s de pausa por calor (${describe(ctx)})")
        return s
    }

    /** True while a job waits for the phone to cool (the processing screen says so). */
    @Volatile var paused = false

    fun describe(ctx: Context): String {
        val h = headroom(ctx)
        return String.format(Locale.US, "batería %.0f °C", battery(ctx)) +
            (if (h.isFinite()) String.format(Locale.US, " · margen térmico %.0f %%", (1f - h).coerceIn(0f, 1f) * 100) else "") +
            " · estado ${status(ctx)}"
    }
}
