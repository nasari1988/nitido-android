package com.nitido.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.BitmapFactory
import android.os.SystemClock
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.nio.channels.FileChannel
import java.util.Locale
import kotlin.math.sqrt

/**
 * DreamLite's instruction reader (Qwen3-VL-2B) on the phone's CPU with int8 weights: step 1, to see
 * whether it fits and how long it takes before porting the rest of DreamLite. The pack carries the
 * parts (ci/qwenvl_export.py), the word table in float16 and a test case with the server's answer.
 */
object DreamReader {
    const val PACK = "lector-dreamlite"
    private const val H = 2048

    fun isReady(ctx: Context) = SdModel.isReady(ctx, PACK)

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
        SdModel.download(ctx, PACK, cancelled, onProgress)

    private fun session(f: File, threads: Int): OrtSession {
        val o = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(threads)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        return OrtEnvironment.getEnvironment().createSession(f.path, o)
    }

    /** Runs the test case; a line for the report. Throws on failure. Blocking. */
    fun selfTest(ctx: Context, stop: () -> Boolean): String {
        val d = SdModel.dir(ctx, PACK)
        val env = OrtEnvironment.getEnvironment()
        val js = JSONObject(File(d, "qvl_test.json").readText())
        val idsJ = js.getJSONArray("ids"); val L = idsJ.length()
        val ids = IntArray(L) { idsJ.getInt(it) }
        val posJ = js.getJSONArray("pos")
        val pos = LongArray(3 * L) { i -> posJ.getJSONArray(i / L).getLong(i % L) }
        val p0 = js.getInt("image_start"); val drop = js.getInt("drop")
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
        JobLog.add("Lector DreamLite: $L piezas de texto, foto en $p0 · $threads hilos")

        // the photo, as plain 0..1 RGB
        val bmp = BitmapFactory.decodeFile(File(d, "qvl_test.png").path) ?: error("no se pudo leer la foto de prueba")
        val px = IntArray(512 * 512); bmp.getPixels(px, 0, 512, 0, 0, 512, 512)
        val pix = FloatArray(3 * 512 * 512)
        for (i in px.indices) { val v = px[i]
            pix[i] = ((v shr 16) and 0xFF) / 255f; pix[512 * 512 + i] = ((v shr 8) and 0xFF) / 255f; pix[2 * 512 * 512 + i] = (v and 0xFF) / 255f }

        var tOpen = 0L; var tRun = 0L
        val t0 = SystemClock.elapsedRealtime()
        var s = session(File(d, "qvl_vision.onnx"), threads); tOpen += SystemClock.elapsedRealtime() - t0
        var t = SystemClock.elapsedRealtime()
        val image: FloatArray; val deep: FloatArray
        OnnxTensor.createTensor(env, FloatBuffer.wrap(pix), longArrayOf(1, 3, 512, 512)).use { tin ->
            s.run(mapOf("pixels" to tin)).use { r ->
                image = (r[0] as OnnxTensor).floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } }
                deep = (r[1] as OnnxTensor).floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } }
            }
        }
        val tVision = SystemClock.elapsedRealtime() - t; tRun += tVision
        s.close()
        if (stop()) error("detenida")

        // the words: looked up in the float16 table (memory-mapped), the photo put in its place
        t = SystemClock.elapsedRealtime()
        var h = FloatArray(L * H)
        RandomAccessFile(File(d, "qvl_embed.f16"), "r").use { raf ->
            val map = raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length()).order(ByteOrder.LITTLE_ENDIAN)
            for (k in 0 until L) {
                if (k in p0 until p0 + 256) { System.arraycopy(image, (k - p0) * H, h, k * H, H); continue }
                val base = ids[k].toLong() * H * 2
                for (j in 0 until H) h[k * H + j] = android.util.Half.toFloat(map.getShort((base + j * 2).toInt()))
            }
        }
        val tWords = SystemClock.elapsedRealtime() - t

        val partMs = ArrayList<Long>()
        for (k in 0 until 4) {
            if (stop()) error("detenida")
            t = SystemClock.elapsedRealtime()
            s = session(File(d, "qvl_text_$k.onnx"), threads); tOpen += SystemClock.elapsedRealtime() - t
            t = SystemClock.elapsedRealtime()
            val feeds = HashMap<String, OnnxTensor>()
            feeds["hidden"] = OnnxTensor.createTensor(env, FloatBuffer.wrap(h), longArrayOf(1, L.toLong(), H.toLong()))
            feeds["pos"] = OnnxTensor.createTensor(env, LongBuffer.wrap(pos), longArrayOf(3, 1, L.toLong()))
            if (k == 0) feeds["deep"] = OnnxTensor.createTensor(env, FloatBuffer.wrap(deep), longArrayOf(3, 256, H.toLong()))
            try {
                s.run(feeds).use { r -> h = (r[0] as OnnxTensor).floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } } }
            } finally { feeds.values.forEach { it.close() } }
            val ms = SystemClock.elapsedRealtime() - t
            partMs += ms; tRun += ms
            s.close()
        }

        // how close to the server's full-precision answer
        val ref = ByteBuffer.wrap(File(d, "qvl_ref.f16").readBytes()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        var cosSum = 0.0; var cosMin = 1.0; val n = L - drop
        for (k in 0 until n) {
            var dot = 0.0; var a2 = 0.0; var b2 = 0.0
            for (j in 0 until H) {
                val a = h[(k + drop) * H + j].toDouble(); val b = android.util.Half.toFloat(ref.get(k * H + j)).toDouble()
                dot += a * b; a2 += a * a; b2 += b * b
            }
            val c = dot / (sqrt(a2) * sqrt(b2) + 1e-9)
            cosSum += c; if (c < cosMin) cosMin = c
        }
        val cos = cosSum / n
        val line = String.format(Locale.US, "foto %.1f s · palabras %d ms · texto %.1f s (partes %s ms) · abrir %.1f s · parecido %.4f (mín %.3f; servidor %.4f)",
            tVision / 1000f, tWords, partMs.sum() / 1000f, partMs.joinToString("/"), tOpen / 1000f, cos, cosMin, js.optDouble("cos_server", 0.0))
        JobLog.add("Lector DreamLite: $line")
        if (cos < 0.95) error("se aleja del original (parecido ${"%.3f".format(cos)})")
        return line
    }
}
