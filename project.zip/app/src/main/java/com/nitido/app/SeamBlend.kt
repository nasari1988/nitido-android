package com.nitido.app

import android.graphics.Color
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Seams that don't show. Multi-band blending (Burt & Adelson): the picture is split into layers from
 * fine detail to broad color and light; fine detail switches over a thin border, broad color over a
 * wide one. A new piece then takes on the light and tone around it instead of looking pasted on.
 * Also: matching the color of newly drawn skin to the person's own skin.
 */
object SeamBlend {

    /** [a] where [m] = 0, [b] where [m] = 1 (pixels [w]×[h], ARGB). Returns the mix. */
    fun multiBand(a: IntArray, b: IntArray, m: FloatArray, w: Int, h: Int): IntArray {
        val levels = maxOf(1, minOf(6, (ln(minOf(w, h) / 16.0) / ln(2.0)).toInt()))
        val out = Array(3) { FloatArray(w * h) }
        // mask pyramid (gaussian)
        val mg = gaussPyr(m, w, h, levels)
        for (c in 0 until 3) {
            val sh = 16 - 8 * c
            val pa = FloatArray(w * h) { ((a[it] shr sh) and 0xFF).toFloat() }
            val pb = FloatArray(w * h) { ((b[it] shr sh) and 0xFF).toFloat() }
            val ga = gaussPyr(pa, w, h, levels); val gb = gaussPyr(pb, w, h, levels)
            // top: the broadest layer, blended with the broadest mask
            val top = ga.last(); var cur = FloatArray(top.v.size) { i -> top.v[i] * (1 - mg.last().v[i]) + gb.last().v[i] * mg.last().v[i] }
            var cw = top.w; var ch = top.h
            for (l in levels - 1 downTo 0) {
                val fa = ga[l]; val fb = gb[l]; val fm = mg[l]
                val upA = up(ga[l + 1].v, ga[l + 1].w, ga[l + 1].h, fa.w, fa.h)
                val upB = up(gb[l + 1].v, gb[l + 1].w, gb[l + 1].h, fb.w, fb.h)
                val upC = up(cur, cw, ch, fa.w, fa.h)
                cur = FloatArray(fa.v.size) { i ->
                    val k = fm.v[i]
                    upC[i] + (fa.v[i] - upA[i]) * (1 - k) + (fb.v[i] - upB[i]) * k
                }
                cw = fa.w; ch = fa.h
            }
            out[c] = cur
        }
        return IntArray(w * h) { i ->
            Color.rgb(out[0][i].roundToInt().coerceIn(0, 255), out[1][i].roundToInt().coerceIn(0, 255), out[2][i].roundToInt().coerceIn(0, 255))
        }
    }

    private class Lv(val v: FloatArray, val w: Int, val h: Int)

    private fun gaussPyr(src: FloatArray, w: Int, h: Int, levels: Int): List<Lv> {
        val list = mutableListOf(Lv(src, w, h))
        for (i in 0 until levels) { val p = list.last(); list += down(p.v, p.w, p.h) }
        return list
    }

    /** Blur [1 2 1] both ways, then every second pixel. */
    private fun down(s: FloatArray, w: Int, h: Int): Lv {
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val l = s[y * w + maxOf(0, x - 1)]; val r = s[y * w + minOf(w - 1, x + 1)]
            tmp[y * w + x] = (l + 2 * s[y * w + x] + r) / 4
        }
        val nw = (w + 1) / 2; val nh = (h + 1) / 2
        val o = FloatArray(nw * nh)
        for (y in 0 until nh) for (x in 0 until nw) {
            val sx = minOf(w - 1, x * 2); val sy = minOf(h - 1, y * 2)
            val u = tmp[maxOf(0, sy - 1) * w + sx]; val d = tmp[minOf(h - 1, sy + 1) * w + sx]
            o[y * nw + x] = (u + 2 * tmp[sy * w + sx] + d) / 4
        }
        return Lv(o, nw, nh)
    }

    /** Bilinear up to [w]×[h]. */
    private fun up(s: FloatArray, sw: Int, sh: Int, w: Int, h: Int): FloatArray {
        val o = FloatArray(w * h)
        for (y in 0 until h) {
            val fy = ((y + 0.5f) / 2f - 0.5f).coerceIn(0f, (sh - 1).toFloat())
            val y0 = fy.toInt(); val y1 = minOf(sh - 1, y0 + 1); val ty = fy - y0
            for (x in 0 until w) {
                val fx = ((x + 0.5f) / 2f - 0.5f).coerceIn(0f, (sw - 1).toFloat())
                val x0 = fx.toInt(); val x1 = minOf(sw - 1, x0 + 1); val tx = fx - x0
                val a = s[y0 * sw + x0] * (1 - tx) + s[y0 * sw + x1] * tx
                val b = s[y1 * sw + x0] * (1 - tx) + s[y1 * sw + x1] * tx
                o[y * w + x] = a * (1 - ty) + b * ty
            }
        }
        return o
    }

    // ---- skin color ----

    /** Mean and spread of Y, Cb, Cr over the chosen pixels. */
    class Stats(val mean: FloatArray, val sd: FloatArray, val n: Int)

    fun stats(px: IntArray, pick: (Int) -> Boolean): Stats? {
        val sum = DoubleArray(3); val sq = DoubleArray(3); var n = 0
        for (i in px.indices step 2) if (pick(i)) {
            val v = ycc(px[i])
            for (c in 0 until 3) { val d = v[c].toDouble(); sum[c] = sum[c] + d; sq[c] = sq[c] + d * d }
            n++
        }
        if (n < 400) return null
        val m = FloatArray(3) { (sum[it] / n).toFloat() }
        return Stats(m, FloatArray(3) { maxOf(1f, sqrt(maxOf(0.0, sq[it] / n - m[it].toDouble() * m[it])).toFloat()) }, n)
    }

    /** [p] moved from [from]'s color to [to]'s, by [k] (0..1). Light keeps most of its shading. */
    fun transfer(p: Int, from: Stats, to: Stats, k: Float): Int {
        val v = ycc(p)
        val o = FloatArray(3)
        for (c in 0 until 3) {
            val ratio = (to.sd[c] / from.sd[c]).coerceIn(if (c == 0) 0.8f else 0.6f, if (c == 0) 1.25f else 1.6f)
            o[c] = (v[c] - from.mean[c]) * ratio + to.mean[c]
        }
        val r = rgb(o)
        fun ch(sh: Int) = (((p shr sh) and 0xFF) * (1 - k) + ((r shr sh) and 0xFF) * k).roundToInt().coerceIn(0, 255)
        return Color.rgb(ch(16), ch(8), ch(0))
    }

    /** Words for SDXL from the person's skin (mean luma of the skin). */
    fun toneWords(s: Stats): String = when {
        s.mean[0] > 185 -> "pale skin"
        s.mean[0] > 160 -> "fair skin"
        s.mean[0] > 130 -> "light tan skin"
        s.mean[0] > 100 -> "tan skin"
        s.mean[0] > 70 -> "brown skin"
        else -> "dark skin"
    }

    private fun ycc(p: Int): FloatArray {
        val r = ((p shr 16) and 0xFF).toFloat(); val g = ((p shr 8) and 0xFF).toFloat(); val b = (p and 0xFF).toFloat()
        return floatArrayOf(0.299f * r + 0.587f * g + 0.114f * b,
            128f - 0.168736f * r - 0.331264f * g + 0.5f * b,
            128f + 0.5f * r - 0.418688f * g - 0.081312f * b)
    }

    private fun rgb(v: FloatArray): Int {
        val y = v[0]; val cb = v[1] - 128; val cr = v[2] - 128
        return Color.rgb((y + 1.402f * cr).roundToInt().coerceIn(0, 255),
            (y - 0.344136f * cb - 0.714136f * cr).roundToInt().coerceIn(0, 255),
            (y + 1.772f * cb).roundToInt().coerceIn(0, 255))
    }
}
