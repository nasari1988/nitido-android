package com.nitido.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.os.Build
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * The log of the current or last job, from any screen, with a button to copy it (to send it in
 * the chat while the app is being tested). It includes the app version and the phone.
 */
object LogDialog {
    fun text(a: Activity): String {
        val live = JobLog.asText()
        val body = if (BgWork.busy || live.isNotBlank()) live else JobLog.saved(a).orEmpty()
        val ver = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName } catch (t: Throwable) { "?" }
        val head = "Nítido $ver · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}"
        return head + "\n" + body.ifBlank { a.getString(R.string.log_empty) }
    }

    fun show(a: Activity) {
        val t = text(a)
        val tv = TextView(a).apply {
            text = t
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setTextColor(ContextCompat.getColor(a, R.color.fg))
            val p = (16 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, p / 2)
        }
        MaterialAlertDialogBuilder(a)
            .setTitle(R.string.log_title)
            .setView(ScrollView(a).apply { addView(tv) })
            .setPositiveButton(R.string.log_copy) { _, _ ->
                a.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("registro", t))
                Toast.makeText(a, R.string.log_copied, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.log_close, null)
            .show()
    }

    /** Adds the "Registro" label at the end of a screen's option labels. */
    fun addTo(a: Activity, bar: OptionBar) =
        bar.add(a.getString(R.string.log_title), { "☰ " + a.getString(R.string.log_title) }, tap = { show(a) })
}
