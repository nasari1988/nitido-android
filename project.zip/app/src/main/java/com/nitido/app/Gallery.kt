package com.nitido.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore

/** The phone's gallery: Nítido's results go to Pictures/Nitido (album "Nitido"). */
object Gallery {
    /**
     * Saves [bmp] as a JPEG. With [replace] (an earlier save of the same result) that picture is
     * overwritten instead of adding a copy; if it is gone, a new one is made. Null when it fails.
     */
    fun saveImage(ctx: Context, bmp: Bitmap, name: String, replace: Uri? = null): Uri? {
        val cr = ctx.contentResolver
        if (replace != null) try {
            cr.openOutputStream(replace, "wt")?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                ?: throw IllegalStateException("sin salida")
            JobLog.add("Galería: reemplazada $replace")
            return replace
        } catch (t: Throwable) {
            JobLog.add("Galería: no se pudo reemplazar ($t), se guarda una nueva")
        }
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            cr.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            cr.update(uri, values, null, null)
            JobLog.add("Galería: guardada $uri")
            uri
        } catch (t: Throwable) {
            JobLog.error("Galería: no se pudo guardar", t)
            null
        }
    }
}
