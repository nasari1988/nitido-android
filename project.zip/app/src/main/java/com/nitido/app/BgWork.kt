package com.nitido.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Keeps long jobs (generating, refining, enhancing, downloading models) alive when the user
 * switches apps or turns the screen off: a foreground service with a progress notification
 * and a Stop button, plus a partial wake lock so the CPU/GPU keep working.
 *
 * Jobs run in [scope], which is not tied to any screen, so leaving the screen doesn't cancel them.
 */
object BgWork {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private const val CHANNEL_RUN = "work"
    private const val CHANNEL_DONE = "done"
    const val ID_RUN = 1
    private const val ID_DONE = 2
    const val ACTION_STOP = "com.nitido.app.STOP"
    const val ID_DL = 3
    private const val ID_DL_DONE = 4
    const val ACTION_STOP_DL = "com.nitido.app.STOP_DL"

    @Volatile var onStop: (() -> Unit)? = null
    /** A job is running (this survives leaving and reopening a screen). */
    @Volatile var busy = false
    @Volatile private var title = ""
    @Volatile private var target: Class<*> = MainActivity::class.java
    @Volatile private var lastUpdate = 0L

    // Downloads have their own lane: they use the network, jobs use the GPU, so both can run at once.
    /** Id of the model being downloaded, or null. */
    @Volatile var dlId: String? = null
    @Volatile var onStopDl: (() -> Unit)? = null
    @Volatile private var dlTitle = ""
    @Volatile private var dlTarget: Class<*> = ModelsActivity::class.java
    @Volatile private var dlLast = 0L
    @Volatile private var dlText = ""
    @Volatile private var dlPct = 0

    fun downloading() = dlId != null

    /** Starts a download in its own notification. [stop] is called from its Stop button. */
    fun startDownload(ctx: Context, id: String, title: String, target: Class<*>, stop: () -> Unit) {
        val app = ctx.applicationContext
        dlId = id; dlTitle = title; dlTarget = target; onStopDl = stop; dlText = ""; dlPct = 0
        channels(app)
        app.getSystemService(NotificationManager::class.java).cancel(ID_DL_DONE)
        if (canNotify(app)) app.getSystemService(NotificationManager::class.java).notify(ID_DL, downloadNote(app))
        keepAlive(app)
    }

    fun updateDownload(ctx: Context, text: String, pct: Int) {
        val now = SystemClock.elapsedRealtime()
        if (now - dlLast < 700 && pct in 1..99) return
        dlLast = now; dlText = text; dlPct = pct
        val app = ctx.applicationContext
        if (canNotify(app)) app.getSystemService(NotificationManager::class.java).notify(ID_DL, downloadNote(app))
    }

    fun finishDownload(ctx: Context, message: String?) {
        val app = ctx.applicationContext
        dlId = null; onStopDl = null
        val nm = app.getSystemService(NotificationManager::class.java)
        if (busy) nm.cancel(ID_DL) else app.stopService(Intent(app, BgService::class.java))
        nm.cancel(ID_DL)
        if (message != null && canNotify(app)) {
            nm.notify(ID_DL_DONE, NotificationCompat.Builder(app, CHANNEL_DONE)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(dlTitle)
                .setContentText(message)
                .setContentIntent(open(app, dlTarget, 2))
                .setAutoCancel(true)
                .build())
        }
    }

    internal fun downloadNote(ctx: Context): Notification {
        val stop = PendingIntent.getService(ctx, 3, Intent(ctx, BgService::class.java).setAction(ACTION_STOP_DL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(ctx, CHANNEL_RUN)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(dlTitle)
            .setContentText(dlText.ifEmpty { ctx.getString(R.string.models_starting) })
            .setProgress(100, dlPct.coerceIn(0, 100), dlPct <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open(ctx, dlTarget, 2))
            .addAction(0, ctx.getString(R.string.stop), stop)
            .build()
    }

    private fun keepAlive(app: Context) {
        try {
            ContextCompat.startForegroundService(app, Intent(app, BgService::class.java))
        } catch (t: Throwable) {
            // Not allowed right now (rare); the work still runs while the app is open.
            JobLog.notice("No se pudo activar el trabajo en segundo plano (${t.javaClass.simpleName}): mantén Nítido abierto hasta que termine")
        }
    }

    /** Starts the foreground service. [stop] is called when the user taps Stop in the notification. */
    fun start(ctx: Context, title: String, target: Class<*>, stop: () -> Unit) {
        val app = ctx.applicationContext
        this.title = title
        this.target = target
        onStop = stop
        busy = true
        jobText = ""; jobPct = 0; jobStarted = SystemClock.elapsedRealtime(); jobDetail = ""; progressAt = jobStarted
        JobLog.attach(ctx)
        JobLog.start(title)
        JobLog.add(JobLog.deviceLine(app))
        channels(app)
        app.getSystemService(NotificationManager::class.java).cancel(ID_DONE)
        keepAlive(app)
    }

    /** What Inicio shows about the running job (title, last progress line, percent). */
    @Volatile var jobText = ""
        private set
    @Volatile var jobPct = 0
        private set
    @Volatile var jobStarted = 0L
        private set
    /** Stage, piece and time left of the running job (set by the processing screen). */
    @Volatile var jobDetail = ""
    fun jobTitle() = title
    fun dlTitle() = dlTitle
    fun dlText() = dlText
    fun dlPct() = dlPct

    /** When the running job last reported progress (elapsedRealtime). */
    @Volatile var progressAt = 0L
        private set

    /**
     * Stop pressed: asks the job to stop; if a few seconds later it still hasn't ended and hasn't
     * reported anything for a while, it is gone (its screen was closed by Android after it had
     * finished, say), so it is marked as ended here instead of staying "working" forever.
     */
    fun stopOrRelease(ctx: Context) {
        onStop?.invoke()
        val app = ctx.applicationContext
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (busy && SystemClock.elapsedRealtime() - progressAt > 30_000) {
                JobLog.notice("Detener: el trabajo ya no respondía; se dio por terminado")
                finish(app, app.getString(R.string.job_released))
            }
        }, 6000)
    }

    fun update(ctx: Context, text: String, pct: Int) {
        jobText = text; jobPct = pct
        val now = SystemClock.elapsedRealtime()
        progressAt = now
        if (now - lastUpdate < 700 && pct in 1..99) return
        lastUpdate = now
        val app = ctx.applicationContext
        if (!canNotify(app)) return
        app.getSystemService(NotificationManager::class.java).notify(ID_RUN, running(app, text, pct))
    }

    /** Stops the service and, if [message] is given, leaves a notification that opens the app. */
    fun finish(ctx: Context, message: String?) {
        val app = ctx.applicationContext
        onStop = null
        busy = false
        JobLog.add(message ?: app.getString(R.string.log_ended))
        JobLog.save(app)
        if (message != null) try {
            app.getSharedPreferences("nitido", Context.MODE_PRIVATE).edit()
                .putString("last_section", target.name).putString("last_message", message)
                .putLong("last_time", System.currentTimeMillis()).apply()
        } catch (t: Throwable) { }
        if (dlId != null) {
            // a download is still going: the service stays, now showing the download
            keepAlive(app)
            app.getSystemService(NotificationManager::class.java).cancel(ID_RUN)
        } else app.stopService(Intent(app, BgService::class.java))
        if (message != null && canNotify(app) && Prefs.notifyDone(app)) {
            val n = NotificationCompat.Builder(app, CHANNEL_DONE)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(message)
                .setContentIntent(open(app, target, 0))
                .setAutoCancel(true)
                .build()
            app.getSystemService(NotificationManager::class.java).notify(ID_DONE, n)
        }
    }

    fun canNotify(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    internal fun running(ctx: Context, text: String, pct: Int): Notification {
        val stop = PendingIntent.getService(ctx, 1, Intent(ctx, BgService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(ctx, CHANNEL_RUN)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(100, pct.coerceIn(0, 100), pct <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open(ctx, target, 0))
            .addAction(0, ctx.getString(R.string.stop), stop)
            .build()
    }

    private fun open(ctx: Context, cls: Class<*>, code: Int): PendingIntent = PendingIntent.getActivity(
        ctx, code, Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_RUN, ctx.getString(R.string.notif_channel_run), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_DONE, ctx.getString(R.string.notif_channel_done), NotificationManager.IMPORTANCE_DEFAULT))
    }

    internal fun currentTitle() = title

    fun jobTarget(): Class<*> = target
}

class BgService : Service() {
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == BgWork.ACTION_STOP) {
            BgWork.stopOrRelease(this)
            return START_NOT_STICKY
        }
        if (intent?.action == BgWork.ACTION_STOP_DL) {
            BgWork.onStopDl?.invoke()
            return START_NOT_STICKY
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        try {
            if (BgWork.busy || BgWork.dlId == null)
                ServiceCompat.startForeground(this, BgWork.ID_RUN, BgWork.running(this, getString(R.string.notif_working), 0), type)
            else
                ServiceCompat.startForeground(this, BgWork.ID_DL, BgWork.downloadNote(this), type)
            if (BgWork.busy) JobLog.add("Trabajo en segundo plano activo (notificación)")
        } catch (t: Throwable) {
            JobLog.notice("Android no permitió el trabajo en segundo plano (${t.javaClass.simpleName}): mantén Nítido abierto hasta que termine")
        }
        if (wake == null) {
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nitido:work").apply {
                    setReferenceCounted(false)
                    acquire(3 * 60 * 60 * 1000L)   // safety cap: 3 h
                }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wake?.let { if (it.isHeld) it.release() }
        wake = null
        super.onDestroy()
    }
}
