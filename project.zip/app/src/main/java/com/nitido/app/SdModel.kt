package com.nitido.app

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Stable Diffusion 1.5 converted to MNN (8-bit weights, OpenCL-optimized),
 * downloaded once from Hugging Face into the app's private storage.
 */
object SdModel {
    private const val BASE = "https://huggingface.co/taobao-mnn/stable-diffusion-v1-5-mnn-gpu/resolve/main/"

    /** File name to approximate size in bytes (for the progress bar). */
    val FILES = linkedMapOf(
        "text_encoder.mnn" to 250_000L,
        "text_encoder.mnn.weight" to 238_000_000L,
        "unet.mnn" to 1_010_000L,
        "unet.mnn.weight" to 864_000_000L,
        "vae_decoder.mnn" to 164_000L,
        "vae_decoder.mnn.weight" to 49_600_000L,
        "vocab.json" to 1_060_000L,
        "merges.txt" to 525_000L,
        "alphas.txt" to 7_000L,
    )
    val TOTAL: Long = FILES.values.sum()

    fun dir(ctx: Context): File = File(ctx.filesDir, "sd15").apply { mkdirs() }

    fun isReady(ctx: Context): Boolean {
        val d = dir(ctx)
        return FILES.keys.all { File(d, it).let { f -> f.exists() && f.length() > 0 } }
    }

    fun delete(ctx: Context) { dir(ctx).deleteRecursively() }

    /**
     * Downloads every missing file, resuming partial ones.
     * [onProgress] receives bytes done (approximate) out of [TOTAL].
     */
    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long) -> Unit) {
        val d = dir(ctx)
        var doneBefore = 0L
        for ((name, approx) in FILES) {
            val target = File(d, name)
            if (target.exists() && target.length() > 0) { doneBefore += approx; onProgress(doneBefore); continue }
            val part = File(d, "$name.part")
            var attempt = 0
            while (true) {
                if (cancelled()) throw InterruptedException()
                try {
                    fetch(BASE + name, part, cancelled) { got -> onProgress(doneBefore + minOf(got, approx)) }
                    break
                } catch (e: IOException) {
                    attempt++
                    if (attempt >= 5) throw e
                    Thread.sleep(2000L * attempt)
                }
            }
            if (!part.renameTo(target)) throw IOException("No se pudo guardar $name")
            doneBefore += approx
            onProgress(doneBefore)
        }
    }

    private fun fetch(url: String, part: File, cancelled: () -> Boolean, onBytes: (Long) -> Unit) {
        val have = if (part.exists()) part.length() else 0L
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 20_000
            readTimeout = 60_000
            if (have > 0) setRequestProperty("Range", "bytes=$have-")
        }
        try {
            val code = conn.responseCode
            val append = code == HttpURLConnection.HTTP_PARTIAL
            if (code != HttpURLConnection.HTTP_OK && !append) throw IOException("HTTP $code")
            var got = if (append) have else 0L
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(256 * 1024)
                    var lastReport = 0L
                    while (true) {
                        if (cancelled()) throw InterruptedException()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        if (got - lastReport > 2_000_000) { onBytes(got); lastReport = got }
                    }
                }
            }
            onBytes(got)
        } finally {
            conn.disconnect()
        }
    }
}
