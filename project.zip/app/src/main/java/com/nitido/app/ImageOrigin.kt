package com.nitido.app

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/**
 * Where a picture comes from: a person invented by Crear (from text only) or a real photo.
 *
 * Nothing is guessed from the picture itself. Crear writes the sha256 of every file it makes from
 * text alone (no photo, no img2img, no reference face) in a private list inside the app; Editar
 * hashes the file it opens and looks it up. Not in the list = a real photo, whatever its source
 * (gallery, internet, other AI apps). Results of editing a listed picture are listed too.
 */
object ImageOrigin {
    private const val FILE = "origen.txt"
    private val lock = Any()
    @Volatile private var cache: MutableSet<String>? = null

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE)

    /** Ajustes › Registro de imágenes IA: the three switches. */
    fun recordOn(ctx: Context) = prefs(ctx).getBoolean("origin_record", true)
    fun setRecordOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("origin_record", on).apply()
    fun inheritOn(ctx: Context) = prefs(ctx).getBoolean("origin_inherit", true)
    fun setInheritOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("origin_inherit", on).apply()
    fun badgeOn(ctx: Context) = prefs(ctx).getBoolean("origin_badge", true)
    fun setBadgeOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("origin_badge", on).apply()

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    private fun set(ctx: Context): MutableSet<String> = synchronized(lock) {
        cache ?: run {
            val f = file(ctx)
            val s = if (f.exists()) f.readLines().map { it.trim() }.filter { it.length == 64 }.toMutableSet() else mutableSetOf()
            cache = s
            s
        }
    }

    private fun sha256(input: InputStream): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(1 shl 16)
        while (true) { val n = input.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun hashOf(f: File): String? = try { f.inputStream().use { sha256(it) } } catch (t: Throwable) { null }
    fun hashOf(ctx: Context, uri: Uri): String? = try { ctx.contentResolver.openInputStream(uri)?.use { sha256(it) } } catch (t: Throwable) { null }

    private fun add(ctx: Context, h: String?) {
        if (h == null) return
        synchronized(lock) {
            val s = set(ctx)
            if (s.add(h)) try { file(ctx).appendText(h + "\n") } catch (t: Throwable) { JobLog.error("Registro IA", t) }
        }
    }

    /** A file made by Nítido from an AI picture (Crear from text, or an edit of a listed one). */
    fun register(ctx: Context, f: File) = add(ctx, hashOf(f))
    fun register(ctx: Context, uri: Uri) = add(ctx, hashOf(ctx, uri))

    fun isAi(ctx: Context, f: File): Boolean = hashOf(f)?.let { it in set(ctx) } ?: false
    fun isAi(ctx: Context, uri: Uri): Boolean = hashOf(ctx, uri)?.let { it in set(ctx) } ?: false

    fun remove(ctx: Context, f: File) {
        val h = hashOf(f) ?: return
        synchronized(lock) {
            val s = set(ctx)
            if (s.remove(h)) try { file(ctx).writeText(s.joinToString("") { it + "\n" }) } catch (t: Throwable) { JobLog.error("Registro IA", t) }
        }
    }

    fun count(ctx: Context): Int = set(ctx).size
    fun bytes(ctx: Context): Long = file(ctx).let { if (it.exists()) it.length() else 0L }

    fun clear(ctx: Context) = synchronized(lock) {
        file(ctx).delete()
        cache = mutableSetOf()
        JobLog.add("Registro de imágenes IA: borrado")
    }

    /**
     * Orders that undress or ask for nudity, in Spanish or English (see [isNude]). On a real photo
     * they are refused, whatever «Se entiende como» says; on a picture invented by Crear: «Sin ropa».
     */
    private val NUDE_RX = Regex(
        """(?<![\p{L}])(desnud\w*|encuerad\w*|sin\s+ropa|sin\s+nada\s+de\s+ropa|en\s+cueros|""" +
        """sin\s+(?:brasier|sost[eé]n|sujetador|calzones|bragas|ropa\s+interior)|topless|nude\w*|naked|undress\w*|""" +
        """nsfw|no\s+clothes|without\s+clothes|""" +
        """pez[oó]n\w*|nipple\w*|genital\w*|pubic|vagina\w*|pene\b|penis|""" +
        """transparent\w*\s+(?:dress|top|shirt|blouse|lingerie)|see-through|sheer\s+(?:dress|top|lingerie))""",
        RegexOption.IGNORE_CASE)

    /** «Quítale el vestido», «take off her shirt»: undressing, unless another garment is put in its place. */
    private val REMOVE_RX = Regex(
        """(?<![\p{L}])(qu[ií]t\w*|s[aá]c\w*|remov\w*|take\s+off|takes\s+off|strip\w*)\s+(?:\w+\s+){0,3}""" +
        """(ropa|vestido|camisa|blusa|falda|pantal\w*|playera|top|brasier|sost[eé]n|bikini|traje|calzones|bragas|""" +
        """clothes|clothing|dress|shirt|blouse|skirt|pants|jeans|bra\b|underwear|panties|swimsuit|outfit)""",
        RegexOption.IGNORE_CASE)
    private val REPLACE_RX = Regex("""(?<![\p{L}])(pon\w*|c[aá]mbi\w*|por\s+un|por\s+una|reempl\w*|replace\w*|put\s+on|wear\w*|dress\s+(?:her|him)\s+in|with\s+a|into\s+a)""",
        RegexOption.IGNORE_CASE)

    fun isNude(text: String): Boolean =
        NUDE_RX.containsMatchIn(text) || (REMOVE_RX.containsMatchIn(text) && !REPLACE_RX.containsMatchIn(text))

    /** Kept away from every real photo: what the fill models are told to avoid there. */
    const val REAL_PHOTO_NEGATIVE = "nude, naked, nsfw, topless, nipples, exposed breasts, genitals, see-through clothes"
}
