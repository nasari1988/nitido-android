package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import android.content.Context
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Locale
import kotlin.math.floor

/**
 * Más fluido: the frame between two frames, with RIFE 4.25 (hzwer/Practical-RIFE, MIT), from the
 * "fluido" pack. The network looks at both frames at a fixed small size (on the NPU, or the CPU when
 * the NPU says no) and gives the motion to each frame plus how much of each to take; the full-size
 * frames are then moved along that motion here and mixed, so the result keeps all their detail.
 */
class Interpolator private constructor(
    private val session: OrtSession, val mw: Int, val mh: Int, val onNpu: Boolean,
    private val quant: Map<String, NpuTile.Quant>,
) : AutoCloseable {

    private val env = OrtEnvironment.getEnvironment()
    private val a = FloatArray(3 * mw * mh)
    private val b = FloatArray(3 * mw * mh)
    private val flow = FloatArray(4 * mw * mh)
    private val mask = FloatArray(mw * mh)
    var lastMs = 0L; private set
    private var bad = 0

    /** The frame halfway between [p0] and [p1] (ARGB, [w]×[h]); a plain mix if the network gave nonsense. */
    fun middle(p0: IntArray, p1: IntArray, w: Int, h: Int): IntArray {
        val t0 = SystemClock.elapsedRealtime()
        shrink(p0, w, h, a); shrink(p1, w, h, b)
        val ok = try { infer() } catch (t: Throwable) {
            if (bad++ < 3) JobLog.error("Más fluido", t)
            false
        }
        val out = if (ok) warp(p0, p1, w, h) else VideoEnhancer.blend(p0, p1)
        lastMs = SystemClock.elapsedRealtime() - t0
        return out
    }

    private fun infer(): Boolean {
        val shape = longArrayOf(1, 3, mh.toLong(), mw.toLong())
        val t0 = tensor("img0", a, shape); val t1 = tensor("img1", b, shape)
        try {
            if (onNpu) NpuMeter.begin()
            try {
                session.run(mapOf("img0" to t0, "img1" to t1)).use { r ->
                    read(r.get("flow").get() as OnnxTensor, "flow", flow)
                    read(r.get("mask").get() as OnnxTensor, "mask", mask)
                }
            } finally { if (onNpu) NpuMeter.end() }
        } finally { t0.close(); t1.close() }
        // a sane result: motion within the picture, mask 0..1
        var i = 0
        while (i < mask.size) { val m = mask[i]; if (!m.isFinite() || m < -0.05f || m > 1.05f) return bad("máscara $m"); i += 97 }
        i = 0
        while (i < flow.size) { val f = flow[i]; if (!f.isFinite() || kotlin.math.abs(f) > mw) return bad("movimiento $f"); i += 101 }
        return true
    }

    private fun bad(what: String): Boolean {
        if (bad++ < 3) JobLog.notice("Más fluido: resultado fuera de rango ($what); ese cuadro va mezclado")
        return false
    }

    private fun tensor(name: String, data: FloatArray, shape: LongArray): OnnxTensor {
        val q = quant[name] ?: return OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)
        val inv = 1f / q.scale
        return if (q.type == 0x0408 || q.type == 0x0308) {
            val bb = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
            val lo = if (q.type == 0x0408) 0 else -128; val hi = if (q.type == 0x0408) 255 else 127
            for (v in data) bb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toByte())
            bb.rewind()
            OnnxTensor.createTensor(env, bb, shape, if (q.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
        } else {
            val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
            val sb = bb.asShortBuffer()
            val lo = if (q.type == 0x0416) 0 else -32768; val hi = if (q.type == 0x0416) 65535 else 32767
            for (v in data) sb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toShort())
            OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
        }
    }

    private fun read(o: OnnxTensor, name: String, out: FloatArray) {
        val q = quant[name]
        if (q == null) { o.floatBuffer.get(out, 0, minOf(out.size, o.floatBuffer.remaining())); return }
        val bb = o.byteBuffer.order(ByteOrder.nativeOrder())
        if (q.type == 0x0408 || q.type == 0x0308) {
            for (i in 0 until minOf(out.size, bb.remaining())) { val v = bb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0408) v and 0xFF else v) + q.offset) }
        } else {
            val sb = bb.asShortBuffer()
            for (i in 0 until minOf(out.size, sb.remaining())) { val v = sb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0416) v and 0xFFFF else v) + q.offset) }
        }
    }

    /** The frame at the network's size (stretched to it), as 0..1 RGB planes. */
    private fun shrink(px: IntArray, w: Int, h: Int, dst: FloatArray) {
        val n = mw * mh
        val sx = w.toFloat() / mw; val sy = h.toFloat() / mh
        for (y in 0 until mh) {
            val fy = ((y + 0.5f) * sy - 0.5f).coerceIn(0f, (h - 1).toFloat())
            val y0 = fy.toInt(); val y1 = minOf(y0 + 1, h - 1); val ty = fy - y0
            for (x in 0 until mw) {
                val fx = ((x + 0.5f) * sx - 0.5f).coerceIn(0f, (w - 1).toFloat())
                val x0 = fx.toInt(); val x1 = minOf(x0 + 1, w - 1); val tx = fx - x0
                val c00 = px[y0 * w + x0]; val c01 = px[y0 * w + x1]; val c10 = px[y1 * w + x0]; val c11 = px[y1 * w + x1]
                val i = y * mw + x
                for (ch in 0 until 3) {
                    val sh = 16 - 8 * ch
                    val v0 = ((c00 shr sh) and 0xFF) * (1 - tx) + ((c01 shr sh) and 0xFF) * tx
                    val v1 = ((c10 shr sh) and 0xFF) * (1 - tx) + ((c11 shr sh) and 0xFF) * tx
                    dst[ch * n + i] = (v0 * (1 - ty) + v1 * ty) / 255f
                }
            }
        }
    }

    /** Full size: each frame moved along its motion (scaled up from the network's size) and mixed by the mask. */
    private fun warp(p0: IntArray, p1: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(w * h)
        val n = mw * mh
        val kx = mw.toFloat() / w; val ky = mh.toFloat() / h       // full size -> network size
        val fx = w.toFloat() / mw; val fy = h.toFloat() / mh       // network pixels -> full-size pixels
        for (y in 0 until h) {
            val gy = ((y + 0.5f) * ky - 0.5f).coerceIn(0f, (mh - 1).toFloat())
            val gy0 = gy.toInt(); val gy1 = minOf(gy0 + 1, mh - 1); val ty = gy - gy0
            for (x in 0 until w) {
                val gx = ((x + 0.5f) * kx - 0.5f).coerceIn(0f, (mw - 1).toFloat())
                val gx0 = gx.toInt(); val gx1 = minOf(gx0 + 1, mw - 1); val tx = gx - gx0
                val i00 = gy0 * mw + gx0; val i01 = gy0 * mw + gx1; val i10 = gy1 * mw + gx0; val i11 = gy1 * mw + gx1
                fun at(c: Int): Float {
                    val o = c * n
                    return (flow[o + i00] * (1 - tx) + flow[o + i01] * tx) * (1 - ty) + (flow[o + i10] * (1 - tx) + flow[o + i11] * tx) * ty
                }
                val m = ((mask[i00] * (1 - tx) + mask[i01] * tx) * (1 - ty) + (mask[i10] * (1 - tx) + mask[i11] * tx) * ty).coerceIn(0f, 1f)
                val c0 = sample(p0, w, h, x + at(0) * fx, y + at(1) * fy)
                val c1 = sample(p1, w, h, x + at(2) * fx, y + at(3) * fy)
                var r = 0; var g = 0; var bl = 0
                for (ch in 0 until 3) {
                    val sh = 16 - 8 * ch
                    val v = (((c0 shr sh) and 0xFF) * m + ((c1 shr sh) and 0xFF) * (1 - m) + 0.5f).toInt().coerceIn(0, 255)
                    when (ch) { 0 -> r = v; 1 -> g = v; else -> bl = v }
                }
                out[y * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        return out
    }

    /** Bilinear pixel at (x, y), the edges repeated. */
    private fun sample(px: IntArray, w: Int, h: Int, x: Float, y: Float): Int {
        val cx = x.coerceIn(0f, (w - 1).toFloat()); val cy = y.coerceIn(0f, (h - 1).toFloat())
        val x0 = floor(cx).toInt(); val y0 = floor(cy).toInt()
        val x1 = minOf(x0 + 1, w - 1); val y1 = minOf(y0 + 1, h - 1)
        val tx = cx - x0; val ty = cy - y0
        val c00 = px[y0 * w + x0]; val c01 = px[y0 * w + x1]; val c10 = px[y1 * w + x0]; val c11 = px[y1 * w + x1]
        var out = 0xFF shl 24
        for (sh in intArrayOf(16, 8, 0)) {
            val v0 = ((c00 shr sh) and 0xFF) * (1 - tx) + ((c01 shr sh) and 0xFF) * tx
            val v1 = ((c10 shr sh) and 0xFF) * (1 - tx) + ((c11 shr sh) and 0xFF) * tx
            out = out or ((v0 * (1 - ty) + v1 * ty + 0.5f).toInt().coerceIn(0, 255) shl sh)
        }
        return out
    }

    override fun close() { try { session.close() } catch (_: Throwable) { } }

    companion object {
        const val PACK = "fluido"

        fun isReady(ctx: Context) = SdModel.isReady(ctx, PACK)
        fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
            SdModel.download(ctx, PACK, cancelled, onProgress)

        /** The network size for a frame of [w]×[h] (as stored): wide, tall or square. */
        fun sizeFor(w: Int, h: Int): Pair<Int, Int> {
            val r = w.toFloat() / h
            return when { r > 1.2f -> 1024 to 576; r < 0.83f -> 576 to 1024; else -> 704 to 704 }
        }

        /** Opens RIFE for frames of [w]×[h]: the NPU version first (unless [cpuOnly]), then the CPU one. */
        fun open(ctx: Context, w: Int, h: Int, cpuOnly: Boolean = false): Interpolator {
            val dir = SdModel.dir(ctx, PACK)
            val (mw, mh) = sizeFor(w, h)
            val name = "rife_${mw}x$mh"
            val ctxF = File(dir, "${name}_ctx.onnx"); val bin = File(dir, "$name.bin")
            if (!cpuOnly && ctxF.exists() && bin.exists() && bin.length() > 0) {
                try {
                    NpuUnet.prepareDsp(ctx)
                    val t0 = SystemClock.elapsedRealtime()
                    val o = OrtSession.SessionOptions().apply {
                        setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                        addConfigEntry("session.disable_cpu_ep_fallback", "0")
                        addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
                    }
                    val s = OrtEnvironment.getEnvironment().createSession(ctxF.path, o)
                    val q = readQuant(File(ctxF.path + ".json"))
                    JobLog.add("Más fluido: RIFE $name en la NPU (abrió en ${String.format(Locale.US, "%.1f", (SystemClock.elapsedRealtime() - t0) / 1000f)} s)" +
                        if (q.isNotEmpty()) " · entradas/salidas en enteros" else "")
                    return Interpolator(s, mw, mh, true, q)
                } catch (t: Throwable) {
                    JobLog.notice("Más fluido: la NPU no abrió $name (${(t.message ?: t.javaClass.simpleName).take(200)}); se usa la CPU")
                }
            } else if (!cpuOnly) JobLog.add("Más fluido: $name no tiene versión NPU; se usa la CPU")
            val f = File(dir, "$name.onnx")
            if (!f.exists()) throw IllegalStateException("falta $name.onnx (descarga el paquete Más fluido)")
            val o = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 6))
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            }
            val s = OrtEnvironment.getEnvironment().createSession(f.path, o)
            JobLog.add("Más fluido: RIFE $name en la CPU")
            return Interpolator(s, mw, mh, false, emptyMap())
        }

        private fun readQuant(f: File): Map<String, NpuTile.Quant> = try {
            val j = org.json.JSONObject(f.readText()).optJSONObject("quant")
            if (j == null) emptyMap() else j.keys().asSequence().mapNotNull { k ->
                val o = j.getJSONObject(k)
                if (!o.has("scale")) null else k to NpuTile.Quant(o.getInt("qnn_type"), o.getDouble("scale").toFloat(), o.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }
    }
}
