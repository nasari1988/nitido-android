package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The old-photo restoration pack (published by "Convertir modelo" under the name "restauracion"):
 * SCUNet (noise and grain), CodeFormer (faces), LaMa (scratches and stains), DDColor (colorize).
 */
object RestorePack {
    const val ID = "restauracion"
    const val DENOISE = "rest_denoise.mnn"
    const val FACES = "rest_faces.mnn"
    const val LAMA = "rest_lama.mnn"
    const val COLOR = "rest_color.mnn"

    fun isReady(ctx: Context) = SdModel.isReady(ctx, ID)

    /** The model file, if the pack is installed and that model made it into the pack. */
    fun file(ctx: Context, name: String): File? =
        File(SdModel.dir(ctx, ID), name).takeIf { isReady(ctx) && it.exists() && it.length() > 0 }

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
        SdModel.download(ctx, ID, cancelled, onProgress)
}

/** Classic (non-AI) fixes and the glue around the AI models. */
object RestoreTools {

    private fun pixels(b: Bitmap): IntArray = IntArray(b.width * b.height).also { b.getPixels(it, 0, b.width, 0, 0, b.width, b.height) }

    private fun mutable(b: Bitmap, px: IntArray): Bitmap =
        Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888).also { it.setPixels(px, 0, b.width, 0, 0, b.width, b.height) }

    /** True when the photo has (almost) no color: black and white or sepia-free gray. */
    fun isGrayscale(b: Bitmap): Boolean {
        val s = Bitmap.createScaledBitmap(b, 128, max(1, 128 * b.height / b.width), true)
        val px = pixels(s)
        var spread = 0.0
        for (p in px) {
            val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
            spread += max(r, max(g, bl)) - min(r, min(g, bl))
        }
        return spread / px.size < 12
    }

    /**
     * Faded photos: stretches each color channel on its own between its darkest and brightest
     * values (which also removes the pink/yellow cast of old prints), then adds a little color back.
     */
    fun fixColor(src: Bitmap, saturate: Boolean): Bitmap {
        val px = pixels(src)
        val hist = Array(3) { IntArray(256) }
        val step = max(1, px.size / 300_000)
        var n = 0
        for (i in px.indices step step) {
            val p = px[i]
            hist[0][Color.red(p)]++; hist[1][Color.green(p)]++; hist[2][Color.blue(p)]++
            n++
        }
        fun pct(h: IntArray, q: Float): Int {
            val target = (n * q).toInt(); var acc = 0
            for (v in 0..255) { acc += h[v]; if (acc > target) return v }
            return 255
        }
        val lut = Array(3) { c ->
            var lo = pct(hist[c], 0.004f).toFloat()
            var hi = pct(hist[c], 0.996f).toFloat()
            if (hi - lo < 40f) { val mid = (hi + lo) / 2; lo = mid - 20; hi = mid + 20 }   // don't blow up flat images
            IntArray(256) { v -> ((v - lo) / (hi - lo) * 255f).roundToInt().coerceIn(0, 255) }
        }
        val sat = if (saturate) 1.12f else 1f
        for (i in px.indices) {
            val p = px[i]
            var r = lut[0][Color.red(p)].toFloat(); var g = lut[1][Color.green(p)].toFloat(); var b = lut[2][Color.blue(p)].toFloat()
            if (sat != 1f) {
                val y = 0.299f * r + 0.587f * g + 0.114f * b
                r = y + (r - y) * sat; g = y + (g - y) * sat; b = y + (b - y) * sat
            }
            px[i] = Color.rgb(r.roundToInt().coerceIn(0, 255), g.roundToInt().coerceIn(0, 255), b.roundToInt().coerceIn(0, 255))
        }
        return mutable(src, px)
    }

    /**
     * Colorizes with DDColor: the model sees the photo in gray at 512×512 and returns colors; only
     * those colors are kept and laid over the original, full-size brightness.
     */
    fun colorize(ctx: Context, model: File, src: Bitmap, gpu: Boolean): Bitmap {
        val s = 512
        val small = Bitmap.createScaledBitmap(src, s, s, true)
        val sp = pixels(small)
        val gray = FloatArray(s * s) { i -> val p = sp[i]; (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)) / 255f }
        val out = FloatArray(3 * s * s)
        val tile = try { MnnTile(ctx, model.absolutePath, gpu, precise = true) } catch (t: Throwable) {
            if (!gpu) throw t; MnnTile(ctx, model.absolutePath, false, precise = true)
        }
        tile.use { if (!it.run(gray, out)) throw IllegalStateException("DDColor failed") }
        val n = s * s
        val colored = IntArray(n) { i ->
            Color.rgb((out[i] * 255f).roundToInt().coerceIn(0, 255), (out[n + i] * 255f).roundToInt().coerceIn(0, 255),
                (out[2 * n + i] * 255f).roundToInt().coerceIn(0, 255))
        }
        val big = Bitmap.createScaledBitmap(mutable(small, colored), src.width, src.height, true)
        val cp = pixels(big)
        val px = pixels(src)
        for (i in px.indices) {
            val o = px[i]; val c = cp[i]
            val y = 0.299f * Color.red(o) + 0.587f * Color.green(o) + 0.114f * Color.blue(o)
            val cb = -0.168736f * Color.red(c) - 0.331264f * Color.green(c) + 0.5f * Color.blue(c)
            val cr = 0.5f * Color.red(c) - 0.418688f * Color.green(c) - 0.081312f * Color.blue(c)
            px[i] = Color.rgb((y + 1.402f * cr).roundToInt().coerceIn(0, 255),
                (y - 0.344136f * cb - 0.714136f * cr).roundToInt().coerceIn(0, 255),
                (y + 1.772f * cb).roundToInt().coerceIn(0, 255))
        }
        return mutable(src, px)
    }

    /**
     * Removes painted scratches, dust and stains with LaMa, working in 512×512 windows over the
     * parts of the photo that have paint, and changing only the painted pixels (slightly widened).
     */
    fun removeMarks(ctx: Context, model: File, src: Bitmap, mask: Bitmap, gpu: Boolean,
                    onProgress: (Float) -> Unit, cancelled: () -> Boolean): Bitmap? {
        val w = src.width; val h = src.height
        val m = if (mask.width == w && mask.height == h) mask else Bitmap.createScaledBitmap(mask, w, h, false)
        val ma = pixels(m)
        // widen the painted area by 2 px so the edges of each scratch are replaced too
        val hard = BooleanArray(w * h) { (ma[it] ushr 24) > 30 }
        val sel = BooleanArray(w * h)
        val r = 2
        for (y in 0 until h) for (x in 0 until w) if (hard[y * w + x]) {
            for (dy in -r..r) for (dx in -r..r) {
                val yy = y + dy; val xx = x + dx
                if (yy in 0 until h && xx in 0 until w) sel[yy * w + xx] = true
            }
        }
        val px = pixels(src)
        val t = 512; val stride = 448
        val xs = starts(w, t, stride); val ys = starts(h, t, stride)
        val todo = mutableListOf<Pair<Int, Int>>()
        for (y0 in ys) for (x0 in xs) {
            var any = false
            loop@ for (y in max(0, y0) until min(h, y0 + t)) for (x in max(0, x0) until min(w, x0 + t)) if (sel[y * w + x]) { any = true; break@loop }
            if (any) todo += x0 to y0
        }
        if (todo.isEmpty()) return src
        val tile = try { MnnTile(ctx, model.absolutePath, gpu, precise = true) } catch (e: Throwable) {
            if (!gpu) throw e; MnnTile(ctx, model.absolutePath, false, precise = true)
        }
        val n = t * t
        val input = FloatArray(4 * n)
        val out = FloatArray(3 * n)
        tile.use { lama ->
            for ((k, pos) in todo.withIndex()) {
                if (cancelled()) return null
                val (x0, y0) = pos
                for (y in 0 until t) {
                    val sy = (y0 + y).coerceIn(0, h - 1)
                    for (x in 0 until t) {
                        val sx = (x0 + x).coerceIn(0, w - 1)
                        val p = px[sy * w + sx]; val i = y * t + x
                        input[i] = Color.red(p) / 255f; input[n + i] = Color.green(p) / 255f; input[2 * n + i] = Color.blue(p) / 255f
                        input[3 * n + i] = if (sel[sy * w + sx]) 1f else 0f
                    }
                }
                if (!lama.run(input, out)) throw IllegalStateException("LaMa failed")
                for (y in 0 until t) {
                    val sy = y0 + y; if (sy !in 0 until h) continue
                    for (x in 0 until t) {
                        val sx = x0 + x; if (sx !in 0 until w) continue
                        val j = sy * w + sx
                        if (!sel[j]) continue
                        val i = y * t + x
                        px[j] = Color.rgb((out[i] * 255f).roundToInt().coerceIn(0, 255), (out[n + i] * 255f).roundToInt().coerceIn(0, 255),
                            (out[2 * n + i] * 255f).roundToInt().coerceIn(0, 255))
                    }
                }
                onProgress((k + 1f) / todo.size)
            }
        }
        return mutable(src, px)
    }

    /** Window start positions covering [len] with windows of [t] (centered when the image is smaller). */
    private fun starts(len: Int, t: Int, stride: Int): List<Int> {
        if (len <= t) return listOf(-(t - len) / 2)
        val out = mutableListOf<Int>()
        var p = 0
        while (true) {
            if (p + t >= len) { out += len - t; break }
            out += p; p += stride
        }
        return out
    }
}
