package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The old-photo restoration pack (published by "Convertir modelo" under the name "restauracion"):
 * SCUNet (noise and grain), CodeFormer (faces), LaMa (scratches and stains), DDColor (colorize).
 */
object RestorePack {
    const val ID = "restauracion"
    const val DENOISE = "rest_denoise.mnn"
    const val DEBLUR = "rest_deblur.mnn"
    const val FACES = "rest_faces.mnn"
    const val LAMA = "rest_lama.mnn"
    const val COLOR = "rest_color.mnn"

    fun isReady(ctx: Context) = SdModel.isReady(ctx, ID)

    /**
     * The NPU versions published after the pack was downloaded (Enfocar and Quitar ruido: NAFNet,
     * ~54 MB): fetched on their own, without asking to update the whole pack. Their sizes are
     * checked against the published list; files.txt gets them so no update is offered for them.
     * Quietly does nothing without internet. Blocking: call from a work thread.
     */
    fun fetchNpuExtras(ctx: Context, say: (String) -> Unit = {}) {
        if (!isReady(ctx)) return
        val dir = SdModel.dir(ctx, ID)
        val wanted = listOf("rest_deblur", "rest_denoise", "rest_lama", "rest_color").flatMap { listOf("$it.npu.bin", "$it.npu_ctx.onnx", "$it.npu_ctx.onnx.json") }
        if (wanted.all { File(dir, it).let { f -> f.exists() && f.length() > 0 } }) return
        val base = "https://github.com/${ModelCatalog.REPO}/releases/download/modelo-$ID/"
        fun open(name: String) = (java.net.URL(base + name).openConnection() as java.net.HttpURLConnection).apply {
            instanceFollowRedirects = true; connectTimeout = 15_000; readTimeout = 30_000
            setRequestProperty("User-Agent", "Nitido-app")
        }
        val list = try {
            val c = open("files.txt")
            try { if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null } finally { c.disconnect() }
        } catch (t: Throwable) { null } ?: return
        val sizes = list.lines().mapNotNull { l -> l.trim().split(" ").takeIf { it.size == 2 }?.let { it[0] to (it[1].toLongOrNull() ?: -1L) } }.toMap()
        val todo = wanted.filter { sizes.containsKey(it) && File(dir, it).length() != sizes[it] }
        if (todo.isEmpty()) return
        JobLog.add("Paquete: bajando las versiones NPU nuevas de Enfocar, Quitar ruido, Rayones y Colorear (${todo.size} archivos, ${ModelCatalog.mb(todo.sumOf { sizes[it] ?: 0L })})")
        for (n in todo) {
            say(n)
            val part = File(dir, "$n.part")
            try {
                val c = open(n)
                try {
                    if (c.responseCode != 200) { JobLog.notice("Paquete: $n no se pudo bajar (${c.responseCode})"); return }
                    c.inputStream.use { inp -> part.outputStream().use { inp.copyTo(it, 1 shl 16) } }
                } finally { c.disconnect() }
                if (part.length() != sizes[n]) { JobLog.notice("Paquete: $n llegó incompleto"); part.delete(); return }
                val f = File(dir, n); f.delete(); part.renameTo(f)
            } catch (t: Throwable) {
                part.delete(); JobLog.add("Paquete: sin internet para $n (${t.message}); sigue en la GPU"); return
            }
        }
        // the local list knows them now: no "update" is offered for files already here
        try {
            val lf = File(dir, "files.txt")
            val have = if (lf.exists()) lf.readLines().filter { it.isNotBlank() } else emptyList()
            val names = have.map { it.substringBefore(' ') }.toSet()
            lf.writeText((have + wanted.filter { it !in names && sizes.containsKey(it) }.map { "$it ${sizes[it]}" }).joinToString("\n") + "\n")
        } catch (_: Throwable) { }
        JobLog.add("Paquete: versiones NPU de Enfocar y Quitar ruido listas")
    }

    /** The model file, if the pack is installed and that model made it into the pack. */
    fun file(ctx: Context, name: String): File? =
        File(SdModel.dir(ctx, ID), name).takeIf { isReady(ctx) && it.exists() && it.length() > 0 }

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
        SdModel.download(ctx, ID, cancelled, onProgress)
}

/** Classic (non-AI) fixes and the glue around the AI models. */
object RestoreTools {

    private fun pixels(b: Bitmap): IntArray = IntArray(b.width * b.height).also { b.getPixels(it, 0, b.width, 0, 0, b.width, b.height) }

    /** Which processor each AI step used in the last run (e.g. "Colorear" to "NPU"), for the final message. */
    val engines = java.util.concurrent.ConcurrentHashMap<String, String>()
    /** Why the NPU was not used for a step, when it was tried (for the log). */
    val npuNotes = java.util.concurrent.ConcurrentHashMap<String, String>()

    /**
     * The NPU version of a pack model, opened: "rest_color.mnn" -> "rest_color.npu_ctx.onnx" (+ its
     * .bin and .json), compiled in the server for this NPU (W8A16). Null when it isn't there or
     * the NPU refused it (then [npuNotes] says why).
     */
    /** Remembers that [base]'s NPU version (this exact file) ran far too slowly, so it isn't tried again. */
    fun markNpuSlow(ctx: Context, model: File) {
        val f = File(model.parentFile, model.name.removeSuffix(".mnn") + ".npu.bin")
        ctx.getSharedPreferences("npu_slow", Context.MODE_PRIVATE).edit().putLong(f.name, f.length()).apply()
    }

    enum class NpuMode { AUTO, ALWAYS, OFF }
    /** Set by Restaurar's Processor label for each run: AUTO skips steps known to be slower on the NPU. */
    @Volatile var npuMode = NpuMode.AUTO

    fun npuFor(ctx: Context, model: File, step: String, allowOff: Boolean = false): NpuTile? {
        val dir = model.parentFile ?: return null
        val base = model.name.removeSuffix(".mnn")
        if (npuMode == NpuMode.OFF) return null
        // measured on this phone to be worse on the NPU (see NPU_OFF): the GPU/CPU, and their NPU
        // files go to free the space ([allowOff]: a step that fixes the NPU's problem itself)
        if (base in NPU_OFF && npuMode == NpuMode.AUTO && !allowOff) {
            if (base != "rest_lama") dir.listFiles()?.filter { it.name.startsWith("$base.npu") }?.forEach {
                JobLog.add("borrando ${it.name} (${ModelCatalog.mb(it.length())}), este paso va mejor sin la NPU"); it.delete()
            }
            return null
        }
        val binF = File(dir, "$base.npu.bin")
        if (npuMode == NpuMode.AUTO && binF.exists() && ctx.getSharedPreferences("npu_slow", Context.MODE_PRIVATE).getLong(binF.name, -1L) == binF.length()) {
            npuNotes[step] = "la NPU resultó demasiado lenta con este modelo; se usa la GPU"
            JobLog.add("NPU: $base se omite (fue demasiado lenta antes)")
            return null
        }
        // the float versions of the first try don't run on this NPU (it has no fp16): free their space
        dir.listFiles()?.filter { it.name == "$base.npu.onnx" || it.name.startsWith("ctx_npu_$base") }?.forEach {
            JobLog.add("borrando ${it.name} (${ModelCatalog.mb(it.length())}), ya no se usa"); it.delete()
        }
        val f = File(dir, "$base.npu_ctx.onnx")
        val bin = File(dir, "$base.npu.bin")
        if (!f.exists() && !bin.exists()) {
            // this step has no NPU version yet (not an error: it runs on the GPU as before)
            JobLog.add("NPU: $base todavía no tiene versión NPU")
            return null
        }
        if (!f.exists() || !bin.exists() || bin.length() == 0L) {
            npuNotes[step] = "falta ${if (!f.exists()) f.name else bin.name} (actualiza el paquete de restauración)"
            JobLog.notice("NPU: falta ${if (!f.exists()) f.path else bin.path}")
            return null
        }
        JobLog.add("NPU: abriendo ${f.name} + ${bin.name} (${ModelCatalog.mb(bin.length())})")
        val t = NpuTile.openPrecompiled(ctx, f, base)
        if (t == null) npuNotes[step] = NpuTile.lastError ?: "?"
        return t
    }

    private fun range(a: FloatArray): String {
        var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE; var bad = 0
        for (v in a) { if (!v.isFinite()) { bad++; continue }; if (v < lo) lo = v; if (v > hi) hi = v }
        return "mín %.2f máx %.2f".format(java.util.Locale.US, lo, hi) + (if (bad > 0) " · $bad no válidos" else "")
    }

    fun sane(a: FloatArray, lo: Float, hi: Float): Boolean {
        var nonZero = false
        for (v in a) { if (!v.isFinite() || v < lo || v > hi) return false; if (v != 0f) nonZero = true }
        return nonZero
    }

    private fun mutable(b: Bitmap, px: IntArray): Bitmap =
        Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888).also { it.setPixels(px, 0, b.width, 0, 0, b.width, b.height) }

    /** True when the photo has (almost) no color: black and white or sepia-free gray. */
    fun isGrayscale(b: Bitmap): Boolean {
        val s = Bitmap.createScaledBitmap(b, 128, max(1, 128 * b.height / b.width), true)
        val px = pixels(s)
        var spread = 0.0
        for (p in px) {
            val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
            spread += max(r, max(g, bl)) - min(r, min(g, bl))
        }
        return spread / px.size < 12
    }

    /**
     * How sharp the photo is at its fine scale compared with half size (Laplacian energy). A
     * really blurred photo (out of focus, moved) has almost no fine detail: below ~0.35. Grainy or
     * sharp photos are well above. Measured on the computer with blurred copies of test photos.
     */
    fun blurRatio(b: Bitmap): Float {
        fun lap(bm: Bitmap): Double {
            val w = bm.width; val h = bm.height
            val px = IntArray(w * h); bm.getPixels(px, 0, w, 0, 0, w, h)
            val g = FloatArray(w * h) { i -> val p = px[i]; 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p) }
            var s = 0.0; var s2 = 0.0; var n = 0
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                val l = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]
                s += l; s2 += l * l; n++
            }
            if (n == 0) return 0.0
            val m = s / n
            return s2 / n - m * m
        }
        val long = max(b.width, b.height)
        val k = if (long > 1024) 1024f / long else 1f
        val a = Bitmap.createScaledBitmap(b, max(8, (b.width * k).toInt()), max(8, (b.height * k).toInt()), true)
        val half = Bitmap.createScaledBitmap(a, max(4, a.width / 2), max(4, a.height / 2), true)
        val full = lap(a); val h2 = lap(half)
        return if (h2 <= 1e-6) 1f else (full / h2).toFloat()
    }

    /**
     * A photo without real colors: gray, sepia, or any single tint (a bluish or greenish old
     * print). Little color, and the color there is points the same way in almost every pixel.
     * These get colorized by ✦ Restaurar todo.
     */
    fun isOneTone(b: Bitmap): Boolean {
        if (isGrayscale(b) || isSepia(b)) return true
        val sm = Bitmap.createScaledBitmap(b, 128, max(1, 128 * b.height / b.width), true)
        val px = pixels(sm)
        var spread = 0.0; var sx = 0.0; var sy = 0.0; var len = 0.0
        for (p in px) {
            val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
            spread += max(r, max(g, bl)) - min(r, min(g, bl))
            // the pixel's color as a direction (opponent axes)
            val x = (r - g).toDouble(); val y = (r + g - 2 * bl) / 2.0
            sx += x; sy += y; len += Math.sqrt(x * x + y * y)
        }
        val avg = spread / px.size
        val consistency = if (len > 0) Math.sqrt(sx * sx + sy * sy) / len else 1.0
        return avg < 40 && consistency > 0.85
    }

    /** True for sepia / single-tone prints: little color, almost all of it the same warm tint. */
    fun isSepia(b: Bitmap): Boolean {
        val sm = Bitmap.createScaledBitmap(b, 128, max(1, 128 * b.height / b.width), true)
        val px = pixels(sm)
        var spread = 0.0; var warm = 0; var ordered = 0
        for (p in px) {
            val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
            spread += max(r, max(g, bl)) - min(r, min(g, bl))
            if (r - bl > 6) warm++
            if (r >= g - 3 && g >= bl - 3) ordered++
        }
        return spread / px.size < 45 && warm > px.size * 0.7 && ordered > px.size * 0.8
    }

    /**
     * Faded photos: stretches each color channel on its own between its darkest and brightest
     * values (which also removes the pink/yellow cast of old prints), then adds a little color back.
     */
    fun fixColor(src: Bitmap, saturate: Boolean, gentle: Boolean = false): Bitmap {
        val px = pixels(src)
        val hist = Array(3) { IntArray(256) }
        val step = max(1, px.size / 300_000)
        var n = 0
        for (i in px.indices step step) {
            val p = px[i]
            hist[0][Color.red(p)]++; hist[1][Color.green(p)]++; hist[2][Color.blue(p)]++
            n++
        }
        fun pct(h: IntArray, q: Float): Int {
            val target = (n * q).toInt(); var acc = 0
            for (v in 0..255) { acc += h[v]; if (acc > target) return v }
            return 255
        }
        val lut = Array(3) { c ->
            // Black-and-white, sepia, or about to be colorized: a softer stretch that keeps the
            // whites (old prints are flat, and a full stretch burns the light areas).
            var lo = pct(hist[c], if (gentle) 0.005f else 0.004f).toFloat()
            var hi = pct(hist[c], if (gentle) 0.999f else 0.996f).toFloat()
            val minRange = if (gentle) 140f else 40f
            if (hi - lo < minRange) { val mid = (hi + lo) / 2; lo = mid - minRange / 2; hi = mid + minRange / 2 }   // don't blow up flat images
            IntArray(256) { v -> ((v - lo) / (hi - lo) * 255f).roundToInt().coerceIn(0, 255) }
        }
        for (i in px.indices) {
            val p = px[i]
            px[i] = Color.rgb(lut[0][Color.red(p)], lut[1][Color.green(p)], lut[2][Color.blue(p)])
        }
        neutralize(px, src.width, src.height)
        val sat = if (saturate) 1.12f else 1f
        for (i in px.indices) {
            val p = px[i]
            var r = Color.red(p).toFloat(); var g = Color.green(p).toFloat(); var b = Color.blue(p).toFloat()
            if (sat != 1f) {
                val y = 0.299f * r + 0.587f * g + 0.114f * b
                r = y + (r - y) * sat; g = y + (g - y) * sat; b = y + (b - y) * sat
            }
            px[i] = Color.rgb(r.roundToInt().coerceIn(0, 255), g.roundToInt().coerceIn(0, 255), b.roundToInt().coerceIn(0, 255))
        }
        return mutable(src, px)
    }

    /**
     * Removes a leftover color cast (the green / pink of faded prints): the nearly gray areas of
     * the photo (walls, floor, white clothes) are assumed to be gray, and the whole photo is
     * shifted by most of the color they show. Strongly colored areas don't take part.
     */
    private fun neutralize(px: IntArray, w: Int, h: Int) {
        // Faded prints often have a cast that changes across the photo (green on one side, pink
        // on the other), so the cast is measured in a 4×4 grid of zones and the correction is
        // blended smoothly between zone centers. Zones with few gray pixels lean on the average.
        val g = 4
        val lab = FloatArray(3)
        val sa = DoubleArray(g * g); val sb = DoubleArray(g * g); val cnt = IntArray(g * g)
        var ta = 0.0; var tb = 0.0; var tn = 0
        val step = max(1, kotlin.math.sqrt(px.size / 200_000.0).toInt())
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                toLab(px[y * w + x], lab)
                val chroma = Math.hypot(lab[1].toDouble(), lab[2].toDouble())
                if (lab[0] in 15f..92f && chroma < 22.0) {
                    val c = min(g - 1, y * g / h) * g + min(g - 1, x * g / w)
                    sa[c] = sa[c] + lab[1]; sb[c] = sb[c] + lab[2]; cnt[c]++
                    ta += lab[1]; tb += lab[2]; tn++
                }
                x += step
            }
            y += step
        }
        if (tn < 500) return
        val ma = ta / tn; val mb = tb / tn
        val perCell = tn / (g * g).toDouble()
        val oa = FloatArray(g * g); val ob = FloatArray(g * g)
        for (c in 0 until g * g) {
            val trust = if (cnt[c] == 0) 0.0 else minOf(1.0, cnt[c] / (perCell * 0.5))
            val a = if (cnt[c] == 0) ma else trust * sa[c] / cnt[c] + (1 - trust) * ma
            val b = if (cnt[c] == 0) mb else trust * sb[c] / cnt[c] + (1 - trust) * mb
            oa[c] = (-0.8 * a).toFloat(); ob[c] = (-0.8 * b).toFloat()
        }
        if (oa.all { kotlin.math.abs(it) < 0.75f } && ob.all { kotlin.math.abs(it) < 0.75f }) return
        for (yy in 0 until h) {
            val fy = ((yy + 0.5f) * g / h - 0.5f).coerceIn(0f, g - 1f)
            val y0 = fy.toInt(); val y1 = min(y0 + 1, g - 1); val ty = fy - y0
            for (xx in 0 until w) {
                val fx = ((xx + 0.5f) * g / w - 0.5f).coerceIn(0f, g - 1f)
                val x0 = fx.toInt(); val x1 = min(x0 + 1, g - 1); val tx = fx - x0
                fun bil(o: FloatArray) = (o[y0 * g + x0] * (1 - tx) + o[y0 * g + x1] * tx) * (1 - ty) +
                    (o[y1 * g + x0] * (1 - tx) + o[y1 * g + x1] * tx) * ty
                val i = yy * w + xx
                toLab(px[i], lab)
                px[i] = fromLab(lab[0], lab[1] + bil(oa), lab[2] + bil(ob))
            }
        }
    }

    /**
     * The part of a photographed or scanned print without the background strips around it
     * (scanner lid, table, cloth): near each edge (up to 6%) it looks for a sharp jump in the
     * average color of rows / columns. Returns the whole picture when there's no clear border.
     */
    fun borderCrop(src: Bitmap): android.graphics.Rect {
        val k = minOf(1f, 480f / maxOf(src.width, src.height))
        val sm = Bitmap.createScaledBitmap(src, maxOf(8, (src.width * k).toInt()), maxOf(8, (src.height * k).toInt()), true)
        val w = sm.width; val h = sm.height
        val px = pixels(sm)
        fun profile(rows: Boolean): Array<FloatArray> {
            val n = if (rows) h else w; val m = if (rows) w else h
            return Array(n) { i ->
                var r = 0f; var g = 0f; var b = 0f; var c = 0
                for (j in (m / 10) until (m - m / 10)) {
                    val p = if (rows) px[i * w + j] else px[j * w + i]
                    r += Color.red(p); g += Color.green(p); b += Color.blue(p); c++
                }
                floatArrayOf(r / c, g / c, b / c)
            }
        }
        /** Index of the first line inside the photo, counting from the edge, or 0. */
        fun cut(prof: Array<FloatArray>, fromEnd: Boolean): Int {
            val n = prof.size
            val max = maxOf(2, (n * 0.06f).toInt())
            fun at(i: Int) = prof[if (fromEnd) n - 1 - i else i]
            fun band(a: Int, b: Int): FloatArray {
                val o = FloatArray(3); var c = 0
                for (i in a until b) { val v = at(i.coerceIn(0, n - 1)); o[0] += v[0]; o[1] += v[1]; o[2] += v[2]; c++ }
                return floatArrayOf(o[0] / c, o[1] / c, o[2] / c)
            }
            var best = 0f; var where = 0
            val win = maxOf(2, n / 100)
            for (j in win until max) {
                val a = band(j - win, j); val b = band(j, j + win)
                val d = kotlin.math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]))
                if (d > best) { best = d; where = j }
            }
            return if (best > 35f && where >= maxOf(2, n / 200)) (where + maxOf(1, n / 200)) else 0
        }
        val rows = profile(true); val cols = profile(false)
        val top = cut(rows, false); val bottom = cut(rows, true)
        val left = cut(cols, false); val right = cut(cols, true)
        val inv = 1f / k
        val r = android.graphics.Rect((left * inv).toInt(), (top * inv).toInt(),
            src.width - (right * inv).toInt(), src.height - (bottom * inv).toInt())
        return if (r.width() > src.width / 2 && r.height() > src.height / 2) r else android.graphics.Rect(0, 0, src.width, src.height)
    }

    /** [a] + ([b] - [a]) × [k], pixel by pixel ([b] same size as [a]). */
    fun mix(a: Bitmap, b: Bitmap, k: Float): Bitmap {
        val pa = pixels(a); val pb = pixels(if (b.width == a.width && b.height == a.height) b else Bitmap.createScaledBitmap(b, a.width, a.height, true))
        for (i in pa.indices) {
            val x = pa[i]; val y = pb[i]
            fun m(sh: Int) = (((x shr sh) and 0xFF) + ((((y shr sh) and 0xFF) - ((x shr sh) and 0xFF)) * k)).roundToInt().coerceIn(0, 255)
            pa[i] = Color.rgb(m(16), m(8), m(0))
        }
        return mutable(a, pa)
    }

    /**
     * Colorizes with DDColor. The model sees the photo in gray at its own size and returns the Lab
     * color channels (a, b); those are enlarged and combined with the photo's own full-size
     * lightness (L), as the official DDColor pipeline does.
     */
    fun colorize(ctx: Context, model: File, src: Bitmap, gpu: Boolean, sat: Float = COLOR_SAT): Bitmap {
        fun grayInput(s: Int): FloatArray {
            val n = s * s
            val sp = pixels(Bitmap.createScaledBitmap(src, s, s, true))
            val input = FloatArray(3 * n)
            for (i in 0 until n) {
                // a gray with the same lightness as the pixel (Lab L with a = b = 0, back in sRGB)
                val g = grayOf(sp[i])
                input[i] = g; input[n + i] = g; input[2 * n + i] = g
            }
            return input
        }
        var s = 0
        var got: FloatArray? = null
        // DDColor on this NPU (W8A16) took 7 s against 3.8 s on the CPU with the same colors: the
        // CPU it is. Its NPU files, if an earlier pack brought them, are removed to free the space.
        // The NPU when it has been as fast as the CPU here, or when the phone is warm (the CPU slows
        // down a lot with heat: 38 s instead of 4-7 s; the NPU hardly does). Times are remembered.
        val tp = ctx.getSharedPreferences("color_times", Context.MODE_PRIVATE)
        val cpuMs = tp.getFloat("cpu", 0f); val npuMs = tp.getFloat("npu", 0f)
        val hr = HeatGuard.headroom(ctx)
        val warm = hr.isFinite() && hr > 0.5f
        val useNpu = npuMode == NpuMode.ALWAYS || (npuMode == NpuMode.AUTO &&
            (warm || (npuMs > 0f && cpuMs > 0f && npuMs <= cpuMs * 1.1f) || npuMs == 0f && cpuMs > 15000f))
        JobLog.add("Colorear: " + (if (useNpu) "NPU" else "procesador") + " · antes: procesador ${if (cpuMs > 0) "${cpuMs.toInt()} ms" else "?"}, NPU ${if (npuMs > 0) "${npuMs.toInt()} ms" else "?"}" +
            (if (hr.isFinite()) " · margen térmico ${((1f - hr).coerceIn(0f, 1f) * 100).toInt()} %" else ""))
        fun remember(key: String, ms: Long) { val old = tp.getFloat(key, 0f); tp.edit().putFloat(key, if (old > 0f) old * 0.6f + ms * 0.4f else ms.toFloat()).apply() }
        if (COLOR_ON_NPU || useNpu) npuFor(ctx, model, "color", allowOff = true)?.use { npu ->
            val sz = npu.inShape[2].toInt()
            val o = FloatArray(2 * sz * sz)
            val t1 = android.os.SystemClock.elapsedRealtime()
            val ok = try { npu.run(grayInput(sz), o) } catch (t: Throwable) { npuNotes["color"] = t.message ?: "error"; JobLog.error("Colorear en NPU", t); false }
            val ms = android.os.SystemClock.elapsedRealtime() - t1
            JobLog.add("Colorear NPU ${sz}×$sz: $ms ms · a/b ${range(o)}")
            if (ok) remember("npu", ms)
            if (ok && sane(o, -400f, 400f)) { s = sz; got = o } else if (ok) npuNotes["color"] = "resultado fuera de rango ${range(o)}"
        }
        engines["color"] = if (got != null) "NPU" else "CPU"
        if (got == null) {
            // CPU: one 512×512 pass takes a few seconds, and it is exact there
            MnnTile(ctx, model.absolutePath, false, precise = true).use { net ->
                s = net.inShape[2]
                val n = s * s
                val o = FloatArray(2 * n)
                val t1 = android.os.SystemClock.elapsedRealtime()
                val inp = grayInput(s)
                if (!net.run(inp, o)) throw IllegalStateException("DDColor failed")
                // a second look at the photo flipped left-right. Where both looks agree the color
                // stays; where they disagree (an arm blue in one, skin in the other) DDColor is
                // guessing, so that part is left with little color instead of a wrong one.
                val flip = FloatArray(3 * n)
                for (c in 0 until 3) for (y in 0 until s) for (x in 0 until s) flip[c * n + y * s + x] = inp[c * n + y * s + (s - 1 - x)]
                val o2 = FloatArray(2 * n)
                var unsure = 0
                if (net.run(flip, o2)) {
                    for (y in 0 until s) for (x in 0 until s) {
                        val i = y * s + x; val j = y * s + (s - 1 - x)
                        val a1 = o[i]; val b1 = o[n + i]; val a2 = o2[j]; val b2 = o2[n + j]
                        val d = Math.hypot((a1 - a2).toDouble(), (b1 - b2).toDouble()).toFloat()
                        val sure = (1f - (d - 12f) / 30f).coerceIn(0.25f, 1f)
                        if (sure < 0.7f) unsure++
                        o[i] = (a1 + a2) * 0.5f * sure; o[n + i] = (b1 + b2) * 0.5f * sure
                    }
                } else JobLog.notice("Colorear: la segunda mirada falló; se usa una sola")
                remember("cpu", android.os.SystemClock.elapsedRealtime() - t1)
                JobLog.add("Colorear CPU ${s}×$s (2 miradas): ${android.os.SystemClock.elapsedRealtime() - t1} ms · a/b ${range(o)} · dudoso ${unsure * 100 / n} % · " +
                    "4 hilos de ${Runtime.getRuntime().availableProcessors()} núcleos · ${HeatGuard.describe(ctx)}")
                got = o
            }
        }
        val ab = got!!
        val n = s * s
        run {
            val w = src.width; val h = src.height
            val px = pixels(src)
            val lab = FloatArray(3)
            val L = FloatArray(w * h); val A = FloatArray(w * h); val B = FloatArray(w * h)
            for (y in 0 until h) {
                val fy = ((y + 0.5f) * s / h - 0.5f).coerceIn(0f, s - 1f)
                val y0 = fy.toInt(); val y1 = min(y0 + 1, s - 1); val ty = fy - y0
                for (x in 0 until w) {
                    val fx = ((x + 0.5f) * s / w - 0.5f).coerceIn(0f, s - 1f)
                    val x0 = fx.toInt(); val x1 = min(x0 + 1, s - 1); val tx = fx - x0
                    fun bil(off: Int): Float {
                        val a = ab[off + y0 * s + x0] * (1 - tx) + ab[off + y0 * s + x1] * tx
                        val b = ab[off + y1 * s + x0] * (1 - tx) + ab[off + y1 * s + x1] * tx
                        return a * (1 - ty) + b * ty
                    }
                    val i = y * w + x
                    toLab(px[i], lab)
                    L[i] = lab[0] / 100f
                    // DDColor's colors are strong: keep [sat] of them (81 % normally; Avanzado sets it)
                    A[i] = bil(0) * sat; B[i] = bil(n) * sat
                }
            }
            // The colors come at 512 px: fit them to the photo's own edges (guided filter on the
            // lightness) so they don't spill over edges as purple / rainbow halos.
            val r = maxOf(4, maxOf(w, h) / 220)
            val A2 = guided(L, A, w, h, r, 1e-3f); val B2 = guided(L, B, w, h, r, 1e-3f)
            skinFromFaces(src, L, A2, B2, w, h)
            oneSkinPerPerson(ctx, src, A2, B2, w, h)
            for (i in px.indices) {
                // DDColor paints big near-white areas (white dresses, walls) pink: fade the color out
                // in the brightest parts. Skin and mid tones (lightness below ~0.7) are untouched; the
                // warm axis (b) keeps a little more, so whites read as old paper, not as grey.
                val k = ((L[i] - 0.70f) / 0.25f).coerceIn(0f, 1f)
                val fade = k * k * (3 - 2 * k)
                var a = A2[i] * (1f - 0.85f * fade)
                var b = B2[i] * (1f - 0.6f * fade)
                // a more natural look: DDColor leans to pink-purple (a > 0 with b < 0) on old photos.
                // Purples are cut the most, pinks a bit, and everything gets a slight warm (b > 0) light
                if (a > 0f && b < 0f) { a *= 0.45f; b *= 0.35f }
                else if (a > 0f) a *= 0.75f
                else if (b < 0f) b *= 0.7f
                b += 4f * (1f - 0.5f * fade)
                px[i] = fromLab(L[i] * 100f, a, b)
            }
            return mutable(src, px)
        }
    }

    /**
     * DDColor gets faces right but often paints arms and legs gray-blue or purple. Each face's
     * skin color (or a natural skin tone when the face itself came out cold) is carried to the
     * cold, skin-bright pixels under and around that face: that person's arms, hands, legs.
     * Clothes keep their color: only cold or gray parts with a lightness like the face's move.
     */
    /**
     * Autoprueba «Colorear: procesador contra NPU»: one 512×512 look of DDColor on each, with the
     * time, the phone's heat and how far apart their colors are. Remembers both times (the choice
     * in [colorize] uses them).
     */
    fun colorBench(ctx: Context, model: File, gray: Bitmap): String {
        val s0 = 512; val n = s0 * s0
        val sp = pixels(Bitmap.createScaledBitmap(gray, s0, s0, true))
        val input = FloatArray(3 * n)
        for (i in 0 until n) { val g = grayOf(sp[i]); input[i] = g; input[n + i] = g; input[2 * n + i] = g }
        val tp = ctx.getSharedPreferences("color_times", Context.MODE_PRIVATE)
        val oc = FloatArray(2 * n)
        val tc = MnnTile(ctx, model.absolutePath, false, precise = true).use { net ->
            val t = android.os.SystemClock.elapsedRealtime(); if (!net.run(input, oc)) throw IllegalStateException("CPU falló"); android.os.SystemClock.elapsedRealtime() - t
        }
        val old = npuMode; npuMode = NpuMode.ALWAYS
        val npu0: NpuTile? = try { npuFor(ctx, model, "color", allowOff = true) } finally { npuMode = old }
        val npu = npu0 ?: return "procesador ${tc} ms · NPU: no disponible (${npuNotes["color"] ?: "sin archivos; se bajan al restaurar con Colorear"}) · ${HeatGuard.describe(ctx)}"
        val on = FloatArray(2 * n)
        val tn = npu.use { u -> val t = android.os.SystemClock.elapsedRealtime(); if (!u.run(input, on)) throw IllegalStateException("NPU falló"); android.os.SystemClock.elapsedRealtime() - t }
        var d = 0.0; for (i in oc.indices) d += kotlin.math.abs(oc[i] - on[i]); d /= oc.size
        tp.edit().putFloat("cpu", tc.toFloat()).putFloat("npu", tn.toFloat()).apply()
        return "procesador $tc ms · NPU $tn ms · diferencia de color media %.1f (a/b) · %s".format(java.util.Locale.US, d, HeatGuard.describe(ctx))
    }

    /**
     * One skin tone per person. DDColor gives a face, the arms and the legs different colors (a pale
     * face, peach arms, orange legs). MediaPipe marks the skin (face and body); each skin pixel goes
     * to the nearest face (people stand under their faces); each person's tone is the median of their
     * skin, pulled into a natural range (never cold, never orange); every skin pixel moves to it,
     * keeping 35 % of its own difference (lips and cheeks a bit redder, shadows as they were).
     */
    private fun oneSkinPerPerson(ctx: Context, src: Bitmap, A: FloatArray, B: FloatArray, w: Int, h: Int) {
        val pt = try { BodyParts.of(ctx, src) } catch (t: Throwable) { null } ?: run { JobLog.add("Piel: no se encontraron personas; sin tono único"); return }
        val pw = pt.w; val ph = pt.h
        fun cls(i: Int) = pt.classes[i].toInt() and 0xFF
        // faces: groups of face-skin pixels (a coarse grid joins each face's pixels)
        val cell = maxOf(4, pw / 48)
        val gw = (pw + cell - 1) / cell; val gh = (ph + cell - 1) / cell
        val cnt = IntArray(gw * gh)
        for (y in 0 until ph) for (x in 0 until pw) if (cls(y * pw + x) == BodyParts.FACE_SKIN) cnt[(y / cell) * gw + x / cell]++
        val label = IntArray(gw * gh) { -1 }
        val faces = ArrayList<FloatArray>()   // cx, cy, size (pixels)
        for (g in cnt.indices) if (cnt[g] > cell * cell / 4 && label[g] < 0) {
            val stack = ArrayDeque<Int>(); stack.add(g); label[g] = faces.size
            var sx = 0.0; var sy = 0.0; var sn = 0.0
            while (stack.isNotEmpty()) {
                val c = stack.removeLast(); val cx = c % gw; val cy = c / gw
                sx += (cx + 0.5) * cell * cnt[c]; sy += (cy + 0.5) * cell * cnt[c]; sn += cnt[c]
                for ((dx, dy) in listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)) {
                    val nx = cx + dx; val ny = cy + dy
                    if (nx in 0 until gw && ny in 0 until gh) { val q = ny * gw + nx; if (label[q] < 0 && cnt[q] > cell * cell / 4) { label[q] = faces.size; stack.add(q) } }
                }
            }
            if (sn > cell * cell) faces += floatArrayOf((sx / sn).toFloat(), (sy / sn).toFloat(), sn.toFloat())
        }
        if (faces.isEmpty()) { JobLog.add("Piel: no se encontraron caras en el mapa de piel; sin tono único"); return }
        // each skin pixel (map size) -> its person: nearest face, vertical distance counting less below the face
        val owner = IntArray(pw * ph) { -1 }
        for (y in 0 until ph) for (x in 0 until pw) {
            val c = cls(y * pw + x); if (c != BodyParts.FACE_SKIN && c != BodyParts.BODY_SKIN) continue
            var best = -1; var bd = Float.MAX_VALUE
            for ((k, f) in faces.withIndex()) {
                val dx = x - f[0]; val dy = y - f[1]
                val d = dx * dx + (if (dy > 0) dy * 0.3f else dy) * (if (dy > 0) dy * 0.3f else dy)
                if (d < bd) { bd = d; best = k }
            }
            owner[y * pw + x] = best
        }
        // each person's tone: median a, b of their skin (photo pixels under the map)
        val sxk = w.toFloat() / pw; val syk = h.toFloat() / ph
        val ta = FloatArray(faces.size); val tb = FloatArray(faces.size); val ma = FloatArray(faces.size); val mb = FloatArray(faces.size)
        for (k in faces.indices) {
            val av = ArrayList<Float>(); val bv = ArrayList<Float>()
            for (i in owner.indices) if (owner[i] == k) {
                val X = ((i % pw + 0.5f) * sxk).toInt().coerceIn(0, w - 1); val Y = ((i / pw + 0.5f) * syk).toInt().coerceIn(0, h - 1)
                av += A[Y * w + X]; bv += B[Y * w + X]
            }
            if (av.size < 30) { ta[k] = Float.NaN; continue }
            av.sort(); bv.sort()
            ma[k] = av[av.size / 2]; mb[k] = bv[bv.size / 2]
            // a natural skin range: warm (b over a), never grey, never orange
            var a = ma[k].coerceIn(6f, 20f); var b = mb[k].coerceIn(10f, 26f)
            val ch = kotlin.math.hypot(a, b); if (ch > 30f) { a *= 30f / ch; b *= 30f / ch }
            ta[k] = a; tb[k] = b
        }
        // soft skin weight at the photo's size (the map smoothed, then read bilinearly)
        val wmap = FloatArray(pw * ph) { if (owner[it] >= 0) 1f else 0f }
        val sm = FloatArray(pw * ph)
        val r = 1
        for (y in 0 until ph) for (x in 0 until pw) {
            var sum = 0f; var n = 0
            for (dy in -r..r) for (dx in -r..r) { val yy = y + dy; val xx = x + dx; if (yy in 0 until ph && xx in 0 until pw) { sum += wmap[yy * pw + xx]; n++ } }
            sm[y * pw + x] = sum / n
        }
        var moved = 0L
        for (Y in 0 until h) {
            val fy = ((Y + 0.5f) / syk - 0.5f).coerceIn(0f, ph - 1f); val y0 = fy.toInt(); val y1 = min(y0 + 1, ph - 1); val ty = fy - y0
            for (X in 0 until w) {
                val fx = ((X + 0.5f) / sxk - 0.5f).coerceIn(0f, pw - 1f); val x0 = fx.toInt(); val x1 = min(x0 + 1, pw - 1); val tx = fx - x0
                val wt = (sm[y0 * pw + x0] * (1 - tx) + sm[y0 * pw + x1] * tx) * (1 - ty) + (sm[y1 * pw + x0] * (1 - tx) + sm[y1 * pw + x1] * tx) * ty
                if (wt <= 0.02f) continue
                val k = owner[(fy + 0.5f).toInt().coerceIn(0, ph - 1) * pw + (fx + 0.5f).toInt().coerceIn(0, pw - 1)].takeIf { it >= 0 }
                    ?: owner[y0 * pw + x0].takeIf { it >= 0 } ?: continue
                if (ta[k].isNaN()) continue
                val i = Y * w + X
                val na = ta[k] + 0.35f * (A[i] - ma[k]); val nb = tb[k] + 0.35f * (B[i] - mb[k])
                A[i] += (na - A[i]) * wt; B[i] += (nb - B[i]) * wt
                moved++
            }
        }
        JobLog.add("Piel: un tono por persona (${faces.size}): " + faces.indices.filter { !ta[it].isNaN() }.joinToString(", ") {
            "a %.0f→%.0f b %.0f→%.0f".format(java.util.Locale.US, ma[it], ta[it], mb[it], tb[it]) } + " · ${moved * 100 / (w.toLong() * h)} % de la foto")
    }

    /**
     * DDColor often paints the irises blue or green (restored faces have clear, bright irises). In a
     * colorized old photo the eyes stay as the photo shows them: almost no color, a little warm.
     */
    private fun calmEyes(eyes: List<FloatArray>, A: FloatArray, B: FloatArray, w: Int, h: Int) {
        for (e in eyes) {
            val r = maxOf(3f, e[2])
            val x0 = maxOf(0, (e[0] - r).toInt()); val x1 = minOf(w - 1, (e[0] + r).toInt())
            val y0 = maxOf(0, (e[1] - r * 0.7f).toInt()); val y1 = minOf(h - 1, (e[1] + r * 0.7f).toInt())
            for (y in y0..y1) for (x in x0..x1) {
                val dx = (x - e[0]) / r; val dy = (y - e[1]) / (r * 0.7f)
                val t = ((1f - kotlin.math.sqrt(dx * dx + dy * dy)) / 0.5f).coerceIn(0f, 1f)
                val wgt = t * t * (3f - 2f * t)
                if (wgt <= 0f) continue
                val i = y * w + x
                val a = A[i] * 0.3f + 2f * 0.7f
                val b = (if (B[i] < 0f) B[i] * 0.1f else B[i] * 0.5f) + 4f * 0.5f
                A[i] += (a - A[i]) * wgt; B[i] += (b - B[i]) * wgt
            }
        }
        if (eyes.isNotEmpty()) JobLog.add("Colorear: ${eyes.size} ojos sin el color inventado (iris casi neutros)")
    }

    private fun skinFromFaces(src: Bitmap, L: FloatArray, A: FloatArray, B: FloatArray, w: Int, h: Int) {
        val long = maxOf(w, h)
        val k = if (long > 1600) 1600f / long else 1f
        val small = if (k < 1f) Bitmap.createScaledBitmap(src, (w * k).toInt(), (h * k).toInt(), true) else src
        val det = com.google.mlkit.vision.face.FaceDetection.getClient(com.google.mlkit.vision.face.FaceDetectorOptions.Builder()
            .setPerformanceMode(com.google.mlkit.vision.face.FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(com.google.mlkit.vision.face.FaceDetectorOptions.LANDMARK_MODE_ALL).setMinFaceSize(0.03f).build())
        // the eyes: (x, y, radius) in the photo
        val eyes = ArrayList<FloatArray>()
        val faces = try {
            com.google.android.gms.tasks.Tasks.await(det.process(com.google.mlkit.vision.common.InputImage.fromBitmap(small, 0))).map { f ->
                val r = f.boundingBox
                for (t in intArrayOf(com.google.mlkit.vision.face.FaceLandmark.LEFT_EYE, com.google.mlkit.vision.face.FaceLandmark.RIGHT_EYE))
                    f.getLandmark(t)?.position?.let { p -> eyes += floatArrayOf(p.x / k, p.y / k, r.width() / k * 0.13f) }
                android.graphics.Rect((r.left / k).toInt(), (r.top / k).toInt(), (r.right / k).toInt(), (r.bottom / k).toInt())
            }
        } catch (t: Throwable) { JobLog.notice("Colorear: no se pudieron buscar caras (${t.message})"); emptyList() } finally { det.close() }
        if (faces.isEmpty()) return
        calmEyes(eyes, A, B, w, h)
        var moved = 0
        for (f in faces) {
            // the face's own skin: the middle of the box, skipping very dark / very bright pixels
            var sa = 0.0; var sb = 0.0; var sl = 0.0; var n = 0
            val cx0 = f.left + f.width() / 4; val cx1 = f.right - f.width() / 4
            val cy0 = f.top + f.height() / 4; val cy1 = f.bottom - f.height() / 4
            for (y in cy0.coerceAtLeast(0) until cy1.coerceAtMost(h)) for (x in cx0.coerceAtLeast(0) until cx1.coerceAtMost(w)) {
                val i = y * w + x
                if (L[i] < 0.15f || L[i] > 0.9f) continue
                sa += A[i]; sb += B[i]; sl += L[i]; n++
            }
            if (n < 20) continue
            var ta = (sa / n).toFloat(); var tb = (sb / n).toFloat(); val tl = (sl / n).toFloat()
            // a face that came out cold too: a natural skin tone instead (Lab a≈12, b≈17, softened like the rest)
            if (tb < 8f || ta < 3f) { ta = 12f * SKIN_SAT; tb = 17f * SKIN_SAT }
            val fw = f.width().toFloat(); val fh = f.height().toFloat()
            val x0 = (f.centerX() - 3 * fw).toInt().coerceAtLeast(0); val x1 = (f.centerX() + 3 * fw).toInt().coerceAtMost(w - 1)
            val y0 = f.top.coerceAtLeast(0); val y1 = (f.top + 9 * fh).toInt().coerceAtMost(h - 1)
            for (y in y0..y1) {
                val wy = if (y < f.bottom) 1f else (1f - (y - f.bottom) / (8 * fh)).coerceIn(0.3f, 1f)
                for (x in x0..x1) {
                    val i = y * w + x
                    val l = L[i]
                    if (l < 0.12f || l > 0.85f) continue
                    // only pixels that are cold or nearly gray (warm ones are skin or warm clothes already)
                    val cold = ((8f - B[i]) / 12f).coerceIn(0f, 1f) * if (A[i] < ta + 6f) 1f else 0.4f
                    if (cold <= 0f) continue
                    val dx = Math.abs(x - f.centerX()) / (3 * fw)
                    val wx = (1f - dx * dx).coerceIn(0f, 1f)
                    val dl = (l - tl) / 0.25f
                    val wl = Math.exp((-dl * dl).toDouble()).toFloat()
                    val wgt = 0.85f * cold * wx * wy * wl
                    if (wgt < 0.05f) continue
                    A[i] += (ta - A[i]) * wgt; B[i] += (tb - B[i]) * wgt
                    moved++
                }
            }
        }
        JobLog.add("Colorear: piel de ${faces.size} cara(s) llevada a brazos y piernas (${moved * 100L / (w.toLong() * h)} % de la foto)")
    }

    /** Colorear's color strength by default (the share of DDColor's color kept); was 0.72. */
    const val COLOR_SAT = 0.81f
    /** The natural skin tone used when a face came out cold, at the old strength (it is a tone, not a choice). */
    private const val SKIN_SAT = 0.72f
    private const val COLOR_ON_NPU = false
    // measured on this phone: Colorear slower (7 s vs 3.8 s on the CPU), Desenfoque ~3 min per piece,
    // Caras fast but with a cracked skin texture (8-bit weights lose the fine detail)
    // and Rayones: its fill comes out blue-green / green on sepia and black-and-white photos
    // rest_deblur is back on the NPU: NAFNet replaced Restormer there (Restormer took ~3 min a piece on it)
    private val NPU_OFF = setOf("rest_color", "rest_faces", "rest_lama")

    /** Mean over a (2r+1)² square, edges clamped (two running-sum passes). */
    private fun box(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h); val out = FloatArray(w * h)
        val n = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val o = y * w
            var acc = 0f
            for (x in -r..r) acc += src[o + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[o + x] = acc / n
                acc += src[o + (x + r + 1).coerceAtMost(w - 1)] - src[o + (x - r).coerceAtLeast(0)]
            }
        }
        for (x in 0 until w) {
            var acc = 0f
            for (y in -r..r) acc += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = acc / n
                acc += tmp[(y + r + 1).coerceAtMost(h - 1) * w + x] - tmp[(y - r).coerceAtLeast(0) * w + x]
            }
        }
        return out
    }

    /** Guided filter (He et al.): smooths [p] but keeps the edges of guide [g]. */
    private fun guided(g: FloatArray, p: FloatArray, w: Int, h: Int, r: Int, eps: Float): FloatArray {
        val n = w * h
        val mI = box(g, w, h, r); val mP = box(p, w, h, r)
        val gg = FloatArray(n) { g[it] * g[it] }; val gp = FloatArray(n) { g[it] * p[it] }
        val cI = box(gg, w, h, r); val cIP = box(gp, w, h, r)
        val a = FloatArray(n); val b = FloatArray(n)
        for (i in 0 until n) {
            val v = cI[i] - mI[i] * mI[i]
            a[i] = (cIP[i] - mI[i] * mP[i]) / (v + eps)
            b[i] = mP[i] - a[i] * mI[i]
        }
        val mA = box(a, w, h, r); val mB = box(b, w, h, r)
        return FloatArray(n) { mA[it] * g[it] + mB[it] }
    }

    // ---- sRGB <-> CIE Lab (D65), as OpenCV does for float images ----
    private fun lin(c: Float) = if (c <= 0.04045f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    private fun gam(c: Float) = if (c <= 0.0031308f) 12.92f * c else (1.055f * Math.pow(c.toDouble(), 1 / 2.4).toFloat() - 0.055f)
    private fun f(t: Float) = if (t > 0.008856f) Math.cbrt(t.toDouble()).toFloat() else 7.787f * t + 16f / 116f
    private fun fi(t: Float) = if (t > 0.206893f) t * t * t else (t - 16f / 116f) / 7.787f

    private val linLut by lazy { FloatArray(256) { lin(it / 255f) } }

    private fun toLab(p: Int, out: FloatArray) {
        val r = linLut[Color.red(p)]; val g = linLut[Color.green(p)]; val b = linLut[Color.blue(p)]
        val x = (0.412453f * r + 0.357580f * g + 0.180423f * b) / 0.950456f
        val y = 0.212671f * r + 0.715160f * g + 0.072169f * b
        val z = (0.019334f * r + 0.119193f * g + 0.950227f * b) / 1.088754f
        val fy = f(y)
        out[0] = 116f * fy - 16f
        out[1] = 500f * (f(x) - fy)
        out[2] = 200f * (fy - f(z))
    }

    private fun fromLab(l: Float, a: Float, b: Float): Int {
        val fy = (l + 16f) / 116f
        val x = fi(fy + a / 500f) * 0.950456f
        val y = fi(fy)
        val z = fi(fy - b / 200f) * 1.088754f
        val r = 3.240479f * x - 1.537150f * y - 0.498535f * z
        val g = -0.969256f * x + 1.875992f * y + 0.041556f * z
        val bl = 0.055648f * x - 0.204043f * y + 1.057311f * z
        fun to8(v: Float) = (gam(v.coerceIn(0f, 1f)) * 255f).roundToInt().coerceIn(0, 255)
        return Color.rgb(to8(r), to8(g), to8(bl))
    }

    /** sRGB gray (0..1) with the same Lab lightness as [p]. */
    private fun grayOf(p: Int): Float {
        val y = 0.212671f * lin(Color.red(p) / 255f) + 0.715160f * lin(Color.green(p) / 255f) + 0.072169f * lin(Color.blue(p) / 255f)
        return gam(y)
    }

    /**
     * Removes painted scratches, dust and stains with LaMa, working in 512×512 windows over the
     * parts of the photo that have paint, and changing only the painted pixels (slightly widened).
     */
    fun removeMarks(ctx: Context, model: File, src: Bitmap, mask: Bitmap, gpu: Boolean,
                    onProgress: (Float) -> Unit, cancelled: () -> Boolean): Bitmap? {
        val w = src.width; val h = src.height
        val m = if (mask.width == w && mask.height == h) mask else Bitmap.createScaledBitmap(mask, w, h, false)
        val ma = pixels(m)
        // widen the painted area by 2 px so the edges of each scratch are replaced too
        val hard = BooleanArray(w * h) { (ma[it] ushr 24) > 30 }
        val sel = BooleanArray(w * h)
        val r = 2
        for (y in 0 until h) for (x in 0 until w) if (hard[y * w + x]) {
            for (dy in -r..r) for (dx in -r..r) {
                val yy = y + dy; val xx = x + dx
                if (yy in 0 until h && xx in 0 until w) sel[yy * w + xx] = true
            }
        }
        val px = pixels(src)
        val t = 512; val stride = 448
        val xs = starts(w, t, stride); val ys = starts(h, t, stride)
        val todo = mutableListOf<Pair<Int, Int>>()
        for (y0 in ys) for (x0 in xs) {
            var any = false
            loop@ for (y in max(0, y0) until min(h, y0 + t)) for (x in max(0, x0) until min(w, x0 + t)) if (sel[y * w + x]) { any = true; break@loop }
            if (any) todo += x0 to y0
        }
        if (todo.isEmpty()) return src.also { JobLog.add("Rayones: ninguna ventana con marcas") }
        JobLog.add("Rayones: ${todo.size} ventanas de ${t}×$t")
        // The NPU first (16 bits); then the CPU. (The phone's GPU gives LaMa's Fourier layers,
        // written as matrix products, as a colored grid.) The NPU's first window is checked.
        // On a black-and-white or sepia photo the NPU is used too: its fill's only problem there was
        // the color (green or blue patches), and on such a photo only the fill's brightness is kept;
        // the color comes from the untouched pixels around it (fixTone). Color photos: the CPU.
        val oneTone = isOneTone(src) || isSepia(src)
        var npu = npuFor(ctx, model, "marks", allowOff = oneTone)
        if (npu != null && oneTone) JobLog.add("Rayones: foto de un solo tono; NPU con el color tomado de alrededor")
        var cpu: MnnTile? = null
        val n = t * t
        val input = FloatArray(4 * n)
        val out = FloatArray(3 * n)
        engines["marks"] = if (npu != null) "NPU" else "CPU"
        val lama = object {
            var checked = false
            var cpuLogged = false
            fun run(i: FloatArray, o: FloatArray): Boolean {
                npu?.let { u ->
                    val t1 = android.os.SystemClock.elapsedRealtime()
                    val ok = try { u.run(i, o) } catch (e: Throwable) { npuNotes["marks"] = e.message ?: "error"; JobLog.error("Rayones en NPU", e); false }
                    if (!checked) JobLog.add("Rayones NPU, primera ventana: ${android.os.SystemClock.elapsedRealtime() - t1} ms · ${range(o)}")
                    if (ok && (checked || sane(o, -0.5f, 1.5f))) { checked = true; return true }
                    if (ok) npuNotes["marks"] = "resultado fuera de rango ${range(o)}"
                    u.close(); npu = null; engines["marks"] = "CPU"
                }
                return cpuRun(i, o)
            }
            fun cpuRun(i: FloatArray, o: FloatArray): Boolean {
                val c = cpu ?: MnnTile(ctx, model.absolutePath, false, precise = true).also { cpu = it }
                val t1 = android.os.SystemClock.elapsedRealtime()
                return c.run(i, o).also { if (!cpuLogged) { cpuLogged = true; JobLog.add("Rayones CPU, primera ventana: ${android.os.SystemClock.elapsedRealtime() - t1} ms") } }
            }
            val onNpu get() = npu != null
        }
        /**
         * One-tone photo: the fill keeps its brightness (Y) and takes the tint of the window's
         * untouched pixels (their mean R−Y, G−Y, B−Y), so it can't come out green or blue.
         */
        fun fixTone(i: FloatArray, o: FloatArray) {
            val m = 3 * n
            var dr = 0.0; var dg = 0.0; var db = 0.0; var cnt = 0
            for (j in 0 until n) if (i[m + j] < 0.5f) {
                val y = 0.299f * i[j] + 0.587f * i[n + j] + 0.114f * i[2 * n + j]
                dr += i[j] - y; dg += i[n + j] - y; db += i[2 * n + j] - y; cnt++
            }
            if (cnt < 50) return
            val tr = (dr / cnt).toFloat(); val tg = (dg / cnt).toFloat(); val tb = (db / cnt).toFloat()
            for (j in 0 until n) if (i[m + j] > 0.5f) {
                val y = 0.299f * o[j] + 0.587f * o[n + j] + 0.114f * o[2 * n + j]
                o[j] = y + tr; o[n + j] = y + tg; o[2 * n + j] = y + tb
            }
        }

        /**
         * The NPU's fill (8-bit weights) can come out in the wrong color on big marks (a green patch
         * on a sepia photo). Compares the tint (red-green, blue-green) of the filled pixels with a ring
         * of untouched pixels around them; true when they clearly don't match.
         */
        fun offColor(i: FloatArray, o: FloatArray): String? {
            var fr = 0.0; var fb = 0.0; var fn = 0
            var rr = 0.0; var rb = 0.0; var rn = 0
            val m = 3 * n
            for (y in 0 until t) for (x in 0 until t) {
                val j = y * t + x
                if (i[m + j] > 0.5f) {
                    fr += o[j] - o[n + j]; fb += o[2 * n + j] - o[n + j]; fn++
                } else {
                    // a ring: within 6 px of a filled pixel
                    var near = false
                    loop@ for (dy in -6..6 step 3) for (dx in -6..6 step 3) {
                        val yy = y + dy; val xx = x + dx
                        if (yy in 0 until t && xx in 0 until t && i[m + yy * t + xx] > 0.5f) { near = true; break@loop }
                    }
                    if (near) { rr += i[j] - i[n + j]; rb += i[2 * n + j] - i[n + j]; rn++ }
                }
            }
            if (fn < 50 || rn < 50) return null
            val dr = fr / fn - rr / rn; val db = fb / fn - rb / rn
            val d = kotlin.math.sqrt(dr * dr + db * db)
            return if (d > 0.06) "tinte del relleno distinto al de alrededor (%.2f)".format(java.util.Locale.US, d) else null
        }
        try {
            for ((k, pos) in todo.withIndex()) {
                if (cancelled()) return null
                val (x0, y0) = pos
                for (y in 0 until t) {
                    val sy = (y0 + y).coerceIn(0, h - 1)
                    for (x in 0 until t) {
                        val sx = (x0 + x).coerceIn(0, w - 1)
                        val p = px[sy * w + sx]; val i = y * t + x
                        input[i] = Color.red(p) / 255f; input[n + i] = Color.green(p) / 255f; input[2 * n + i] = Color.blue(p) / 255f
                        input[3 * n + i] = if (sel[sy * w + sx]) 1f else 0f
                    }
                }
                if (!lama.run(input, out)) throw IllegalStateException("LaMa failed")
                if (lama.onNpu && oneTone) fixTone(input, out)
                if (lama.onNpu) offColor(input, out)?.let { why ->
                    JobLog.notice("Rayones ventana ${k + 1}: $why; se repite en el procesador normal")
                    npuNotes["marks"] = "en alguna zona el color no cuadró; se rehízo en el procesador normal"
                    if (!lama.cpuRun(input, out)) throw IllegalStateException("LaMa failed")
                    engines["marks"] = "NPU + CPU"
                }
                for (y in 0 until t) {
                    val sy = y0 + y; if (sy !in 0 until h) continue
                    for (x in 0 until t) {
                        val sx = x0 + x; if (sx !in 0 until w) continue
                        val j = sy * w + sx
                        if (!sel[j]) continue
                        val i = y * t + x
                        px[j] = Color.rgb((out[i] * 255f).roundToInt().coerceIn(0, 255), (out[n + i] * 255f).roundToInt().coerceIn(0, 255),
                            (out[2 * n + i] * 255f).roundToInt().coerceIn(0, 255))
                    }
                }
                onProgress((k + 1f) / todo.size)
            }
        } finally {
            npu?.close(); cpu?.close()
        }
        return mutable(src, px)
    }

    /** Window start positions covering [len] with windows of [t] (centered when the image is smaller). */
    private fun starts(len: Int, t: Int, stride: Int): List<Int> {
        if (len <= t) return listOf(-(t - len) / 2)
        val out = mutableListOf<Int>()
        var p = 0
        while (true) {
            if (p + t >= len) { out += len - t; break }
            out += p; p += stride
        }
        return out
    }
}
