package com.nitido.app

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator

/**
 * Inicio: the four tools as big buttons (Restaurar foto, Mejorar video, Crear imagen, Editar con
 * palabras), the running job (bar, percent, detail; no picture), Mis resultados and ⚙ Ajustes.
 * No thumbnails of results here (privacy). One job at a time (memory): the others wait.
 * The first time, the welcome screen comes first.
 */
class HomeActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var col: LinearLayout
    private lateinit var jobCard: LinearLayout
    private lateinit var jobTitle: TextView
    private lateinit var jobPct: TextView
    private lateinit var jobBar: LinearProgressIndicator
    private lateinit var jobLine: TextView
    private lateinit var jobDetail: TextView
    private lateinit var dlCard: LinearLayout
    private lateinit var dlTitle: TextView
    private lateinit var dlPct: TextView
    private lateinit var dlBar: LinearProgressIndicator
    private lateinit var dlLine: TextView
    private lateinit var extra: LinearLayout
    private lateinit var logLink: TextView
    /** Each tool's tile: its screen, its mode (Crear / Editar share a screen) and its subtitle. */
    private class Tile(val cls: Class<*>, val mode: String?, val view: LinearLayout, val sub: TextView, val subText: String)
    private val tiles = mutableListOf<Tile>()

    private fun c(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Prefs.welcomed(this)) {
            startActivity(Intent(this, WelcomeActivity::class.java))
        }
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(20))
        }
        col.setBackgroundColor(c(R.color.bg)); col.fitsSystemWindows = true
        setContentView(col)

        val head = row()
        head.addView(text(getString(R.string.home_title), 26f, c(R.color.fg), true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(text("⚙", 24f, c(R.color.fg2)).apply {
            setPadding(dp(12), dp(4), dp(4), dp(4))
            contentDescription = getString(R.string.settings_title)
            setOnClickListener { startActivity(Intent(this@HomeActivity, SettingsActivity::class.java)) }
        })
        col.addView(head)
        col.addView(text(getString(R.string.home_sub), 13f, c(R.color.muted)))

        // the four tools: big rows that share the screen (no pictures here: privacy)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun add(icon: String, title: Int, sub: Int, cls: Class<*>, mode: String? = null) =
            grid.addView(tile(icon, title, sub, cls, mode), LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        add("✧", R.string.home_restore, R.string.home_restore_sub, RestoreActivity::class.java)
        add("▶", R.string.home_video, R.string.home_video_sub, VideoActivity::class.java)
        add("✦", R.string.home_create, R.string.home_create_sub, GenerateActivity::class.java, GenerateActivity.MODE_CREATE)
        add("✎", R.string.home_edit, R.string.home_edit_sub, GenerateActivity::class.java, GenerateActivity.MODE_EDIT)
        col.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })

        // Modo avanzado: the photo enlarger and Modelos also get a place here
        extra = row()
        extra.addView(smallTile(getString(R.string.home_enhance)) { open(MainActivity::class.java) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(10) })
        extra.addView(smallTile(getString(R.string.home_models)) { open(ModelsActivity::class.java) }, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(extra, lp(10))

        // running job: bar, percent and detail
        jobCard = card(accent = true).apply { visibility = View.GONE }
        val top = row()
        jobTitle = text("", 15f, c(R.color.fg), true)
        top.addView(jobTitle, LinearLayout.LayoutParams(0, -2, 1f))
        jobPct = text("", 22f, c(R.color.fg), true)
        top.addView(jobPct)
        jobCard.addView(top)
        jobBar = bar()
        jobCard.addView(jobBar, lp(10))
        jobLine = text("", 12f, c(R.color.muted))
        jobCard.addView(jobLine, lp(8))
        jobDetail = text("", 12f, c(R.color.muted))
        jobCard.addView(jobDetail, lp(2))
        val btns = row()
        btns.addView(chip(getString(R.string.home_detail)) { openJob() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        btns.addView(chip(getString(R.string.stop)) { BgWork.stopOrRelease(this) }, LinearLayout.LayoutParams(0, -2, 1f))
        jobCard.addView(btns, lp(10))
        jobCard.setOnClickListener { openJob() }
        col.addView(jobCard, lp(12))

        // download in progress
        dlCard = card().apply { visibility = View.GONE }
        val dtop = row()
        dlTitle = text("", 13f, c(R.color.fg))
        dtop.addView(dlTitle, LinearLayout.LayoutParams(0, -2, 1f))
        dlPct = text("", 15f, c(R.color.fg), true)
        dtop.addView(dlPct)
        dlCard.addView(dtop)
        dlBar = bar()
        dlCard.addView(dlBar, lp(8))
        dlLine = text("", 12f, c(R.color.muted))
        dlCard.addView(dlLine, lp(6))
        dlCard.setOnClickListener { open(ModelsActivity::class.java) }
        col.addView(dlCard, lp(8))

        // Mis resultados: Nítido's own gallery (nothing of it is shown here)
        val res = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        res.addView(text("▣  " + getString(R.string.home_results), 16f, c(R.color.fg), true), LinearLayout.LayoutParams(0, -2, 1f))
        res.addView(text("›", 20f, c(R.color.muted)))
        res.setOnClickListener { startActivity(Intent(this, ResultsActivity::class.java)) }
        col.addView(res, lp(12))
        logLink = text("☰ " + getString(R.string.log_open_last), 13f, c(R.color.accent)).apply {
            setPadding(0, dp(10), 0, 0)
            setOnClickListener { LogDialog.show(this@HomeActivity) }
        }
        col.addView(logLink, lp(2))

        CrashReport.showIfNeeded(this)
    }

    override fun onResume() {
        super.onResume()
        val adv = Prefs.advanced(this)
        extra.visibility = if (adv) View.VISIBLE else View.GONE
        logLink.visibility = if (adv) View.VISIBLE else View.GONE
        tick()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacksAndMessages(null)
    }

    private fun tick() {
        refreshJob()
        ui.postDelayed({ tick() }, 500)
    }

    private fun refreshJob() {
        val busy = BgWork.busy
        jobCard.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            jobTitle.text = BgWork.jobTitle()
            jobPct.text = "${BgWork.jobPct.coerceIn(0, 100)} %"
            jobBar.setProgressCompat(BgWork.jobPct.coerceIn(0, 100), true)
            jobLine.text = BgWork.jobDetail.ifBlank { getString(R.string.home_working) }
            val secs = (SystemClock.elapsedRealtime() - BgWork.jobStarted) / 1000
            jobDetail.text = if (Prefs.advanced(this)) getString(R.string.home_job_detail, if (NpuMeter.inUse()) "⚡ NPU" else "GPU", secs)
                else getString(R.string.home_job_simple, secs)
        }
        val dl = BgWork.downloading()
        dlCard.visibility = if (dl) View.VISIBLE else View.GONE
        if (dl) {
            dlTitle.text = BgWork.dlTitle()
            dlPct.text = "${BgWork.dlPct().coerceIn(0, 100)} %"
            dlBar.setProgressCompat(BgWork.dlPct().coerceIn(0, 100), true)
            dlLine.text = BgWork.dlText()
        }
        val running = if (busy) BgWork.jobTarget() else null
        for (t in tiles) {
            val blocked = busy && t.cls != running
            t.view.alpha = if (blocked) 0.45f else 1f
            t.sub.text = when {
                t.cls == running && (t.mode == null || t.mode == GenerateActivity.runningMode) -> getString(R.string.home_working)
                blocked -> getString(R.string.home_wait)
                else -> t.subText
            }
        }
    }

    private fun openJob() {
        val cls = BgWork.jobTarget()
        if (cls == GenerateActivity::class.java) openTool(cls, GenerateActivity.runningMode) else open(cls)
    }

    /** Opens a section, reusing it if it is already open behind (its job and picture stay). */
    private fun open(cls: Class<*>) =
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))

    private fun openTool(cls: Class<*>, mode: String?) {
        val i = Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        if (mode != null) i.putExtra(GenerateActivity.EXTRA_MODE, mode)
        startActivity(i)
    }

    // ───────── small builders ─────────

    private fun tile(icon: String, title: Int, sub: Int, cls: Class<*>, mode: String?): LinearLayout {
        val t = card().apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        t.addView(text(icon, 30f, c(R.color.accent)).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(48), -2))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        texts.addView(text(getString(title), 18f, c(R.color.fg), true))
        val s = text(getString(sub), 13f, c(R.color.muted))
        texts.addView(s)
        t.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        t.addView(text("›", 22f, c(R.color.muted)))
        t.setOnClickListener {
            val running = if (BgWork.busy) BgWork.jobTarget() else null
            if (running != null && cls != running)
                AlertDialog.Builder(this).setMessage(R.string.home_wait_msg).setPositiveButton(android.R.string.ok, null).show()
            else openTool(cls, mode)
        }
        tiles += Tile(cls, mode, t, s, getString(sub))
        return t
    }

    private fun smallTile(label: String, onClick: () -> Unit) = card().apply {
        gravity = Gravity.CENTER; setPadding(dp(10), dp(12), dp(10), dp(12))
        addView(text(label, 14f, c(R.color.fg)).apply { gravity = Gravity.CENTER })
        setOnClickListener { onClick() }
    }

    private fun card(accent: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            setColor(c(R.color.stage)); cornerRadius = dp(16).toFloat()
            setStroke(dp(if (accent) 2 else 1), c(if (accent) R.color.accent else R.color.line))
        }
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun bar() = LinearProgressIndicator(this).apply {
        max = 100; trackThickness = dp(8); trackCornerRadius = dp(4)
        setIndicatorColor(c(R.color.accent)); trackColor = c(R.color.track)
    }

    private fun chip(label: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = label; textSize = 13f; setOnClickListener { onClick() }
        }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
}
