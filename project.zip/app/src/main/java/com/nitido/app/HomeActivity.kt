package com.nitido.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.io.File

/**
 * Inicio: the four sections, the running job (only its bar, percent and detail) and the last result.
 * While a picture is being made, Crear, Restaurar and Mejorar wait (one job at a time: memory).
 */
class HomeActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var col: LinearLayout
    private lateinit var jobCard: LinearLayout
    private lateinit var jobTitle: TextView
    private lateinit var jobPct: TextView
    private lateinit var jobBar: LinearProgressIndicator
    private lateinit var jobLine: TextView
    private lateinit var jobDetail: TextView
    private lateinit var dlCard: LinearLayout
    private lateinit var dlTitle: TextView
    private lateinit var dlPct: TextView
    private lateinit var dlBar: LinearProgressIndicator
    private lateinit var dlLine: TextView
    private lateinit var lastCard: LinearLayout
    private lateinit var lastThumb: ImageView
    private lateinit var lastTitle: TextView
    private lateinit var lastSub: TextView
    private val tiles = HashMap<Class<*>, Pair<LinearLayout, TextView>>()
    private var lastTarget: Class<*>? = null

    private fun c(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(c(R.color.bg)); fitsSystemWindows = true; addView(col)
        })
        col.addView(text(getString(R.string.home_title), 26f, c(R.color.fg), true))
        col.addView(text(getString(R.string.home_sub), 13f, c(R.color.muted)))

        // running job: bar, percent and detail
        jobCard = card(accent = true).apply { visibility = View.GONE }
        val top = row()
        jobTitle = text("", 15f, c(R.color.fg), true)
        top.addView(jobTitle, LinearLayout.LayoutParams(0, -2, 1f))
        jobPct = text("", 22f, c(R.color.fg), true)
        top.addView(jobPct)
        jobCard.addView(top)
        jobBar = bar()
        jobCard.addView(jobBar, lp(10))
        jobLine = text("", 12f, c(R.color.muted))
        jobCard.addView(jobLine, lp(8))
        jobDetail = text("", 12f, c(R.color.muted))
        jobCard.addView(jobDetail, lp(2))
        val btns = row()
        btns.addView(chip(getString(R.string.home_detail)) { open(BgWork.jobTarget()) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        btns.addView(chip(getString(R.string.stop)) { BgWork.onStop?.invoke() }, LinearLayout.LayoutParams(0, -2, 1f))
        jobCard.addView(btns, lp(10))
        col.addView(jobCard, lp(14))

        // download in progress
        dlCard = card().apply { visibility = View.GONE }
        val dtop = row()
        dlTitle = text("", 13f, c(R.color.fg))
        dtop.addView(dlTitle, LinearLayout.LayoutParams(0, -2, 1f))
        dlPct = text("", 15f, c(R.color.fg), true)
        dtop.addView(dlPct)
        dlCard.addView(dtop)
        dlBar = bar()
        dlCard.addView(dlBar, lp(8))
        dlLine = text("", 12f, c(R.color.muted))
        dlCard.addView(dlLine, lp(6))
        dlCard.setOnClickListener { open(ModelsActivity::class.java) }
        col.addView(dlCard, lp(8))

        // the four sections
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val r1 = row(); val r2 = row()
        r1.addView(tile("✦", R.string.home_create, R.string.home_create_sub, GenerateActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        r1.addView(tile("✧", R.string.home_restore, R.string.home_restore_sub, RestoreActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f))
        r2.addView(tile("×4", R.string.home_enhance, R.string.home_enhance_sub, MainActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        r2.addView(tile("▤", R.string.home_models, R.string.home_models_sub, ModelsActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f))
        val r3 = row()
        r3.addView(tile("▶", R.string.home_video, R.string.home_video_sub, VideoActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f))
        grid.addView(r1)
        grid.addView(r2, lp(8))
        grid.addView(r3, lp(8))
        col.addView(grid, lp(14))

        // last result
        col.addView(text(getString(R.string.home_last), 12f, c(R.color.muted)), lp(16))
        lastCard = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        lastThumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(c(R.color.stage_hi), 10); clipToOutline = true
        }
        lastCard.addView(lastThumb, LinearLayout.LayoutParams(dp(56), dp(56)))
        val lc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        lastTitle = text("", 14f, c(R.color.fg), true)
        lastSub = text("", 12f, c(R.color.muted))
        lc.addView(lastTitle); lc.addView(lastSub)
        lastCard.addView(lc, LinearLayout.LayoutParams(0, -2, 1f))
        lastCard.addView(text("›", 20f, c(R.color.muted)))
        lastCard.setOnClickListener { lastTarget?.let { open(it) } }
        col.addView(lastCard, lp(6))
        // while the app is being tested: the last job's log, from the start screen too
        col.addView(text("☰ " + getString(R.string.log_open_last), 13f, c(R.color.accent)).apply {
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { LogDialog.show(this@HomeActivity) }
        }, lp(4))

        CrashReport.showIfNeeded(this)
    }

    override fun onResume() {
        super.onResume()
        refreshLast()
        tick()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacksAndMessages(null)
    }

    private fun tick() {
        refreshJob()
        ui.postDelayed({ tick() }, 500)
    }

    private fun refreshJob() {
        val busy = BgWork.busy
        jobCard.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            jobTitle.text = BgWork.jobTitle()
            jobPct.text = "${BgWork.jobPct.coerceIn(0, 100)} %"
            jobBar.setProgressCompat(BgWork.jobPct.coerceIn(0, 100), true)
            jobLine.text = BgWork.jobDetail.ifBlank { getString(R.string.home_working) }
            val secs = (SystemClock.elapsedRealtime() - BgWork.jobStarted) / 1000
            jobDetail.text = getString(R.string.home_job_detail, if (NpuMeter.inUse()) "⚡ NPU" else "GPU", secs)
        }
        val dl = BgWork.downloading()
        dlCard.visibility = if (dl) View.VISIBLE else View.GONE
        if (dl) {
            dlTitle.text = BgWork.dlTitle()
            dlPct.text = "${BgWork.dlPct().coerceIn(0, 100)} %"
            dlBar.setProgressCompat(BgWork.dlPct().coerceIn(0, 100), true)
            dlLine.text = BgWork.dlText()
        }
        val running = if (busy) BgWork.jobTarget() else null
        for ((cls, t) in tiles) {
            val blocked = busy && cls != ModelsActivity::class.java && cls != running
            t.first.alpha = if (blocked) 0.45f else 1f
            t.second.text = when {
                cls == running -> getString(R.string.home_working)
                blocked -> getString(R.string.home_wait)
                else -> t.second.tag as String
            }
        }
    }

    /** The newest result of any section: picture made, photo restored or enhanced. */
    private fun refreshLast() {
        val prefs = getSharedPreferences("nitido", MODE_PRIVATE)
        val cands = listOfNotNull(
            prefs.getString("last_result", null)?.let { File(it) to GenerateActivity::class.java },
            RestoreSession.outFile(this) to RestoreActivity::class.java,
            File(cacheDir, MainActivity.LAST_FILE) to MainActivity::class.java,
            File(cacheDir, VideoEnhancer.LAST_FILE) to VideoActivity::class.java,
        ).filter { it.first.exists() && it.first.length() > 0 }
        val best = cands.maxByOrNull { it.first.lastModified() }
        if (best == null) { lastCard.visibility = View.GONE; return }
        lastTarget = best.second
        lastCard.visibility = View.VISIBLE
        lastTitle.text = getString(when (best.second) {
            GenerateActivity::class.java -> R.string.home_last_create
            RestoreActivity::class.java -> R.string.home_last_restore
            VideoActivity::class.java -> R.string.home_last_video
            else -> R.string.home_last_enhance
        })
        lastSub.text = if (prefs.getString("last_section", null) == best.second.name) prefs.getString("last_message", "") else ""
        try {
            if (best.first.name.endsWith(".mp4")) {
                val mr = android.media.MediaMetadataRetriever()
                mr.setDataSource(best.first.path)
                lastThumb.setImageBitmap(mr.getFrameAtTime(0)?.let { Bitmap.createScaledBitmap(it, 160, 160 * it.height / it.width.coerceAtLeast(1), true) })
                mr.release()
            } else {
                val o = BitmapFactory.Options().apply { inSampleSize = 8 }
                lastThumb.setImageBitmap(BitmapFactory.decodeFile(best.first.path, o))
            }
        } catch (t: Throwable) { }
    }

    /** Opens a section, reusing it if it is already open behind (its job and picture stay). */
    private fun open(cls: Class<*>) =
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))

    // ───────── small builders ─────────

    private fun tile(icon: String, title: Int, sub: Int, cls: Class<*>): LinearLayout {
        val t = card().apply { setPadding(dp(14), dp(14), dp(14), dp(14)) }
        t.addView(text(icon, 22f, c(R.color.accent)))
        t.addView(text(getString(title), 15f, c(R.color.fg), true), lp(8))
        val s = text(getString(sub), 12f, c(R.color.muted)).apply { tag = getString(sub) }
        t.addView(s)
        t.setOnClickListener {
            val running = if (BgWork.busy) BgWork.jobTarget() else null
            if (running != null && cls != ModelsActivity::class.java && cls != running)
                AlertDialog.Builder(this).setMessage(R.string.home_wait_msg).setPositiveButton(android.R.string.ok, null).show()
            else open(cls)
        }
        tiles[cls] = t to s
        return t
    }

    private fun card(accent: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            setColor(c(R.color.stage)); cornerRadius = dp(14).toFloat()
            setStroke(dp(if (accent) 2 else 1), c(if (accent) R.color.accent else R.color.line))
        }
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun bar() = LinearProgressIndicator(this).apply {
        max = 100; trackThickness = dp(8); trackCornerRadius = dp(4)
        setIndicatorColor(c(R.color.accent)); trackColor = c(R.color.track)
    }

    private fun chip(label: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = label; textSize = 13f; setOnClickListener { onClick() }
        }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
}
