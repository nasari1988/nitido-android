package com.nitido.app

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator

/**
 * Inicio: the sections as big buttons, the running job (bar, percent, detail; no picture) and a
 * link to the gallery. No thumbnails of results here (privacy).
 * While a picture is being made, Crear, Restaurar and Mejorar wait (one job at a time: memory).
 */
class HomeActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var col: LinearLayout
    private lateinit var jobCard: LinearLayout
    private lateinit var jobTitle: TextView
    private lateinit var jobPct: TextView
    private lateinit var jobBar: LinearProgressIndicator
    private lateinit var jobLine: TextView
    private lateinit var jobDetail: TextView
    private lateinit var dlCard: LinearLayout
    private lateinit var dlTitle: TextView
    private lateinit var dlPct: TextView
    private lateinit var dlBar: LinearProgressIndicator
    private lateinit var dlLine: TextView
    private val tiles = HashMap<Class<*>, Pair<LinearLayout, TextView>>()

    private fun c(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        col.setBackgroundColor(c(R.color.bg)); col.fitsSystemWindows = true
        setContentView(col)
        col.addView(text(getString(R.string.home_title), 26f, c(R.color.fg), true))
        col.addView(text(getString(R.string.home_sub), 13f, c(R.color.muted)))

        // running job: bar, percent and detail
        jobCard = card(accent = true).apply { visibility = View.GONE }
        val top = row()
        jobTitle = text("", 15f, c(R.color.fg), true)
        top.addView(jobTitle, LinearLayout.LayoutParams(0, -2, 1f))
        jobPct = text("", 22f, c(R.color.fg), true)
        top.addView(jobPct)
        jobCard.addView(top)
        jobBar = bar()
        jobCard.addView(jobBar, lp(10))
        jobLine = text("", 12f, c(R.color.muted))
        jobCard.addView(jobLine, lp(8))
        jobDetail = text("", 12f, c(R.color.muted))
        jobCard.addView(jobDetail, lp(2))
        val btns = row()
        btns.addView(chip(getString(R.string.home_detail)) { open(BgWork.jobTarget()) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        btns.addView(chip(getString(R.string.stop)) { BgWork.stopOrRelease(this) }, LinearLayout.LayoutParams(0, -2, 1f))
        jobCard.addView(btns, lp(10))
        col.addView(jobCard, lp(14))

        // download in progress
        dlCard = card().apply { visibility = View.GONE }
        val dtop = row()
        dlTitle = text("", 13f, c(R.color.fg))
        dtop.addView(dlTitle, LinearLayout.LayoutParams(0, -2, 1f))
        dlPct = text("", 15f, c(R.color.fg), true)
        dtop.addView(dlPct)
        dlCard.addView(dtop)
        dlBar = bar()
        dlCard.addView(dlBar, lp(8))
        dlLine = text("", 12f, c(R.color.muted))
        dlCard.addView(dlLine, lp(6))
        dlCard.setOnClickListener { open(ModelsActivity::class.java) }
        col.addView(dlCard, lp(8))

        // the sections: big buttons that fill the screen (no pictures here: privacy)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val r1 = row(); val r2 = row(); val r3 = row()
        r1.addView(tile("✦", R.string.home_create, R.string.home_create_sub, GenerateActivity::class.java), cell(true))
        r1.addView(tile("✧", R.string.home_restore, R.string.home_restore_sub, RestoreActivity::class.java), cell(false))
        r2.addView(tile("×4", R.string.home_enhance, R.string.home_enhance_sub, MainActivity::class.java), cell(true))
        r2.addView(tile("▶", R.string.home_video, R.string.home_video_sub, VideoActivity::class.java), cell(false))
        r3.addView(tile("▤", R.string.home_models, R.string.home_models_sub, ModelsActivity::class.java), cell(false))
        for ((i, r) in listOf(r1, r2, r3).withIndex()) {
            r.gravity = Gravity.FILL
            grid.addView(r, LinearLayout.LayoutParams(-1, 0, 1f).apply { if (i > 0) topMargin = dp(10) })
        }
        col.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(14) })

        // the results: opens the gallery; nothing of them is shown here
        val res = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)) }
        res.addView(text("▣  " + getString(R.string.home_results), 15f, c(R.color.fg), true), LinearLayout.LayoutParams(0, -2, 1f))
        res.addView(text(getString(R.string.home_results_sub), 12f, c(R.color.muted)))
        res.setOnClickListener { openGallery() }
        col.addView(res, lp(12))
        col.addView(text("☰ " + getString(R.string.log_open_last), 13f, c(R.color.accent)).apply {
            setPadding(0, dp(10), 0, 0)
            setOnClickListener { LogDialog.show(this@HomeActivity) }
        }, lp(2))

        CrashReport.showIfNeeded(this)
    }

    override fun onResume() {
        super.onResume()
        tick()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacksAndMessages(null)
    }

    private fun tick() {
        refreshJob()
        ui.postDelayed({ tick() }, 500)
    }

    private fun refreshJob() {
        val busy = BgWork.busy
        jobCard.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            jobTitle.text = BgWork.jobTitle()
            jobPct.text = "${BgWork.jobPct.coerceIn(0, 100)} %"
            jobBar.setProgressCompat(BgWork.jobPct.coerceIn(0, 100), true)
            jobLine.text = BgWork.jobDetail.ifBlank { getString(R.string.home_working) }
            val secs = (SystemClock.elapsedRealtime() - BgWork.jobStarted) / 1000
            jobDetail.text = getString(R.string.home_job_detail, if (NpuMeter.inUse()) "⚡ NPU" else "GPU", secs)
        }
        val dl = BgWork.downloading()
        dlCard.visibility = if (dl) View.VISIBLE else View.GONE
        if (dl) {
            dlTitle.text = BgWork.dlTitle()
            dlPct.text = "${BgWork.dlPct().coerceIn(0, 100)} %"
            dlBar.setProgressCompat(BgWork.dlPct().coerceIn(0, 100), true)
            dlLine.text = BgWork.dlText()
        }
        val running = if (busy) BgWork.jobTarget() else null
        for ((cls, t) in tiles) {
            val blocked = busy && cls != ModelsActivity::class.java && cls != running
            t.first.alpha = if (blocked) 0.45f else 1f
            t.second.text = when {
                cls == running -> getString(R.string.home_working)
                blocked -> getString(R.string.home_wait)
                else -> t.second.tag as String
            }
        }
    }

    /** The phone's gallery, where Nítido saves its results (Pictures/Nitido, Movies/Nitido). */
    private fun openGallery() {
        val tries = listOf(
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            Intent(Intent.ACTION_VIEW, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
        )
        for (i in tries) {
            try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (t: Throwable) { }
        }
        AlertDialog.Builder(this).setMessage(R.string.home_results_none).setPositiveButton(android.R.string.ok, null).show()
    }

    /** Opens a section, reusing it if it is already open behind (its job and picture stay). */
    private fun open(cls: Class<*>) =
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))

    // ───────── small builders ─────────

    private fun tile(icon: String, title: Int, sub: Int, cls: Class<*>): LinearLayout {
        val t = card().apply { setPadding(dp(14), dp(14), dp(14), dp(14)); gravity = Gravity.CENTER }
        t.addView(text(icon, 32f, c(R.color.accent)).apply { gravity = Gravity.CENTER })
        t.addView(text(getString(title), 17f, c(R.color.fg), true).apply { gravity = Gravity.CENTER }, lp(8))
        val s = text(getString(sub), 12f, c(R.color.muted)).apply { tag = getString(sub); gravity = Gravity.CENTER }
        t.addView(s)
        t.setOnClickListener {
            val running = if (BgWork.busy) BgWork.jobTarget() else null
            if (running != null && cls != ModelsActivity::class.java && cls != running)
                AlertDialog.Builder(this).setMessage(R.string.home_wait_msg).setPositiveButton(android.R.string.ok, null).show()
            else open(cls)
        }
        tiles[cls] = t to s
        return t
    }

    private fun card(accent: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            setColor(c(R.color.stage)); cornerRadius = dp(14).toFloat()
            setStroke(dp(if (accent) 2 else 1), c(if (accent) R.color.accent else R.color.line))
        }
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun bar() = LinearProgressIndicator(this).apply {
        max = 100; trackThickness = dp(8); trackCornerRadius = dp(4)
        setIndicatorColor(c(R.color.accent)); trackColor = c(R.color.track)
    }

    private fun chip(label: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = label; textSize = 13f; setOnClickListener { onClick() }
        }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun cell(gap: Boolean) = LinearLayout.LayoutParams(0, -1, 1f).apply { if (gap) marginEnd = dp(10) }

    private fun lp(top: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
}
