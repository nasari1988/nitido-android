package com.nitido.app

import android.content.Context
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * Plays a video inside Nítido, fitted as big as the space allows (never cropped): ▶/❚❚, a bar to
 * move through it, the time, sound on/off, "Mejorado ⇄ Original" (jumps to the same moment of the
 * other video) and ⤢ (full screen). The controls hide while playing and come back with a tap.
 */
class VideoPlayerView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val tex = TextureView(ctx)
    private val playBtn = label("▶", 20f)
    private val time = label("0:00", 13f)
    private val sound = label("🔈", 16f)
    private val seek = SeekBar(ctx)
    private val swap = label("", 13f)
    private val full = label("⤢", 18f)
    private val bottom = LinearLayout(ctx)
    private val ui = Handler(Looper.getMainLooper())

    private var mp: MediaPlayer? = null
    private var surface: Surface? = null
    private var vw = 0; private var vh = 0
    private var improved: Uri? = null
    private var original: Uri? = null
    private var showingImproved = true
    private var muted = false
    private var pendingSeek = 0
    private var autoPlay = false
    private var prepared = false

    /** ⤢ pressed: the screen opens the full-screen player at [positionMs]. */
    var onFullscreen: ((improved: Uri?, original: Uri?, showImproved: Boolean, positionMs: Int) -> Unit)? = null
    /** Tells the screen when the playing state changes (to keep its own buttons in step). */
    var onState: ((playing: Boolean) -> Unit)? = null

    init {
        setBackgroundColor(Color.BLACK)
        addView(tex, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER))
        tex.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { surface = Surface(st); load() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fit() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { release(); surface?.release(); surface = null; return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        // top: Mejorado ⇄ Original (left), ⤢ (right)
        swap.background = pill(); swap.setPadding(dp(10), dp(5), dp(10), dp(5)); swap.visibility = View.GONE
        swap.setOnClickListener { switchSource() }
        addView(swap, LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(10), dp(10), 0, 0) })
        full.background = pill(); full.setPadding(dp(10), dp(2), dp(10), dp(4))
        full.setOnClickListener { onFullscreen?.invoke(improved, original, showingImproved, position()) }
        addView(full, LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(10), dp(10), 0) })
        // bottom: ▶ ─── 0:12 / 0:42 🔈
        bottom.orientation = LinearLayout.HORIZONTAL; bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.background = pill(); bottom.setPadding(dp(10), dp(4), dp(10), dp(4))
        playBtn.setPadding(dp(4), dp(4), dp(8), dp(4))
        playBtn.setOnClickListener { toggle() }
        bottom.addView(playBtn)
        bottom.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(time)
        sound.setPadding(dp(10), dp(4), dp(4), dp(4))
        sound.setOnClickListener { muted = !muted; applyVolume() }
        bottom.addView(sound)
        addView(bottom, LayoutParams(LayoutParams.MATCH_PARENT, -2, Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(8), dp(8)) })
        seek.max = 1000
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val m = mp ?: return
                if (prepared) m.seekTo((m.duration.toLong() * p / 1000).toInt())
                showTime()
            }
            override fun onStartTrackingTouch(s: SeekBar) { ui.removeCallbacks(hideControls) }
            override fun onStopTrackingTouch(s: SeekBar) { scheduleHide() }
        })
        setOnClickListener { if (bottom.visibility == View.VISIBLE) setControls(false) else { setControls(true); scheduleHide() } }
    }

    /** What to play: the enhanced video (may be null: only the original yet) and the original. */
    fun setVideos(improvedUri: Uri?, originalUri: Uri?, startImproved: Boolean = true, positionMs: Int = 0, play: Boolean = false) {
        improved = improvedUri; original = originalUri
        showingImproved = startImproved && improvedUri != null
        pendingSeek = positionMs; autoPlay = play
        swap.visibility = if (improvedUri != null && originalUri != null) View.VISIBLE else View.GONE
        updateSwap()
        load()
    }

    fun hasVideo() = (improved ?: original) != null
    fun position(): Int = try { if (prepared) mp?.currentPosition ?: 0 else pendingSeek } catch (t: Throwable) { 0 }
    fun isPlaying(): Boolean = try { prepared && mp?.isPlaying == true } catch (t: Throwable) { false }
    /** Full screen: "Mejorado ⇄ Original" at the top middle (‹ Volver takes the corner). */
    fun swapAtCenter() { (swap.layoutParams as LayoutParams).gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; swap.requestLayout() }

    fun showFullscreenButton(show: Boolean) { full.visibility = if (show) View.VISIBLE else View.GONE }

    fun pause() { try { if (isPlaying()) mp?.pause() } catch (t: Throwable) { }; showPlaying() }

    fun release() {
        ui.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (t: Throwable) { }
        mp = null; prepared = false
    }

    private fun current(): Uri? = if (showingImproved) improved ?: original else original ?: improved

    private fun load() {
        val s = surface ?: return
        val u = current() ?: return
        release()
        readSize(u)
        val m = MediaPlayer()
        mp = m
        try {
            m.setSurface(s)
            m.setDataSource(context, u)
            m.setOnPreparedListener {
                prepared = true
                fit()
                if (pendingSeek > 0) it.seekTo(pendingSeek)
                applyVolume()
                if (autoPlay) it.start() else it.seekTo(pendingSeek.coerceAtLeast(1))   // shows the first picture
                showPlaying(); tickTime()
            }
            m.setOnCompletionListener { showPlaying(); setControls(true) }
            m.setOnVideoSizeChangedListener { _, w, h -> if (vw == 0 || vh == 0) { vw = w; vh = h; fit() } }
            m.setOnErrorListener { _, what, extra ->
                JobLog.notice("Reproductor: error $what/$extra con ${u.lastPathSegment}"); true
            }
            m.prepareAsync()
        } catch (t: Throwable) {
            JobLog.error("Reproductor", t)
        }
        setControls(true)
    }

    /** The size the video is shown at (turned upright), from its own data. */
    private fun readSize(u: Uri) {
        vw = 0; vh = 0
        try {
            MediaMetadataRetriever().run {
                setDataSource(context, u)
                val w = extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val r = extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                release()
                if (r == 90 || r == 270) { vw = h; vh = w } else { vw = w; vh = h }
            }
        } catch (t: Throwable) { }
    }

    /** As big as the space allows, whole (no cropping). */
    private fun fit() {
        if (vw <= 0 || vh <= 0 || width <= 0 || height <= 0) return
        val k = minOf(width.toFloat() / vw, height.toFloat() / vh)
        val lp = tex.layoutParams as LayoutParams
        val w = (vw * k).toInt(); val h = (vh * k).toInt()
        if (lp.width != w || lp.height != h) { lp.width = w; lp.height = h; lp.gravity = Gravity.CENTER; tex.layoutParams = lp }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); post { fit() } }

    private fun toggle() {
        val m = mp ?: return
        if (!prepared) { autoPlay = true; return }
        try { if (m.isPlaying) m.pause() else m.start() } catch (t: Throwable) { }
        showPlaying(); if (isPlaying()) scheduleHide()
    }

    private fun switchSource() {
        if (improved == null || original == null) return
        pendingSeek = position(); autoPlay = isPlaying()
        showingImproved = !showingImproved
        updateSwap(); load()
    }

    private fun updateSwap() {
        swap.text = context.getString(if (showingImproved) R.string.player_improved else R.string.player_original)
    }

    private fun applyVolume() {
        val v = if (muted) 0f else 1f
        try { mp?.setVolume(v, v) } catch (t: Throwable) { }
        sound.text = if (muted) "🔇" else "🔈"
    }

    private fun showPlaying() {
        playBtn.text = if (isPlaying()) "❚❚" else "▶"
        if (isPlaying()) { ui.removeCallbacks(ticker); ui.post(ticker) } else showTime()
        onState?.invoke(isPlaying())
    }

    private val ticker = Runnable { tickTime() }
    private fun tickTime() {
        showTime()
        val m = mp ?: return
        if (prepared && m.duration > 0) seek.progress = (m.currentPosition.toLong() * 1000 / m.duration).toInt()
        ui.removeCallbacks(ticker)
        if (isPlaying()) ui.postDelayed(ticker, 250)   // paused: no clock running (CPU in the background)
    }

    private fun showTime() {
        val m = mp ?: return
        if (!prepared) return
        time.text = "${clock(m.currentPosition)} / ${clock(m.duration)}"
    }

    private fun clock(ms: Int): String { val s = ms / 1000; return "${s / 60}:%02d".format(s % 60) }

    private val hideControls = Runnable { if (isPlaying()) setControls(false) }
    private fun scheduleHide() { ui.removeCallbacks(hideControls); ui.postDelayed(hideControls, 3000) }

    private fun setControls(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        bottom.visibility = v
        full.visibility = if (onFullscreen != null) v else View.GONE
        swap.visibility = if (show && improved != null && original != null) View.VISIBLE else View.GONE
    }

    private fun label(s: String, size: Float) = TextView(context).apply {
        text = s; textSize = size; setTextColor(Color.WHITE)
    }

    private fun pill() = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = 12 * d }

    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); release() }
}
