package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityRestoreBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * "Restaurar foto antigua": one button that runs, in order,
 * scratches → color → grain → blur → colorize → enlarge → faces. All on the phone.
 */
class RestoreActivity : AppCompatActivity() {

    private lateinit var b: ActivityRestoreBinding
    private val aiThread = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private var source: Bitmap? = null
    private var result: Bitmap? = null
    private var marks: Bitmap? = null
    private var sourceName = "foto"
    private var job: Job? = null
    @Volatile private var cancel = false

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }

    private val maskLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) { marks = MaskHolder.mask; updateUi() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRestoreBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.back.setOnClickListener { finish() }
        b.pick.setOnClickListener { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        b.go.setOnClickListener { if (job?.isActive == true) { cancel = true } else restore() }
        b.save.setOnClickListener { save() }
        b.packDownload.setOnClickListener { if (job?.isActive == true) cancel = true else downloadPack() }
        b.marks.setOnClickListener {
            val photo = source ?: return@setOnClickListener
            MaskHolder.photo = photo
            MaskHolder.mask = marks
            maskLauncher.launch(Intent(this, MaskActivity::class.java))
        }
        b.marksClear.setOnClickListener { marks = null; updateUi() }
        b.optFaces.setOnCheckedChangeListener { _, _ -> updateUi() }
        b.fidelityValue.text = "${b.fidelity.value.roundToInt()}%"
        b.fidelity.addOnChangeListener { _, v, _ -> b.fidelityValue.text = "${v.roundToInt()}%" }
        b.save.isEnabled = false
        b.go.isEnabled = false
        updateUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        aiThread.close()
    }

    private fun updateUi() {
        val ready = RestorePack.isReady(this)
        b.packCard.visibility = if (ready) View.GONE else View.VISIBLE
        fun has(n: String) = RestorePack.file(this, n) != null
        b.optDenoise.isEnabled = has(RestorePack.DENOISE)
        if (!has(RestorePack.DENOISE)) b.optDenoise.isChecked = false
        b.optColorize.isEnabled = has(RestorePack.COLOR)
        if (!has(RestorePack.COLOR)) b.optColorize.isChecked = false
        b.marks.isEnabled = source != null && has(RestorePack.LAMA)
        b.marks.text = getString(if (marks != null) R.string.restore_marks_edit else R.string.restore_marks)
        b.marksClear.visibility = if (marks != null) View.VISIBLE else View.GONE
        val faceModel = has(RestorePack.FACES)
        b.fidelityRow.visibility = if (b.optFaces.isChecked && faceModel) View.VISIBLE else View.GONE
    }

    private fun setStatus(s: String) { b.status.text = s }

    private fun loadImage(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = max(info.size.width, info.size.height)
                        if (long > 4096) {
                            val k = 4096f / long
                            dec.setTargetSize((info.size.width * k).roundToInt(), (info.size.height * k).roundToInt())
                        }
                    }.copy(Bitmap.Config.ARGB_8888, false)
                } catch (t: Throwable) { null }
            }
            if (bmp == null) { setStatus(getString(R.string.err_open)); return@launch }
            sourceName = try {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0).substringBeforeLast('.') else null
                } ?: "foto"
            } catch (t: Throwable) { "foto" }
            source = bmp
            result = null
            marks = null
            b.compare.after = null
            b.compare.before = bmp
            b.compare.resetView()
            b.save.isEnabled = false
            b.go.isEnabled = true
            val gray = withContext(Dispatchers.Default) { RestoreTools.isGrayscale(bmp) }
            if (gray && b.optColorize.isEnabled) b.optColorize.isChecked = true
            setStatus(getString(if (gray) R.string.restore_loaded_bw else R.string.restore_loaded))
            updateUi()
        }
    }

    private fun downloadPack() {
        cancel = false
        b.packDownload.text = getString(R.string.stop)
        job = lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    RestorePack.download(this@RestoreActivity, { cancel }) { done, total ->
                        runOnUiThread { setStatus(getString(R.string.restore_pack_dl, done / 1_000_000, total / 1_000_000)) }
                    }
                    null
                } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            }
            b.packDownload.text = getString(R.string.restore_pack_download)
            setStatus(when {
                err == null -> getString(R.string.restore_pack_ready)
                cancel -> getString(R.string.cancelled)
                err.contains("no encontrado") -> getString(R.string.restore_pack_missing)
                else -> getString(R.string.restore_pack_error, err)
            })
            updateUi()
        }
    }

    private fun restore() {
        if (BgWork.busy) { setStatus(getString(R.string.busy_body, BgWork.currentTitle())); return }
        val src0 = source ?: return
        val gpu = b.optGpu.isChecked
        val scale = when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }
        val doMarks = marks != null && RestorePack.file(this, RestorePack.LAMA) != null
        val doColor = b.optColor.isChecked
        val doDenoise = b.optDenoise.isChecked
        val doDeblur = b.optDeblur.isChecked
        val doColorize = b.optColorize.isChecked
        val doFaces = b.optFaces.isChecked
        val fidelity = b.fidelity.value / 100f
        val codeFormer = RestorePack.file(this, RestorePack.FACES)
        val useFaces = doFaces && (codeFormer != null || FaceRestorer.isReady(this))
        val markMask = marks

        // big photos are reduced first: old prints don't hold more detail than this
        val cap = when (scale) { 4 -> 1024; 2 -> 1600; else -> 2400 }
        val long = max(src0.width, src0.height)
        val src = if (long > cap) Bitmap.createScaledBitmap(src0, src0.width * cap / long, src0.height * cap / long, true) else src0

        val stages = listOfNotNull(
            "m".takeIf { doMarks }, "c".takeIf { doColor }, "n".takeIf { doDenoise }, "d".takeIf { doDeblur },
            "k".takeIf { doColorize }, "u".takeIf { scale > 1 }, "f".takeIf { useFaces })
        if (stages.isEmpty()) { setStatus(getString(R.string.restore_nothing)); return }
        val t0 = SystemClock.elapsedRealtime()
        fun report(stage: String, p: Float, label: String) {
            val total = (stages.indexOf(stage) + p) / stages.size
            BgWork.update(this, label, (total * 100).roundToInt())
            runOnUiThread { b.progress.progress = (total * 1000).roundToInt(); setStatus(label) }
        }

        cancel = false
        setBusy(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        BgWork.start(this, getString(R.string.notif_restoring), RestoreActivity::class.java) { cancel = true }
        job = lifecycleScope.launch {
            var facesFound = -1
            var error: String? = null
            val out = withContext(aiThread) {
                try {
                    var img: Bitmap = src
                    if (doMarks) {
                        val label = getString(R.string.step_marks)
                        report("m", 0f, label)
                        img = RestoreTools.removeMarks(applicationContext, RestorePack.file(applicationContext, RestorePack.LAMA)!!,
                            img, markMask!!, gpu, { p -> report("m", p, label) }, { cancel }) ?: return@withContext null
                    }
                    if (doColor) {
                        report("c", 0f, getString(R.string.step_color))
                        img = RestoreTools.fixColor(img, saturate = !doColorize)
                    }
                    if (doDenoise) {
                        val label = getString(R.string.step_denoise)
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU,
                            RestorePack.file(applicationContext, RestorePack.DENOISE)!!.absolutePath, pad = 32, precise = true).use { d ->
                            img = d.upscale(img, 1, { p -> report("n", p, label) }, { cancel }) ?: return@withContext null
                        }
                    }
                    if (doDeblur) {
                        val label = getString(R.string.step_deblur)
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, Upscaler.MODEL_DEBLUR, pad = 24).use { d ->
                            img = d.upscale(img, 1, { p -> report("d", p, label) }, { cancel }) ?: return@withContext null
                        }
                    }
                    if (doColorize) {
                        report("k", 0f, getString(R.string.step_colorize))
                        img = RestoreTools.colorize(applicationContext, RestorePack.file(applicationContext, RestorePack.COLOR)!!, img, gpu)
                    }
                    if (scale > 1) {
                        val label = getString(R.string.step_upscale)
                        val model = if (MnnTile.hasAsset(applicationContext, Upscaler.MODEL_SIAX)) Upscaler.MODEL_SIAX else Upscaler.MODEL_X4PLUS
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, model).use { u ->
                            img = u.upscale(img, scale, { p -> report("u", p, label) }, { cancel }) ?: return@withContext null
                        }
                    }
                    if (useFaces) {
                        if (!img.isMutable || img === src) img = img.copy(Bitmap.Config.ARGB_8888, true)
                        FaceRestorer(applicationContext, gpu, codeFormer, fidelity).use { fr ->
                            facesFound = fr.restoreAll(img, { i, n ->
                                report("f", if (n == 0) 1f else i.toFloat() / n, getString(R.string.step_faces, minOf(i + 1, n), n))
                            }, { cancel })
                        }
                    }
                    img
                } catch (t: OutOfMemoryError) {
                    error = "memoria insuficiente"; null
                } catch (t: Throwable) {
                    android.util.Log.e("Nitido", "restore failed", t)
                    error = t.message ?: t.javaClass.simpleName; null
                }
            }
            setBusy(false)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            BgWork.finish(this@RestoreActivity, when {
                out != null -> getString(R.string.notif_done_image)
                cancel -> null
                else -> getString(R.string.notif_failed)
            })
            if (out == null) {
                setStatus(if (cancel) getString(R.string.cancelled) else getString(R.string.restore_failed, error ?: "?"))
                return@launch
            }
            result = out
            b.compare.after = out
            b.save.isEnabled = true
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            val notes = mutableListOf(getString(R.string.restore_done, secs, out.width, out.height))
            if (facesFound == 0) notes += getString(R.string.faces_none)
            if (facesFound > 0) notes += getString(R.string.faces_done, facesFound)
            if (doFaces && !useFaces) notes += getString(R.string.restore_no_face_model)
            setStatus(notes.joinToString(" "))
        }
    }

    private fun setBusy(busy: Boolean) {
        b.go.text = getString(if (busy) R.string.stop else R.string.restore_go)
        b.progress.visibility = if (busy) View.VISIBLE else View.INVISIBLE
        b.progress.progress = 0
        b.pick.isEnabled = !busy
        b.save.isEnabled = !busy && result != null
        b.marks.isEnabled = !busy && source != null && RestorePack.file(this, RestorePack.LAMA) != null
        b.packDownload.isEnabled = !busy
    }

    private fun save() {
        val bmp = result ?: return
        b.save.isEnabled = false
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "${sourceName}_restaurada_${System.currentTimeMillis() / 1000}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    true
                } catch (t: Throwable) { false }
            }
            b.save.isEnabled = true
            setStatus(getString(if (ok) R.string.saved else R.string.err_save))
        }
    }
}
