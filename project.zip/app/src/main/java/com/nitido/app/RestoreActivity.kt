package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityRestoreBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * "Restaurar foto antigua": one button that runs, in order,
 * scratches → color → grain → blur → colorize → enlarge → faces. All on the phone.
 */
/**
 * Everything the Restore screen is working on lives here, outside the screen, so rotating the
 * phone, turning the screen off or switching apps doesn't lose the photo or stop the work.
 * The photo and the result are also written to the app's cache, in case Android closes the app.
 */
object RestoreSession {
    var source: Bitmap? = null
    var result: Bitmap? = null
    /** Manual color/sharpness touches on the result, and the result as shown with them. */
    var adjust = PhotoAdjust.Values()
    var adjusted: Bitmap? = null
    var marks: Bitmap? = null
    /** Rayones automático: the detector's map for the photo, the marks it gave and how many damages. */
    var autoMap: ScratchDetector.Map? = null
    var autoMarks: Bitmap? = null
    var autoCount = 0
    var overlay: Bitmap? = null
    /** The photo came in black and white (so "Original B/N" is offered on the result). */
    var wasGray = false
    /** Where the result was saved by itself (Guardar then replaces it with the touched version). */
    var savedUri: android.net.Uri? = null
    /** RestoreTools.blurRatio of the photo (below ~0.35 = really blurred). */
    var blurRatio = 1f
    /** Tries of the current restoration (one automatic retry, then the "no se pudo" notice). */
    var tries = 0
    /** "Ahora no" to the Realismo download: not asked again until the app is closed. */
    var realDeclined = false
    var sourceName = "foto"
    var job: Job? = null
    @Volatile var cancel = false
    var busy = false
    var status = ""
    var progress = 0
    var ui: RestoreActivity? = null
    // what the processing screen shows
    var live: Bitmap? = null
    var stepName = ""
    var stepIdx = 0
    var stepCount = 1
    var stepFrac = 0f
    var totalFrac = 0f
    var piece: String? = null
    var etaSec: Float? = null
    var t0 = 0L
    val aiThread = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    fun srcFile(ctx: android.content.Context) = java.io.File(ctx.cacheDir, "restore_src.jpg")
    fun outFile(ctx: android.content.Context) = java.io.File(ctx.cacheDir, "restore_out.jpg")
}

class RestoreActivity : AppCompatActivity() {

    lateinit var b: ActivityRestoreBinding
    lateinit var proc: ProcessScreen
    private val S = RestoreSession
    private val aiThread get() = S.aiThread
    private var source: Bitmap? get() = S.source; set(v) { S.source = v }
    // a new result starts with no manual touches
    private var result: Bitmap? get() = S.result; set(v) { S.result = v; S.adjust = PhotoAdjust.Values(); S.adjusted = null }
    private var adjustJob: Job? = null
    private var marks: Bitmap? get() = S.marks; set(v) { S.marks = v }
    private var sourceName: String get() = S.sourceName; set(v) { S.sourceName = v }
    private var job: Job? get() = S.job; set(v) { S.job = v }
    private var cancel: Boolean get() = S.cancel; set(v) { S.cancel = v }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }

    private val maskLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            marks = MaskHolder.mask
            // corrected by hand: show those marks in red
            val ph = source; val mk = marks
            S.overlay = if (ph != null && mk != null) ScratchDetector.overlay(ph, mk) else null
            render()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRestoreBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.back.setOnClickListener { finish() }
        b.pick.setOnClickListener { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        b.go.setOnClickListener {
            if (job?.isActive == true) { cancel = true; if (SdNative.loadError == null) SdNative.cancel() }
            else if (simple) restoreAll() else { S.tries = 0; restore() }
        }
        b.save.setOnClickListener { save() }
        b.packDownload.setOnClickListener { if (job?.isActive == true) cancel = true else downloadPack() }
        b.marks.setOnClickListener {
            val photo = source ?: return@setOnClickListener
            MaskHolder.photo = photo
            MaskHolder.mask = marks
            maskLauncher.launch(Intent(this, MaskActivity::class.java))
        }
        b.marksClear.setOnClickListener { marks = null; S.overlay = null; render() }
        b.optFaces.setOnCheckedChangeListener { _, _ -> updateUi() }
        b.optDetail.setOnCheckedChangeListener { _, _ -> updateUi() }
        b.optDeblur.setOnCheckedChangeListener { _, _ -> updateUi() }
        for (sw in listOf(b.optCrop, b.optColor, b.optDenoise, b.optColorize, b.optGpu)) sw.setOnCheckedChangeListener { _, _ -> updateUi() }
        b.scaleGroup.addOnButtonCheckedListener { _, _, checked -> if (checked) updateUi() }
        b.sharpValue.text = "${b.sharpAmount.value.roundToInt()}%"
        b.sharpAmount.addOnChangeListener { _, v, _ -> b.sharpValue.text = "${v.roundToInt()}%" }
        b.detailValue.text = "${b.detailAmount.value.roundToInt()}%"
        b.detailAmount.addOnChangeListener { _, v, _ -> b.detailValue.text = "${v.roundToInt()}%" }
        b.fidelityValue.text = "${b.fidelity.value.roundToInt()}%"
        b.fidelity.addOnChangeListener { _, v, _ -> b.fidelityValue.text = "${v.roundToInt()}%" }
        buildAdjust()
        setupOptions()
        LogDialog.addTo(this, opts)
        buildSimple()
        (b.compare.parent as? android.widget.FrameLayout)?.let { f -> FullscreenActivity.addButton(this, f) { b.compare.before to b.compare.after } }
        proc = ProcessScreen(this) { cancel = true; if (SdNative.loadError == null) SdNative.cancel() }
        S.ui = this
        if (source == null) reloadFromDisk() else render()
    }

    override fun onResume() {
        super.onResume()
        if (simple != !Prefs.advanced(this)) { applyMode(); render() }
    }

    override fun onDestroy() {
        if (S.ui === this) S.ui = null
        super.onDestroy()
    }

    /** Shows whatever the session holds: photo, result, progress, messages. */
    fun render() {
        // before restoring: the photo with what Rayones will repair in red
        b.compare.before = if (result == null && !S.busy && marks != null) S.overlay ?: source else source
        b.compare.after = if (S.adjust.isNeutral) result else S.adjusted ?: result
        b.adjustBox.visibility = if (result != null && !S.busy && !simple) View.VISIBLE else View.GONE
        syncAdjust()
        b.status.text = S.status
        b.go.text = getString(if (S.busy) R.string.stop else R.string.restore_go)
        b.go.isEnabled = source != null
        b.progress.visibility = if (S.busy) View.VISIBLE else View.INVISIBLE
        b.progress.progress = S.progress
        b.pick.isEnabled = !S.busy
        b.save.isEnabled = !S.busy && result != null
        b.packDownload.isEnabled = !S.busy
        if (S.busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        updateUi()
        if (S.busy) b.marks.isEnabled = false
        renderSimple()
        if (S.busy) {
            proc.show(getString(R.string.proc_restoring), S.live ?: source, S.t0)
            proc.update(S.stepName, S.stepIdx, S.stepCount, S.stepFrac, S.totalFrac, S.piece, S.etaSec)
        } else proc.hide()
    }

    /** Retoques finales (the same panel as the other tools): edits S.adjust, redraws the preview. */
    private lateinit var adjustPanel: AdjustPanel

    private fun buildAdjust() {
        adjustPanel = AdjustPanel(this, { result }, { S.adjust }, { v -> S.adjust = v; scheduleAdjust() },
            { cb -> b.compare.onPick = cb }, { S.wasGray })
    }

    private fun syncAdjust() { if (::adjustPanel.isInitialized) adjustPanel.sync() }

    /** Redraws the preview with the touches, a moment after the slider stops (on a smaller copy). */
    private fun scheduleAdjust() {
        val src = result ?: return
        val v = S.adjust
        adjustJob?.cancel()
        adjustJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(60)
            val shown = withContext(Dispatchers.Default) {
                if (v.isNeutral) null else PhotoAdjust.apply(PhotoAdjust.previewOf(src), v)
            }
            if (S.adjust != v || result !== src) return@launch
            if (!v.isNeutral && shown == null) return@launch
            S.adjusted = shown
            b.compare.after = shown ?: src
            b.compare.invalidate()
        }
    }

    /** Sends the picture being worked on to the processing screen. */
    fun livePreview(bmp: Bitmap, force: Boolean = false) {
        if (force) S.live = bmp
        S.ui?.proc?.preview(bmp, force)
    }

    private fun reloadFromDisk() {
        render()
        val app = applicationContext
        lifecycleScope.launch {
            val (src, out) = withContext(Dispatchers.IO) {
                fun read(f: java.io.File) = if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.path) else null
                read(RestoreSession.srcFile(app)) to read(RestoreSession.outFile(app))
            }
            if (src == null || source != null) return@launch
            source = src
            result = out
            S.wasGray = withContext(Dispatchers.Default) { RestoreTools.isOneTone(src) }
            sourceName = getSharedPreferences("nitido", MODE_PRIVATE).getString("restore_name", "foto") ?: "foto"
            render()
        }
    }

    /** Remembers the photo (or result) on disk, in the background. */
    private fun persist(bmp: Bitmap, file: java.io.File) {
        BgWork.scope.launch(Dispatchers.IO) {
            try {
                val tmp = java.io.File(file.path + ".tmp")
                tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                tmp.renameTo(file)
            } catch (_: Throwable) { }
        }
    }

    private fun updateUi() {
        val ready = RestorePack.isReady(this)
        fun has(n: String) = RestorePack.file(this, n) != null
        val partial = ready && listOf(RestorePack.DENOISE, RestorePack.DEBLUR, RestorePack.FACES, RestorePack.LAMA, RestorePack.COLOR).any { !has(it) }
        b.packCard.visibility = if ((!ready || partial) && !simple) View.VISIBLE else View.GONE
        b.packInfo.text = getString(if (partial) R.string.restore_pack_partial else R.string.restore_pack_info)
        if (job?.isActive != true) b.packDownload.text = getString(if (partial) R.string.restore_pack_update else R.string.restore_pack_download)
        b.optDenoise.isEnabled = has(RestorePack.DENOISE)
        if (!has(RestorePack.DENOISE)) b.optDenoise.isChecked = false
        b.optColorize.isEnabled = has(RestorePack.COLOR)
        if (!has(RestorePack.COLOR)) b.optColorize.isChecked = false
        b.marks.isEnabled = source != null && has(RestorePack.LAMA)
        b.marks.text = getString(if (marks != null) R.string.restore_marks_edit else R.string.restore_marks)
        b.marksClear.visibility = if (marks != null) View.VISIBLE else View.GONE
        b.sharpRow.visibility = if (b.optDeblur.isChecked) View.VISIBLE else View.GONE
        b.estimate.text = estimateText() ?: ""
        val sd = SdDetail.pickModel(this)
        b.optDetail.isEnabled = sd != null
        if (sd == null) b.optDetail.isChecked = false
        b.detailRow.visibility = if (b.optDetail.isChecked) View.VISIBLE else View.GONE
        b.detailHint.text = if (sd == null) getString(R.string.restore_detail_none)
            else getString(R.string.restore_detail_hint, ModelCatalog.displayName(sd))
        val faceModel = has(RestorePack.FACES)
        b.fidelityRow.visibility = if (b.optFaces.isChecked && faceModel) View.VISIBLE else View.GONE
        if (::opts.isInitialized) opts.refresh()
    }

    // ---------- the chosen options, as labels under the picture ----------

    private lateinit var opts: OptionBar

    /** "auto", "npu", "gpu" or "cpu" (the Processor label). */
    private var procMode = "auto"

    private fun setupOptions() {
        opts = OptionBar(this, b.optLabels, b.optPanel)
        val holder = b.optHolder
        val fidelityHint = holder.getChildAt(holder.indexOfChild(b.fidelityRow) + 1)
        fun toggle(sw: com.google.android.material.materialswitch.MaterialSwitch, name: Int) =
            opts.add(getString(name), { getString(name) }, on = { sw.isChecked }, shown = { sw.isEnabled },
                tap = { sw.isChecked = !sw.isChecked })
        toggle(b.optCrop, R.string.opt_crop)
        toggle(b.optColor, R.string.opt_color)
        toggle(b.optDenoise, R.string.opt_denoise)
        opts.add(getString(R.string.opt_deblur_short), { getString(R.string.opt_deblur_short) + if (b.optDeblur.isChecked) " ${b.sharpAmount.value.roundToInt()} %" else "" },
            listOf(b.optDeblur, b.sharpRow), on = { b.optDeblur.isChecked }, shown = { true }, closeOnPick = false)
        opts.add(getString(R.string.opt_faces_short), {
            if (b.optFaces.isChecked) getString(R.string.opt_faces_on, b.fidelity.value.roundToInt()) else getString(R.string.opt_faces_short)
        }, listOf(b.optFaces, b.fidelityRow, fidelityHint), on = { b.optFaces.isChecked }, shown = { true }, closeOnPick = false)
        toggle(b.optColorize, R.string.opt_colorize)
        opts.add(getString(R.string.opt_detail), { getString(R.string.opt_detail) }, listOf(b.optDetail, b.detailRow, b.detailHint),
            on = { b.optDetail.isChecked }, shown = { true }, closeOnPick = false)
        opts.add(getString(R.string.label_scale), {
            when (b.scaleGroup.checkedButtonId) { R.id.rScale4 -> "×4"; R.id.rScale1 -> "×1"; else -> "×2" }
        }, listOf(b.scaleGroup))
        // Processor: Auto (each step on what is fastest on this phone) / NPU / GPU / CPU, remembered
        val procPrefs = getSharedPreferences("restore", MODE_PRIVATE)
        val modes = listOf("auto" to R.string.proc_auto, "npu" to R.string.procsel_npu, "gpu" to R.string.procsel_gpu, "cpu" to R.string.procsel_cpu)
        procMode = procPrefs.getString("proc", null) ?: if (b.optGpu.isChecked) "auto" else "cpu"
        b.optGpu.isChecked = procMode != "cpu"
        val procHint = android.widget.TextView(this).apply {
            textSize = 12f; setTextColor(androidx.core.content.ContextCompat.getColor(this@RestoreActivity, R.color.muted))
            setPadding(0, (6 * resources.displayMetrics.density).toInt(), 0, 0)
        }
        fun hintFor(m: String) = getString(when (m) { "npu" -> R.string.proc_npu_hint; "gpu" -> R.string.proc_gpu_hint; "cpu" -> R.string.proc_cpu_hint; else -> R.string.proc_auto_hint })
        val procGroup = com.google.android.material.chip.ChipGroup(this).apply { isSingleSelection = true; isSelectionRequired = true }
        for ((m, label) in modes) {
            procGroup.addView(com.google.android.material.chip.Chip(this).apply {
                id = View.generateViewId(); text = getString(label); isCheckable = true; isChecked = m == procMode; tag = m
                setOnClickListener {
                    procMode = m
                    b.optGpu.isChecked = m != "cpu"
                    procPrefs.edit().putString("proc", m).apply()
                    procHint.text = hintFor(m)
                    updateUi()
                }
            })
        }
        procHint.text = hintFor(procMode)
        val procBox = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; addView(procGroup); addView(procHint) }
        b.optHolder.addView(procBox)
        opts.add(getString(R.string.proc_title), { "⚡ " + getString(modes.first { it.first == procMode }.second) }, listOf(procBox),
            on = { true }, shown = { true })
        val autoPanel = buildAutoPanel()
        b.optHolder.addView(autoPanel)
        opts.add(getString(R.string.restore_marks), {
            when {
                marks != null && marks === S.autoMarks -> getString(R.string.auto_marks_label, S.autoCount)
                marks != null -> getString(R.string.opt_marks_on)
                else -> getString(R.string.opt_marks_off)
            }
        }, listOf(autoPanel, b.marks.parent as View), on = { marks != null }, shown = { b.marks.isEnabled }, closeOnPick = false)
        opts.add(getString(R.string.adjust_title), { getString(R.string.adjust_title) }, listOf(b.adjustBox),
            shown = { result != null && !S.busy }, closeOnPick = false)
        setupRealism(procPrefs)
        setupReimagine(procPrefs)
    }


    // ---------- the simple screen: ✦ Restaurar todo, Avanzado, retoques ----------

    private var simple = true
    private lateinit var simpleBox: android.widget.LinearLayout
    private lateinit var simpleSub: android.widget.TextView
    private lateinit var simpleLinks: android.widget.LinearLayout
    private lateinit var finishBox: android.widget.LinearLayout
    private lateinit var saveBtn: com.google.android.material.button.MaterialButton
    private lateinit var backSimple: android.widget.TextView

    /** In Modo avanzado: a link back to the simple screen (the switch is also in Ajustes). */
    private fun simpleLink(onBack: () -> Unit) = Ui.text(this, getString(R.string.back_to_simple), 14f, R.color.accent).apply {
        gravity = android.view.Gravity.CENTER
        setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8))
        setOnClickListener { Prefs.setAdvanced(context, false); JobLog.add("Volver a lo sencillo"); onBack() }
    }

    /** The simple screen's own pieces, put under the picture; the old controls stay for Avanzado. */
    private fun buildSimple() {
        val root = b.root as android.widget.LinearLayout
        simpleBox = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        simpleSub = Ui.text(this, "", 13f, R.color.muted).apply { gravity = android.view.Gravity.CENTER }
        simpleBox.addView(simpleSub, Ui.lp(this, 4))
        simpleLinks = Ui.row(this).apply { gravity = android.view.Gravity.CENTER }
        simpleLinks.addView(Ui.text(this, getString(R.string.simple_mark_more), 14f, R.color.accent).apply {
            setPadding(Ui.dp(context, 12), Ui.dp(context, 10), Ui.dp(context, 12), Ui.dp(context, 10))
            setOnClickListener { markMore() }
        })
        simpleLinks.addView(Ui.text(this, getString(R.string.simple_advanced), 14f, R.color.accent).apply {
            setPadding(Ui.dp(context, 12), Ui.dp(context, 10), Ui.dp(context, 12), Ui.dp(context, 10))
            setOnClickListener { showAdvancedSheet() }
        })
        simpleBox.addView(simpleLinks)
        root.addView(simpleBox, root.indexOfChild(b.status) + 1)

        finishBox = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val btns = Ui.row(this)
        btns.addView(Ui.outlineButton(this, getString(R.string.simple_redo)) { redo() },
            android.widget.LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(this@RestoreActivity, 8) })
        saveBtn = Ui.bigButton(this, getString(R.string.save)) { save() }
        btns.addView(saveBtn, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        finishBox.addView(btns, Ui.lp(this, 8))
        root.addView(finishBox, root.indexOfChild(simpleBox) + 1)
        backSimple = simpleLink { applyMode(); render() }
        root.addView(backSimple, root.indexOfChild(b.status) + 1)
        applyMode()
    }

    /** Simple (Ajustes › Modo avanzado off) or the old screen with every option. */
    private fun applyMode() {
        simple = !Prefs.advanced(this)
        // the retoques panel lives in the finish box (simple) or in the old option selector
        (adjustPanel.parent as? android.view.ViewGroup)?.removeView(adjustPanel)
        if (simple) finishBox.addView(adjustPanel, 0) else b.adjustBox.addView(adjustPanel)
        for (v in listOf(b.optPanel, b.optLabels, b.estimate, b.save)) Ui.gone(v, simple)
        Ui.gone(backSimple, simple)
        if (simple) b.packCard.visibility = View.GONE
        b.go.textSize = if (simple) 17f else 14f
        if (simple && source != null && !S.busy && result == null) applySimpleDefaults()
    }

    private fun renderSimple() {
        if (!::simpleBox.isInitialized) return
        if (!simple) {
            simpleBox.visibility = View.GONE; finishBox.visibility = View.GONE
            b.go.visibility = View.VISIBLE
            return
        }
        b.packCard.visibility = View.GONE
        val done = result != null && !S.busy
        finishBox.visibility = if (done) View.VISIBLE else View.GONE
        simpleBox.visibility = if (done) View.GONE else View.VISIBLE
        b.go.visibility = if (done) View.GONE else View.VISIBLE
        b.go.isEnabled = true
        b.go.text = when {
            S.busy -> getString(R.string.stop)
            source == null -> getString(R.string.simple_pick_photo)
            else -> getString(R.string.simple_restore_all)
        }
        simpleLinks.visibility = if (source != null && !S.busy) View.VISIBLE else View.GONE
        simpleSub.text = when {
            source == null -> getString(R.string.simple_restore_intro)
            else -> getString(R.string.simple_restore_sub) + (simpleEta()?.let { " · $it" } ?: "")
        }
        saveBtn.isEnabled = !S.busy
        saveBtn.text = getString(if (S.savedUri != null && S.adjust.isNeutral) R.string.simple_saved else R.string.save)
        if (done) syncAdjust()
    }

    private val simplePrefs by lazy { getSharedPreferences("restore", MODE_PRIVATE) }

    /**
     * What ✦ Restaurar todo does, chosen for the photo: every repair on, colorize only if it is
     * black and white, textura real unless Calidad is "Rápido", ×2, Reimaginar off (it can change
     * people). The Avanzado sheet's choices are kept.
     */
    private fun applySimpleDefaults() {
        val q = Prefs.quality(this)
        fun has(n: String) = RestorePack.file(this, n) != null
        b.optCrop.isChecked = true
        b.optColor.isChecked = true
        b.optDenoise.isChecked = has(RestorePack.DENOISE)
        b.sharpAmount.value = 80f
        b.optFaces.isChecked = simplePrefs.getBoolean("s_faces", true)
        b.fidelity.value = 70f
        b.optColorize.isChecked = S.wasGray && has(RestorePack.COLOR) && simplePrefs.getBoolean("s_colorize", true)
        b.optDetail.isChecked = false
        realOn = simplePrefs.getBoolean("s_real", true) && q != "fast" && !(S.realDeclined && !Realism.isReady(this))
        realPct = if (q == "max") 110 else 100
        reimOn = simplePrefs.getBoolean("s_reim", false) && Reimagine.models(this).isNotEmpty()
        // Desenfoque is the slowest step; with Realismo on it only runs on a really blurred photo
        val blurry = S.blurRatio < 0.35f
        b.optDeblur.isChecked = q != "fast" && (!realOn || blurry)
        b.scaleGroup.check(when (simplePrefs.getInt("s_scale", 2)) { 1 -> R.id.rScale1; 4 -> R.id.rScale4; else -> R.id.rScale2 })
        procMode = "auto"; b.optGpu.isChecked = true
        restorePrefs.edit().putBoolean("auto_marks", simplePrefs.getBoolean("s_marks", true)).apply()
    }

    /** ✦ Restaurar todo: downloads what is missing (asking first), then restores. */
    private fun restoreAll() {
        if (source == null) { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)); return }
        applySimpleDefaults()
        if (!RestorePack.isReady(this)) {
            Ui.askDownload(this, getString(R.string.simple_feature_restore), getString(R.string.simple_size_restore),
                onYes = { downloadPack { restoreAll() } })
            return
        }
        if (realOn && !Realism.isReady(this) && !S.realDeclined) {
            Ui.askDownload(this, getString(R.string.simple_feature_real), getString(R.string.simple_size_real),
                onYes = { S.tries = 0; restore() },   // the restoration downloads it as its first part
                onNo = { S.realDeclined = true; realOn = false; S.tries = 0; restore() })
            return
        }
        S.tries = 0
        restore()
    }

    /** "Marcar algo más": the finger editor, starting from the automatic marks. */
    private fun markMore() {
        if (RestorePack.file(this, RestorePack.LAMA) == null) {
            Ui.askDownload(this, getString(R.string.simple_feature_restore), getString(R.string.simple_size_restore),
                onYes = { downloadPack { } })
            return
        }
        b.marks.performClick()
    }

    /** Rehacer: back to the photo (with its marks) to restore it again, maybe with other choices. */
    private fun redo() {
        result = null
        S.savedUri = null
        RestoreSession.outFile(applicationContext).delete()
        S.status = if (S.autoCount > 0) getString(R.string.auto_marks_found, S.autoCount) else ""
        applySimpleDefaults()
        render()
    }

    /** Avanzado: the few choices of ✦ Restaurar todo, in plain words (remembered). */
    private fun showAdvancedSheet() {
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            setPadding(Ui.dp(context, 18), Ui.dp(context, 14), Ui.dp(context, 18), Ui.dp(context, 18))
        }
        box.addView(Ui.text(this, getString(R.string.simple_adv_title), 17f, bold = true))
        fun sw(label: String, note: String?, key: String, def: Boolean, enabled: Boolean = true) {
            val s = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
                text = label; isChecked = simplePrefs.getBoolean(key, def) && enabled; isEnabled = enabled
                setTextColor(getColor(R.color.fg))
                setOnCheckedChangeListener { _, on -> simplePrefs.edit().putBoolean(key, on).apply() }
            }
            box.addView(s, Ui.lp(this, 6))
            if (note != null) box.addView(Ui.text(this, note, 12f, R.color.muted))
        }
        sw(getString(R.string.simple_adv_marks), getString(R.string.simple_adv_marks_note), "s_marks", true)
        sw(getString(R.string.simple_adv_colorize), null, "s_colorize", true)
        sw(getString(R.string.simple_adv_real), getString(if (Realism.isReady(this)) R.string.simple_adv_real_note else R.string.simple_adv_real_dl), "s_real", true)
        sw(getString(R.string.simple_adv_faces), null, "s_faces", true)
        box.addView(Ui.text(this, getString(R.string.simple_adv_scale), 14f, R.color.fg), Ui.lp(this, 12))
        val scales = Ui.chipRow(this)
        val cur = simplePrefs.getInt("s_scale", 2)
        val chips = mutableListOf<android.widget.TextView>()
        for (k in listOf(1, 2, 4)) {
            chips += Ui.chip(this, if (k == 1) getString(R.string.simple_adv_scale_same) else "×$k", k == cur) {
                simplePrefs.edit().putInt("s_scale", k).apply()
                chips.forEachIndexed { i, c -> Ui.setChip(c, listOf(1, 2, 4)[i] == k) }
            }
        }
        chips.forEach { scales.addView(it) }
        box.addView(scales, Ui.lp(this, 4))
        val hasReim = Reimagine.models(this).isNotEmpty()
        sw(getString(R.string.simple_adv_reim), getString(if (hasReim) R.string.simple_adv_reim_note else R.string.reim_no_model), "s_reim", false, hasReim)
        val links = Ui.row(this)
        links.addView(Ui.text(this, getString(R.string.simple_adv_reset), 14f, R.color.accent).apply {
            setPadding(0, Ui.dp(context, 14), Ui.dp(context, 18), Ui.dp(context, 4))
            setOnClickListener {
                simplePrefs.edit().remove("s_marks").remove("s_colorize").remove("s_real").remove("s_faces").remove("s_scale").remove("s_reim").apply()
                dlg.dismiss(); applySimpleDefaults(); render()
            }
        })
        links.addView(Ui.text(this, getString(R.string.simple_adv_all), 14f, R.color.accent).apply {
            setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 4))
            setOnClickListener { Prefs.setAdvanced(this@RestoreActivity, true); dlg.dismiss(); applyMode(); render() }
        })
        box.addView(links)
        dlg.setOnDismissListener {
            if (source != null && result == null && !S.busy) {
                val wasAuto = marks != null && marks === S.autoMarks
                applySimpleDefaults()
                // Rayones turned off / on: drop or bring back the automatic marks
                if (!simplePrefs.getBoolean("s_marks", true) && wasAuto) { marks = null; S.overlay = null }
                else if (simplePrefs.getBoolean("s_marks", true) && marks == null) source?.let { detectDamage(it) }
                render()
            }
        }
        dlg.setContentView(android.widget.ScrollView(this).apply { addView(box) })
        dlg.show()
    }

    // ---------- ✦ Realismo ----------

    private var realOn = false
    private var realPct = 100

    /** PiSA-SR on the NPU: gives the cleaned photo real texture, faithful to it (pack downloaded on first use). */
    private fun setupRealism(prefs: android.content.SharedPreferences) {
        realOn = prefs.getBoolean("real_on", false)
        realPct = prefs.getInt("real_pct", 100)
        val d = resources.displayMetrics.density
        val muted = androidx.core.content.ContextCompat.getColor(this, R.color.muted)
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val sw = com.google.android.material.materialswitch.MaterialSwitch(this).apply { text = getString(R.string.real_switch); isChecked = realOn }
        val amount = android.widget.TextView(this).apply { textSize = 13f; setTextColor(muted); setPadding(0, (8 * d).toInt(), 0, 0) }
        val slider = com.google.android.material.slider.Slider(this).apply { valueFrom = 50f; valueTo = 130f; stepSize = 10f; value = realPct.toFloat().coerceIn(50f, 130f) }
        val ends = android.widget.LinearLayout(this).apply {
            addView(android.widget.TextView(this@RestoreActivity).apply { text = getString(R.string.real_soft); textSize = 12f; setTextColor(muted) },
                android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            addView(android.widget.TextView(this@RestoreActivity).apply { text = getString(R.string.real_strong); textSize = 12f; setTextColor(muted) })
        }
        val hint = android.widget.TextView(this).apply { textSize = 12f; setTextColor(muted); setPadding(0, (6 * d).toInt(), 0, 0) }
        fun refresh() {
            amount.text = getString(R.string.real_amount, realPct)
            hint.text = getString(if (Realism.isReady(this)) R.string.real_hint else R.string.real_hint_download)
        }
        sw.setOnCheckedChangeListener { _, on -> realOn = on; prefs.edit().putBoolean("real_on", on).apply(); updateUi() }
        slider.addOnChangeListener { _, v, _ -> realPct = v.toInt(); prefs.edit().putInt("real_pct", realPct).apply(); refresh(); opts.refresh() }
        for (v in listOf(sw, amount, slider, ends, hint)) box.addView(v)
        b.optHolder.addView(box)
        refresh()
        opts.add(getString(R.string.real_title), {
            if (realOn) getString(R.string.real_label_on, realPct) else getString(R.string.real_title)
        }, listOf(box), on = { realOn }, shown = { true }, closeOnPick = false)
    }

    // ---------- ✎ Rayones automático ----------

    private val restorePrefs by lazy { getSharedPreferences("restore", MODE_PRIVATE) }
    private val autoOn get() = restorePrefs.getBoolean("auto_marks", true)
    private val sensitivity get() = restorePrefs.getInt("auto_sens", 60)

    /** Looks for scratches, stains and folds in the new photo (in the background) and marks them. */
    private fun detectDamage(photo: Bitmap) {
        if (!autoOn || !ScratchDetector.isReady(this)) return
        val gpu = procMode != "cpu"
        setStatus(getString(R.string.auto_marks_looking))
        lifecycleScope.launch {
            val map = withContext(Dispatchers.Default) { try { ScratchDetector.detect(applicationContext, photo, gpu) } catch (t: Throwable) { JobLog.error("Detector de rayones", t); null } }
            if (map == null || source !== photo) return@launch
            S.autoMap = map
            applyAuto()
        }
    }

    /** The marks from the detector at the current sensitivity (keeps the photo's own marks if painted by hand). */
    private fun applyAuto() {
        val map = S.autoMap ?: return
        val photo = source ?: return
        lifecycleScope.launch {
            val (m, n) = withContext(Dispatchers.Default) { ScratchDetector.mask(map, photo.width, photo.height, sensitivity) }
            val ov = withContext(Dispatchers.Default) { ScratchDetector.overlay(photo, m) }
            if (source !== photo) return@launch
            S.autoMarks = m; S.autoCount = n; S.overlay = ov
            marks = if (n > 0) m else null
            setStatus(if (n > 0) getString(R.string.auto_marks_found, n) else getString(R.string.auto_marks_none))
            render()
            if (::opts.isInitialized) opts.refresh()
        }
    }

    /** Rayones' panel: automatic or by hand, the sensitivity, and correcting with the finger. */
    private fun buildAutoPanel(): View {
        val d = resources.displayMetrics.density
        val muted = androidx.core.content.ContextCompat.getColor(this, R.color.muted)
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val group = com.google.android.material.button.MaterialButtonToggleGroup(this).apply { isSingleSelection = true; isSelectionRequired = true }
        fun seg(text: Int) = com.google.android.material.button.MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            id = View.generateViewId(); this.text = getString(text)
        }
        val auto = seg(R.string.auto_marks_auto); val hand = seg(R.string.auto_marks_hand)
        group.addView(auto, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        group.addView(hand, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        group.check(if (autoOn) auto.id else hand.id)
        val label = android.widget.TextView(this).apply { textSize = 13f; setTextColor(muted); setPadding(0, (8 * d).toInt(), 0, 0); text = getString(R.string.auto_marks_sens) }
        val slider = com.google.android.material.slider.Slider(this).apply { valueFrom = 0f; valueTo = 100f; stepSize = 5f; value = sensitivity.toFloat() }
        val ends = android.widget.LinearLayout(this).apply {
            addView(android.widget.TextView(this@RestoreActivity).apply { text = getString(R.string.auto_marks_low); textSize = 12f; setTextColor(muted) },
                android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            addView(android.widget.TextView(this@RestoreActivity).apply { text = getString(R.string.auto_marks_high); textSize = 12f; setTextColor(muted) })
        }
        val missing = android.widget.TextView(this).apply { textSize = 12f; setTextColor(muted); setPadding(0, (6 * d).toInt(), 0, 0) }
        fun sync() {
            val a = group.checkedButtonId == auto.id
            label.visibility = if (a) View.VISIBLE else View.GONE
            slider.visibility = label.visibility; ends.visibility = label.visibility
            missing.visibility = if (a && !ScratchDetector.isReady(this)) View.VISIBLE else View.GONE
            missing.text = getString(R.string.auto_marks_missing)
        }
        group.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            restorePrefs.edit().putBoolean("auto_marks", id == auto.id).apply()
            sync()
            if (id == auto.id) { if (S.autoMap != null) applyAuto() else source?.let { detectDamage(it) } }
            else { if (marks === S.autoMarks) marks = null; S.overlay = null; render() }
        }
        slider.addOnChangeListener { _, v, fromUser -> if (fromUser) { restorePrefs.edit().putInt("auto_sens", v.toInt()).apply(); applyAuto() } }
        for (v in listOf(group, label, slider, ends, missing)) box.addView(v)
        sync()
        return box
    }

    // ---------- ✦ Reimaginar ----------

    private var reimOn = false
    private var reimPct = 40
    private var reimFaces = true

    /** The last, optional step: the photo redrawn by an SDXL model on the NPU (Reimagine). */
    private fun setupReimagine(prefs: android.content.SharedPreferences) {
        reimOn = prefs.getBoolean("reim_on", false)
        reimPct = prefs.getInt("reim_pct", 40)
        reimFaces = prefs.getBoolean("reim_faces", true)
        val d = resources.displayMetrics.density
        val muted = androidx.core.content.ContextCompat.getColor(this, R.color.muted)
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val sw = com.google.android.material.materialswitch.MaterialSwitch(this).apply { text = getString(R.string.reim_switch); isChecked = reimOn }
        val amount = android.widget.TextView(this).apply { textSize = 13f; setTextColor(muted); setPadding(0, (8 * d).toInt(), 0, 0) }
        val slider = com.google.android.material.slider.Slider(this).apply {
            valueFrom = 10f; valueTo = 70f; stepSize = 5f; value = reimPct.toFloat().coerceIn(10f, 70f)
        }
        val ends = android.widget.LinearLayout(this).apply {
            addView(android.widget.TextView(this@RestoreActivity).apply { text = getString(R.string.reim_faithful); textSize = 12f; setTextColor(muted) },
                android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            addView(android.widget.TextView(this@RestoreActivity).apply { text = getString(R.string.reim_new); textSize = 12f; setTextColor(muted) })
        }
        val faces = com.google.android.material.materialswitch.MaterialSwitch(this).apply { text = getString(R.string.reim_faces); isChecked = reimFaces }
        val model = android.widget.TextView(this).apply { textSize = 13f; setPadding(0, (8 * d).toInt(), 0, 0) }
        val hint = android.widget.TextView(this).apply { textSize = 12f; setTextColor(muted); setPadding(0, (6 * d).toInt(), 0, 0) }
        fun refresh() {
            amount.text = getString(R.string.reim_amount, reimPct)
            val m = Reimagine.models(this).firstOrNull()
            model.text = if (m != null) getString(R.string.reim_model, m) else getString(R.string.reim_no_model)
            sw.isEnabled = m != null
            if (m == null) sw.isChecked = false
            hint.text = getString(R.string.reim_hint)
        }
        sw.setOnCheckedChangeListener { _, on -> reimOn = on; prefs.edit().putBoolean("reim_on", on).apply(); updateUi() }
        slider.addOnChangeListener { _, v, _ -> reimPct = v.toInt(); prefs.edit().putInt("reim_pct", reimPct).apply(); refresh(); opts.refresh() }
        faces.setOnCheckedChangeListener { _, on -> reimFaces = on; prefs.edit().putBoolean("reim_faces", on).apply() }
        for (v in listOf(sw, amount, slider, ends, faces, model, hint)) box.addView(v)
        b.optHolder.addView(box)
        refresh()
        opts.add(getString(R.string.reim_title), {
            if (reimOn) getString(R.string.reim_label_on, reimPct) else getString(R.string.reim_title)
        }, listOf(box), on = { reimOn }, shown = { true }, closeOnPick = false)
    }

    private fun setStatus(s: String) {
        S.status = s
        S.ui?.let { a -> a.runOnUiThread { if (!a.isDestroyed) a.b.status.text = s } }
    }

    private fun loadImage(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = max(info.size.width, info.size.height)
                        if (long > 4096) {
                            val k = 4096f / long
                            dec.setTargetSize((info.size.width * k).roundToInt(), (info.size.height * k).roundToInt())
                        }
                    }.copy(Bitmap.Config.ARGB_8888, false)
                } catch (t: Throwable) { null }
            }
            if (bmp == null) { setStatus(getString(R.string.err_open)); return@launch }
            sourceName = try {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0).substringBeforeLast('.') else null
                } ?: "foto"
            } catch (t: Throwable) { "foto" }
            source = bmp
            result = null
            marks = null
            RestoreSession.outFile(applicationContext).delete()
            persist(bmp, RestoreSession.srcFile(applicationContext))
            getSharedPreferences("nitido", MODE_PRIVATE).edit().putString("restore_name", sourceName).apply()
            b.compare.resetView()
            render()
            S.autoMap = null; S.autoMarks = null; S.overlay = null; S.autoCount = 0
            val gray = withContext(Dispatchers.Default) { RestoreTools.isOneTone(bmp) }
            S.wasGray = gray
            S.blurRatio = withContext(Dispatchers.Default) { RestoreTools.blurRatio(bmp) }
            S.savedUri = null
            if (gray && b.optColorize.isEnabled) b.optColorize.isChecked = true
            if (simple) applySimpleDefaults()
            setStatus(getString(when {
                simple && gray -> R.string.simple_loaded_bw
                simple -> R.string.simple_loaded
                gray -> R.string.restore_loaded_bw
                else -> R.string.restore_loaded
            }))
            updateUi()
            detectDamage(bmp)
        }
    }

    private fun downloadPack(then: (() -> Unit)? = null) {
        if (BgWork.dlId == RestorePack.ID) { setStatus(getString(R.string.models_busy_dl, getString(R.string.models_pack))); return }
        cancel = false
        b.packDownload.text = getString(R.string.stop)
        val app = applicationContext
        job = BgWork.scope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    RestorePack.download(app, { cancel }) { done, total ->
                        setStatus(app.getString(R.string.restore_pack_dl, done / 1_000_000, total / 1_000_000))
                    }
                    null
                } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            }
            setStatus(when {
                err == null -> getString(R.string.restore_pack_ready)
                cancel -> getString(R.string.cancelled)
                err.contains("no encontrado") -> getString(R.string.restore_pack_missing)
                else -> getString(R.string.restore_pack_error, err)
            })
            S.ui?.render()
            if (err == null) {
                // the detector came with the pack: look at the photo now
                S.ui?.let { a -> a.source?.let { if (S.autoMap == null) a.detectDamage(it) } }
                then?.invoke()
            }
        }
    }

    /** The steps the current options will run, in order (same codes as the progress steps). */
    private fun plannedStages(): List<String> {
        val scale = when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }
        val faces = b.optFaces.isChecked && (RestorePack.file(this, RestorePack.FACES) != null || FaceRestorer.isReady(this))
        return listOfNotNull(
            "m".takeIf { marks != null && RestorePack.file(this, RestorePack.LAMA) != null }, "c".takeIf { b.optColor.isChecked },
            "n".takeIf { b.optDenoise.isChecked }, "k".takeIf { b.optColorize.isChecked }, "d".takeIf { b.optDeblur.isChecked },
            "s".takeIf { b.optDetail.isChecked && SdDetail.pickModel(this) != null },
            "p".takeIf { realOn }, "r".takeIf { reimOn && Reimagine.models(this).isNotEmpty() }, "u".takeIf { scale > 1 }, "f".takeIf { faces })
    }

    private fun workMp(scale: Int): Float {
        val s = source ?: return 0f
        val cap = when (scale) { 4 -> 1024; 2 -> 1600; else -> 2400 }
        val k = minOf(1f, cap.toFloat() / max(s.width, s.height))
        return s.width * k * s.height * k / 1e6f
    }

    /** "~2 min" for the steps ✦ Restaurar todo will run. */
    private fun simpleEta(): String? {
        if (source == null) return null
        val scale = when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }
        val stages = plannedStages().ifEmpty { return null }
        return StageTimes.format(StageTimes.estimate(this, stages, true, workMp(scale), scale))
    }

    private fun estimateText(): String? {
        if (source == null) return null
        val scale = when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }
        val stages = plannedStages()
        if (stages.isEmpty()) return null
        val gpu = b.optGpu.isChecked
        val sec = StageTimes.estimate(this, stages, gpu, workMp(scale), scale)
        val learned = stages.all { StageTimes.learned(this, it, gpu) }
        return getString(if (learned) R.string.restore_estimate else R.string.restore_estimate_first, StageTimes.format(sec))
    }

    private fun restore(confirmed: Boolean = false) {
        if (BgWork.busy) { setStatus(getString(R.string.busy_body, BgWork.currentTitle())); return }
        if (!confirmed) {
            val (level, charging) = StageTimes.battery(this)
            if (level < 30 && !charging) {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                    .setTitle(getString(R.string.battery_title, level))
                    .setMessage(getString(R.string.battery_body,
                        StageTimes.format(StageTimes.estimate(this, plannedStages(), b.optGpu.isChecked,
                            workMp(when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }),
                            when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }))))
                    .setPositiveButton(R.string.battery_go) { _, _ -> restore(true) }
                    .setNegativeButton(R.string.battery_wait, null)
                    .show()
                return
            }
        }
        val src0 = source ?: return
        val gpu = b.optGpu.isChecked
        val scale = when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }
        val doMarks = marks != null && RestorePack.file(this, RestorePack.LAMA) != null
        val doColor = b.optColor.isChecked
        val doDenoise = b.optDenoise.isChecked
        val doDeblur = b.optDeblur.isChecked
        val doColorize = b.optColorize.isChecked
        val doFaces = b.optFaces.isChecked
        val detailModel = if (b.optDetail.isChecked) SdDetail.pickModel(this) else null
        val detailStrength = b.detailAmount.value / 100f
        val useReal = realOn
        val realStrength = realPct / 100f
        val reimModel = if (reimOn) Reimagine.models(this).firstOrNull() else null
        val reimStrength = reimPct / 100f
        val reimWithFaces = reimFaces
        val sharpAmount = b.sharpAmount.value / 100f
        val fidelity = b.fidelity.value / 100f
        val codeFormer = RestorePack.file(this, RestorePack.FACES)
        val useFaces = doFaces && (codeFormer != null || FaceRestorer.isReady(this))
        var markMask = marks

        // big photos are reduced first: old prints don't hold more detail than this
        val cap = when (scale) { 4 -> 1024; 2 -> 1600; else -> 2400 }
        val long = max(src0.width, src0.height)
        var src = if (long > cap) Bitmap.createScaledBitmap(src0, src0.width * cap / long, src0.height * cap / long, true) else src0
        // the strips of scanner / table around the print go first, so they don't upset the colors
        if (b.optCrop.isChecked) {
            val r = RestoreTools.borderCrop(src)
            if (r.width() < src.width || r.height() < src.height) {
                markMask = markMask?.let { mm ->
                    val k = mm.width.toFloat() / src.width
                    Bitmap.createBitmap(mm, (r.left * k).toInt(), (r.top * k).toInt(),
                        (r.width() * k).toInt().coerceAtMost(mm.width - (r.left * k).toInt()),
                        (r.height() * k).toInt().coerceAtMost(mm.height - (r.top * k).toInt()))
                }
                src = Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height())
            }
        }
        val mp = src.width * src.height / 1e6f

        val stages = listOfNotNull(
            "m".takeIf { doMarks }, "c".takeIf { doColor }, "n".takeIf { doDenoise }, "k".takeIf { doColorize },
            "d".takeIf { doDeblur }, "s".takeIf { detailModel != null }, "p".takeIf { useReal }, "r".takeIf { reimModel != null }, "u".takeIf { scale > 1 },
            "f".takeIf { useFaces })
        if (stages.isEmpty()) { setStatus(getString(R.string.restore_nothing)); return }
        val t0 = SystemClock.elapsedRealtime()
        // measured time of each step, to make the next estimates better
        val took = HashMap<String, Long>()
        RestoreTools.engines.clear(); RestoreTools.npuNotes.clear()
        RestoreTools.npuMode = when (procMode) { "npu" -> RestoreTools.NpuMode.ALWAYS; "auto" -> RestoreTools.NpuMode.AUTO; else -> RestoreTools.NpuMode.OFF }
        val stageNames = mapOf("m" to "Rayones", "c" to "Color", "n" to "Grano", "k" to "Colorear", "d" to "Desenfoque",
            "s" to "Detalle IA", "p" to "Realismo", "r" to "Reimaginar", "u" to "Escala ×$scale", "f" to "Caras")
        // expected seconds of each step on this phone (learned), for the time left
        val expect = stages.associateWith { st ->
            StageTimes.perMp(applicationContext, st, gpu) * (if (st == "f") mp * scale * scale else mp)
        }
        var curStage: String? = null
        var curSince = 0L
        fun report(stage: String, p: Float, label: String, piece: String? = null) {
            if (stage != curStage) {
                val now = SystemClock.elapsedRealtime()
                curStage?.let { took[it] = (took[it] ?: 0L) + (now - curSince)
                    JobLog.add("Paso ${stageNames[it] ?: it} terminado en ${"%.1f".format(java.util.Locale.US, (now - curSince) / 1000f)} s") }
                JobLog.add("Paso ${stageNames[stage] ?: stage} empieza")
                curStage = stage; curSince = now
            }
            val idx = stages.indexOf(stage)
            val total = (idx + p) / stages.size
            BgWork.update(applicationContext, label, (total * 100).roundToInt())
            S.progress = (total * 1000).roundToInt()
            S.status = label
            S.stepName = label.trimEnd('…', '.'); S.stepIdx = idx; S.stepCount = stages.size
            S.stepFrac = p; S.totalFrac = total; S.piece = piece
            // time left = rest of this step + the steps after it, scaled by how this run compares
            // with what was expected so far
            val now = SystemClock.elapsedRealtime()
            val doneExpected = stages.take(idx).sumOf { (expect[it] ?: 0f).toDouble() }.toFloat() + p * (expect[stage] ?: 0f)
            val ratio = if (doneExpected > 20f) ((now - t0) / 1000f / doneExpected).coerceIn(0.3f, 3f) else 1f
            val left = ((1 - p) * (expect[stage] ?: 0f) + stages.drop(idx + 1).sumOf { (expect[it] ?: 0f).toDouble() }.toFloat()) * ratio
            S.etaSec = left
            S.ui?.proc?.update(S.stepName, idx, stages.size, p, total, piece, left)
        }
        fun Upscaler.live(): Upscaler { onTile = { bmp -> S.ui?.livePreview(bmp) }; return this }

        cancel = false
        S.busy = true
        S.progress = 0
        S.t0 = SystemClock.elapsedRealtime()
        S.live = src
        S.stepName = ""; S.stepFrac = 0f; S.totalFrac = 0f; S.piece = null
        S.etaSec = StageTimes.estimate(applicationContext, stages, gpu, mp, scale)
        JobLog.add("Foto ${src.width}×${src.height} · pasos: ${stages.joinToString(", ") { stageNames[it] ?: it }} · procesador elegido: $procMode")
        JobLog.add("Paquete: " + (SdModel.dir(applicationContext, RestorePack.ID).listFiles()?.filter { it.isFile }?.sortedBy { it.name }
            ?.joinToString(", ") { "${it.name} ${ModelCatalog.mb(it.length())}" } ?: "no instalado"))
        render()
        BgWork.start(this, getString(R.string.notif_restoring), RestoreActivity::class.java) {
            cancel = true
            if (SdNative.loadError == null) SdNative.cancel()
        }
        JobLog.add(String.format(java.util.Locale.US, "Foto %d×%d · nitidez %.2f (menos de 0.35 = muy borrosa) · Desenfoque %s",
            src0.width, src0.height, S.blurRatio, if (b.optDeblur.isChecked) "sí" else "no"))
        val appCtx = applicationContext
        job = BgWork.scope.launch {
            var facesFound = -1
            var error: String? = null
            // the photo as it was after the last finished step: kept if the job stops or fails later
            var partial: Bitmap? = null
            var partialStep = ""
            fun keep(b: Bitmap) { partial = b; partialStep = curStage?.let { stageNames[it] } ?: ""; S.ui?.livePreview(b, true) }
            val out = withContext(aiThread) {
                try {
                    var img: Bitmap = src
                    if (doMarks) {
                        val label = appCtx.getString(R.string.step_marks)
                        report("m", 0f, label)
                        img = RestoreTools.removeMarks(applicationContext, RestorePack.file(applicationContext, RestorePack.LAMA)!!,
                            img, markMask!!, gpu, { p -> report("m", p, label) }, { cancel }) ?: return@withContext null
                    }
                    if (doColor) {
                        report("c", 0f, appCtx.getString(R.string.step_color))
                        img = RestoreTools.fixColor(img, saturate = !doColorize,
                            gentle = doColorize || RestoreTools.isOneTone(img) || RestoreTools.isSepia(img))
                        keep(img)
                    }
                    if (doDenoise) {
                        val label = appCtx.getString(R.string.step_denoise)
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU,
                            RestorePack.file(applicationContext, RestorePack.DENOISE)!!.absolutePath, pad = 32, precise = true, tryFast = true).live().use { d ->
                            img = d.upscale(img, 1, { p -> report("n", p, label) }, { cancel }) ?: return@withContext null
                            RestoreTools.engines["denoise"] = d.engine.label
                        }
                        keep(img)
                    }
                    if (doColorize) {
                        report("k", 0f, appCtx.getString(R.string.step_colorize))
                        img = RestoreTools.colorize(applicationContext, RestorePack.file(applicationContext, RestorePack.COLOR)!!, img, gpu)
                        keep(img)
                    }
                    // Faces are later restored from this clean version (grain removed, colors fixed),
                    // not from the sharpened one: sharpening turns blurry skin into blotches.
                    val faceSource = img
                    if (doDeblur) {
                        val label = appCtx.getString(R.string.step_deblur)
                        val before = img
                        // Restormer (trained on out-of-focus photos) when the pack has it, else NAFNet
                        val restormer = RestorePack.file(applicationContext, RestorePack.DEBLUR)
                        val deblur = if (restormer != null)
                            Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, restormer.absolutePath, pad = 32, precise = true, tryFast = true)
                        else Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, Upscaler.MODEL_DEBLUR, pad = 24)
                        deblur.live().use { d ->
                            img = d.upscale(img, 1, { p -> report("d", p, label) }, { cancel }) ?: return@withContext null
                            RestoreTools.engines["deblur"] = d.engine.label
                        }
                        if (sharpAmount < 0.99f) img = RestoreTools.mix(before, img, sharpAmount)
                        keep(img)
                    }
                    if (detailModel != null) {
                        img = SdDetail.redraw(applicationContext, img, detailModel, detailStrength, gpu,
                            { i, n -> report("s", if (n == 0) 1f else i.toFloat() / n, appCtx.getString(R.string.step_detail_short), appCtx.getString(R.string.proc_piece, minOf(i + 1, n), n)) },
                            { cancel }) ?: return@withContext null
                        keep(img)
                    }
                    if (useReal) {
                        if (!Realism.isReady(appCtx)) {
                            JobLog.add("Descargando el paquete Realismo (una sola vez)")
                            Realism.download(appCtx, { cancel }) { got, total ->
                                report("p", 0f, appCtx.getString(R.string.real_downloading, if (total > 0) (got * 100 / total).toInt() else 0))
                            }
                        }
                        if (Realism.isReady(appCtx)) {
                            img = Realism.run(applicationContext, img, realStrength, { cancel }) { i, n ->
                                report("p", i.toFloat() / n, appCtx.getString(R.string.real_step), appCtx.getString(R.string.proc_piece, i, n))
                            } ?: if (cancel) return@withContext null else img.also { JobLog.notice("Realismo no pudo terminar; sigue sin ese paso") }
                            keep(img)
                        } else if (!cancel) JobLog.notice("Realismo: no se pudo descargar el paquete; sigue sin ese paso")
                    }
                    if (reimModel != null) {
                        // before enlarging: SDXL works at about 1 MP; the enlargement keeps its detail
                        img = Reimagine.run(applicationContext, img, reimModel, reimStrength, reimWithFaces, { cancel }) { txt, f ->
                            report("r", f, txt)
                        } ?: if (cancel) return@withContext null else img.also { JobLog.notice("Reimaginar no pudo terminar; queda la foto restaurada") }
                        keep(img)
                    }
                    if (scale > 1) {
                        val label = appCtx.getString(R.string.step_upscale)
                        val model = if (MnnTile.hasAsset(applicationContext, Upscaler.MODEL_SIAX)) Upscaler.MODEL_SIAX else Upscaler.MODEL_X4PLUS
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, model).live().use { u ->
                            img = u.upscale(img, scale, { p -> report("u", p, label) }, { cancel }) ?: return@withContext null
                        }
                        keep(img)
                    }
                    if (useFaces) {
                        if (!img.isMutable || img === src) img = img.copy(Bitmap.Config.ARGB_8888, true)
                        FaceRestorer(applicationContext, gpu, codeFormer, fidelity).use { fr ->
                            facesFound = fr.restoreAll(img, { i, n ->
                                report("f", if (n == 0) 1f else i.toFloat() / n, appCtx.getString(R.string.step_faces, minOf(i + 1, n), n))
                            }, { cancel }, from = faceSource)
                            if (codeFormer != null) RestoreTools.engines["faces"] = fr.engineLabel
                        }
                    }
                    img
                } catch (t: OutOfMemoryError) {
                    JobLog.error("Restaurar sin memoria", t)
                    error = "memoria insuficiente"; null
                } catch (t: Throwable) {
                    android.util.Log.e("Nitido", "restore failed", t)
                    JobLog.error("Restaurar falló", t)
                    error = t.message ?: t.javaClass.simpleName; null
                }
            }
            S.busy = false
            BgWork.finish(appCtx, when {
                out != null -> appCtx.getString(R.string.notif_done_image)
                cancel -> null
                else -> appCtx.getString(R.string.notif_failed)
            })
            if (out == null) {
                S.status = if (cancel) appCtx.getString(R.string.cancelled) else appCtx.getString(R.string.restore_failed, error ?: "?")
                if (cancel) JobLog.add(S.status) else JobLog.error(S.status)
                // what was already done is not thrown away: it becomes the result, ready to save
                val got = partial
                if (got != null && got !== src) {
                    result = got
                    persist(got, RestoreSession.outFile(appCtx))
                    if (Prefs.autosave(appCtx)) S.savedUri = withContext(Dispatchers.IO) {
                        Gallery.saveImage(appCtx, got, "${sourceName}_restaurada_${System.currentTimeMillis() / 1000}")
                    }
                    S.status = appCtx.getString(if (cancel) R.string.partial_stopped else R.string.partial_failed, partialStep) +
                        (if (S.savedUri != null) " " + appCtx.getString(R.string.simple_saved_auto) else "")
                    JobLog.notice("Se conserva lo hecho hasta «$partialStep» (${got.width}×${got.height})")
                }
                JobLog.save(appCtx)
                S.ui?.render()
                if (!cancel) S.ui?.let { a ->
                    S.tries++
                    if (S.tries < 2 && !a.isFinishing) {
                        // one automatic retry, on the GPU (the NPU is the usual reason a step fails)
                        JobLog.notice("Reintento automático en la GPU")
                        if (a.procMode != "cpu") a.procMode = "gpu"
                        a.restore(true)
                    } else Ui.failed(a, S.tries) { S.tries = 0; a.restore(true) }
                }
                return@launch
            }
            result = out
            S.tries = 0
            persist(out, RestoreSession.outFile(appCtx))
            if (Prefs.autosave(appCtx)) {
                val name = "${sourceName}_restaurada_${System.currentTimeMillis() / 1000}"
                S.savedUri = withContext(Dispatchers.IO) { Gallery.saveImage(appCtx, out, name) }
            }
            curStage?.let { took[it] = (took[it] ?: 0L) + (SystemClock.elapsedRealtime() - curSince)
                JobLog.add("Paso ${stageNames[it] ?: it} terminado en ${"%.1f".format(java.util.Locale.US, (SystemClock.elapsedRealtime() - curSince) / 1000f)} s") }
            for ((st, ms) in took) StageTimes.record(appCtx, st, gpu, ms / 1000f, mp)
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            val notes = mutableListOf(appCtx.getString(R.string.restore_done, secs, out.width, out.height))
            if (facesFound == 0) notes += appCtx.getString(R.string.faces_none)
            if (facesFound > 0) notes += appCtx.getString(R.string.faces_done, facesFound)
            if (doFaces && !useFaces) notes += appCtx.getString(R.string.restore_no_face_model)
            val names = linkedMapOf("marks" to R.string.step_name_marks, "denoise" to R.string.step_name_denoise,
                "color" to R.string.step_name_colorize, "deblur" to R.string.step_name_deblur, "faces" to R.string.step_name_faces)
            val eng = names.mapNotNull { (k, r) -> RestoreTools.engines[k]?.let { appCtx.getString(r) + ": " + it } }
            if (eng.isNotEmpty()) notes += "· " + eng.joinToString(" · ")
            for ((k, why) in RestoreTools.npuNotes) names[k]?.let {
                // the detail goes to the log; the message gets a short line
                JobLog.notice(appCtx.getString(R.string.restore_npu_note, appCtx.getString(it), why.take(400)))
                val short = when {
                    "actualiza" in why -> R.string.npu_short_missing
                    "lenta" in why -> R.string.npu_short_slow
                    "no cuadró" in why -> R.string.npu_short_redone
                    "distinta" in why || "fuera" in why -> R.string.npu_short_bad
                    else -> R.string.npu_short_failed
                }
                notes += "\n" + appCtx.getString(it) + ": " + appCtx.getString(short)
            }
            JobLog.add(notes.joinToString(" ")); JobLog.save(appCtx)
            // the simple screen gets the short version (the processors used are in the log)
            S.status = if (Prefs.advanced(appCtx)) notes.joinToString(" ")
                else listOfNotNull(appCtx.getString(R.string.simple_done, secs),
                    appCtx.getString(R.string.faces_done, facesFound).takeIf { facesFound > 0 },
                    appCtx.getString(R.string.simple_saved_auto).takeIf { S.savedUri != null }).joinToString(" · ")
            S.ui?.render()
        }
    }

    private fun save() {
        val res = result ?: return
        val adj = S.adjust
        if (S.savedUri != null && adj.isNeutral) { setStatus(getString(R.string.simple_saved_auto)); return }
        b.save.isEnabled = false
        if (::saveBtn.isInitialized) saveBtn.isEnabled = false
        val app = applicationContext
        lifecycleScope.launch {
            val uri = withContext(Dispatchers.IO) {
                // the touches are applied to the full-size picture only when saving
                val bmp = if (adj.isNeutral) res else PhotoAdjust.apply(res, adj) ?: res
                Gallery.saveImage(app, bmp, "${sourceName}_restaurada_${System.currentTimeMillis() / 1000}", S.savedUri)
            }
            if (uri != null && adj.isNeutral) S.savedUri = uri
            b.save.isEnabled = true
            if (::saveBtn.isInitialized) saveBtn.isEnabled = true
            setStatus(getString(if (uri != null) R.string.saved else R.string.err_save))
            render()
        }
    }
}
