package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityRestoreBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * "Restaurar foto antigua": one button that runs, in order,
 * scratches → color → grain → blur → colorize → enlarge → faces. All on the phone.
 */
/**
 * Everything the Restore screen is working on lives here, outside the screen, so rotating the
 * phone, turning the screen off or switching apps doesn't lose the photo or stop the work.
 * The photo and the result are also written to the app's cache, in case Android closes the app.
 */
object RestoreSession {
    var source: Bitmap? = null
    var result: Bitmap? = null
    var marks: Bitmap? = null
    var sourceName = "foto"
    var job: Job? = null
    @Volatile var cancel = false
    var busy = false
    var status = ""
    var progress = 0
    var ui: RestoreActivity? = null
    val aiThread = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    fun srcFile(ctx: android.content.Context) = java.io.File(ctx.cacheDir, "restore_src.jpg")
    fun outFile(ctx: android.content.Context) = java.io.File(ctx.cacheDir, "restore_out.jpg")
}

class RestoreActivity : AppCompatActivity() {

    lateinit var b: ActivityRestoreBinding
    private val S = RestoreSession
    private val aiThread get() = S.aiThread
    private var source: Bitmap? get() = S.source; set(v) { S.source = v }
    private var result: Bitmap? get() = S.result; set(v) { S.result = v }
    private var marks: Bitmap? get() = S.marks; set(v) { S.marks = v }
    private var sourceName: String get() = S.sourceName; set(v) { S.sourceName = v }
    private var job: Job? get() = S.job; set(v) { S.job = v }
    private var cancel: Boolean get() = S.cancel; set(v) { S.cancel = v }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }

    private val maskLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) { marks = MaskHolder.mask; updateUi() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRestoreBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.back.setOnClickListener { finish() }
        b.pick.setOnClickListener { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        b.go.setOnClickListener { if (job?.isActive == true) { cancel = true } else restore() }
        b.save.setOnClickListener { save() }
        b.packDownload.setOnClickListener { if (job?.isActive == true) cancel = true else downloadPack() }
        b.marks.setOnClickListener {
            val photo = source ?: return@setOnClickListener
            MaskHolder.photo = photo
            MaskHolder.mask = marks
            maskLauncher.launch(Intent(this, MaskActivity::class.java))
        }
        b.marksClear.setOnClickListener { marks = null; updateUi() }
        b.optFaces.setOnCheckedChangeListener { _, _ -> updateUi() }
        b.fidelityValue.text = "${b.fidelity.value.roundToInt()}%"
        b.fidelity.addOnChangeListener { _, v, _ -> b.fidelityValue.text = "${v.roundToInt()}%" }
        S.ui = this
        if (source == null) reloadFromDisk() else render()
    }

    override fun onDestroy() {
        if (S.ui === this) S.ui = null
        super.onDestroy()
    }

    /** Shows whatever the session holds: photo, result, progress, messages. */
    fun render() {
        b.compare.before = source
        b.compare.after = result
        b.status.text = S.status
        b.go.text = getString(if (S.busy) R.string.stop else R.string.restore_go)
        b.go.isEnabled = source != null
        b.progress.visibility = if (S.busy) View.VISIBLE else View.INVISIBLE
        b.progress.progress = S.progress
        b.pick.isEnabled = !S.busy
        b.save.isEnabled = !S.busy && result != null
        b.packDownload.isEnabled = !S.busy
        if (S.busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        updateUi()
        if (S.busy) b.marks.isEnabled = false
    }

    private fun reloadFromDisk() {
        render()
        val app = applicationContext
        lifecycleScope.launch {
            val (src, out) = withContext(Dispatchers.IO) {
                fun read(f: java.io.File) = if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.path) else null
                read(RestoreSession.srcFile(app)) to read(RestoreSession.outFile(app))
            }
            if (src == null || source != null) return@launch
            source = src
            result = out
            sourceName = getSharedPreferences("nitido", MODE_PRIVATE).getString("restore_name", "foto") ?: "foto"
            render()
        }
    }

    /** Remembers the photo (or result) on disk, in the background. */
    private fun persist(bmp: Bitmap, file: java.io.File) {
        BgWork.scope.launch(Dispatchers.IO) {
            try {
                val tmp = java.io.File(file.path + ".tmp")
                tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                tmp.renameTo(file)
            } catch (_: Throwable) { }
        }
    }

    private fun updateUi() {
        val ready = RestorePack.isReady(this)
        fun has(n: String) = RestorePack.file(this, n) != null
        val partial = ready && listOf(RestorePack.DENOISE, RestorePack.FACES, RestorePack.LAMA, RestorePack.COLOR).any { !has(it) }
        b.packCard.visibility = if (!ready || partial) View.VISIBLE else View.GONE
        b.packInfo.text = getString(if (partial) R.string.restore_pack_partial else R.string.restore_pack_info)
        if (job?.isActive != true) b.packDownload.text = getString(if (partial) R.string.restore_pack_update else R.string.restore_pack_download)
        b.optDenoise.isEnabled = has(RestorePack.DENOISE)
        if (!has(RestorePack.DENOISE)) b.optDenoise.isChecked = false
        b.optColorize.isEnabled = has(RestorePack.COLOR)
        if (!has(RestorePack.COLOR)) b.optColorize.isChecked = false
        b.marks.isEnabled = source != null && has(RestorePack.LAMA)
        b.marks.text = getString(if (marks != null) R.string.restore_marks_edit else R.string.restore_marks)
        b.marksClear.visibility = if (marks != null) View.VISIBLE else View.GONE
        val faceModel = has(RestorePack.FACES)
        b.fidelityRow.visibility = if (b.optFaces.isChecked && faceModel) View.VISIBLE else View.GONE
    }

    private fun setStatus(s: String) {
        S.status = s
        S.ui?.let { a -> a.runOnUiThread { if (!a.isDestroyed) a.b.status.text = s } }
    }

    private fun loadImage(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = max(info.size.width, info.size.height)
                        if (long > 4096) {
                            val k = 4096f / long
                            dec.setTargetSize((info.size.width * k).roundToInt(), (info.size.height * k).roundToInt())
                        }
                    }.copy(Bitmap.Config.ARGB_8888, false)
                } catch (t: Throwable) { null }
            }
            if (bmp == null) { setStatus(getString(R.string.err_open)); return@launch }
            sourceName = try {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0).substringBeforeLast('.') else null
                } ?: "foto"
            } catch (t: Throwable) { "foto" }
            source = bmp
            result = null
            marks = null
            RestoreSession.outFile(applicationContext).delete()
            persist(bmp, RestoreSession.srcFile(applicationContext))
            getSharedPreferences("nitido", MODE_PRIVATE).edit().putString("restore_name", sourceName).apply()
            b.compare.resetView()
            render()
            val gray = withContext(Dispatchers.Default) { RestoreTools.isGrayscale(bmp) }
            if (gray && b.optColorize.isEnabled) b.optColorize.isChecked = true
            setStatus(getString(if (gray) R.string.restore_loaded_bw else R.string.restore_loaded))
            updateUi()
        }
    }

    private fun downloadPack() {
        cancel = false
        b.packDownload.text = getString(R.string.stop)
        val app = applicationContext
        job = BgWork.scope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    RestorePack.download(app, { cancel }) { done, total ->
                        setStatus(app.getString(R.string.restore_pack_dl, done / 1_000_000, total / 1_000_000))
                    }
                    null
                } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            }
            setStatus(when {
                err == null -> getString(R.string.restore_pack_ready)
                cancel -> getString(R.string.cancelled)
                err.contains("no encontrado") -> getString(R.string.restore_pack_missing)
                else -> getString(R.string.restore_pack_error, err)
            })
            S.ui?.render()
        }
    }

    private fun restore() {
        if (BgWork.busy) { setStatus(getString(R.string.busy_body, BgWork.currentTitle())); return }
        val src0 = source ?: return
        val gpu = b.optGpu.isChecked
        val scale = when (b.scaleGroup.checkedButtonId) { R.id.rScale1 -> 1; R.id.rScale4 -> 4; else -> 2 }
        val doMarks = marks != null && RestorePack.file(this, RestorePack.LAMA) != null
        val doColor = b.optColor.isChecked
        val doDenoise = b.optDenoise.isChecked
        val doDeblur = b.optDeblur.isChecked
        val doColorize = b.optColorize.isChecked
        val doFaces = b.optFaces.isChecked
        val fidelity = b.fidelity.value / 100f
        val codeFormer = RestorePack.file(this, RestorePack.FACES)
        val useFaces = doFaces && (codeFormer != null || FaceRestorer.isReady(this))
        val markMask = marks

        // big photos are reduced first: old prints don't hold more detail than this
        val cap = when (scale) { 4 -> 1024; 2 -> 1600; else -> 2400 }
        val long = max(src0.width, src0.height)
        val src = if (long > cap) Bitmap.createScaledBitmap(src0, src0.width * cap / long, src0.height * cap / long, true) else src0

        val stages = listOfNotNull(
            "m".takeIf { doMarks }, "c".takeIf { doColor }, "n".takeIf { doDenoise }, "d".takeIf { doDeblur },
            "k".takeIf { doColorize }, "u".takeIf { scale > 1 }, "f".takeIf { useFaces })
        if (stages.isEmpty()) { setStatus(getString(R.string.restore_nothing)); return }
        val t0 = SystemClock.elapsedRealtime()
        fun report(stage: String, p: Float, label: String) {
            val total = (stages.indexOf(stage) + p) / stages.size
            BgWork.update(applicationContext, label, (total * 100).roundToInt())
            S.progress = (total * 1000).roundToInt()
            S.status = label
            S.ui?.let { a -> a.runOnUiThread { if (!a.isDestroyed) { a.b.progress.progress = S.progress; a.b.status.text = label } } }
        }

        cancel = false
        S.busy = true
        S.progress = 0
        render()
        BgWork.start(this, getString(R.string.notif_restoring), RestoreActivity::class.java) { cancel = true }
        val appCtx = applicationContext
        job = BgWork.scope.launch {
            var facesFound = -1
            var error: String? = null
            val out = withContext(aiThread) {
                try {
                    var img: Bitmap = src
                    if (doMarks) {
                        val label = appCtx.getString(R.string.step_marks)
                        report("m", 0f, label)
                        img = RestoreTools.removeMarks(applicationContext, RestorePack.file(applicationContext, RestorePack.LAMA)!!,
                            img, markMask!!, gpu, { p -> report("m", p, label) }, { cancel }) ?: return@withContext null
                    }
                    if (doColor) {
                        report("c", 0f, appCtx.getString(R.string.step_color))
                        img = RestoreTools.fixColor(img, saturate = !doColorize)
                    }
                    if (doDenoise) {
                        val label = appCtx.getString(R.string.step_denoise)
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU,
                            RestorePack.file(applicationContext, RestorePack.DENOISE)!!.absolutePath, pad = 32, precise = true).use { d ->
                            img = d.upscale(img, 1, { p -> report("n", p, label) }, { cancel }) ?: return@withContext null
                        }
                    }
                    if (doDeblur) {
                        val label = appCtx.getString(R.string.step_deblur)
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, Upscaler.MODEL_DEBLUR, pad = 24).use { d ->
                            img = d.upscale(img, 1, { p -> report("d", p, label) }, { cancel }) ?: return@withContext null
                        }
                    }
                    if (doColorize) {
                        report("k", 0f, appCtx.getString(R.string.step_colorize))
                        img = RestoreTools.colorize(applicationContext, RestorePack.file(applicationContext, RestorePack.COLOR)!!, img, gpu)
                    }
                    if (scale > 1) {
                        val label = appCtx.getString(R.string.step_upscale)
                        val model = if (MnnTile.hasAsset(applicationContext, Upscaler.MODEL_SIAX)) Upscaler.MODEL_SIAX else Upscaler.MODEL_X4PLUS
                        Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU, model).use { u ->
                            img = u.upscale(img, scale, { p -> report("u", p, label) }, { cancel }) ?: return@withContext null
                        }
                    }
                    if (useFaces) {
                        if (!img.isMutable || img === src) img = img.copy(Bitmap.Config.ARGB_8888, true)
                        FaceRestorer(applicationContext, gpu, codeFormer, fidelity).use { fr ->
                            facesFound = fr.restoreAll(img, { i, n ->
                                report("f", if (n == 0) 1f else i.toFloat() / n, appCtx.getString(R.string.step_faces, minOf(i + 1, n), n))
                            }, { cancel })
                        }
                    }
                    img
                } catch (t: OutOfMemoryError) {
                    error = "memoria insuficiente"; null
                } catch (t: Throwable) {
                    android.util.Log.e("Nitido", "restore failed", t)
                    error = t.message ?: t.javaClass.simpleName; null
                }
            }
            S.busy = false
            BgWork.finish(appCtx, when {
                out != null -> appCtx.getString(R.string.notif_done_image)
                cancel -> null
                else -> appCtx.getString(R.string.notif_failed)
            })
            if (out == null) {
                S.status = if (cancel) appCtx.getString(R.string.cancelled) else appCtx.getString(R.string.restore_failed, error ?: "?")
                S.ui?.render()
                return@launch
            }
            result = out
            persist(out, RestoreSession.outFile(appCtx))
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            val notes = mutableListOf(appCtx.getString(R.string.restore_done, secs, out.width, out.height))
            if (facesFound == 0) notes += appCtx.getString(R.string.faces_none)
            if (facesFound > 0) notes += appCtx.getString(R.string.faces_done, facesFound)
            if (doFaces && !useFaces) notes += appCtx.getString(R.string.restore_no_face_model)
            S.status = notes.joinToString(" ")
            S.ui?.render()
        }
    }

    private fun save() {
        val bmp = result ?: return
        b.save.isEnabled = false
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "${sourceName}_restaurada_${System.currentTimeMillis() / 1000}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    true
                } catch (t: Throwable) { false }
            }
            b.save.isEnabled = true
            setStatus(getString(if (ok) R.string.saved else R.string.err_save))
        }
    }
}
