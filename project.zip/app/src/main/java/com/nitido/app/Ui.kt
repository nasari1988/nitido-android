package com.nitido.app

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * The simple app: one big button per tool, the app decides the technical parts. These are the
 * user's few choices (Ajustes) and the small pieces every screen shares (chips, the download
 * notice, the "no se pudo terminar" notice).
 */
object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE)

    /** Ajustes › Modo avanzado: the old controls (every option) instead of one button. */
    fun advanced(ctx: Context) = p(ctx).getBoolean("advanced", false)
    fun setAdvanced(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("advanced", on).apply()

    /** Ajustes › Calidad: "fast", "balanced" (default) or "max". */
    fun quality(ctx: Context) = p(ctx).getString("quality", "balanced") ?: "balanced"
    fun setQuality(ctx: Context, q: String) = p(ctx).edit().putString("quality", q).apply()

    /** Results go to the gallery (album Nítido) by themselves when a job ends. */
    fun autosave(ctx: Context) = p(ctx).getBoolean("autosave", true)
    fun setAutosave(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("autosave", on).apply()

    /** Mis resultados asks for the fingerprint (or the phone's PIN). */
    fun lockResults(ctx: Context) = p(ctx).getBoolean("lock_results", false)
    fun setLockResults(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("lock_results", on).apply()

    /** A notification when a job ends. */
    fun notifyDone(ctx: Context) = p(ctx).getBoolean("notify_done", true)
    fun setNotifyDone(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("notify_done", on).apply()

    /** The welcome screen was seen. */
    fun welcomed(ctx: Context) = p(ctx).getBoolean("welcomed", false)
    fun setWelcomed(ctx: Context) = p(ctx).edit().putBoolean("welcomed", true).apply()
}

object Ui {
    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    fun color(ctx: Context, id: Int) = ContextCompat.getColor(ctx, id)

    fun text(ctx: Context, s: CharSequence, size: Float, colorId: Int = R.color.fg, bold: Boolean = false) = TextView(ctx).apply {
        text = s; textSize = size; setTextColor(color(ctx, colorId))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun round(ctx: Context, fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(ctx, radiusDp).toFloat()
        if (stroke != null) setStroke(dp(ctx, 1), stroke)
    }

    /** A small rounded label that can be tapped; [selected] paints it with the accent. */
    fun chip(ctx: Context, s: String, selected: Boolean = false, onClick: (() -> Unit)? = null) = TextView(ctx).apply {
        text = s; textSize = 13f; gravity = Gravity.CENTER
        setPadding(dp(ctx, 12), dp(ctx, 7), dp(ctx, 12), dp(ctx, 7))
        setChip(this, selected)
        if (onClick != null) setOnClickListener { onClick() }
    }

    fun setChip(v: TextView, selected: Boolean) {
        val ctx = v.context
        v.isSelected = selected
        v.setTextColor(color(ctx, if (selected) R.color.on_accent else R.color.fg2))
        v.background = round(ctx, color(ctx, if (selected) R.color.accent else R.color.chip), 16, color(ctx, if (selected) R.color.accent else R.color.line_hi))
    }

    /** The one big button of a screen (cream, like the rest of the app's main buttons). */
    fun bigButton(ctx: Context, s: String, onClick: () -> Unit) = MaterialButton(ctx).apply {
        text = s; textSize = 17f; isAllCaps = false
        minHeight = dp(ctx, 56)
        cornerRadius = dp(ctx, 14)
        backgroundTintList = ColorStateList.valueOf(color(ctx, R.color.cta))
        setTextColor(color(ctx, R.color.on_cta))
        setOnClickListener { onClick() }
    }

    fun outlineButton(ctx: Context, s: String, onClick: () -> Unit) =
        MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = s; textSize = 14f; isAllCaps = false; cornerRadius = dp(ctx, 12)
            setOnClickListener { onClick() }
        }

    /** A row of chips that wraps to the next line when they don't fit. */
    fun chipRow(ctx: Context) = com.google.android.material.chip.ChipGroup(ctx).apply {
        chipSpacingHorizontal = dp(ctx, 6); chipSpacingVertical = dp(ctx, 6)
    }

    fun row(ctx: Context) = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    fun lp(ctx: Context, top: Int = 0, w: Int = LinearLayout.LayoutParams.MATCH_PARENT) =
        LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(ctx, top) }

    fun onWifi(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    } catch (t: Throwable) { false }

    /**
     * "Falta un paquete": what is missing, its size, whether the phone is on Wi-Fi, and two
     * buttons. [what] is the feature in plain words ("Textura real", "Restaurar foto").
     */
    fun askDownload(a: Activity, what: String, sizeText: String, onYes: () -> Unit, onNo: () -> Unit = {}) {
        val wifi = onWifi(a)
        val msg = a.getString(R.string.dl_ask_body, what, sizeText) + "\n\n" +
            a.getString(if (wifi) R.string.dl_ask_wifi else R.string.dl_ask_data)
        MaterialAlertDialogBuilder(a)
            .setTitle(R.string.dl_ask_title)
            .setMessage(msg)
            .setPositiveButton(R.string.dl_ask_yes) { _, _ -> onYes() }
            .setNegativeButton(R.string.dl_ask_no) { _, _ -> onNo() }
            .setOnCancelListener { onNo() }
            .show()
    }

    /**
     * "No se pudo terminar": the original is safe, try again, or send the report (the log, no
     * photos) by any app (mail, chat…).
     */
    fun failed(a: Activity, tries: Int, onRetry: () -> Unit) {
        if (a.isFinishing || a.isDestroyed) return
        MaterialAlertDialogBuilder(a)
            .setTitle(R.string.fail_title)
            .setMessage(a.getString(R.string.fail_body, tries) + "\n\n" + a.getString(R.string.fail_no_photos))
            .setPositiveButton(R.string.fail_retry) { _, _ -> onRetry() }
            .setNegativeButton(R.string.fail_report) { _, _ -> sendReport(a) }
            .setNeutralButton(R.string.close, null)
            .show()
    }

    /** The log of the last job, shared as text (it has no pictures). */
    fun sendReport(a: Activity) {
        val t = LogDialog.text(a)
        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, a.getString(R.string.report_subject))
            putExtra(android.content.Intent.EXTRA_TEXT, t)
        }
        try { a.startActivity(android.content.Intent.createChooser(send, a.getString(R.string.report_choose))) }
        catch (e: Throwable) { LogDialog.show(a) }
    }

    fun gone(v: View?, gone: Boolean) { v?.visibility = if (gone) View.GONE else View.VISIBLE }
}
