package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import java.io.File
import java.util.Locale

/**
 * ✦ Realismo (Restaurar): PiSA-SR (Stable Diffusion 2.1 + its restoration LoRAs, one step) on the
 * NPU, in 512×512 pieces that overlap: each piece's latent minus [strength] × the UNet's prediction,
 * decoded. Gives a cleaned photo back real texture (skin, hair, cloth) while staying faithful to it.
 * Colors are matched back to the input (the authors' AdaIN fix). Pack "realismo".
 */
object Realism {
    const val PACK = "realismo"
    private const val T = 512
    private const val L = 64
    private const val OVER = 64

    fun isReady(ctx: Context) = SdModel.isReady(ctx, PACK) &&
        listOf("pisa_enc", "pisa_unet", "pisa_dec").all { File(SdModel.dir(ctx, PACK), "${it}_ctx.onnx").exists() }

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
        SdModel.download(ctx, PACK, cancelled, onProgress)

    /**
     * [strength] 0.5..1.3 (1 = the authors' default). Pieces at the photo's size (a big photo has
     * many). Null when cancelled or the NPU can't run it.
     */
    fun run(ctx: Context, src: Bitmap, strength: Float, cancelled: () -> Boolean, progress: (Int, Int) -> Unit): Bitmap? {
        val dir = SdModel.dir(ctx, PACK)
        val t0 = SystemClock.elapsedRealtime()
        val enc = NpuTile.openPrecompiled(ctx, File(dir, "pisa_enc_ctx.onnx"), "pisa_enc") ?: return fail("codificador")
        val unet = NpuTile.openPrecompiled(ctx, File(dir, "pisa_unet_ctx.onnx"), "pisa_unet") ?: run { enc.close(); return fail("UNet") }
        val dec = NpuTile.openPrecompiled(ctx, File(dir, "pisa_dec_ctx.onnx"), "pisa_dec") ?: run { enc.close(); unet.close(); return fail("decodificador") }
        JobLog.add("Realismo (PiSA-SR) abierto en la NPU en ${SystemClock.elapsedRealtime() - t0} ms · intensidad ${(strength * 100).toInt()} %")
        try {
            val w = src.width; val h = src.height
            // a photo smaller than a piece is enlarged to it (and back at the end)
            val k = maxOf(1f, T.toFloat() / minOf(w, h))
            val img = if (k > 1f) Bitmap.createScaledBitmap(src, (w * k).toInt().coerceAtLeast(T), (h * k).toInt().coerceAtLeast(T), true) else src
            val W = img.width; val H = img.height
            fun starts(len: Int): List<Int> {
                if (len <= T) return listOf(0)
                val n = (len - OVER + (T - OVER) - 1) / (T - OVER)
                return (0 until n).map { i -> Math.round(i.toDouble() * (len - T) / (n - 1)).toInt() }
            }
            val ys = starts(H); val xs = starts(W)
            val total = ys.size * xs.size
            // Memory: only a band of 2 piece-heights is kept as numbers (not the whole photo); the
            // finished rows go straight into the result. A 12 MP photo needs ~70 MB, not ~380 MB.
            val Hb = 2 * T
            val acc = FloatArray(3 * W * Hb); val wsum = FloatArray(W * Hb)
            var base = 0   // the photo row that is the band's first row
            val out0 = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val row = IntArray(W)
            fun finish(upTo: Int) {
                val n = (upTo - base).coerceAtMost(Hb)
                for (r in 0 until n) {
                    for (x in 0 until W) {
                        val P = r * W + x
                        val q = 1f / maxOf(1e-6f, wsum[P])
                        fun c(ch: Int) = ((acc[ch * W * Hb + P] * q + 1f) * 127.5f + 0.5f).toInt().coerceIn(0, 255)
                        row[x] = (0xFF shl 24) or (c(0) shl 16) or (c(1) shl 8) or c(2)
                    }
                    out0.setPixels(row, 0, W, 0, base + r, W, 1)
                }
                // move the rest of the band up
                val keep = Hb - n
                for (ch in 0 until 3) System.arraycopy(acc, ch * W * Hb + n * W, acc, ch * W * Hb, keep * W)
                System.arraycopy(wsum, n * W, wsum, 0, keep * W)
                for (ch in 0 until 3) java.util.Arrays.fill(acc, ch * W * Hb + keep * W, (ch + 1) * W * Hb, 0f)
                java.util.Arrays.fill(wsum, keep * W, W * Hb, 0f)
                base += n
            }
            val inp = FloatArray(3 * T * T); val lat = FloatArray(4 * L * L); val pred = FloatArray(4 * L * L); val out = FloatArray(3 * T * T)
            val tile = IntArray(T * T)
            var done = 0; var tUnet = 0L
            for (y0 in ys) {
                // rows above this band get nothing more: they are done
                while (base < y0) finish(y0)
                for (x0 in xs) {
                    if (cancelled()) return null
                    HeatGuard.waitIfHot(ctx, cancelled)
                    img.getPixels(tile, 0, T, x0, y0, T, T)
                    for (i in 0 until T * T) {
                        val p = tile[i]
                        inp[i] = ((p shr 16) and 0xFF) / 127.5f - 1f
                        inp[T * T + i] = ((p shr 8) and 0xFF) / 127.5f - 1f
                        inp[2 * T * T + i] = (p and 0xFF) / 127.5f - 1f
                    }
                    if (!enc.run(inp, lat)) return fail("codificador (pieza ${done + 1})")
                    val tu = SystemClock.elapsedRealtime()
                    if (!unet.run(lat, pred)) return fail("UNet (pieza ${done + 1})")
                    tUnet += SystemClock.elapsedRealtime() - tu
                    for (i in lat.indices) lat[i] -= strength * pred[i]
                    if (!dec.run(lat, out)) return fail("decodificador (pieza ${done + 1})")
                    adain(out, inp)
                    // soft edges where pieces overlap
                    for (y in 0 until T) {
                        val wy = edge(y, y0 > 0, y0 + T < H)
                        val by = y0 - base + y
                        for (x in 0 until T) {
                            val wgt = wy * edge(x, x0 > 0, x0 + T < W)
                            val P = by * W + x0 + x; val i = y * T + x
                            acc[P] += wgt * out[i]; acc[W * Hb + P] += wgt * out[T * T + i]; acc[2 * W * Hb + P] += wgt * out[2 * T * T + i]
                            wsum[P] += wgt
                        }
                    }
                    done++
                    progress(done, total)
                }
            }
            while (base < H) finish(H)
            var bmp = out0
            if (k > 1f) bmp = Bitmap.createScaledBitmap(bmp, w, h, true)
            JobLog.add(String.format(Locale.US, "Realismo listo: %d piezas en %.1f s (UNet %.0f ms por pieza)",
                total, (SystemClock.elapsedRealtime() - t0) / 1000f, tUnet.toFloat() / maxOf(1, total)))
            return bmp
        } finally { enc.close(); unet.close(); dec.close() }
    }

    private fun fail(what: String): Bitmap? { JobLog.notice("Realismo: falló el $what en la NPU (${NpuTile.lastError ?: "?"})"); return null }

    private fun edge(i: Int, before: Boolean, after: Boolean): Float {
        var v = 1f
        if (before && i < OVER) v = (i + 0.5f) / OVER
        if (after && i >= T - OVER) v = minOf(v, (T - i - 0.5f) / OVER)
        return v
    }

    /** The authors' color fix: each channel's mean and spread taken from the input piece. */
    private fun adain(out: FloatArray, ref: FloatArray) {
        val n = T * T
        for (c in 0 until 3) {
            var mo = 0.0; var mr = 0.0
            for (i in 0 until n) { mo += out[c * n + i]; mr += ref[c * n + i] }
            mo /= n; mr /= n
            var so = 0.0; var sr = 0.0
            for (i in 0 until n) { val a = out[c * n + i] - mo; val b = ref[c * n + i] - mr; so += a * a; sr += b * b }
            val k = (Math.sqrt(sr / n) / (Math.sqrt(so / n) + 1e-5)).toFloat()
            for (i in 0 until n) out[c * n + i] = ((out[c * n + i] - mo) * k + mr).toFloat()
        }
    }
}
