package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Editar con palabras: the editor redraws the whole photo at 512 px, which loses detail and bends
 * bodies, hands and faces that weren't meant to change. Here the edit is compared with the original
 * and only what really changed is taken from it; everything else stays the original photo at its own
 * full size. Faces inside the changed areas are then sharpened with the restoration face model.
 */
object EditBlend {

    class Result(val image: Bitmap, val changedPct: Int, val faces: Int, val whole: Boolean)

    /** [edited] (any size) put over [orig] where it differs; [orig]'s size. Blocking. */
    fun keepUnchanged(ctx: Context, orig: Bitmap, edited: Bitmap, fixFaces: Boolean = true): Result {
        val w = orig.width; val h = orig.height
        val ed = Bitmap.createScaledBitmap(edited, w, h, true).copy(Bitmap.Config.ARGB_8888, true)

        // compare on a small copy, both blurred the same, so detail and noise don't count as change
        val k = 256f / max(w, h)
        val sw = max(8, (w * k).roundToInt()); val sh = max(8, (h * k).roundToInt())
        val o = blur(px(Bitmap.createScaledBitmap(orig, sw, sh, true)), sw, sh, 2)
        val e = blur(px(Bitmap.createScaledBitmap(ed, sw, sh, true)), sw, sh, 2)
        // the editor often shifts the colors of the whole picture a little: that is not a change
        val shift = IntArray(3)
        for (c in 0 until 3) {
            val d = IntArray(o.size) { i -> ch(e[i], c) - ch(o[i], c) }
            d.sort(); shift[c] = d[d.size / 2]
        }
        val m = FloatArray(o.size)
        for (i in o.indices) {
            var d = 0
            for (c in 0 until 3) d = max(d, abs(ch(e[i], c) - ch(o[i], c) - shift[c]))
            m[i] = ((d - 16f) / (40f - 16f)).coerceIn(0f, 1f)
        }
        // grow a little past the edges of the change and soften them (no hard seams)
        val grown = maxFilter(m, sw, sh, 3)
        val mask = blurF(grown, sw, sh, 4)
        val changed = mask.average().toFloat()
        val pct = (changed * 100).roundToInt()

        // the whole picture changed (a new style, night, a painting…): the edit as it is, at full size
        if (changed > 0.6f) {
            JobLog.add("Editar: cambió casi toda la foto ($pct %): se usa completa, a ${w}×$h")
            return Result(ed, pct, 0, true)
        }

        // faces in the changed parts: the restoration face model, finding them in the original photo
        var faces = 0
        if (fixFaces && changed > 0.01f) try {
            val packFaces = RestorePack.file(ctx, RestorePack.FACES)
            if (packFaces != null || FaceRestorer.isReady(ctx)) {
                FaceRestorer(ctx, true, packFaces).use { fr -> faces = fr.restoreAll(ed, { _, _ -> }, { false }, from = orig) }
            }
        } catch (t: Throwable) { JobLog.error("Editar: caras", t) }

        // full-size mask and the mix
        val mb = Bitmap.createBitmap(IntArray(sw * sh) { i -> val v = (mask[i] * 255).roundToInt(); Color.argb(255, v, v, v) }, sw, sh, Bitmap.Config.ARGB_8888)
        val mf = px(Bitmap.createScaledBitmap(mb, w, h, true))
        val op = px(orig); val ep = px(ed)
        for (i in op.indices) {
            val t = (mf[i] and 0xFF) / 255f
            if (t <= 0.004f) continue
            val a = op[i]; val b = ep[i]
            op[i] = Color.rgb(mix(Color.red(a), Color.red(b), t), mix(Color.green(a), Color.green(b), t), mix(Color.blue(a), Color.blue(b), t))
        }
        val out = Bitmap.createBitmap(op, w, h, Bitmap.Config.ARGB_8888)
        JobLog.add("Editar: se cambió $pct % de la foto; el resto queda como el original a ${w}×$h · caras arregladas $faces")
        return Result(out, pct, faces, false)
    }

    private fun mix(a: Int, b: Int, t: Float) = (a + (b - a) * t).roundToInt().coerceIn(0, 255)
    private fun ch(p: Int, c: Int) = when (c) { 0 -> Color.red(p); 1 -> Color.green(p); else -> Color.blue(p) }
    private fun px(b: Bitmap) = IntArray(b.width * b.height).also { b.getPixels(it, 0, b.width, 0, 0, b.width, b.height) }

    /** Box blur of colors, radius [r]. */
    private fun blur(p: IntArray, w: Int, h: Int, r: Int): IntArray {
        val out = IntArray(p.size)
        for (y in 0 until h) for (x in 0 until w) {
            var rs = 0; var gs = 0; var bs = 0; var n = 0
            for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) {
                val v = p[yy * w + xx]; rs += Color.red(v); gs += Color.green(v); bs += Color.blue(v); n++
            }
            out[y * w + x] = Color.rgb(rs / n, gs / n, bs / n)
        }
        return out
    }

    private fun blurF(p: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val out = FloatArray(p.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f; var n = 0
            for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) { s += p[yy * w + xx]; n++ }
            out[y * w + x] = s / n
        }
        return out
    }

    private fun maxFilter(p: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val out = FloatArray(p.size)
        for (y in 0 until h) for (x in 0 until w) {
            var m = 0f
            for (yy in max(0, y - r)..min(h - 1, y + r)) for (xx in max(0, x - r)..min(w - 1, x + r)) m = max(m, p[yy * w + xx])
            out[y * w + x] = m
        }
        return out
    }
}
