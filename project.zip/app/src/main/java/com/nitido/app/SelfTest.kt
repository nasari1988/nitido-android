package com.nitido.app

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.net.Uri
import android.os.Debug
import android.os.StatFs
import android.os.SystemClock
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Autoprueba: runs every installed tool once on small made-up pictures (and a 2-second made-up
 * video), the same calls the real screens use, and checks that each one opens, finishes and gives a
 * sane picture (not black, not flat, not wildly different from the input). Each test records its
 * time and the most memory the app used while it ran. Nothing is downloaded; the test pictures are
 * drawn here and the gallery copies it makes are deleted again.
 */
object SelfTest {

    enum class State { WAIT, RUN, OK, FAIL, SKIP }

    class Item(val name: String) {
        @Volatile var state = State.WAIT
        @Volatile var detail = ""
        @Volatile var ms = 0L
        @Volatile var peakMb = 0
    }

    /** Thrown by a check that didn't pass (its message goes in the report). */
    private class Bad(msg: String) : Exception(msg)

    @Volatile var items: List<Item> = emptyList()
        private set
    @Volatile var running = false
        private set
    @Volatile var stop = false
    @Volatile var finishedAt = 0L
        private set
    /** Called (from the work thread) after every change. */
    @Volatile var onChange: (() -> Unit)? = null

    private class Test(val name: String, val skip: (Context) -> String?, val run: (Context) -> String)

    // ---------- the made-up pictures ----------

    /** A landscape with sky, sun, hills, a house, fine stripes, text and grain (like a phone photo). */
    fun scene(w: Int, h: Int, shift: Float = 0f): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h * 0.6f, Color.rgb(70, 130, 200), Color.rgb(200, 220, 240), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        c.save(); c.translate(-shift, 0f)
        p.color = Color.rgb(250, 210, 90); c.drawCircle(w * 0.78f, h * 0.2f, h * 0.09f, p)
        val hill = Path().apply {
            moveTo(-w * 0.2f, h.toFloat()); lineTo(-w * 0.2f, h * 0.62f)
            cubicTo(w * 0.2f, h * 0.45f, w * 0.5f, h * 0.75f, w * 1.4f, h * 0.55f); lineTo(w * 1.4f, h.toFloat()); close()
        }
        p.color = Color.rgb(70, 120, 60); c.drawPath(hill, p)
        p.color = Color.rgb(180, 90, 70); c.drawRect(w * 0.18f, h * 0.48f, w * 0.38f, h * 0.72f, p)
        p.color = Color.rgb(90, 50, 40)
        c.drawPath(Path().apply { moveTo(w * 0.15f, h * 0.49f); lineTo(w * 0.28f, h * 0.36f); lineTo(w * 0.41f, h * 0.49f); close() }, p)
        p.color = Color.rgb(240, 230, 200)
        c.drawRect(w * 0.22f, h * 0.53f, w * 0.27f, h * 0.6f, p); c.drawRect(w * 0.30f, h * 0.53f, w * 0.35f, h * 0.6f, p)
        // fine stripes and checks: what upscalers and sharpeners must keep
        p.color = Color.rgb(30, 30, 30)
        var x = w * 0.55f
        while (x < w * 0.9f) { c.drawRect(x, h * 0.66f, x + 2f, h * 0.9f, p); x += 6f }
        p.textSize = h * 0.07f; p.color = Color.WHITE
        c.drawText("Nítido 2026", w * 0.05f, h * 0.95f, p)
        c.restore()
        // grain, like a photo taken in low light
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val rnd = java.util.Random(7)
        for (i in px.indices) {
            val n = (rnd.nextGaussian() * 7).roundToInt()
            val v = px[i]
            px[i] = Color.rgb((Color.red(v) + n).coerceIn(0, 255), (Color.green(v) + n).coerceIn(0, 255), (Color.blue(v) + n).coerceIn(0, 255))
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
        return b
    }

    private fun gray(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) { val v = px[i]; val y = (Color.red(v) * 299 + Color.green(v) * 587 + Color.blue(v) * 114) / 1000; px[i] = Color.rgb(y, y, y) }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------- checks on a result ----------

    private class Stats(val mean: Float, val std: Float, val chroma: Float)

    private fun stats(px: IntArray): Stats {
        var s = 0.0; var s2 = 0.0; var ch = 0.0
        val step = maxOf(1, px.size / 200_000)
        var n = 0
        var i = 0
        while (i < px.size) {
            val v = px[i]; val r = Color.red(v); val g = Color.green(v); val b = Color.blue(v)
            val y = (r * 299 + g * 587 + b * 114) / 1000.0
            s += y; s2 += y * y; ch += (maxOf(r, g, b) - minOf(r, g, b)); n++
            i += step
        }
        val m = s / n
        return Stats(m.toFloat(), sqrt(maxOf(0.0, s2 / n - m * m)).toFloat(), (ch / n).toFloat())
    }

    private fun pixels(b: Bitmap) = IntArray(b.width * b.height).also { b.getPixels(it, 0, b.width, 0, 0, b.width, b.height) }

    /** Mean difference (0..255) between [out] shrunk/grown to [ref]'s size and [ref]. */
    private fun diff(ref: Bitmap, out: Bitmap): Float {
        val o = if (out.width == ref.width && out.height == ref.height) out else Bitmap.createScaledBitmap(out, ref.width, ref.height, true)
        val a = pixels(ref); val b = pixels(o)
        var d = 0L
        for (i in a.indices) {
            d += abs(Color.red(a[i]) - Color.red(b[i])) + abs(Color.green(a[i]) - Color.green(b[i])) + abs(Color.blue(a[i]) - Color.blue(b[i]))
        }
        return d / (3f * a.size)
    }

    /** A picture that came out black, white, flat or unrelated to the input is a failure. */
    private fun checkPicture(what: String, ref: Bitmap?, out: Bitmap?, maxDiff: Float = 40f): String {
        if (out == null) throw Bad("$what no devolvió imagen")
        val st = stats(pixels(out))
        if (st.std < 4f) throw Bad(String.format(Locale.US, "$what salió plana (brillo %.0f, variación %.1f)", st.mean, st.std))
        if (st.mean < 8f || st.mean > 247f) throw Bad(String.format(Locale.US, "$what salió %s (brillo %.0f)", if (st.mean < 8f) "negra" else "blanca", st.mean))
        val d = if (ref != null) diff(ref, out) else -1f
        if (ref != null && d > maxDiff) throw Bad(String.format(Locale.US, "$what muy distinta de la original (diferencia %.0f de 255)", d))
        return String.format(Locale.US, "%d×%d · brillo %.0f · variación %.0f%s", out.width, out.height, st.mean, st.std,
            if (ref != null) String.format(Locale.US, " · diferencia %.1f", d) else "")
    }

    /** For the screens: null when [b] looks like a real picture, else what is wrong with it. */
    fun pictureProblem(b: Bitmap): String? = try { checkPicture("la imagen", null, b); null } catch (e: Bad) { e.message }

    private fun ensure(ok: Boolean, msg: String) { if (!ok) throw Bad(msg) }

    // ---------- memory ----------

    private fun usedMb(): Int {
        val rt = Runtime.getRuntime()
        val java = rt.totalMemory() - rt.freeMemory()
        return ((java + Debug.getNativeHeapAllocatedSize()) / 1_000_000).toInt()
    }

    private fun pssMb(): Int = try { Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1000 } catch (t: Throwable) { 0 }

    private fun memLine(ctx: Context): String {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val rt = Runtime.getRuntime()
        return String.format(Locale.US, "RAM %.1f GB", mi.totalMem / 1e9) + " · libre ${mi.availMem / 1_000_000} MB" +
            (if (mi.lowMemory) " (poca)" else "") + " · Java ${(rt.totalMemory() - rt.freeMemory()) / 1_000_000}/${rt.maxMemory() / 1_000_000} MB" +
            " · nativa ${Debug.getNativeHeapAllocatedSize() / 1_000_000} MB · total app ${pssMb()} MB"
    }

    // ---------- the tests ----------

    private fun tests(): List<Test> {
        val list = ArrayList<Test>()
        val img = { scene(640, 480) }

        list += Test("Teléfono y memoria", { null }) { ctx ->
            val st = StatFs(ctx.filesDir.path)
            JobLog.add("Autoprueba: " + memLine(ctx))
            memLine(ctx) + " · espacio libre ${st.availableBytes / 1_000_000_000} GB · " + HeatGuard.describe(ctx)
        }
        list += Test("Galería: guardar y borrar", { null }) { ctx ->
            val uri = Gallery.saveImage(ctx, scene(320, 240), "nitido_autoprueba") ?: throw Bad("no se pudo guardar en la galería")
            val n = ctx.contentResolver.delete(uri, null, null)
            ensure(n == 1, "se guardó pero no se pudo borrar la copia de prueba ($uri)")
            "guardó y borró la copia de prueba"
        }
        list += Test("Traductor (español → inglés)", { null }) { _ ->
            val en = Translate.toEnglish("un perro en la playa")
            ensure(en.lowercase(Locale.ROOT).contains("dog"), "no tradujo (quedó «$en»)")
            "«un perro en la playa» → «$en»"
        }
        list += Test("Detector de rayones", { c -> if (!ScratchDetector.isReady(c)) "paquete Restaurar no descargado" else null }) { ctx ->
            val m = ScratchDetector.detect(ctx, img(), true) ?: throw Bad("no devolvió el mapa")
            var on = 0; for (v in m.prob) if ((v.toInt() and 0xFF) > 180) on++
            "mapa ${m.w}×${m.h} · ${on * 100 / maxOf(1, m.prob.size)} % marcado (la foto de prueba no tiene rayones)"
        }
        list += Test("Quitar marcas", { c -> if (RestorePack.file(c, RestorePack.LAMA) == null) "paquete Restaurar no descargado" else null }) { ctx ->
            val src = img()
            val damaged = src.copy(Bitmap.Config.ARGB_8888, true)
            val mask = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
            val p = Paint().apply { strokeWidth = 5f; color = Color.WHITE }
            Canvas(damaged).drawLine(60f, 80f, 560f, 400f, p); Canvas(mask).drawLine(60f, 80f, 560f, 400f, p)
            val out = RestoreTools.removeMarks(ctx, RestorePack.file(ctx, RestorePack.LAMA)!!, damaged, mask, true, {}, { stop })
            val r = checkPicture("la foto", src, out)
            // the white line must be gone: the pixels under it look like their surroundings again
            val o = pixels(out!!); val mk = pixels(mask)
            var white = 0; var n = 0
            for (i in o.indices) if ((mk[i] ushr 24) > 30) { n++; if (Color.red(o[i]) > 235 && Color.green(o[i]) > 235 && Color.blue(o[i]) > 235) white++ }
            ensure(white * 4 < n, "la raya sigue ahí (${white * 100 / maxOf(1, n)} % blanca)")
            "$r · raya quitada (${white * 100 / maxOf(1, n)} % queda blanca)"
        }
        list += Test("Paquete: versiones NPU de Enfocar y Quitar ruido", { c -> if (!RestorePack.isReady(c)) "paquete Restaurar no descargado" else null }) { ctx ->
            RestorePack.fetchNpuExtras(ctx)
            val d = SdModel.dir(ctx, RestorePack.ID)
            val have = listOf("rest_deblur", "rest_denoise").filter { File(d, "$it.npu.bin").exists() && File(d, "$it.npu_ctx.onnx").exists() }
            ensure(have.size == 2, "faltan archivos NPU (${listOf("rest_deblur", "rest_denoise").minus(have.toSet()).joinToString()})")
            "listos: " + have.joinToString { "$it.npu.bin ${ModelCatalog.mb(File(d, "$it.npu.bin").length())}" }
        }
        list += Test("Quitar ruido", { c -> if (RestorePack.file(c, RestorePack.DENOISE) == null) "paquete Restaurar no descargado" else null }) { ctx ->
            val src = img()
            Upscaler(ctx, Engine.GPU, RestorePack.file(ctx, RestorePack.DENOISE)!!.absolutePath, pad = 32, precise = true, tryFast = true).use { u ->
                val out = u.upscale(src, 1, {}, { stop })
                checkPicture("la foto", src, out, 25f) + " · " + u.engine.label
            }
        }
        list += Test("Enfocar (desenfoque)", { null }) { ctx ->
            val src = img()
            val restormer = RestorePack.file(ctx, RestorePack.DEBLUR)
            val u = if (restormer != null) Upscaler(ctx, Engine.GPU, restormer.absolutePath, pad = 32, precise = true, tryFast = true)
                else Upscaler(ctx, Engine.GPU, Upscaler.MODEL_DEBLUR, pad = 24)
            u.use { checkPicture("la foto", src, it.upscale(src, 1, {}, { stop }), 25f) + " · ${it.modelName} · ${it.engine.label}" }
        }
        list += Test("Colorear", { c -> if (RestorePack.file(c, RestorePack.COLOR) == null) "paquete Restaurar no descargado" else null }) { ctx ->
            val g = gray(img())
            val out = RestoreTools.colorize(ctx, RestorePack.file(ctx, RestorePack.COLOR)!!, g, true)
            val r = checkPicture("la foto", g, out, 60f)
            val ch = stats(pixels(out)).chroma
            ensure(ch > 6f, String.format(Locale.US, "no le dio color (color %.1f)", ch))
            r + String.format(Locale.US, " · color %.0f", ch)
        }
        list += Test("Ampliar ×4", { null }) { ctx ->
            val src = Bitmap.createScaledBitmap(img(), 240, 180, true)
            val model = if (MnnTile.hasAsset(ctx, Upscaler.MODEL_SIAX)) Upscaler.MODEL_SIAX else Upscaler.MODEL_X4PLUS
            Upscaler(ctx, Engine.GPU, model).use { u ->
                val out = u.upscale(src, 4, {}, { stop })
                ensure(out != null && out.width == 960 && out.height == 720, "tamaño incorrecto (${out?.width}×${out?.height})")
                checkPicture("la foto", src, out, 25f) + " · $model · ${u.engine.label}"
            }
        }
        list += Test("Caras", { c -> if (RestorePack.file(c, RestorePack.FACES) == null && !FaceRestorer.isReady(c)) "modelo de caras no descargado" else null }) { ctx ->
            val src = img().copy(Bitmap.Config.ARGB_8888, true)
            FaceRestorer(ctx, true, RestorePack.file(ctx, RestorePack.FACES)).use { fr ->
                val n = fr.restoreAll(src, { _, _ -> }, { stop })
                "abrió en ${fr.engineLabel} · $n caras (la foto de prueba no tiene caras: solo se prueba que abre)"
            }
        }
        list += Test("Realismo (NPU)", { c -> if (!Realism.isReady(c)) "paquete Realismo no descargado" else null }) { ctx ->
            val src = scene(512, 512)
            val out = Realism.run(ctx, src, 1f, { stop }) { _, _ -> } ?: throw Bad("no terminó (${NpuTile.lastError ?: "ver registro"})")
            checkPicture("la foto", src, out, 45f)
        }
        list += Test("Más fluido (NPU)", { c -> if (!Interpolator.isReady(c)) "paquete Más fluido no descargado" else null }) { ctx ->
            val w = 1280; val h = 720
            val a = pixels(scene(w, h, 0f)); val b = pixels(scene(w, h, 24f))
            Interpolator.open(ctx, w, h).use { ip ->
                val t0 = SystemClock.elapsedRealtime()
                val mid = ip.middle(a, b, w, h)
                val ms = SystemClock.elapsedRealtime() - t0
                ensure(mid.size == w * h, "tamaño incorrecto")
                val ref = Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
                checkPicture("el cuadro de en medio", ref, Bitmap.createBitmap(mid, w, h, Bitmap.Config.ARGB_8888), 35f) + " · $ms ms"
            }
        }
        list += Test("Limpiar video (NPU)", { c -> if (!Rbvsr.isReady(c)) "paquete Limpiar no descargado" else null }) { ctx ->
            // the user's case: a 1080p video, 12 frames (two blocks) of a camera pan
            val w = 1920; val h = 1080; val n = 12
            val rb = Rbvsr.open(ctx, w, h, w, h) ?: throw Bad("la NPU no abrió las piezas (ver registro)")
            rb.use { r ->
                var count = 0; var firstOut: IntArray? = null; var badSize = false
                fun take(l: List<Pair<IntArray, Long>>) { for (o in l) { if (firstOut == null) firstOut = o.first; if (o.first.size != w * h) badSize = true; count++ } }
                val t0 = SystemClock.elapsedRealtime()
                var first: Bitmap? = null
                for (i in 0 until n) {
                    if (stop) throw Bad("detenida")
                    val f = scene(w, h, i * 6f)
                    if (i == 0) first = f
                    take(r.push(pixels(f), w, h, i * 33_333L))
                }
                take(r.flush())
                val ms = SystemClock.elapsedRealtime() - t0
                ensure(count == n, "salieron $count cuadros de $n")
                ensure(!badSize, "cuadros de tamaño incorrecto")
                val pic = Bitmap.createBitmap(firstOut!!, w, h, Bitmap.Config.ARGB_8888)
                val rt = Runtime.getRuntime()
                val javaMb = (rt.totalMemory() - rt.freeMemory()) / 1_000_000
                ensure(javaMb < 350, "la memoria de Java llegó a $javaMb MB de ${rt.maxMemory() / 1_000_000} (riesgo de cierre)")
                checkPicture("el primer cuadro", first, pic, 30f) + " · ${ms / n} ms por cuadro · Java $javaMb MB · nativa ${Debug.getNativeHeapAllocatedSize() / 1_000_000} MB"
            }
        }
        list += Test("Video completo (2 s)", { null }) { ctx ->
            videoRun(ctx, if (Rbvsr.isReady(ctx)) Rbvsr.MODEL else Upscaler.MODEL_ULTRASHARP, enhance = true, fluid = Interpolator.isReady(ctx), extras = false)
        }

        list += Test("Retoques (luz, color, B/N, sepia)", { null }) { _ ->
            val src = img()
            val v = PhotoAdjust.Values(brightness = 20, contrast = 15, saturation = 25, warmth = 30, tint = -10, sharpness = 40, shadows = 30)
            val a = PhotoAdjust.apply(src, v) ?: throw Bad("los retoques no devolvieron imagen")
            val r1 = checkPicture("con retoques", src, a, 45f)
            val g = PhotoAdjust.autoGains(src)
            val bw = PhotoAdjust.apply(src, PhotoAdjust.Values(bw = true)) ?: throw Bad("B/N no devolvió imagen")
            ensure(stats(pixels(bw)).chroma < 3f, "B/N quedó con color")
            val sep = PhotoAdjust.apply(src, PhotoAdjust.Values(sepia = true)) ?: throw Bad("sepia no devolvió imagen")
            checkPicture("en sepia", src, sep, 70f)
            val wb = PhotoAdjust.apply(src, PhotoAdjust.Values(gainR = g.first, gainG = g.second, gainB = g.third)) ?: throw Bad("color automático falló")
            checkPicture("con color automático", src, wb, 40f)
            "$r1 · color automático ${String.format(Locale.US, "%.2f/%.2f/%.2f", g.first, g.second, g.third)} · B/N y sepia bien"
        }
        for ((model, label) in listOf(Upscaler.MODEL_QSR to "Ultrarrápido", Upscaler.MODEL_FILE to "Rápido", Upscaler.MODEL_X4PLUS to "Detalle")) {
            list += Test("Ampliar ×4 en la NPU ($label)", { c -> if (!NpuTile.has(c, model)) "esta versión no trae su modelo NPU" else null }) { ctx ->
                val src = Bitmap.createScaledBitmap(img(), 240, 180, true)
                Upscaler(ctx, Engine.NPU, model).use { u ->
                    ensure(u.engine == Engine.NPU, "no abrió en la NPU (${NpuTile.lastError ?: "sin detalle"}); usó ${u.engine.label}")
                    checkPicture("la foto", src, u.upscale(src, 4, {}, { stop }), 25f) + " · NPU"
                }
            }
        }
        list += Test("Ampliar ×4 en el procesador", { null }) { ctx ->
            val src = Bitmap.createScaledBitmap(img(), 120, 90, true)
            Upscaler(ctx, Engine.CPU, Upscaler.MODEL_X4PLUS).use { u -> checkPicture("la foto", src, u.upscale(src, 4, {}, { stop }), 25f) + " · ${u.engine.label}" }
        }
        list += Test("Reimaginar (NPU)", { c -> if (Reimagine.models(c).isEmpty()) "sin modelo SDXL con NPU" else null }) { ctx ->
            val src = scene(768, 576)
            val id = Reimagine.models(ctx).first()
            val out = try { Reimagine.run(ctx, src, id, 0.3f, true, { stop }) { _, _ -> } } finally { NpuUnet.releaseAll(); SdNative.release() }
            "$id · " + checkPicture("la foto", src, out, 60f)
        }
        list += Test("Detalle IA", { c -> if (SdNative.loadError != null) "el motor no cargó" else if (SdDetail.pickModel(c) == null) "sin modelo para Detalle IA" else null }) { ctx ->
            val src = scene(512, 384)
            val id = SdDetail.pickModel(ctx)!!
            val out = try { SdDetail.redraw(ctx, src, id, 0.25f, true, { _, _ -> }, { stop }) } finally { SdNative.release() }
            "$id · " + checkPicture("la foto", src, out, 50f)
        }
        list += Test("Catálogo de modelos (internet)", { null }) { _ ->
            val all = ModelCatalog.fetchRemote()
            ensure(all.isNotEmpty(), "el catálogo llegó vacío")
            "${all.size} modelos en el catálogo"
        }
        list += Test("Video: Más fluido solo", { c -> if (!Interpolator.isReady(c)) "paquete Más fluido no descargado" else null }) { ctx ->
            videoRun(ctx, Upscaler.MODEL_ULTRASHARP, enhance = false, fluid = true, extras = false)
        }
        list += Test("Video: ampliar ×2 + recorte + opciones", { null }) { ctx ->
            // the other model, the cut, every cleaning switch, H.265 and retoques
            videoRun(ctx, Upscaler.MODEL_ULTRASHARP, enhance = true, fluid = false, extras = true)
        }
        return list
    }

    /** A made-up 2-second video: the timelapse maker writes it, then the whole Mejorar video path runs. */
    fun testVideo(ctx: Context): File {
        val f = File(ctx.cacheDir, "autoprueba_in.mp4")
        if (!f.exists() || f.length() < 1000) TimelapseVideo.writeMp4((0 until 24).map { scene(512, 288, it * 4f) }, f, fps = 12, holdLastSec = 0f)
        return f
    }

    private fun videoRun(ctx: Context, model: String, enhance: Boolean, fluid: Boolean, extras: Boolean): String {
        val f = testVideo(ctx)
        val adj = if (extras) PhotoAdjust.Values(brightness = 10, saturation = 15) else PhotoAdjust.Values()
        val plan = VideoEnhancer.plan(ctx, Uri.fromFile(f), "autoprueba.mp4", f.length(), 2, model, Engine.GPU, false,
            if (extras) 300_000L else 0L, if (extras) 1_700_000L else 0L, adj, extras, extras, extras, extras, enhance = enhance, fluid = fluid)
        val uri = VideoEnhancer(ctx, Uri.fromFile(f), plan).make { stop } ?: throw Bad("no terminó (ver registro)")
        val mmr = android.media.MediaMetadataRetriever()
        val info = try {
            mmr.setDataSource(ctx, uri)
            val ww = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val hh = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val dur = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val mime = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: ""
            val fr = mmr.getFrameAtTime(dur * 500, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: throw Bad("el video hecho no tiene imagen")
            val want = if (extras) 1400L else 2000L
            ensure(dur in want - 600..want + 600, "duración incorrecta ($dur ms, se esperaban ~$want)")
            "${ww}×$hh · ${dur / 1000f} s · $mime · " + checkPicture("el cuadro", null, fr)
        } finally { try { mmr.release() } catch (_: Throwable) { } }
        try { ctx.contentResolver.delete(uri, null, null) } catch (_: Throwable) { }
        return "${model.substringAfterLast('/')}${if (plan.fluid) " + Más fluido" else ""} · $info (copia de prueba borrada)"
    }

    /** One Crear test per installed image model: 2 steps at its smallest size, checked as a picture. */
    private fun createTests(ctx: Context): List<Test> {
        val ids = try {
            ModelCatalog.imageModels(ctx).filter { it != Rbvsr.PACK && it != "limpiar" && SdModel.isReady(ctx, it) }
        } catch (t: Throwable) { emptyList() }
        return ids.map { id ->
            Test("Crear: ${ModelCatalog.displayName(id)}", { c ->
                when {
                    SdNative.loadError != null -> "el motor no cargó (${SdNative.loadError})"
                    SdModel.readMode(c, id) == 2 -> "modelo de zonas pintadas: se prueba al usarlo"
                    SdModel.isSdxl(c, id) && NpuUnet.dirFor(c, id) == null -> "SDXL sin versión NPU"
                    else -> null
                }
            }) { c -> create(c, id) }
        }
    }

    private fun create(ctx: Context, id: String): String {
        val mode = SdModel.readMode(ctx, id)
        val sdxl = SdModel.isSdxl(ctx, id)
        val npuDir = if (mode == 0) NpuUnet.dirFor(ctx, id) else null
        val (w, h) = if (npuDir != null) NpuUnet.sizes(ctx, id).ifEmpty { listOf(if (sdxl) 1024 to 1024 else 512 to 512) }
            .minByOrNull { it.first * it.second }!! else 512 to 512
        val input = if (mode == 1) {
            val b = scene(512, 512); val px = pixels(b); val n = 512 * 512
            FloatArray(3 * n).also { f -> for (i in 0 until n) { val p = px[i]
                f[i] = Color.red(p) / 127.5f - 1f; f[n + i] = Color.green(p) / 127.5f - 1f; f[2 * n + i] = Color.blue(p) / 127.5f - 1f } }
        } else null
        val prompt = if (mode == 1) "make it winter with snow" else "a red apple on a wooden table, photo"
        val fast = Reimagine.isFast(id)
        val out = File(ctx.cacheDir, "sd_autoprueba.jpg").apply { delete() }
        val npu = npuDir?.let { NpuUnet.get(ctx.applicationContext, it) }
        if (npu == null) NpuUnet.releaseAll()
        JobLog.add("Autoprueba Crear: $id · ${if (npu != null) "NPU" else "GPU"} · ${w}×$h · 2 pasos")
        var borrowed = false
        var code: Int
        while (true) {
        code = try {
            SdModel.ensureEncoder(ctx, id)
            SdNative.setNpu(npu)
            SdNative.generate(SdModel.dir(ctx, id).absolutePath, ctx.cacheDir.absolutePath, SdNative.BACKEND_OPENCL,
                mode, SdModel.isDynamic(ctx, id), w, h, 2, 1234, out.absolutePath, prompt, if (mode == 1) "" else "blurry",
                input, 0.75f, if (fast) 1.5f else 7f, 1.5f, null, null, SdNative.PREVIEW_NONE,
                if (fast) SdNative.SAMPLER_DPM else SdNative.SAMPLER_PLMS,
                object : SdNative.Listener {
                    override fun onProgress(pct: Int) { if (stop) SdNative.cancel() }
                    override fun onPreview(rgb: ByteArray, width: Int, height: Int) {}
                })
        } finally {
            SdNative.setNpu(null)
        }
        if (code == 10 && !borrowed && SdModel.borrowDecoder(ctx, id)) {
            try { JobLog.add("Detalle: " + SdNative.lastTimings()) } catch (_: Throwable) { }
            borrowed = true; SdNative.release(); continue
        }
        break
        }
        val timings = try { SdNative.lastTimings() } catch (_: Throwable) { "" }
        if (timings.isNotEmpty()) JobLog.add("Detalle: $timings")
        if (code != SdNative.OK) {
            val why = when (code) {
                2 -> "el modelo no cargó"; 3 -> "la generación falló"; 4 -> "falta el lector de fotos"; 5 -> "tamaño no admitido"
                SdNative.BAD_TEXT -> "el lector de texto dio números inválidos (archivos dañados: vuelve a descargar el modelo)"
                SdNative.BAD_UNET -> "la UNet dio números inválidos"; SdNative.NPU_FAILED -> "la NPU falló"; SdNative.CANCELLED -> "detenida"
                else -> "código $code"
            }
            throw Bad(why + if (timings.isNotEmpty()) " · $timings".take(300) else "")
        }
        val bmp = BitmapFactory.decodeFile(out.path) ?: throw Bad("no se pudo leer la imagen hecha")
        out.delete()
        return "${if (npu != null) "NPU" else "GPU"}${if (borrowed) " · con el decodificador de otro modelo" else ""} · " + checkPicture("la imagen", null, bmp) + if (timings.isNotEmpty()) " · $timings".take(160) else ""
    }

    // ---------- running ----------

    // ---------- the screens, opened and used like a person would ----------

    const val EXTRA = "nitido_autotest"
    private const val EXTRA_SMOKE = "nitido_autotest_smoke"

    @Volatile private var latch: java.util.concurrent.CountDownLatch? = null
    @Volatile private var screenOk = false
    @Volatile private var screenDetail = ""
    @Volatile private var screenUri: Uri? = null
    @Volatile private var screenAct: java.lang.ref.WeakReference<android.app.Activity>? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    /** A screen opened by the autotest finished its part: [detail] starting with "OMITIDA:" = skipped. */
    fun screenDone(a: android.app.Activity, ok: Boolean, detail: String, uri: Uri? = null) {
        JobLog.add("Autoprueba – pantalla ${a.javaClass.simpleName}: ${if (ok) "bien" else "falló"} · $detail")
        screenOk = ok; screenDetail = detail; screenUri = uri
        main.post { try { a.finish() } catch (_: Throwable) { } }
        latch?.countDown()
    }

    /** For the screens: waits (without blocking the screen) until [cond] holds, up to [ms]. */
    suspend fun waitUntil(ms: Long, cond: () -> Boolean): Boolean {
        val end = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < end) { if (cond()) return true; if (stop) return false; kotlinx.coroutines.delay(250) }
        return cond()
    }

    private val watcher = object : android.app.Application.ActivityLifecycleCallbacks {
        override fun onActivityCreated(a: android.app.Activity, b: android.os.Bundle?) {
            if (a.intent?.hasExtra(EXTRA) == true || a.intent?.hasExtra(EXTRA_SMOKE) == true) screenAct = java.lang.ref.WeakReference(a)
        }
        override fun onActivityResumed(a: android.app.Activity) {
            if (a.intent?.getBooleanExtra(EXTRA_SMOKE, false) == true) {
                a.intent.removeExtra(EXTRA_SMOKE)
                main.postDelayed({
                    if (!a.isFinishing) screenDone(a, true, "abrió y se mostró bien" + (if (a.window?.decorView?.isShown == true) "" else " (sin ventana visible)"))
                }, 1500)
            }
        }
        override fun onActivityStarted(a: android.app.Activity) {}
        override fun onActivityPaused(a: android.app.Activity) {}
        override fun onActivityStopped(a: android.app.Activity) {}
        override fun onActivitySaveInstanceState(a: android.app.Activity, b: android.os.Bundle) {}
        override fun onActivityDestroyed(a: android.app.Activity) {}
    }

    /** Opens [cls] (as a new screen on top) and waits for it to report back. */
    private fun screen(ctx: Context, cls: Class<*>, minutes: Long, smoke: Boolean, fill: android.content.Intent.() -> Unit = {}): String {
        val l = java.util.concurrent.CountDownLatch(1)
        latch = l; screenOk = false; screenDetail = ""; screenUri = null; screenAct = null
        val it = android.content.Intent(ctx, cls).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        if (smoke) it.putExtra(EXTRA_SMOKE, true) else it.putExtra(EXTRA, "1")
        it.fill()
        ctx.startActivity(it)
        val limit = SystemClock.elapsedRealtime() + minutes * 60_000
        var done = false
        while (!done && !stop && SystemClock.elapsedRealtime() < limit) done = l.await(1, java.util.concurrent.TimeUnit.SECONDS)
        if (!done && stop) done = l.await(20, java.util.concurrent.TimeUnit.SECONDS)   // the screen stops its work and reports
        latch = null
        if (!done) {
            screenAct?.get()?.let { a -> main.post { try { a.finish() } catch (_: Throwable) { } } }
            throw Bad(if (stop) "detenida" else "la pantalla no terminó en $minutes min (¿se quedó en un aviso o una pregunta?)")
        }
        screenUri?.let { u -> try { ctx.contentResolver.delete(u, null, null) } catch (_: Throwable) { } }
        Thread.sleep(600)
        if (screenDetail.startsWith("OMITIDA:")) throw Skip(screenDetail.removePrefix("OMITIDA:").trim())
        if (!screenOk) throw Bad(screenDetail.ifEmpty { "falló" })
        return screenDetail + if (screenUri != null) " (copia de prueba borrada)" else ""
    }

    private class Skip(msg: String) : Exception(msg)

    private fun screenTests(): List<Test> {
        val l = ArrayList<Test>()
        fun smoke(name: String, cls: Class<*>, skip: (Context) -> String? = { null }, fill: android.content.Intent.() -> Unit = {}) {
            l += Test("Pantalla: $name", skip) { c -> screen(c, cls, 1, true, fill) }
        }
        smoke("Inicio", HomeActivity::class.java)
        smoke("Bienvenida", WelcomeActivity::class.java)
        smoke("Ajustes", SettingsActivity::class.java)
        smoke("Modelos", ModelsActivity::class.java)
        smoke("Mis resultados (pide huella)", ResultsActivity::class.java)
        smoke("Mejorar foto (avanzado)", MainActivity::class.java)
        l += Test("Pantalla: Marcar con el dedo", { null }) { c ->
            MaskHolder.photo = scene(640, 480); MaskHolder.mask = null
            screen(c, MaskActivity::class.java, 1, true)
        }
        l += Test("Pantalla: Pantalla completa (video)", { null }) { c ->
            val f = testVideo(c)
            screen(c, FullscreenActivity::class.java, 1, true) { putExtra("original", Uri.fromFile(f).toString()) }
        }
        l += Test("Usar: ✦ Restaurar todo", { c -> if (!RestorePack.isReady(c)) "paquete Restaurar no descargado" else null }) { c ->
            val f = File(c.cacheDir, "autoprueba_foto.jpg")
            gray(scene(1024, 768)).compress(Bitmap.CompressFormat.JPEG, 80, f.outputStream())
            screen(c, RestoreActivity::class.java, 15, false) { putExtra(EXTRA, f.path) }
        }
        l += Test("Usar: ✦ Crear", { null }) { c ->
            screen(c, GenerateActivity::class.java, 10, false) { putExtra(GenerateActivity.EXTRA_MODE, GenerateActivity.MODE_CREATE) }
        }
        l += Test("Usar: ✦ Crear cambiando una zona", { null }) { c ->
            val f = File(c.cacheDir, "autoprueba_zona.jpg")
            scene(768, 576).compress(Bitmap.CompressFormat.JPEG, 85, f.outputStream())
            screen(c, GenerateActivity::class.java, 10, false) { putExtra(GenerateActivity.EXTRA_MODE, GenerateActivity.MODE_CREATE); putExtra(EXTRA, "zone:" + f.path) }
        }
        l += Test("Usar: ✦ Editar con palabras", { null }) { c ->
            val f = File(c.cacheDir, "autoprueba_editar.jpg")
            scene(768, 576).compress(Bitmap.CompressFormat.JPEG, 85, f.outputStream())
            screen(c, GenerateActivity::class.java, 10, false) { putExtra(GenerateActivity.EXTRA_MODE, GenerateActivity.MODE_EDIT); putExtra(EXTRA, f.path) }
        }
        l += Test("Usar: ✦ Mejorar video", { null }) { c ->
            val f = testVideo(c)
            screen(c, VideoActivity::class.java, 20, false) { putExtra(EXTRA, f.path) }
        }
        return l
    }

    // ---------- saving progress (so a crash doesn't lose it) ----------

    private fun stateFile(ctx: Context) = File(ctx.filesDir, "autoprueba.json")
    private fun logFile(ctx: Context) = File(ctx.filesDir, "autoprueba_log.txt")

    /** The whole log of the last autotest (all its jobs), the newest part if very long. */
    fun fullLog(ctx: Context): String = try { logFile(ctx).readText().takeLast(250_000) } catch (_: Throwable) { "" }

    private fun save(ctx: Context) {
        try {
            val arr = org.json.JSONArray()
            for (it in items) arr.put(org.json.JSONObject().put("n", it.name).put("s", it.state.name).put("d", it.detail).put("ms", it.ms).put("mb", it.peakMb))
            stateFile(ctx).writeText(org.json.JSONObject().put("items", arr).put("t", System.currentTimeMillis()).toString())
        } catch (_: Throwable) { }
    }

    /** Where to go on after the app closed in the middle of a test (-1 = nothing to go on with). */
    @Volatile var resumeAt = -1
        private set

    /** Loads the last run; a test left "running" means the app closed during it: marked as failed. */
    fun load(ctx: Context) {
        if (running || items.isNotEmpty()) return
        try {
            val f = stateFile(ctx); if (!f.exists()) return
            val arr = org.json.JSONObject(f.readText()).getJSONArray("items")
            val its = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Item(o.getString("n")).apply { state = State.valueOf(o.getString("s")); detail = o.optString("d"); ms = o.optLong("ms"); peakMb = o.optInt("mb") }
            }
            val crashed = its.indexOfFirst { it.state == State.RUN }
            if (crashed >= 0) {
                its[crashed].state = State.FAIL
                its[crashed].detail = "la app se cerró durante esta prueba (el informe de cierre sale al abrir la app)"
                resumeAt = crashed + 1
                JobLog.add("Autoprueba: la app se cerró en «${its[crashed].name}»")
            }
            items = its
            save(ctx)
        } catch (_: Throwable) { }
    }

    /** Runs everything (blocking: call from a work thread); [from] > 0 goes on after a closed app. */
    fun runAll(ctx: Context, from: Int = 0) {
        val all = tests() + createTests(ctx) + screenTests()
        val keep = items
        val its = all.mapIndexed { i, t -> if (from > 0 && i < from && i < keep.size && keep[i].name == t.name) keep[i] else Item(t.name) }
        items = its; running = true; stop = false; finishedAt = 0L; resumeAt = -1
        onChange?.invoke()
        JobLog.tee = logFile(ctx).also { if (from == 0) it.writeText(JobLog.deviceLine(ctx) + "\n") }
        JobLog.add("Autoprueba: ${all.size} pruebas" + if (from > 0) " (sigue desde la ${from + 1})" else "")
        (ctx.applicationContext as android.app.Application).registerActivityLifecycleCallbacks(watcher)
        try {
            for ((i, t) in all.withIndex()) {
                if (from > 0 && i < from) continue
                val item = its[i]
                if (stop) { item.state = State.SKIP; item.detail = "detenida"; continue }
                val why = try { t.skip(ctx) } catch (e: Throwable) { "no se pudo comprobar (${e.message})" }
                if (why != null) {
                    item.state = State.SKIP; item.detail = why
                    JobLog.add("Autoprueba – ${t.name}: omitida ($why)")
                    save(ctx); onChange?.invoke(); continue
                }
                if (t.name.startsWith("Pantalla:") || t.name.startsWith("Usar:")) {
                    // the screens run their own work (and its notification)
                    if (BgWork.busy && BgWork.currentTitle() == ctx.getString(R.string.autotest_title)) BgWork.finish(ctx, null)
                }
                HeatGuard.waitIfHot(ctx, { stop }) { d -> item.detail = "esperando a que se enfríe ($d)"; onChange?.invoke() }
                item.state = State.RUN; item.detail = ""
                save(ctx); JobLog.save(ctx); onChange?.invoke()
                System.gc()
                val base = usedMb()
                var peak = base
                val sampler = Thread {
                    try { while (true) { peak = maxOf(peak, usedMb()); Thread.sleep(150) } } catch (_: InterruptedException) { }
                }.apply { isDaemon = true; start() }
                JobLog.add("Autoprueba – ${t.name}: empieza · ${memLine(ctx)}")
                val t0 = SystemClock.elapsedRealtime()
                try {
                    item.detail = t.run(ctx)
                    item.state = State.OK
                } catch (e: Skip) {
                    item.state = State.SKIP; item.detail = e.message ?: ""
                } catch (e: Bad) {
                    item.state = State.FAIL; item.detail = e.message ?: "falló"
                } catch (e: OutOfMemoryError) {
                    item.state = State.FAIL; item.detail = "sin memoria (${e.message?.take(120)})"
                    JobLog.error("Autoprueba – ${t.name}", e)
                } catch (e: Throwable) {
                    item.state = State.FAIL; item.detail = "${e.javaClass.simpleName}: ${e.message?.take(200)}"
                    JobLog.error("Autoprueba – ${t.name}", e)
                }
                item.ms = SystemClock.elapsedRealtime() - t0
                sampler.interrupt()
                item.peakMb = maxOf(peak, usedMb())
                val line = "Autoprueba – ${t.name}: ${when (item.state) { State.OK -> "BIEN"; State.SKIP -> "OMITIDA"; else -> "FALLÓ" }} · ${fmtMs(item.ms)} · " +
                    "memoria máx. ${item.peakMb} MB (antes $base) · ${item.detail}"
                if (item.state == State.FAIL) JobLog.notice(line) else JobLog.add(line)
                save(ctx); onChange?.invoke()
            }
        } finally {
            (ctx.applicationContext as android.app.Application).unregisterActivityLifecycleCallbacks(watcher)
            try { NpuUnet.releaseAll() } catch (_: Throwable) { }
            try { if (SdNative.loadError == null) SdNative.release() } catch (_: Throwable) { }
            running = false; finishedAt = System.currentTimeMillis()
            save(ctx)
            JobLog.add("Autoprueba: " + summary() + " · " + memLine(ctx))
            JobLog.tee = null
            onChange?.invoke()
        }
    }

    fun fmtMs(ms: Long) = if (ms < 1000) "$ms ms" else String.format(Locale.US, "%.1f s", ms / 1000f)

    fun summary(): String {
        val its = items
        return "${its.count { it.state == State.OK }} bien · ${its.count { it.state == State.FAIL }} fallaron · " +
            "${its.count { it.state == State.SKIP }} omitidas"
    }

    /** The results as text (for sharing). */
    fun report(): String = buildString {
        append("Autoprueba de Nítido · ").append(summary()).append('\n')
        for (it in items) {
            val mark = when (it.state) { State.OK -> "✓"; State.FAIL -> "✗"; State.SKIP -> "–"; State.RUN -> "…"; State.WAIT -> "○" }
            append(mark).append(' ').append(it.name)
            if (it.state == State.OK || it.state == State.FAIL) append(" · ").append(fmtMs(it.ms)).append(" · ").append(it.peakMb).append(" MB")
            if (it.detail.isNotEmpty()) append("\n   ").append(it.detail)
            append('\n')
        }
    }
}
