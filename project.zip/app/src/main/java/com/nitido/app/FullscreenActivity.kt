package com.nitido.app

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * ⤢ Full screen: a photo (before/after, with zoom) or a video (the in-app player), black around it,
 * the system bars hidden, and it turns with the phone so a wide video fills the screen.
 */
class FullscreenActivity : AppCompatActivity() {

    private var player: VideoPlayerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).run {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val video = intent.getStringExtra(EXTRA_IMPROVED) ?: intent.getStringExtra(EXTRA_ORIGINAL)
        if (video != null) {
            val p = VideoPlayerView(this)
            player = p
            root.addView(p, FrameLayout.LayoutParams(-1, -1))
            p.swapAtCenter()
            p.setVideos(intent.getStringExtra(EXTRA_IMPROVED)?.let(Uri::parse), intent.getStringExtra(EXTRA_ORIGINAL)?.let(Uri::parse),
                intent.getBooleanExtra(EXTRA_SHOW_IMPROVED, true), savedInstanceState?.getInt("pos") ?: intent.getIntExtra(EXTRA_POS, 0),
                play = savedInstanceState?.getBoolean("playing") ?: true)
        } else {
            val cv = CompareView(this)
            cv.before = images?.first
            cv.after = images?.second
            root.addView(cv, FrameLayout.LayoutParams(-1, -1))
        }
        val d = resources.displayMetrics.density
        // ‹ Volver, at the top left over the picture (the player's own controls start lower)
        root.addView(TextView(this).apply {
            text = "‹"; textSize = 22f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = 12 * d }
            setPadding((14 * d).toInt(), (2 * d).toInt(), (14 * d).toInt(), (4 * d).toInt())
            contentDescription = getString(R.string.fullscreen_back)
            setOnClickListener { finish() }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins((10 * d).toInt(), (10 * d).toInt(), 0, 0)
        })
        setContentView(root)
        JobLog.add("Pantalla completa: " + if (video != null) "video" else "foto")
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        player?.let { out.putInt("pos", it.position()); out.putBoolean("playing", it.isPlaying()) }
    }

    override fun onPause() { super.onPause(); player?.pause() }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && player == null) images = null
    }

    companion object {
        private const val EXTRA_IMPROVED = "improved"
        private const val EXTRA_ORIGINAL = "original"
        private const val EXTRA_SHOW_IMPROVED = "showImproved"
        private const val EXTRA_POS = "pos"
        /** The photo to show (too big for an Intent): before, after. */
        @Volatile private var images: Pair<Bitmap?, Bitmap?>? = null

        fun video(a: Activity, improved: Uri?, original: Uri?, showImproved: Boolean = true, positionMs: Int = 0) {
            if (improved == null && original == null) return
            a.startActivity(Intent(a, FullscreenActivity::class.java)
                .putExtra(EXTRA_IMPROVED, improved?.toString()).putExtra(EXTRA_ORIGINAL, original?.toString())
                .putExtra(EXTRA_SHOW_IMPROVED, showImproved).putExtra(EXTRA_POS, positionMs)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }

        fun photo(a: Activity, before: Bitmap?, after: Bitmap?) {
            if (before == null && after == null) return
            images = before to after
            a.startActivity(Intent(a, FullscreenActivity::class.java))
        }

        /** Adds ⤢ at the top right of the picture's frame; [get] gives (before, after) when pressed. */
        fun addButton(a: Activity, frame: FrameLayout, get: () -> Pair<Bitmap?, Bitmap?>) {
            val d = a.resources.displayMetrics.density
            frame.addView(TextView(a).apply {
                text = "⤢"; textSize = 18f; setTextColor(Color.WHITE)
                background = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = 10 * d }
                setPadding((10 * d).toInt(), (2 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
                contentDescription = a.getString(R.string.fullscreen_open)
                elevation = 4 * d
                setOnClickListener { val (b, af) = get(); photo(a, b, af) }
            }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
                setMargins(0, (10 * d).toInt(), (10 * d).toInt(), 0)
            })
        }
    }
}
