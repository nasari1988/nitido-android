package com.nitido.app

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.TimeUnit

/**
 * Spanish → English on the phone (ML Kit, ~30 MB downloaded once), because the image models only
 * understand English. Text with prompt weights like "(red dress:1.3)" is left as written.
 * Call from a background thread. On any problem the text goes as written.
 */
object Translate {
    private val client by lazy {
        Translation.getClient(TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.SPANISH).setTargetLanguage(TranslateLanguage.ENGLISH).build())
    }

    fun toEnglish(text: String): String {
        val t = text.trim()
        if (t.isEmpty() || Regex(""":\s*\d""").containsMatchIn(t)) return t
        return try {
            Tasks.await(client.downloadModelIfNeeded(DownloadConditions.Builder().build()), 120, TimeUnit.SECONDS)
            val en = Tasks.await(client.translate(t), 30, TimeUnit.SECONDS).trim()
            JobLog.add("Traducido: «$t» → «$en»")
            en.ifEmpty { t }
        } catch (e: Throwable) {
            JobLog.notice("No se pudo traducir (${e.message ?: e.javaClass.simpleName}); va como está escrito")
            t
        }
    }
}
