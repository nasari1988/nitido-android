package com.nitido.app

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.TimeUnit

/**
 * Spanish → English on the phone (ML Kit, ~30 MB downloaded once), because the image models only
 * understand English. Text with prompt weights like "(red dress:1.3)" is left as written.
 * Call from a background thread. On any problem the text goes as written.
 */
object Translate {
    private val client by lazy {
        Translation.getClient(TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.SPANISH).setTargetLanguage(TranslateLanguage.ENGLISH).build())
    }

    fun toEnglish(text: String): String {
        val t = text.trim()
        if (t.isEmpty() || Regex(""":\s*\d""").containsMatchIn(t)) return t
        return try {
            Tasks.await(client.downloadModelIfNeeded(DownloadConditions.Builder().build()), 120, TimeUnit.SECONDS)
            val en = Tasks.await(client.translate(t), 30, TimeUnit.SECONDS).trim()
            JobLog.add("Traducido: «$t» → «$en»")
            en.ifEmpty { t }
        } catch (e: Throwable) {
            JobLog.notice("No se pudo traducir (${e.message ?: e.javaClass.simpleName}); va como está escrito")
            t
        }
    }

    /**
     * For the instruction editor: the English as an order ("make it snowy", "turn the dress into
     * sportswear"), the form the editor was trained on. Spanish wishes ("que nieve", "quiero que…")
     * otherwise come out as statements ("that is snowing") that it barely follows.
     */
    fun toInstruction(text: String): String {
        val t = text.trim()
        if (t.isEmpty() || Regex(""":\s*\d""").containsMatchIn(t)) return t
        // the Spanish wish forms first, so the translator sees an order
        var es = t.replace(Regex("""^(por favor|porfa)[,\s]+""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""^(puedes|podr[ií]as)\s+""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""^(quiero|quisiera|me gustar[ií]a)\s+que\s+""", RegexOption.IGNORE_CASE), "que ")
            .replace(Regex("""^que\s+sea\s+de\s+""", RegexOption.IGNORE_CASE), "hazlo de ")
            .replace(Regex("""^que\s+(nieve|est[eé] nevando)\b""", RegexOption.IGNORE_CASE), "agrega nieve")
            .replace(Regex("""^que\s+(llueva|est[eé] lloviendo)\b""", RegexOption.IGNORE_CASE), "agrega lluvia")
        val en0 = toEnglish(es)
        val en = instructionForm(en0)
        if (en != en0) JobLog.add("Como orden para el editor: «$en»")
        return en
    }

    /** English clean-up into the imperative; also used on text already written in English. */
    fun instructionForm(text: String): String {
        var e = text.trim().trimEnd('.', '!').trim()
        val rules = listOf(
            Regex("""^(please|can you|could you|would you)[,\s]+""", RegexOption.IGNORE_CASE) to "",
            Regex("""^i (want|would like|'d like)( you)? to\s+""", RegexOption.IGNORE_CASE) to "",
            Regex("""^i (want|would like|'d like)\s+(it|him|her|them)\s+to be\s+""", RegexOption.IGNORE_CASE) to "make $2 ",
            Regex("""^i (want|would like|'d like)\s+(a|an|some|the)\s+""", RegexOption.IGNORE_CASE) to "add $2 ",
            Regex("""^(that|let)\s+(it\s+)?(is|be|was)\s+snowing\b""", RegexOption.IGNORE_CASE) to "make it snowy, add snow",
            Regex("""^(that|let)\s+(it\s+)?(is|be|was)\s+raining\b""", RegexOption.IGNORE_CASE) to "make it rainy, add rain",
            Regex("""^(that|let)\s+(it\s+)?(is|be|was)\s+(at\s+)?""", RegexOption.IGNORE_CASE) to "make it ",
            Regex("""^(that|let)\s+(it|he|she|they)\s+(have|has|wear|wears)\s+""", RegexOption.IGNORE_CASE) to "give $2 ",
            Regex("""^that\s+""", RegexOption.IGNORE_CASE) to "",
            Regex("""^change\s+(.+?)\s+(for|by|with|to)\s+(.+)$""", RegexOption.IGNORE_CASE) to "turn $1 into $3",
            Regex("""^replace\s+(.+?)\s+(for|by)\s+(.+)$""", RegexOption.IGNORE_CASE) to "replace $1 with $3",
            Regex("""^put (him|her|them|it)\s+(a|an|some)\s+""", RegexOption.IGNORE_CASE) to "give $1 $2 ",
            Regex("""^(a|an|some)\s+""", RegexOption.IGNORE_CASE) to "add $1 ",
        )
        for ((r, to) in rules) e = r.replace(e, to).trim()
        e = e.replace(Regex("""\bmake it snowing\b""", RegexOption.IGNORE_CASE), "make it snowy")
            .replace(Regex("""\bmake it raining\b""", RegexOption.IGNORE_CASE), "make it rainy")
            .replace(Regex("""^give she\b""", RegexOption.IGNORE_CASE), "give her")
            .replace(Regex("""^give he\b""", RegexOption.IGNORE_CASE), "give him")
            .replace(Regex("""^give they\b""", RegexOption.IGNORE_CASE), "give them")
            .replace(Regex("""\bmake (him|her|them|it)\s+(him|her|them|it)\b""", RegexOption.IGNORE_CASE), "make $1")
        return e.ifEmpty { text.trim() }
    }
}
