package com.nitido.app

/**
 * Reads Android's native crash report ("tombstone"), which ApplicationExitInfo gives as protobuf,
 * and turns the crashing thread into the classic text lines "#00 pc 0000… libx.so (func+off)".
 * Only the few fields needed are decoded (see AOSP system/core/debuggerd/proto/tombstone.proto).
 */
object Tombstone {

    private class Reader(val b: ByteArray, var p: Int, val end: Int) {
        fun more() = p < end
        fun varint(): Long {
            var r = 0L; var s = 0
            while (p < end) {
                val x = b[p++].toInt() and 0xFF
                r = r or ((x and 0x7F).toLong() shl s)
                if (x < 0x80) break
                s += 7
            }
            return r
        }
        /** Returns (field, wireType). */
        fun tag(): Pair<Int, Int> { val t = varint(); return (t ushr 3).toInt() to (t and 7).toInt() }
        fun bytes(): Reader { val n = varint().toInt(); val r = Reader(b, p, p + n); p += n; return r }
        fun string(): String { val n = varint().toInt(); val s = String(b, p, n, Charsets.UTF_8); p += n; return s }
        fun skip(w: Int) {
            when (w) {
                0 -> varint()
                1 -> p += 8
                2 -> { val n = varint().toInt(); p += n }
                5 -> p += 4
                else -> p = end
            }
        }
    }

    private class Frame(var relPc: Long = 0, var fn: String = "", var off: Long = 0, var file: String = "")

    private fun frame(r: Reader): Frame {
        val f = Frame()
        while (r.more()) {
            val (field, w) = r.tag()
            when {
                field == 1 && w == 0 -> f.relPc = r.varint()
                field == 4 && w == 2 -> f.fn = r.string()
                field == 5 && w == 0 -> f.off = r.varint()
                field == 6 && w == 2 -> f.file = r.string()
                else -> r.skip(w)
            }
        }
        return f
    }

    private fun thread(r: Reader): Pair<Long, List<Frame>> {
        var id = 0L
        val frames = ArrayList<Frame>()
        while (r.more()) {
            val (field, w) = r.tag()
            when {
                field == 1 && w == 0 -> id = r.varint()
                field == 4 && w == 2 -> frames += frame(r.bytes())
                else -> r.skip(w)
            }
        }
        return id to frames
    }

    /** Text report, or null if the bytes don't look like a tombstone. */
    fun decode(bytes: ByteArray): String? = try { decodeOrNull(bytes) } catch (t: Throwable) { null }

    private fun decodeOrNull(bytes: ByteArray): String? {
        val r = Reader(bytes, 0, bytes.size)
        var fingerprint = ""
        var tid = -1L
        var signal = ""
        var abort = ""
        val threads = HashMap<Long, List<Frame>>()
        while (r.more()) {
            val (field, w) = r.tag()
            when {
                field == 2 && w == 2 -> fingerprint = r.string()
                field == 6 && w == 0 -> tid = r.varint()
                field == 10 && w == 2 -> {   // Signal: number=1, name=2, code=3, code_name=4, fault_address=9
                    val s = r.bytes(); var name = ""; var code = ""; var addr = -1L
                    while (s.more()) {
                        val (f2, w2) = s.tag()
                        when {
                            f2 == 2 && w2 == 2 -> name = s.string()
                            f2 == 4 && w2 == 2 -> code = s.string()
                            f2 == 9 && w2 == 0 -> addr = s.varint()
                            else -> s.skip(w2)
                        }
                    }
                    signal = "$name $code" + if (addr >= 0) " dirección 0x" + java.lang.Long.toHexString(addr) else ""
                }
                field == 14 && w == 2 -> abort = r.string()
                field == 16 && w == 2 -> {   // map<uint32, Thread>: key=1, value=2
                    val e = r.bytes(); var key = -1L; var t: Pair<Long, List<Frame>>? = null
                    while (e.more()) {
                        val (f2, w2) = e.tag()
                        when {
                            f2 == 1 && w2 == 0 -> key = e.varint()
                            f2 == 2 && w2 == 2 -> t = thread(e.bytes())
                            else -> e.skip(w2)
                        }
                    }
                    t?.let { threads[if (key >= 0) key else it.first] = it.second }
                }
                else -> r.skip(w)
            }
        }
        val frames = threads[tid] ?: threads.values.firstOrNull() ?: return null
        return buildString {
            if (fingerprint.isNotEmpty()) append(fingerprint).append('\n')
            if (signal.isNotBlank()) append(signal.trim()).append('\n')
            if (abort.isNotEmpty()) append("abort: ").append(abort).append('\n')
            frames.take(30).forEachIndexed { i, f ->
                append(String.format("      #%02d pc %016x  %s", i, f.relPc, f.file))
                if (f.fn.isNotEmpty()) append(" (").append(f.fn).append('+').append(f.off).append(')')
                append('\n')
            }
        }
    }
}
