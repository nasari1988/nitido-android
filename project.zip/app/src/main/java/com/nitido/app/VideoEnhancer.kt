package com.nitido.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mejorar video: every frame goes through the same enhancer as Mejorar (on the NPU when chosen),
 * with the phone's own video chip decoding and encoding. Long videos are made in parts of
 * [SEG_US] (10 s), each its own file: if the job is stopped or the phone restarts, it goes on from
 * the last finished part. At the end the parts are joined with the original audio.
 */
class VideoEnhancer(private val ctx: Context, private val src: Uri, val plan: Plan) {

    /** What the job will make; [key] names its folder (same video + same options = same job). */
    data class Plan(
        val key: String, val name: String, val inW: Int, val inH: Int, val rotation: Int,
        val durationUs: Long, val fps: Float, val procW: Int, val procH: Int, val scale: Int,
        val model: String, val engine: Engine, val half: Boolean, val hasAudio: Boolean,
    ) {
        val outW get() = procW * scale
        val outH get() = procH * scale
        val frames get() = max(1, (durationUs / 1e6 * fps).roundToInt())
        val segments get() = max(1, ((durationUs + SEG_US - 1) / SEG_US).toInt())
        val bitrate get() = (outW.toLong() * outH * fps * 0.12f).toLong().coerceIn(2_000_000L, 20_000_000L).toInt()
        /** Bytes the parts plus the final video take while it runs. */
        val spaceBytes get() = bitrate / 8L * (durationUs / 1_000_000L + 1) * 2
    }

    /** One progress report: frames done of all, what is happening, seconds left (or null). */
    class Progress(val done: Int, val total: Int, val text: String, val leftSec: Float?, val paused: Boolean)

    var onProgress: ((Progress) -> Unit)? = null
    /** A processed frame now and then, for the live preview. */
    var onFrame: ((Bitmap) -> Unit)? = null

    private val dir = File(ctx.filesDir, "video/${plan.key}").apply { mkdirs() }

    /** Makes the video; returns the saved video's Uri, or null if stopped ([cancelled]). Throws on errors. */
    fun make(cancelled: () -> Boolean): Uri? {
        File(dir, "plan.json").writeText(JSONObject().apply {
            put("name", plan.name); put("src", src.toString()); put("model", plan.model); put("scale", plan.scale)
            put("engine", plan.engine.name); put("half", plan.half); put("outW", plan.outW); put("outH", plan.outH)
        }.toString())
        val doneParts = (0 until plan.segments).count { File(dir, "seg_%04d.ok".format(it)).exists() }
        JobLog.add("Video ${plan.inW}×${plan.inH} → ${plan.outW}×${plan.outH} · ${"%.1f".format(java.util.Locale.US, plan.durationUs / 1e6)} s · " +
            "${"%.2f".format(java.util.Locale.US, plan.fps)} fps · ${plan.frames} cuadros · ${plan.segments} partes" +
            (if (doneParts > 0) " · $doneParts ya hechas (se continúa)" else "") + (if (plan.half) " · 1 de cada 2 cuadros" else ""))
        if (doneParts < plan.segments) {
            Upscaler(ctx, plan.engine, plan.model).use { up ->
                JobLog.add("Mejorar video con ${plan.model.substringAfterLast('/')} en ${up.engine.label}")
                if (!makeParts(up, cancelled)) return null
            }
        }
        if (cancelled()) return null
        onProgress?.invoke(Progress(plan.frames, plan.frames, ctx.getString(R.string.video_joining), null, false))
        val out = join()
        dir.deleteRecursively()
        return out
    }

    // ───────────────────────── the parts ─────────────────────────

    private var frameMs = -1.0       // average processing time per frame (learned while it runs)
    private var framesDone = 0
    private var lastFrameShown = 0L

    private fun makeParts(up: Upscaler, cancelled: () -> Boolean): Boolean {
        val ex = MediaExtractor().apply { setDataSource(ctx, src, null) }
        try {
            val vt = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }
            ex.selectTrack(vt)
            val inFmt = ex.getTrackFormat(vt)
            val first = (0 until plan.segments).first { !File(dir, "seg_%04d.ok".format(it)).exists() }
            framesDone = (first * SEG_US / 1e6 * plan.fps).roundToInt()
            if (first > 0) ex.seekTo(first * SEG_US, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
            inFmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            dec.configure(inFmt, null, null, 0)
            dec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var part: Part? = null
            try {
                while (true) {
                    if (cancelled()) { part?.abandon(); return false }
                    if (!inputDone) {
                        val ii = dec.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val n = ex.readSampleData(dec.getInputBuffer(ii)!!, 0)
                            if (n < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                            else { dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val oi = dec.dequeueOutputBuffer(info, 10_000)
                    if (oi >= 0) {
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        if (info.size > 0 || !eos) {
                            val pts = info.presentationTimeUs
                            val seg = (pts / SEG_US).toInt().coerceAtMost(plan.segments - 1)
                            val done = File(dir, "seg_%04d.ok".format(seg)).exists()
                            if (!done) {
                                if (part?.index != seg) { part?.finish(); part = Part(seg) }
                                val img = dec.getOutputImage(oi)
                                val frame = img?.let { toBitmap(it) }
                                img?.close()
                                dec.releaseOutputBuffer(oi, false)
                                if (frame != null) part!!.frame(pts, frame, up, cancelled)
                            } else dec.releaseOutputBuffer(oi, false)
                        } else dec.releaseOutputBuffer(oi, false)
                        if (eos) break
                    }
                }
                part?.finish()
                return true
            } finally {
                try { dec.stop() } catch (_: Throwable) { }
                dec.release()
            }
        } finally { ex.release() }
    }

    /** One 10 s part: its own encoder and file. */
    private inner class Part(val index: Int) {
        private val file = File(dir, "seg_%04d.mp4".format(index))
        private val enc: MediaCodec
        private var mux: MediaMuxer? = null
        private var track = -1
        private var firstPts = -1L
        private var count = 0
        private var prev: IntArray? = null
        private var pendingPts = -1L
        private val info = MediaCodec.BufferInfo()

        init {
            file.delete()
            val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, plan.outW, plan.outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, plan.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, plan.fps.roundToInt().coerceAtLeast(1))
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
        }

        fun frame(pts: Long, src: Bitmap, up: Upscaler, cancelled: () -> Boolean) {
            val skip = plan.half && count % 2 == 1
            count++
            if (skip) {
                // made later as the blend of its two neighbours
                pendingPts = pts
                framesDone++
                return
            }
            waitIfHot(cancelled)
            val t0 = SystemClock.elapsedRealtime()
            val small = if (src.width != plan.procW || src.height != plan.procH)
                Bitmap.createScaledBitmap(src, plan.procW, plan.procH, true) else src
            val big = up.upscale(small, plan.scale, {}, cancelled) ?: throw InterruptedException()
            val sized = if (big.width != plan.outW || big.height != plan.outH) Bitmap.createScaledBitmap(big, plan.outW, plan.outH, true) else big
            val px = IntArray(plan.outW * plan.outH)
            sized.getPixels(px, 0, plan.outW, 0, 0, plan.outW, plan.outH)
            val p = prev
            if (pendingPts >= 0 && p != null) { encode(blend(p, px), pendingPts) }
            pendingPts = -1
            encode(px, pts)
            prev = px
            val ms = (SystemClock.elapsedRealtime() - t0).toDouble()
            frameMs = if (frameMs < 0) ms else frameMs * 0.9 + ms * 0.1
            framesDone++
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameShown > 1500) { lastFrameShown = now; onFrame?.invoke(sized) }
            if (framesDone > 2) up.quiet = true
            report(false)
        }

        private fun encode(px: IntArray, pts: Long) {
            if (firstPts < 0) firstPts = pts
            while (true) {
                val ii = enc.dequeueInputBuffer(10_000)
                if (ii >= 0) {
                    val cap = enc.getInputBuffer(ii)?.capacity() ?: (plan.outW * plan.outH * 3 / 2)
                    val img = enc.getInputImage(ii) ?: throw IllegalStateException("el codificador no da imagen")
                    fromArgb(px, plan.outW, plan.outH, img)
                    enc.queueInputBuffer(ii, 0, minOf(cap, plan.outW * plan.outH * 3 / 2), pts, 0)
                    break
                }
                drain(false)
            }
            drain(false)
        }

        private fun drain(end: Boolean) {
            while (true) {
                val oi = enc.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        mux = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also {
                            track = it.addTrack(enc.outputFormat); it.start()
                        }
                    }
                    oi >= 0 -> {
                        val buf = enc.getOutputBuffer(oi)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0 && mux != null) {
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            mux!!.writeSampleData(track, buf, info)
                        }
                        enc.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                    else -> if (!end) return
                }
            }
        }

        fun finish() {
            val p = prev
            if (pendingPts >= 0 && p != null) encode(p, pendingPts)
            pendingPts = -1
            val ii = enc.dequeueInputBuffer(100_000)
            if (ii >= 0) enc.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
            try { enc.stop() } catch (_: Throwable) { }
            enc.release()
            mux?.let { try { it.stop() } catch (_: Throwable) { }; it.release() }
            File(dir, "seg_%04d.json".format(index)).writeText(JSONObject().put("first", firstPts).toString())
            File(dir, "seg_%04d.ok".format(index)).writeText("ok")
            JobLog.add("Parte ${index + 1} de ${plan.segments} lista")
        }

        fun abandon() {
            try { enc.stop() } catch (_: Throwable) { }
            enc.release()
            mux?.let { try { it.stop() } catch (_: Throwable) { }; it.release() }
            file.delete()
        }
    }

    private fun report(paused: Boolean, text: String? = null) {
        val left = if (frameMs > 0) ((plan.frames - framesDone).coerceAtLeast(0) * frameMs / 1000.0 * (if (plan.half) 0.5 else 1.0)).toFloat() else null
        onProgress?.invoke(Progress(framesDone.coerceAtMost(plan.frames), plan.frames,
            text ?: ctx.getString(R.string.video_frame_of, framesDone.coerceAtMost(plan.frames), plan.frames), left, paused))
    }

    // ───────────────────────── heat ─────────────────────────

    private fun temperature(): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private fun hot(): Boolean {
        val pm = ctx.getSystemService(PowerManager::class.java)
        val severe = Build.VERSION.SDK_INT >= 29 && (pm?.currentThermalStatus ?: 0) >= PowerManager.THERMAL_STATUS_SEVERE
        return severe || temperature() >= HOT_C
    }

    /** Pauses while the phone is hot: from [HOT_C] (or the system's "severe") until it is back to [COOL_C]. */
    private fun waitIfHot(cancelled: () -> Boolean) {
        if (!hot()) return
        val t0 = SystemClock.elapsedRealtime()
        JobLog.notice("Pausa por calor: ${"%.0f".format(java.util.Locale.US, temperature())} °C")
        while (!cancelled()) {
            val t = temperature()
            val pm = ctx.getSystemService(PowerManager::class.java)
            val severe = Build.VERSION.SDK_INT >= 29 && (pm?.currentThermalStatus ?: 0) >= PowerManager.THERMAL_STATUS_SEVERE
            if (t <= COOL_C && !severe) break
            report(true, ctx.getString(R.string.video_hot, t.roundToInt(), COOL_C.roundToInt()))
            Thread.sleep(5000)
        }
        JobLog.add("Sigue después de ${(SystemClock.elapsedRealtime() - t0) / 1000} s de pausa por calor")
    }

    // ───────────────────────── joining ─────────────────────────

    private fun join(): Uri {
        val tmp = File(ctx.cacheDir, "video_out.mp4").apply { delete() }
        val mux = MediaMuxer(tmp.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        mux.setOrientationHint(plan.rotation)
        val buf = ByteBuffer.allocateDirect(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var vTrack = -1
        val parts = (0 until plan.segments).map { File(dir, "seg_%04d.mp4".format(it)) }.filter { it.exists() && it.length() > 0 }
        if (parts.isEmpty()) throw IllegalStateException("no salió ningún cuadro del video (el decodificador no entregó imágenes)")
        // the video track's format from the first part (all parts share the same encoder settings)
        MediaExtractor().apply { setDataSource(parts.first().path) }.also { e -> vTrack = mux.addTrack(e.getTrackFormat(0)); e.release() }
        // the original audio, untouched
        var aEx: MediaExtractor? = null
        var aTrack = -1
        if (plan.hasAudio) {
            val e = MediaExtractor().apply { setDataSource(ctx, src, null) }
            val at = (0 until e.trackCount).firstOrNull { e.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
            if (at != null) { e.selectTrack(at); aTrack = mux.addTrack(e.getTrackFormat(at)); aEx = e } else e.release()
        }
        mux.start()
        for ((i, f) in parts.withIndex()) {
            val idx = f.name.substring(4, 8).toInt()
            val first = try { JSONObject(File(dir, "seg_%04d.json".format(idx)).readText()).getLong("first") } catch (t: Throwable) { idx * SEG_US }
            val e = MediaExtractor().apply { setDataSource(f.path) }
            e.selectTrack(0)
            var t0 = -1L
            while (true) {
                val n = e.readSampleData(buf, 0)
                if (n < 0) break
                if (t0 < 0) t0 = e.sampleTime
                info.set(0, n, first + (e.sampleTime - t0), if (e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                mux.writeSampleData(vTrack, buf, info)
                e.advance()
            }
            e.release()
            onProgress?.invoke(Progress(plan.frames, plan.frames, ctx.getString(R.string.video_joining_part, i + 1, parts.size), null, false))
        }
        aEx?.let { e ->
            while (true) {
                val n = e.readSampleData(buf, 0)
                if (n < 0) break
                info.set(0, n, e.sampleTime, if (e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                mux.writeSampleData(aTrack, buf, info)
                e.advance()
            }
            e.release()
        }
        mux.stop(); mux.release()
        // into the gallery: Movies/Nitido
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "${plan.name}_nitido_${System.currentTimeMillis() / 1000}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Nitido")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("la galería no aceptó el video")
        cr.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
        values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
        cr.update(uri, values, null, null)
        JobLog.add("Video guardado: ${ModelCatalog.mb(tmp.length())}")
        // a copy for "Lo último" and the player in the app
        tmp.renameTo(File(ctx.cacheDir, LAST_FILE))
        return uri
    }

    companion object {
        const val SEG_US = 10_000_000L
        const val HOT_C = 44f
        const val COOL_C = 40f
        const val LAST_FILE = "video_last.mp4"
        /** Longest output side and shortest output side (1080p). */
        const val MAX_LONG = 1920
        const val MAX_SHORT = 1080

        /** Reads the video and works out what will be made with these options. */
        fun plan(ctx: Context, uri: Uri, name: String, size: Long, scale: Int, model: String, engine: Engine, half: Boolean): Plan {
            val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
            try {
                val vt = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }
                    ?: throw IllegalArgumentException("el archivo no tiene video")
                val f = ex.getTrackFormat(vt)
                val w = f.getInteger(MediaFormat.KEY_WIDTH)
                val h = f.getInteger(MediaFormat.KEY_HEIGHT)
                val rot = if (f.containsKey("rotation-degrees")) f.getInteger("rotation-degrees") else 0
                val dur = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else 0L
                val fps = if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) try { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() } catch (t: Throwable) { f.getFloat(MediaFormat.KEY_FRAME_RATE) } else 30f
                val audio = (0 until ex.trackCount).any { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                // the frame as stored (rotation is kept as a flag): fit the output in 1080p
                val long = max(w, h); val short = min(w, h)
                val k = minOf(1f, MAX_LONG.toFloat() / (long * scale), MAX_SHORT.toFloat() / (short * scale))
                var pw = ((w * k) / 8).toInt() * 8
                var ph = ((h * k) / 8).toInt() * 8
                // the encoder has to accept the size
                while (!encoderTakes(pw * scale, ph * scale) && pw > 64 && ph > 64) { pw -= 8; ph = ((pw.toFloat() * h / w) / 8).toInt() * 8 }
                val key = (name + "|" + size + "|" + scale + "|" + model + "|" + engine.name + "|" + half).hashCode().toUInt().toString(16)
                return Plan(key, name.substringBeforeLast('.'), w, h, rot, dur, if (fps in 1f..240f) fps else 30f, pw, ph, scale, model, engine, half, audio)
            } finally { ex.release() }
        }

        private fun encoderTakes(w: Int, h: Int): Boolean = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, true) } &&
                    ci.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC).videoCapabilities.isSizeSupported(w, h)
            }
        } catch (t: Throwable) { true }

        /** Parts already made for this plan (to offer "continue"). */
        fun partsDone(ctx: Context, p: Plan) = (0 until p.segments).count { File(ctx.filesDir, "video/${p.key}/seg_%04d.ok".format(it)).exists() }

        /** Estimated seconds: the NPU did Mejorar at ~3.8 µs per input pixel (measured on this phone). */
        fun estimateSec(p: Plan): Float {
            val perFrame = 0.12f + p.procW * p.procH * (if (p.engine == Engine.NPU) 3.8e-6f else 1.6e-5f) * (if (p.model == Upscaler.MODEL_X4PLUS) 0.85f else 1f)
            return p.frames * perFrame * (if (p.half) 0.55f else 1f)
        }

        // ───────── YUV <-> ARGB ─────────

        /** A decoded frame (YUV 4:2:0, any layout) as a Bitmap. The planes are copied out in one go (fast). */
        fun toBitmap(img: Image): Bitmap {
            val w = img.width; val h = img.height
            val y = img.planes[0]; val u = img.planes[1]; val v = img.planes[2]
            val ya = ByteArray(y.buffer.remaining()).also { y.buffer.get(it) }
            val ua = ByteArray(u.buffer.remaining()).also { u.buffer.get(it) }
            val va = ByteArray(v.buffer.remaining()).also { v.buffer.get(it) }
            val yr = y.rowStride; val ys = y.pixelStride
            val ur = u.rowStride; val us = u.pixelStride
            val vr = v.rowStride; val vs = v.pixelStride
            val out = IntArray(w * h)
            for (j in 0 until h) {
                val yRow = j * yr; val uRow = (j shr 1) * ur; val vRow = (j shr 1) * vr; val o = j * w
                for (i in 0 until w) {
                    val yy = (ya[yRow + i * ys].toInt() and 0xFF) - 16
                    val ci = i shr 1
                    val uu = (ua[uRow + ci * us].toInt() and 0xFF) - 128
                    val vv = (va[vRow + ci * vs].toInt() and 0xFF) - 128
                    val c = 298 * yy
                    var r = (c + 409 * vv + 128) shr 8; if (r < 0) r = 0 else if (r > 255) r = 255
                    var g = (c - 100 * uu - 208 * vv + 128) shr 8; if (g < 0) g = 0 else if (g > 255) g = 255
                    var b = (c + 516 * uu + 128) shr 8; if (b < 0) b = 0 else if (b > 255) b = 255
                    out[o + i] = -0x1000000 or (r shl 16) or (g shl 8) or b
                }
            }
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        }

        /** ARGB pixels into the encoder's input image (YUV 4:2:0, BT.601 video range), built in arrays and copied in one go. */
        fun fromArgb(px: IntArray, w: Int, h: Int, img: Image) {
            val y = img.planes[0]; val u = img.planes[1]; val v = img.planes[2]
            val yr = y.rowStride; val ys = y.pixelStride
            val ur = u.rowStride; val us = u.pixelStride
            val vr = v.rowStride; val vs = v.pixelStride
            val yb = y.buffer; val ub = u.buffer; val vb = v.buffer
            val ya = ByteArray(yb.remaining()); val ua = ByteArray(ub.remaining()); val va = ByteArray(vb.remaining())
            for (j in 0 until h) {
                val row = j * yr; val o = j * w
                for (i in 0 until w) {
                    val p = px[o + i]
                    val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
                    val k = row + i * ys
                    if (k < ya.size) ya[k] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte()
                }
            }
            for (j in 0 until h / 2) {
                val o0 = 2 * j * w; val o1 = o0 + w
                for (i in 0 until w / 2) {
                    // the average of the 2×2 pixels
                    val a = px[o0 + 2 * i]; val b2 = px[o0 + 2 * i + 1]; val c = px[o1 + 2 * i]; val d = px[o1 + 2 * i + 1]
                    val r = (((a shr 16) and 0xFF) + ((b2 shr 16) and 0xFF) + ((c shr 16) and 0xFF) + ((d shr 16) and 0xFF)) shr 2
                    val g = (((a shr 8) and 0xFF) + ((b2 shr 8) and 0xFF) + ((c shr 8) and 0xFF) + ((d shr 8) and 0xFF)) shr 2
                    val bb = ((a and 0xFF) + (b2 and 0xFF) + (c and 0xFF) + (d and 0xFF)) shr 2
                    val ku = j * ur + i * us; val kv = j * vr + i * vs
                    if (ku < ua.size) ua[ku] = (((-38 * r - 74 * g + 112 * bb + 128) shr 8) + 128).toByte()
                    if (kv < va.size) va[kv] = (((112 * r - 94 * g - 18 * bb + 128) shr 8) + 128).toByte()
                }
            }
            // NV12 layout (U and V interleaved in one buffer): writing U then V over the same bytes
            // would undo each other, so only the planes' own bytes are written (their pixel stride)
            val pos = yb.position(); yb.put(ya); yb.position(pos)
            if (us == 2 && vs == 2) {
                // interleaved: put the bytes one by one at their own places (U at even, V at odd offsets)
                for (j in 0 until h / 2) for (i in 0 until w / 2) {
                    val ku = j * ur + i * us; val kv = j * vr + i * vs
                    if (ku < ub.limit()) ub.put(ku, ua[ku])
                    if (kv < vb.limit()) vb.put(kv, va[kv])
                }
            } else {
                val pu = ub.position(); ub.put(ua); ub.position(pu)
                val pv = vb.position(); vb.put(va); vb.position(pv)
            }
        }

        fun blend(a: IntArray, b: IntArray): IntArray = IntArray(a.size) { i ->
            val x = a[i]; val y = b[i]
            // per channel average, without carries between channels
            (0xFF shl 24) or ((((x and 0xFEFEFE) + (y and 0xFEFEFE)) ushr 1) and 0xFFFFFF)
        }
    }
}
