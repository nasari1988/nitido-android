package com.nitido.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mejorar video: every frame goes through the same enhancer as Mejorar (on the NPU), with the
 * phone's own video chip decoding and encoding. Long videos are made in parts of [SEG_US] (10 s),
 * each its own file: if the job is stopped or the phone restarts, it goes on from the last
 * finished part. At the end the parts are joined with the original audio (and its date).
 *
 * Per frame: (deinterlace) → (grain: blend with the previous frame where nothing moves) →
 * enhance → (color adjustments + sharpness) → (anti-flicker) → encode (on its own thread).
 */
class VideoEnhancer(private val ctx: Context, private val src: Uri, val plan: Plan) {

    /** What the job will make; [key] names its folder (same video + same options = same job). */
    data class Plan(
        val key: String, val name: String, val inW: Int, val inH: Int, val rotation: Int,
        val startUs: Long, val endUs: Long, val fullUs: Long, val fps: Float, val procW: Int, val procH: Int, val scale: Int,
        val model: String, val engine: Engine, val half: Boolean, val hasAudio: Boolean,
        val adjust: PhotoAdjust.Values, val antiFlicker: Boolean, val denoise: Boolean, val deinterlace: Boolean,
        val hevc: Boolean, val bt709: Boolean, val srcBitrate: Int,
    ) {
        val durationUs get() = endUs - startUs
        val outW get() = procW * scale
        val outH get() = procH * scale
        val frames get() = max(1, (durationUs / 1e6 * fps).roundToInt())
        val segments get() = max(1, ((durationUs + SEG_US - 1) / SEG_US).toInt())
        /** Like the original's quality (scaled to the new size), at least 0.2 bit per pixel; H.265 needs ~35% less. */
        val bitrate get(): Int {
            val outPx = outW.toLong() * outH
            val fromSrc = if (srcBitrate > 0) srcBitrate.toLong() * outPx / max(1L, inW.toLong() * inH) else 0L
            val floor = (outPx * fps * 0.2f).toLong()
            val b = max(fromSrc, floor) * (if (hevc) 65 else 100) / 100
            return b.coerceIn(2_000_000L, 40_000_000L).toInt()
        }
        /** Bytes the parts plus the final video take while it runs. */
        val spaceBytes get() = bitrate / 8L * (durationUs / 1_000_000L + 1) * 2
        /** The output is hardly bigger than the video already is (a 1080p video, say). */
        val littleGain get() = outW * outH < inW.toLong() * inH * 1.3
    }

    /** A decoded frame: its pixels and size. */
    class Frame(val px: IntArray, val w: Int, val h: Int)

    /** One progress report: frames done of all, what is happening, seconds left (or null). */
    class Progress(val done: Int, val total: Int, val text: String, val leftSec: Float?, val paused: Boolean)

    var onProgress: ((Progress) -> Unit)? = null
    /** A processed frame now and then, for the live preview. */
    var onFrame: ((Bitmap) -> Unit)? = null

    private val dir = File(ctx.filesDir, "video/${plan.key}").apply { mkdirs() }

    /** Makes the video; returns the saved video's Uri, or null if stopped ([cancelled]). Throws on errors. */
    fun make(cancelled: () -> Boolean): Uri? {
        File(dir, "plan.json").writeText(JSONObject().apply {
            put("name", plan.name); put("src", src.toString()); put("model", plan.model); put("scale", plan.scale)
            put("outW", plan.outW); put("outH", plan.outH); put("start", plan.startUs); put("end", plan.endUs)
        }.toString())
        val doneParts = (0 until plan.segments).count { File(dir, "seg_%04d.ok".format(it)).exists() }
        JobLog.add("Video ${plan.inW}×${plan.inH} → ${plan.outW}×${plan.outH} · ${fmt(plan.durationUs / 1e6, 1)} s" +
            (if (plan.startUs > 0 || plan.endUs < plan.fullUs) " (de ${fmt(plan.startUs / 1e6, 1)} a ${fmt(plan.endUs / 1e6, 1)} s)" else "") +
            " · ${fmt(plan.fps.toDouble(), 2)} fps · ${plan.frames} cuadros · ${plan.segments} partes" +
            (if (doneParts > 0) " · $doneParts ya hechas (se continúa)" else ""))
        JobLog.add("Opciones: ${plan.model.substringAfterLast('/')} · " + listOfNotNull(
            if (plan.half) "1 de cada 2 cuadros" else null, if (plan.antiFlicker) "anti-parpadeo" else null,
            if (plan.denoise) "quitar grano" else null, if (plan.deinterlace) "desentrelazar" else null,
            if (!plan.adjust.isNeutral) "ajustes ${plan.adjust}" else null,
            (if (plan.hevc) "H.265" else "H.264") + " ${plan.bitrate / 1_000_000} Mbps",
            if (plan.bt709) "color BT.709" else "color BT.601",
        ).joinToString(" · "))
        if (doneParts < plan.segments) {
            openUpscaler().use { up ->
                JobLog.add("Mejorar video con ${up.modelName} en ${up.engine.label}")
                if (!makeParts(up, cancelled)) return null
            }
        }
        if (cancelled()) return null
        onProgress?.invoke(Progress(plan.frames, plan.frames, ctx.getString(R.string.video_joining), null, false))
        val out = join()
        dir.deleteRecursively()
        return out
    }

    /** Ultrarrápido runs only on the NPU: if the NPU says no, Rápido on the GPU. */
    private fun openUpscaler(): Upscaler = openUpscaler(ctx, plan)

    // ───────────────────────── the parts ─────────────────────────

    private var frameMs = -1.0       // average processing time per frame (learned while it runs)
    private var framesDone = 0
    private var lastFrameShown = 0L
    private var lastLogged = 0L
    /** The frame filters' memory (previous frames). */
    private val filters = Filters(plan)

    private fun makeParts(up: Upscaler, cancelled: () -> Boolean): Boolean {
        val ex = MediaExtractor().apply { setDataSource(ctx, src, null) }
        val encoder = Executors.newSingleThreadExecutor()
        try {
            val vt = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }
            ex.selectTrack(vt)
            val inFmt = ex.getTrackFormat(vt)
            val first = (0 until plan.segments).first { !File(dir, "seg_%04d.ok".format(it)).exists() }
            framesDone = (first * SEG_US / 1e6 * plan.fps).roundToInt()
            val seekTo = plan.startUs + first * SEG_US
            if (seekTo > 0) ex.seekTo(seekTo, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
            inFmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            dec.configure(inFmt, null, null, 0)
            dec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var part: Part? = null
            try {
                while (true) {
                    if (cancelled()) { part?.abandon(); return false }
                    if (!inputDone) {
                        val ii = dec.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val n = ex.readSampleData(dec.getInputBuffer(ii)!!, 0)
                            if (n < 0 || ex.sampleTime >= plan.endUs + 500_000) {
                                dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true
                            } else { dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val oi = dec.dequeueOutputBuffer(info, 10_000)
                    if (oi >= 0) {
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        val pts = info.presentationTimeUs
                        val inRange = info.size > 0 && pts >= plan.startUs && pts < plan.endUs
                        val seg = ((pts - plan.startUs) / SEG_US).toInt().coerceIn(0, plan.segments - 1)
                        if (inRange && !File(dir, "seg_%04d.ok".format(seg)).exists()) {
                            if (part?.index != seg) { part?.finish(); part = Part(seg, encoder) }
                            val img = dec.getOutputImage(oi)
                            val frame = img?.let { toFrame(it, plan.bt709) }
                            img?.close()
                            dec.releaseOutputBuffer(oi, false)
                            if (frame != null) part!!.frame(pts - plan.startUs, frame, up, cancelled)
                        } else dec.releaseOutputBuffer(oi, false)
                        if (eos) break
                    }
                }
                part?.finish()
                return true
            } finally {
                try { dec.stop() } catch (_: Throwable) { }
                dec.release()
            }
        } finally {
            ex.release()
            encoder.shutdown()
        }
    }

    /** One 10 s part: its own encoder and file. The encoder works on its own thread (in parallel with the NPU). */
    private inner class Part(val index: Int, private val worker: java.util.concurrent.ExecutorService) {
        private val file = File(dir, "seg_%04d.mp4".format(index))
        private val mime = if (plan.hevc && encoderTakes(MediaFormat.MIMETYPE_VIDEO_HEVC, plan.outW, plan.outH))
            MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        private val enc: MediaCodec
        private var mux: MediaMuxer? = null
        private var track = -1
        private var firstPts = -1L
        private var count = 0
        private var prev: IntArray? = null
        private var pendingPts = -1L
        private val info = MediaCodec.BufferInfo()
        private val inFlight = ArrayDeque<Future<*>>()

        init {
            file.delete()
            val f = MediaFormat.createVideoFormat(mime, plan.outW, plan.outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, plan.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, plan.fps.roundToInt().coerceAtLeast(1))
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                // tell players which color formula the pixels use (HD videos: BT.709)
                setInteger(MediaFormat.KEY_COLOR_STANDARD, if (plan.bt709) MediaFormat.COLOR_STANDARD_BT709 else MediaFormat.COLOR_STANDARD_BT601_NTSC)
                setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
                setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            }
            enc = MediaCodec.createEncoderByType(mime)
            enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            if (index == 0 || firstPart) { firstPart = false; JobLog.add("Codificando en ${if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "H.265" else "H.264"} a ${plan.bitrate / 1_000_000} Mbps") }
        }

        fun frame(pts: Long, src: Frame, up: Upscaler, cancelled: () -> Boolean) {
            val skip = plan.half && count % 2 == 1
            count++
            if (skip) {
                // made later as the blend of its two neighbours
                pendingPts = pts
                framesDone++
                return
            }
            waitIfHot(cancelled)
            val t0 = SystemClock.elapsedRealtime()
            val px = filters.process(src, up, cancelled) ?: throw InterruptedException()
            val p = prev
            if (pendingPts >= 0 && p != null) submit(blend(p, px), pendingPts)
            pendingPts = -1
            submit(px, pts)
            prev = px
            val ms = (SystemClock.elapsedRealtime() - t0).toDouble()
            frameMs = if (frameMs < 0) ms else frameMs * 0.9 + ms * 0.1
            framesDone++
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameShown > 1500) {
                lastFrameShown = now
                onFrame?.invoke(Bitmap.createBitmap(px, plan.outW, plan.outH, Bitmap.Config.ARGB_8888))
            }
            if (framesDone > 2) up.quiet = true
            report(false)
        }

        /** Encoding on the encoder's thread; at most two frames waiting (memory). */
        private fun submit(px: IntArray, pts: Long) {
            while (inFlight.size >= 2) inFlight.removeFirst().get()
            inFlight.addLast(worker.submit(Runnable { encode(px, pts) }))
        }

        private fun encode(px: IntArray, pts: Long) {
            if (firstPts < 0) firstPts = pts
            while (true) {
                val ii = enc.dequeueInputBuffer(10_000)
                if (ii >= 0) {
                    val cap = enc.getInputBuffer(ii)?.capacity() ?: (plan.outW * plan.outH * 3 / 2)
                    val img = enc.getInputImage(ii) ?: throw IllegalStateException("el codificador no da imagen")
                    fromArgb(px, plan.outW, plan.outH, img, plan.bt709)
                    enc.queueInputBuffer(ii, 0, minOf(cap, plan.outW * plan.outH * 3 / 2), pts, 0)
                    break
                }
                drain(false)
            }
            drain(false)
        }

        private fun drain(end: Boolean) {
            while (true) {
                val oi = enc.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        mux = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also {
                            track = it.addTrack(enc.outputFormat); it.start()
                        }
                    }
                    oi >= 0 -> {
                        val buf = enc.getOutputBuffer(oi)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0 && mux != null) {
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            mux!!.writeSampleData(track, buf, info)
                        }
                        enc.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                    else -> if (!end) return
                }
            }
        }

        fun finish() {
            val p = prev
            if (pendingPts >= 0 && p != null) submit(p, pendingPts)
            pendingPts = -1
            worker.submit(Runnable {
                val ii = enc.dequeueInputBuffer(100_000)
                if (ii >= 0) enc.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                drain(true)
                try { enc.stop() } catch (_: Throwable) { }
                enc.release()
                mux?.let { try { it.stop() } catch (_: Throwable) { }; it.release() }
            }).get()
            inFlight.clear()
            File(dir, "seg_%04d.json".format(index)).writeText(JSONObject().put("first", firstPts).toString())
            File(dir, "seg_%04d.ok".format(index)).writeText("ok")
            JobLog.add("Parte ${index + 1} de ${plan.segments} lista" +
                (if (frameMs > 0) " · ${fmt(frameMs / 1000, 2)} s por cuadro" else ""))
        }

        fun abandon() {
            try { worker.submit(Runnable { try { enc.stop() } catch (_: Throwable) { }; enc.release(); mux?.let { try { it.stop() } catch (_: Throwable) { }; it.release() } }).get() } catch (_: Throwable) { }
            file.delete()
        }
    }

    private var firstPart = true

    private fun report(paused: Boolean, text: String? = null) {
        val left = if (frameMs > 0) ((plan.frames - framesDone).coerceAtLeast(0) * frameMs / 1000.0 * (if (plan.half) 0.5 else 1.0)).toFloat() else null
        onProgress?.invoke(Progress(framesDone.coerceAtMost(plan.frames), plan.frames,
            text ?: ctx.getString(R.string.video_frame_of, framesDone.coerceAtMost(plan.frames), plan.frames), left, paused))
    }

    // ───────────────────────── heat ─────────────────────────

    private fun temperature(): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    }

    private fun severe(): Boolean {
        val pm = ctx.getSystemService(PowerManager::class.java)
        return Build.VERSION.SDK_INT >= 29 && (pm?.currentThermalStatus ?: 0) >= PowerManager.THERMAL_STATUS_SEVERE
    }

    /** Pauses while the phone is hot: from [HOT_C] (or the system's "severe") until it is back to [COOL_C]. */
    private fun waitIfHot(cancelled: () -> Boolean) {
        if (!severe() && temperature() < HOT_C) return
        val t0 = SystemClock.elapsedRealtime()
        JobLog.notice("Pausa por calor: ${fmt(temperature().toDouble(), 0)} °C")
        while (!cancelled()) {
            val t = temperature()
            if (t <= COOL_C && !severe()) break
            report(true, ctx.getString(R.string.video_hot, t.roundToInt(), COOL_C.roundToInt()))
            Thread.sleep(5000)
        }
        JobLog.add("Sigue después de ${(SystemClock.elapsedRealtime() - t0) / 1000} s de pausa por calor")
    }

    // ───────────────────────── joining ─────────────────────────

    private fun join(): Uri {
        val tmp = File(ctx.cacheDir, "video_out.mp4").apply { delete() }
        val mux = MediaMuxer(tmp.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        mux.setOrientationHint(plan.rotation)
        // the original's place and date go to the new video
        var dateMs = 0L
        try {
            MediaMetadataRetriever().apply {
                setDataSource(ctx, src)
                extractMetadata(MediaMetadataRetriever.METADATA_KEY_LOCATION)?.let { loc ->
                    Regex("([+-]\\d+\\.\\d+)([+-]\\d+\\.\\d+)").find(loc)?.let { m ->
                        mux.setLocation(m.groupValues[1].toFloat(), m.groupValues[2].toFloat())
                    }
                }
                extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE)?.let { d ->
                    for (pat in listOf("yyyyMMdd'T'HHmmss.SSS'Z'", "yyyyMMdd'T'HHmmss'Z'", "yyyyMMdd'T'HHmmss")) {
                        try { dateMs = java.text.SimpleDateFormat(pat, Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.parse(d)!!.time; break } catch (_: Throwable) { }
                    }
                }
                release()
            }
        } catch (_: Throwable) { }
        val buf = ByteBuffer.allocateDirect(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        val parts = (0 until plan.segments).map { File(dir, "seg_%04d.mp4".format(it)) }.filter { it.exists() && it.length() > 0 }
        if (parts.isEmpty()) throw IllegalStateException("no salió ningún cuadro del video (el decodificador no entregó imágenes)")
        // the video track's format from the first part (all parts share the same encoder settings)
        var vTrack = -1
        MediaExtractor().apply { setDataSource(parts.first().path) }.also { e -> vTrack = mux.addTrack(e.getTrackFormat(0)); e.release() }
        // the original audio, untouched (only the chosen piece)
        var aEx: MediaExtractor? = null
        var aTrack = -1
        if (plan.hasAudio) {
            val e = MediaExtractor().apply { setDataSource(ctx, src, null) }
            val at = (0 until e.trackCount).firstOrNull { e.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
            if (at != null) {
                e.selectTrack(at); aTrack = mux.addTrack(e.getTrackFormat(at)); aEx = e
                if (plan.startUs > 0) e.seekTo(plan.startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            } else e.release()
        }
        mux.start()
        for ((i, f) in parts.withIndex()) {
            val idx = f.name.substring(4, 8).toInt()
            val first = try { JSONObject(File(dir, "seg_%04d.json".format(idx)).readText()).getLong("first") } catch (t: Throwable) { idx * SEG_US }
            val e = MediaExtractor().apply { setDataSource(f.path) }
            e.selectTrack(0)
            var t0 = -1L
            while (true) {
                val n = e.readSampleData(buf, 0)
                if (n < 0) break
                if (t0 < 0) t0 = e.sampleTime
                info.set(0, n, first + (e.sampleTime - t0), if (e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                mux.writeSampleData(vTrack, buf, info)
                e.advance()
            }
            e.release()
            onProgress?.invoke(Progress(plan.frames, plan.frames, ctx.getString(R.string.video_joining_part, i + 1, parts.size), null, false))
        }
        aEx?.let { e ->
            while (true) {
                val n = e.readSampleData(buf, 0)
                if (n < 0) break
                val t = e.sampleTime
                if (t >= plan.endUs) break
                if (t >= plan.startUs) {
                    info.set(0, n, t - plan.startUs, if (e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mux.writeSampleData(aTrack, buf, info)
                }
                e.advance()
            }
            e.release()
        }
        mux.stop(); mux.release()
        // into the gallery: Movies/Nitido, with the original's date so it sorts next to it
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "${plan.name}_nitido_${System.currentTimeMillis() / 1000}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Nitido")
            put(MediaStore.Video.Media.IS_PENDING, 1)
            if (dateMs > 0) put(MediaStore.Video.Media.DATE_TAKEN, dateMs + plan.startUs / 1000)
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("la galería no aceptó el video")
        cr.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
        values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
        if (dateMs > 0) values.put(MediaStore.Video.Media.DATE_TAKEN, dateMs + plan.startUs / 1000)
        cr.update(uri, values, null, null)
        JobLog.add("Video guardado: ${ModelCatalog.mb(tmp.length())}" + if (dateMs > 0) " · con la fecha del original" else "")
        // a copy for "Lo último" and the comparison in the app
        File(ctx.cacheDir, LAST_FILE).delete()
        tmp.renameTo(File(ctx.cacheDir, LAST_FILE))
        return uri
    }

    // ───────────────────────── the frame filters ─────────────────────────

    /** What happens to each frame, with the memory of the previous ones (grain, anti-flicker). */
    class Filters(private val plan: Plan) {
        private var prevIn: IntArray? = null
        private var prevOut: IntArray? = null

        /** A decoded frame (ARGB, the video's size) → the finished frame (ARGB, the output size), or null if stopped. */
        fun process(f: Frame, up: Upscaler, cancelled: () -> Boolean): IntArray? {
            var px = f.px
            if (plan.deinterlace) px = deinterlace(px, f.w, f.h)
            var small = Bitmap.createBitmap(px, f.w, f.h, Bitmap.Config.ARGB_8888)
            if (small.width != plan.procW || small.height != plan.procH) small = Bitmap.createScaledBitmap(small, plan.procW, plan.procH, true)
            if (plan.denoise) {
                val a = IntArray(plan.procW * plan.procH)
                small.getPixels(a, 0, plan.procW, 0, 0, plan.procW, plan.procH)
                val p = prevIn
                val d = if (p != null) temporal(a, p, 14, 1) else a
                prevIn = d
                small = Bitmap.createBitmap(d, plan.procW, plan.procH, Bitmap.Config.ARGB_8888)
            }
            var big = up.upscale(small, plan.scale, {}, cancelled) ?: return null
            if (big.width != plan.outW || big.height != plan.outH) big = Bitmap.createScaledBitmap(big, plan.outW, plan.outH, true)
            if (!plan.adjust.isNeutral) big = PhotoAdjust.apply(big, plan.adjust, cancelled) ?: return null
            val out = IntArray(plan.outW * plan.outH)
            big.getPixels(out, 0, plan.outW, 0, 0, plan.outW, plan.outH)
            if (plan.antiFlicker) {
                val p = prevOut
                val r = if (p != null) temporal(out, p, 10, 0) else out
                prevOut = r
                return r
            }
            return out
        }
    }

    companion object {
        const val SEG_US = 10_000_000L
        const val HOT_C = 44f
        const val COOL_C = 40f
        const val LAST_FILE = "video_last.mp4"
        /** Longest output side and shortest output side (1080p). */
        const val MAX_LONG = 1920
        const val MAX_SHORT = 1080

        private fun fmt(v: Double, d: Int) = String.format(Locale.US, "%.${d}f", v)

        fun openUpscaler(ctx: Context, plan: Plan): Upscaler =
            if (plan.model == Upscaler.MODEL_QSR) {
                try { Upscaler(ctx, Engine.NPU, Upscaler.MODEL_QSR) } catch (t: Throwable) {
                    JobLog.notice("Ultrarrápido no abrió en la NPU (${t.message}); se usa Rápido")
                    Upscaler(ctx, plan.engine, Upscaler.MODEL_FILE)
                }
            } else Upscaler(ctx, plan.engine, plan.model)

        /** Reads the video and works out what will be made with these options. */
        fun plan(ctx: Context, uri: Uri, name: String, size: Long, scale: Int, model: String, engine: Engine, half: Boolean,
                 startUs: Long, endUs: Long, adjust: PhotoAdjust.Values, antiFlicker: Boolean, denoise: Boolean,
                 deinterlace: Boolean, hevc: Boolean): Plan {
            val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
            try {
                val vt = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }
                    ?: throw IllegalArgumentException("el archivo no tiene video")
                val f = ex.getTrackFormat(vt)
                val w = f.getInteger(MediaFormat.KEY_WIDTH)
                val h = f.getInteger(MediaFormat.KEY_HEIGHT)
                val rot = if (f.containsKey("rotation-degrees")) f.getInteger("rotation-degrees") else 0
                val dur = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else 0L
                val fps = if (f.containsKey(MediaFormat.KEY_FRAME_RATE)) try { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() } catch (t: Throwable) { f.getFloat(MediaFormat.KEY_FRAME_RATE) } else 30f
                val audio = (0 until ex.trackCount).any { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                // HD videos use the BT.709 color formula (said in the file, or by size)
                val std = if (f.containsKey(MediaFormat.KEY_COLOR_STANDARD)) f.getInteger(MediaFormat.KEY_COLOR_STANDARD) else 0
                val bt709 = if (std != 0) std == MediaFormat.COLOR_STANDARD_BT709 else min(w, h) >= 720
                var br = if (f.containsKey(MediaFormat.KEY_BIT_RATE)) f.getInteger(MediaFormat.KEY_BIT_RATE) else 0
                if (br <= 0) br = try {
                    MediaMetadataRetriever().run { setDataSource(ctx, uri); val v = extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0; release(); v }
                } catch (t: Throwable) { 0 }
                // the frame as stored (rotation is kept as a flag): fit the output in 1080p
                val long = max(w, h); val short = min(w, h)
                val k = minOf(1f, MAX_LONG.toFloat() / (long * scale), MAX_SHORT.toFloat() / (short * scale))
                var pw = ((w * k) / 8).toInt() * 8
                var ph = ((h * k) / 8).toInt() * 8
                // the encoder has to accept the size
                val mime = if (hevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
                while (!encoderTakes(mime, pw * scale, ph * scale) && !encoderTakes(MediaFormat.MIMETYPE_VIDEO_AVC, pw * scale, ph * scale) && pw > 64 && ph > 64) {
                    pw -= 8; ph = ((pw.toFloat() * h / w) / 8).toInt() * 8
                }
                val s0 = startUs.coerceIn(0, max(0, dur - 500_000))
                val e0 = (if (endUs <= 0) dur else endUs).coerceIn(s0 + 500_000, max(s0 + 500_000, dur))
                val key = listOf(name, size, scale, model, engine.name, half, s0 / 100_000, e0 / 100_000, adjust, antiFlicker, denoise, deinterlace, hevc)
                    .joinToString("|").hashCode().toUInt().toString(16)
                return Plan(key, name.substringBeforeLast('.'), w, h, rot, s0, e0, dur, if (fps in 1f..240f) fps else 30f, pw, ph,
                    scale, model, engine, half, audio, adjust, antiFlicker, denoise, deinterlace, hevc, bt709, br)
            } finally { ex.release() }
        }

        fun encoderTakes(mime: String, w: Int, h: Int): Boolean = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } &&
                    ci.getCapabilitiesForType(mime).videoCapabilities.isSizeSupported(w, h)
            }
        } catch (t: Throwable) { mime == MediaFormat.MIMETYPE_VIDEO_AVC }

        /** Parts already made for this plan (to offer "continue"). */
        fun partsDone(ctx: Context, p: Plan) = (0 until p.segments).count { File(ctx.filesDir, "video/${p.key}/seg_%04d.ok".format(it)).exists() }

        /**
         * Estimated seconds. Measured on this phone: Mejorar on the NPU ~3.8 µs per input pixel
         * (a 536×960 frame took ~2 s); Ultrarrápido is ~8× lighter.
         */
        fun estimateSec(p: Plan): Float {
            val perPx = when {
                p.model == Upscaler.MODEL_QSR -> 0.5e-6f
                p.engine == Engine.NPU -> 3.8e-6f
                else -> 1.6e-5f
            }
            val perFrame = 0.15f + p.procW * p.procH * perPx + (if (!p.adjust.isNeutral) 0.08f else 0f)
            return p.frames * perFrame * (if (p.half) 0.55f else 1f)
        }

        /** Combing in a frame (an interlaced video): lines differ from their neighbours far more than from lines two away. */
        fun looksInterlaced(b: Bitmap): Boolean {
            val w = b.width; val h = b.height
            if (h < 8) return false
            val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
            var near = 0L; var far = 0L
            for (y in 1 until h - 2 step 2) for (x in 0 until w step 3) {
                val g0 = (px[(y - 1) * w + x] shr 8) and 0xFF; val g1 = (px[y * w + x] shr 8) and 0xFF; val g2 = (px[(y + 1) * w + x] shr 8) and 0xFF
                near += abs(2 * g1 - g0 - g2); far += abs(g0 - g2)
            }
            return far > 0 && near > far * 3 && near > w.toLong() * h / 6
        }

        // ───────── per-pixel helpers ─────────

        /** Blends each line with its neighbours (1-2-1): the combing of interlaced video goes away. */
        fun deinterlace(px: IntArray, w: Int, h: Int): IntArray {
            val o = IntArray(px.size)
            for (y in 0 until h) {
                val a = (if (y > 0) y - 1 else y) * w; val c = y * w; val d = (if (y < h - 1) y + 1 else y) * w
                for (x in 0 until w) {
                    val p0 = px[a + x]; val p1 = px[c + x]; val p2 = px[d + x]
                    val r = (((p0 shr 16) and 0xFF) + 2 * ((p1 shr 16) and 0xFF) + ((p2 shr 16) and 0xFF)) shr 2
                    val g = (((p0 shr 8) and 0xFF) + 2 * ((p1 shr 8) and 0xFF) + ((p2 shr 8) and 0xFF)) shr 2
                    val b = ((p0 and 0xFF) + 2 * (p1 and 0xFF) + (p2 and 0xFF)) shr 2
                    o[c + x] = -0x1000000 or (r shl 16) or (g shl 8) or b
                }
            }
            return o
        }

        /**
         * Where a pixel barely changed from the previous frame (by less than [th] per channel), it
         * keeps part of the previous one: grain and shimmer settle, real motion is left alone.
         * [mode] 0: half and half (anti-flicker); 1: two thirds new, one third old (grain).
         */
        fun temporal(cur: IntArray, prev: IntArray, th: Int, mode: Int): IntArray {
            val o = IntArray(cur.size)
            for (i in cur.indices) {
                val c = cur[i]; val p = prev[i]
                val cr = (c shr 16) and 0xFF; val cg = (c shr 8) and 0xFF; val cb = c and 0xFF
                val pr = (p shr 16) and 0xFF; val pg = (p shr 8) and 0xFF; val pb = p and 0xFF
                if (abs(cr - pr) < th && abs(cg - pg) < th && abs(cb - pb) < th) {
                    o[i] = if (mode == 0) -0x1000000 or (((cr + pr) shr 1) shl 16) or (((cg + pg) shr 1) shl 8) or ((cb + pb) shr 1)
                    else -0x1000000 or (((2 * cr + pr) / 3) shl 16) or (((2 * cg + pg) / 3) shl 8) or ((2 * cb + pb) / 3)
                } else o[i] = c
            }
            return o
        }

        // ───────── YUV <-> ARGB (BT.601 or BT.709, video range) ─────────

        /** A decoded frame (YUV 4:2:0, any layout, only its visible part) as ARGB pixels. Planes are copied out in one go (fast). */
        fun toFrame(img: Image, bt709: Boolean): Frame {
            val crop = img.cropRect
            val x0 = crop.left and 1.inv(); val y0 = crop.top and 1.inv()
            val w = crop.width(); val h = crop.height()
            val y = img.planes[0]; val u = img.planes[1]; val v = img.planes[2]
            val ya = ByteArray(y.buffer.remaining()).also { y.buffer.get(it) }
            val ua = ByteArray(u.buffer.remaining()).also { u.buffer.get(it) }
            val va = ByteArray(v.buffer.remaining()).also { v.buffer.get(it) }
            val yr = y.rowStride; val ys = y.pixelStride
            val ur = u.rowStride; val us = u.pixelStride
            val vr = v.rowStride; val vs = v.pixelStride
            // ×256 coefficients
            val kRV = if (bt709) 459 else 409
            val kGU = if (bt709) 55 else 100
            val kGV = if (bt709) 136 else 208
            val kBU = if (bt709) 541 else 516
            val out = IntArray(w * h)
            for (j in 0 until h) {
                val sy = j + y0
                val yRow = sy * yr; val uRow = (sy shr 1) * ur; val vRow = (sy shr 1) * vr; val o = j * w
                for (i in 0 until w) {
                    val sx = i + x0
                    val yy = (ya[yRow + sx * ys].toInt() and 0xFF) - 16
                    val ci = sx shr 1
                    val uu = (ua[uRow + ci * us].toInt() and 0xFF) - 128
                    val vv = (va[vRow + ci * vs].toInt() and 0xFF) - 128
                    val c = 298 * yy
                    var r = (c + kRV * vv + 128) shr 8; if (r < 0) r = 0 else if (r > 255) r = 255
                    var g = (c - kGU * uu - kGV * vv + 128) shr 8; if (g < 0) g = 0 else if (g > 255) g = 255
                    var b = (c + kBU * uu + 128) shr 8; if (b < 0) b = 0 else if (b > 255) b = 255
                    out[o + i] = -0x1000000 or (r shl 16) or (g shl 8) or b
                }
            }
            return Frame(out, w, h)
        }

        /** ARGB pixels into the encoder's input image (YUV 4:2:0, video range), built in arrays and copied in one go. */
        fun fromArgb(px: IntArray, w: Int, h: Int, img: Image, bt709: Boolean) {
            val y = img.planes[0]; val u = img.planes[1]; val v = img.planes[2]
            val yr = y.rowStride; val ys = y.pixelStride
            val ur = u.rowStride; val us = u.pixelStride
            val vr = v.rowStride; val vs = v.pixelStride
            val yb = y.buffer; val ub = u.buffer; val vb = v.buffer
            val ya = ByteArray(yb.remaining()); val ua = ByteArray(ub.remaining()); val va = ByteArray(vb.remaining())
            val yR = if (bt709) 47 else 66; val yG = if (bt709) 157 else 129; val yB = if (bt709) 16 else 25
            val uR = if (bt709) -26 else -38; val uG = if (bt709) -87 else -74
            val vG = if (bt709) -102 else -94; val vB = if (bt709) -10 else -18
            for (j in 0 until h) {
                val row = j * yr; val o = j * w
                for (i in 0 until w) {
                    val p = px[o + i]
                    val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
                    val k = row + i * ys
                    if (k < ya.size) ya[k] = (((yR * r + yG * g + yB * b + 128) shr 8) + 16).toByte()
                }
            }
            for (j in 0 until h / 2) {
                val o0 = 2 * j * w; val o1 = o0 + w
                for (i in 0 until w / 2) {
                    // the average of the 2×2 pixels
                    val a = px[o0 + 2 * i]; val b2 = px[o0 + 2 * i + 1]; val c = px[o1 + 2 * i]; val d = px[o1 + 2 * i + 1]
                    val r = (((a shr 16) and 0xFF) + ((b2 shr 16) and 0xFF) + ((c shr 16) and 0xFF) + ((d shr 16) and 0xFF)) shr 2
                    val g = (((a shr 8) and 0xFF) + ((b2 shr 8) and 0xFF) + ((c shr 8) and 0xFF) + ((d shr 8) and 0xFF)) shr 2
                    val bb = ((a and 0xFF) + (b2 and 0xFF) + (c and 0xFF) + (d and 0xFF)) shr 2
                    val ku = j * ur + i * us; val kv = j * vr + i * vs
                    if (ku < ua.size) ua[ku] = (((uR * r + uG * g + 112 * bb + 128) shr 8) + 128).toByte()
                    if (kv < va.size) va[kv] = (((112 * r + vG * g + vB * bb + 128) shr 8) + 128).toByte()
                }
            }
            val pos = yb.position(); yb.put(ya); yb.position(pos)
            if (us == 2 && vs == 2) {
                // interleaved (NV12/NV21): U and V share bytes, so each is put at its own place
                for (j in 0 until h / 2) for (i in 0 until w / 2) {
                    val ku = j * ur + i * us; val kv = j * vr + i * vs
                    if (ku < ub.limit()) ub.put(ku, ua[ku])
                    if (kv < vb.limit()) vb.put(kv, va[kv])
                }
            } else {
                val pu = ub.position(); ub.put(ua); ub.position(pu)
                val pv = vb.position(); vb.put(va); vb.position(pv)
            }
        }

        fun blend(a: IntArray, b: IntArray): IntArray = IntArray(a.size) { i ->
            val x = a[i]; val y = b[i]
            // per channel average, without carries between channels
            -0x1000000 or ((((x and 0xFEFEFE) + (y and 0xFEFEFE)) ushr 1) and 0xFFFFFF)
        }
    }
}
