package com.nitido.app

import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Mis resultados: what Nítido saved (Pictures/Nitido and Movies/Nitido), newest first, with
 * Todo / Fotos / Videos / Creadas. Tap = see it big (videos play here); hold = choose several to
 * share or delete. Optionally behind the fingerprint (Ajustes).
 */
class ResultsActivity : AppCompatActivity() {

    private class Item(val uri: Uri, val video: Boolean, val name: String, val date: Long, val durationMs: Long)

    private var all = listOf<Item>()
    private var shown = listOf<Item>()
    private var filter = 0
    private val chosen = LinkedHashSet<Uri>()
    private val thumbs = android.util.LruCache<Uri, Bitmap>(120)
    private lateinit var grid: RecyclerView
    private lateinit var empty: TextView
    private lateinit var selBar: LinearLayout
    private lateinit var selText: TextView
    private val filterChips = mutableListOf<TextView>()

    private val deleter = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == RESULT_OK) { chosen.clear(); load() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true
            setPadding(Ui.dp(context, 12), Ui.dp(context, 8), Ui.dp(context, 12), Ui.dp(context, 8))
        }
        val head = Ui.row(this)
        head.addView(Ui.text(this, "←", 22f).apply { setPadding(Ui.dp(context, 6), Ui.dp(context, 6), Ui.dp(context, 14), Ui.dp(context, 6)); setOnClickListener { finish() } })
        head.addView(Ui.text(this, getString(R.string.home_results), 19f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
        if (Prefs.lockResults(this)) head.addView(Ui.text(this, "🔒", 16f))
        col.addView(head)
        val chips = Ui.chipRow(this)
        listOf(R.string.res_all, R.string.res_photos, R.string.res_videos, R.string.res_created).forEachIndexed { i, l ->
            val c = Ui.chip(this, getString(l), i == 0) { filter = i; filterChips.forEachIndexed { k, v -> Ui.setChip(v, k == i) }; applyFilter() }
            filterChips += c; chips.addView(c)
        }
        col.addView(chips, Ui.lp(this, 6))
        // choosing several: N elegidos · Compartir · Borrar · ✕
        selBar = Ui.row(this).apply { visibility = View.GONE; setPadding(0, Ui.dp(context, 6), 0, Ui.dp(context, 2)) }
        selText = Ui.text(this, "", 14f)
        selBar.addView(selText, LinearLayout.LayoutParams(0, -2, 1f))
        selBar.addView(Ui.outlineButton(this, getString(R.string.res_share)) { share() })
        selBar.addView(Ui.outlineButton(this, getString(R.string.res_delete)) { delete() }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = Ui.dp(this, 6) })
        selBar.addView(Ui.text(this, "✕", 18f).apply { setPadding(Ui.dp(context, 12), 0, Ui.dp(context, 4), 0); setOnClickListener { chosen.clear(); refreshSel() } })
        col.addView(selBar)
        grid = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(context, 3)
            adapter = Adapter()
            visibility = View.INVISIBLE
        }
        col.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = Ui.dp(this, 6) })
        empty = Ui.text(this, "", 14f, R.color.muted).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        col.addView(empty, Ui.lp(this, 0))
        col.addView(Ui.text(this, getString(R.string.res_hint), 12f, R.color.muted).apply { gravity = Gravity.CENTER }, Ui.lp(this, 6))
        setContentView(col)
        if (Prefs.lockResults(this)) unlock() else { grid.visibility = View.VISIBLE; load() }
    }

    /** Fingerprint, face or the phone's PIN; nothing is shown until then. */
    private fun unlock() {
        val auth = if (Build.VERSION.SDK_INT >= 30) BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            else BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            // no lock set on the phone: nothing to check against
            JobLog.notice("Mis resultados: el teléfono no tiene huella ni PIN; se abre sin pedirlo")
            grid.visibility = View.VISIBLE; load(); return
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.res_lock_title))
            .setSubtitle(getString(R.string.res_lock_sub))
            .setAllowedAuthenticators(auth)
            .apply { if (Build.VERSION.SDK_INT < 30) setNegativeButtonText(getString(android.R.string.cancel)) }
            .build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { grid.visibility = View.VISIBLE; load() }
            override fun onAuthenticationError(code: Int, msg: CharSequence) { finish() }
        }).authenticate(info)
    }

    private fun load() {
        lifecycleScope.launch {
            all = withContext(Dispatchers.IO) { query() }
            applyFilter()
        }
    }

    private fun query(): List<Item> {
        val out = mutableListOf<Item>()
        fun scan(base: Uri, path: String, video: Boolean) = try {
            val cols = mutableListOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED)
            if (video) cols += MediaStore.Video.Media.DURATION
            contentResolver.query(base, cols.toTypedArray(), "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$path%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) out += Item(ContentUris.withAppendedId(base, c.getLong(0)), video, c.getString(1) ?: "", c.getLong(2),
                    if (video) c.getLong(3) else 0L)
            }
        } catch (t: Throwable) { JobLog.error("Mis resultados", t) }
        scan(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "Pictures/Nitido", false)
        scan(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/Nitido", true)
        return out.sortedByDescending { it.date }
    }

    private fun applyFilter() {
        shown = when (filter) {
            1 -> all.filter { !it.video }
            2 -> all.filter { it.video }
            3 -> all.filter { !it.video && (it.name.startsWith("nitido_ia_") || it.name.startsWith("nitido_editada_")) }
            else -> all
        }
        grid.adapter?.notifyDataSetChanged()
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        empty.text = getString(if (all.isEmpty()) R.string.res_none else R.string.res_none_here)
        refreshSel()
    }

    private fun refreshSel() {
        selBar.visibility = if (chosen.isEmpty()) View.GONE else View.VISIBLE
        selText.text = getString(R.string.res_chosen, chosen.size)
        grid.adapter?.notifyDataSetChanged()
    }

    private fun open(it: Item) {
        if (it.video) FullscreenActivity.video(this, it.uri, null)
        else lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    android.graphics.ImageDecoder.decodeBitmap(android.graphics.ImageDecoder.createSource(contentResolver, it.uri)) { d, info, _ ->
                        d.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = maxOf(info.size.width, info.size.height)
                        if (long > 4096) { val k = 4096f / long; d.setTargetSize((info.size.width * k).toInt(), (info.size.height * k).toInt()) }
                    }
                } catch (t: Throwable) { null }
            }
            if (bmp != null) FullscreenActivity.photo(this@ResultsActivity, null, bmp)
        }
    }

    private fun share() {
        if (chosen.isEmpty()) return
        val uris = ArrayList(chosen)
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
            else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        val anyVideo = all.any { it.uri in chosen && it.video }; val anyPhoto = all.any { it.uri in chosen && !it.video }
        i.type = when { anyVideo && anyPhoto -> "*/*"; anyVideo -> "video/*"; else -> "image/*" }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, getString(R.string.res_share)))
    }

    private fun delete() {
        if (chosen.isEmpty()) return
        val uris = ArrayList(chosen)
        if (Build.VERSION.SDK_INT >= 30) {
            // Android asks the user itself (one confirmation for all)
            val req = MediaStore.createDeleteRequest(contentResolver, uris)
            deleter.launch(IntentSenderRequest.Builder(req.intentSender).build())
        } else com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setMessage(getString(R.string.res_delete_ask, uris.size))
            .setPositiveButton(R.string.res_delete) { _, _ ->
                for (u in uris) try { contentResolver.delete(u, null, null) } catch (t: Throwable) { JobLog.error("Borrar", t) }
                chosen.clear(); load()
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.H>() {
        inner class H(val box: FrameLayout, val img: ImageView, val tag: TextView, val check: TextView) : RecyclerView.ViewHolder(box)

        override fun getItemCount() = shown.size

        override fun onCreateViewHolder(parent: ViewGroup, type: Int): H {
            val side = (parent.width - Ui.dp(parent.context, 8)) / 3
            val box = FrameLayout(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(-1, if (side > 0) side else Ui.dp(context, 110)).apply { setMargins(Ui.dp(context, 2), Ui.dp(context, 2), Ui.dp(context, 2), Ui.dp(context, 2)) }
                background = Ui.round(context, Ui.color(context, R.color.stage), 8)
                clipToOutline = true
            }
            val img = ImageView(parent.context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            box.addView(img, FrameLayout.LayoutParams(-1, -1))
            val tag = Ui.text(parent.context, "", 11f).apply {
                setTextColor(Color.WHITE); setPadding(Ui.dp(context, 6), Ui.dp(context, 2), Ui.dp(context, 6), Ui.dp(context, 2))
                background = Ui.round(context, 0x99000000.toInt(), 6)
            }
            box.addView(tag, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(Ui.dp(parent.context, 4), 0, 0, Ui.dp(parent.context, 4)) })
            val check = Ui.text(parent.context, "✓", 16f, R.color.on_accent, true).apply {
                gravity = Gravity.CENTER; background = Ui.round(context, Ui.color(context, R.color.accent), 14)
            }
            box.addView(check, FrameLayout.LayoutParams(Ui.dp(parent.context, 28), Ui.dp(parent.context, 28), Gravity.TOP or Gravity.END).apply { setMargins(0, Ui.dp(parent.context, 4), Ui.dp(parent.context, 4), 0) })
            return H(box, img, tag, check)
        }

        override fun onBindViewHolder(h: H, pos: Int) {
            val it = shown[pos]
            h.tag.visibility = if (it.video) View.VISIBLE else View.GONE
            h.tag.text = "▶ " + (it.durationMs / 1000).let { s -> "${s / 60}:%02d".format(s % 60) }
            h.check.visibility = if (it.uri in chosen) View.VISIBLE else View.GONE
            h.box.alpha = if (chosen.isNotEmpty() && it.uri !in chosen) 0.7f else 1f
            h.img.setImageBitmap(thumbs.get(it.uri))
            if (thumbs.get(it.uri) == null) {
                h.img.tag = it.uri
                lifecycleScope.launch {
                    val b = withContext(Dispatchers.IO) { try { contentResolver.loadThumbnail(it.uri, Size(320, 320), null) } catch (t: Throwable) { null } }
                    if (b != null) { thumbs.put(it.uri, b); if (h.img.tag == it.uri) h.img.setImageBitmap(b) }
                }
            }
            h.box.setOnClickListener { _ ->
                if (chosen.isNotEmpty()) { if (!chosen.remove(it.uri)) chosen.add(it.uri); refreshSel() } else open(it)
            }
            h.box.setOnLongClickListener { _ -> if (!chosen.remove(it.uri)) chosen.add(it.uri); refreshSel(); true }
        }
    }
}
