package com.nitido.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ajustes › Autoprueba: one button that tries every installed tool with made-up pictures
 * ([SelfTest]); each row shows ✓ / ✗ / –, the time and the memory used, and the whole result
 * (with the log) can be shared in one go.
 */
class AutoTestActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private lateinit var start: com.google.android.material.button.MaterialButton
    private lateinit var share: com.google.android.material.button.MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 16), Ui.dp(context, 8), Ui.dp(context, 16), Ui.dp(context, 24))
        }
        val head = Ui.row(this)
        head.addView(Ui.text(this, "←", 22f).apply { setPadding(Ui.dp(context, 6), Ui.dp(context, 6), Ui.dp(context, 14), Ui.dp(context, 6)); setOnClickListener { finish() } })
        head.addView(Ui.text(this, getString(R.string.autotest_title), 19f, bold = true))
        col.addView(head)
        col.addView(Ui.text(this, getString(R.string.autotest_note), 13f, R.color.muted), Ui.lp(this, 8))
        start = Ui.bigButton(this, getString(R.string.autotest_start)) { begin() }
        col.addView(start, Ui.lp(this, 16))
        summary = Ui.text(this, "", 14f, bold = true)
        col.addView(summary, Ui.lp(this, 14))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list, Ui.lp(this, 6))
        share = Ui.outlineButton(this, getString(R.string.autotest_share)) { shareReport() }
        col.addView(share, Ui.lp(this, 16))
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col) })
        render()
    }

    override fun onResume() {
        super.onResume()
        SelfTest.onChange = { runOnUiThread { if (!isDestroyed) render() } }
        render()
    }

    override fun onPause() {
        super.onPause()
        SelfTest.onChange = null
    }

    private fun begin() {
        if (SelfTest.running) { SelfTest.stop = true; start.text = getString(R.string.autotest_stopping); return }
        if (BgWork.busy) { android.widget.Toast.makeText(this, R.string.set_free_busy, android.widget.Toast.LENGTH_SHORT).show(); return }
        val app = applicationContext
        BgWork.start(this, getString(R.string.autotest_title), AutoTestActivity::class.java) { SelfTest.stop = true }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        BgWork.scope.launch {
            withContext(Dispatchers.Default) {
                try { SelfTest.runAll(app) } catch (t: Throwable) { JobLog.error("Autoprueba", t) }
            }
            BgWork.finish(app, app.getString(R.string.autotest_done, SelfTest.summary()))
            runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); render() }
        }
        render()
    }

    private fun render() {
        val its = SelfTest.items
        start.text = getString(when { SelfTest.running && SelfTest.stop -> R.string.autotest_stopping; SelfTest.running -> R.string.stop
            its.isNotEmpty() -> R.string.autotest_again; else -> R.string.autotest_start })
        summary.text = when {
            its.isEmpty() -> ""
            SelfTest.running -> getString(R.string.autotest_running, its.count { it.state != SelfTest.State.WAIT && it.state != SelfTest.State.RUN }, its.size)
            else -> SelfTest.summary()
        }
        Ui.gone(share, its.isEmpty() || SelfTest.running)
        list.removeAllViews()
        for (it in its) {
            val row = Ui.row(this)
            val (mark, color) = when (it.state) {
                SelfTest.State.OK -> "✓" to R.color.accent
                SelfTest.State.FAIL -> "✗" to R.color.bad
                SelfTest.State.SKIP -> "–" to R.color.muted
                SelfTest.State.RUN -> "◌" to R.color.fg
                SelfTest.State.WAIT -> "○" to R.color.muted
            }
            row.addView(Ui.text(this, mark, 17f, color, bold = true).apply { minWidth = Ui.dp(context, 26) })
            row.addView(Ui.text(this, it.name, 15f, if (it.state == SelfTest.State.SKIP) R.color.muted else R.color.fg),
                LinearLayout.LayoutParams(0, -2, 1f))
            val right = when (it.state) {
                SelfTest.State.OK, SelfTest.State.FAIL -> SelfTest.fmtMs(it.ms) + " · " + it.peakMb + " MB"
                SelfTest.State.RUN -> getString(R.string.autotest_now)
                else -> ""
            }
            row.addView(Ui.text(this, right, 12f, R.color.muted))
            list.addView(row, Ui.lp(this, 10))
            if (it.detail.isNotEmpty())
                list.addView(Ui.text(this, it.detail, 12f, if (it.state == SelfTest.State.FAIL) R.color.bad else R.color.muted).apply {
                    setPadding(Ui.dp(context, 26), 0, 0, 0)
                })
        }
    }

    private fun shareReport() {
        val t = SelfTest.report() + "\n\n" + LogDialog.text(this)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, getString(R.string.autotest_title))
            putExtra(Intent.EXTRA_TEXT, t)
        }
        try { startActivity(Intent.createChooser(send, getString(R.string.report_choose))) } catch (e: Throwable) { LogDialog.show(this) }
    }
}
