package com.nitido.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import android.content.Context
import android.os.Process
import android.os.SystemClock
import android.system.Os
import android.util.Log
import org.json.JSONArray
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.TensorInfo
import android.util.Half
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer

/**
 * Runs a model's UNet on the Qualcomm NPU (Hexagon) with ONNX Runtime's QNN execution provider.
 *
 * The NPU needs fixed sizes, so there is one compiled session per picture size. The first time a
 * size is used, QNN compiles the model for this phone's NPU (takes a while) and the result is kept
 * in the app's files, so later runs start in seconds. The session stays open between pictures
 * (see [get]) and is closed with [releaseAll] when leaving the screen or switching models.
 */
class NpuUnet private constructor(private val ctx: Context, val dir: File) : SdNative.NpuUnet {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var session: OrtSession? = null
    private var shape = ""
    private var profiling = false
    private var steps = 0
    private var stepMs = 0L
    @Volatile var lastError: String? = null
        private set
    /** Short summary for the screen: where the time went, load time, step time. */
    @Volatile var report: String? = null
        private set

    private val model = File(dir, "unet_npu.onnx")
    /** Compiled for the NPU in the server (QAIRT): the phone only loads it. */
    private val precompiled = File(dir, "unet_npu_ctx.onnx")

    private fun cacheFile(h: Int, w: Int) = File(dir, "qnn_ctx_${w * 8}x${h * 8}.onnx")

    /** True once this size was compiled for the NPU (next runs start fast). */
    fun isCompiled(width: Int, height: Int) = precompiled.exists() || cacheFile(height / 8, width / 8).exists()

    private fun open(h: Int, w: Int): OrtSession {
        val key = "${h}x$w"
        session?.let { if (shape == key) return it }
        close()
        prepareDsp(ctx)
        val cache = cacheFile(h, w)
        val opts = OrtSession.SessionOptions()
        opts.setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
        // the few ops the NPU lacks run on the CPU; the heavy rest stays on the NPU
        opts.addConfigEntry("session.disable_cpu_ep_fallback", "0")
        opts.setIntraOpNumThreads(4)
        opts.setSymbolicDimensionValue("h", h.toLong())
        opts.setSymbolicDimensionValue("w", w.toLong())
        // time per operation and where it ran (NPU or CPU), for the first step only
        val prof = File(ctx.cacheDir, "npu_prof").path
        opts.enableProfiling(prof)
        opts.addQnn(mapOf(
            "backend_path" to "libQnnHtp.so",
            "htp_performance_mode" to "burst",
            "htp_graph_finalization_optimization_mode" to "3",
            "enable_htp_fp16_precision" to "1",
        ))
        val t0 = SystemClock.elapsedRealtime()
        val fromCache = cache.exists() || precompiled.exists()
        val s = try {
            if (precompiled.exists()) env.createSession(precompiled.path, opts)
            else if (cache.exists()) env.createSession(cache.path, opts) else {
                // compile for this phone's NPU and keep the result next to the model
                opts.addConfigEntry("ep.context_enable", "1")
                opts.addConfigEntry("ep.context_embed_mode", "0")
                opts.addConfigEntry("ep.context_file_path", cache.path)
                env.createSession(model.path, opts)
            }
        } catch (t: Throwable) {
            if (cache.exists() && !precompiled.exists()) { cache.delete() }   // a bad cache: compile again next time
            throw t
        }
        val loadS = (SystemClock.elapsedRealtime() - t0) / 1000
        session = s
        shape = key
        profiling = true
        steps = 0
        stepMs = 0
        report = "carga ${loadS}s (${if (fromCache) "ya preparada" else "preparada ahora; guardada=" + (if (cache.exists()) "sí" else "no")})"
        return s
    }

    override fun run(sample: FloatArray, channels: Int, timestep: Int, h: Int, emb: FloatArray, out: FloatArray): Boolean {
        return try {
            val w = sample.size / (2 * channels * h)
            val s = open(h, w)
            val embDim = emb.size / (2 * 77)
            val t0 = SystemClock.elapsedRealtime()
            val names = s.inputNames.toList()
            fun pick(vararg keys: String) = names.firstOrNull { n -> keys.any { n.contains(it, true) } } ?: keys[0]
            val nSample = pick("sample"); val nTime = pick("timestep", "time"); val nEmb = pick("encoder", "hidden")
            val tS = floatTensor(s, nSample, sample, longArrayOf(2, channels.toLong(), h.toLong(), w.toLong()))
            val tT = timeTensor(s, nTime, timestep)
            val tE = floatTensor(s, nEmb, emb, longArrayOf(2, 77, embDim.toLong()))
            try {
                s.run(mapOf(nSample to tS, nTime to tT, nEmb to tE)).use { r ->
                    val o = r.get(0) as OnnxTensor
                    val qo = quant[s.outputNames.first()]
                    if (qo != null) dequant(qo, o, out)
                    else if ((o.info as TensorInfo).type == OnnxJavaType.FLOAT16) {
                        val bb = o.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                        for (i in out.indices) out[i] = Half.toFloat(bb.get(i))
                    } else o.floatBuffer.get(out, 0, out.size)
                }
            } finally { tS.close(); tT.close(); tE.close() }
            steps++
            stepMs += SystemClock.elapsedRealtime() - t0
            if (profiling) {
                profiling = false
                try { summarize(s.endProfiling()) } catch (t: Throwable) { Log.w("Nitido", "NPU profile", t) }
            }
            true
        } catch (t: Throwable) {
            lastError = (t.message ?: t.javaClass.simpleName) + qnnLog()
            Log.e("Nitido", "NPU", t)
            false
        }
    }

    private fun typeOf(s: OrtSession, name: String): OnnxJavaType? =
        (s.inputInfo[name]?.info as? TensorInfo)?.type

    /** Quantized NPU tensors (W8A16 graphs): name -> (QNN type, scale, offset), from the server's JSON. */
    private class Quant(val type: Int, val scale: Float, val offset: Int)
    private val quant: Map<String, Quant> by lazy {
        try {
            val j = org.json.JSONObject(File(dir, "unet_npu_ctx.onnx.json").readText()).optJSONObject("quant")
                ?: return@lazy emptyMap()
            j.keys().asSequence().mapNotNull { k ->
                val q = j.getJSONObject(k)
                if (!q.has("scale")) null else k to Quant(q.getInt("qnn_type"), q.getDouble("scale").toFloat(), q.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }
    }

    /** float -> the NPU's integers: q = round(x / scale) - offset (QNN: x = scale * (q + offset)). */
    private fun quantTensor(q: Quant, data: FloatArray, shape: LongArray): OnnxTensor {
        val inv = 1f / q.scale
        return if (q.type == 0x0408 || q.type == 0x0308) {
            val bb = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
            val lo = if (q.type == 0x0408) 0 else -128; val hi = if (q.type == 0x0408) 255 else 127
            for (v in data) bb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toByte())
            bb.rewind()
            OnnxTensor.createTensor(env, bb, shape, if (q.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
        } else {
            val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
            val sb = bb.asShortBuffer()
            val lo = if (q.type == 0x0416) 0 else -32768; val hi = if (q.type == 0x0416) 65535 else 32767
            for (v in data) sb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toShort())
            OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
        }
    }

    private fun dequant(q: Quant, o: OnnxTensor, out: FloatArray) {
        val bb = o.byteBuffer.order(ByteOrder.nativeOrder())
        if (q.type == 0x0408 || q.type == 0x0308) {
            for (i in out.indices) { val b = bb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0408) b and 0xFF else b) + q.offset) }
        } else {
            val sb = bb.asShortBuffer()
            for (i in out.indices) { val v = sb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0416) v and 0xFFFF else v) + q.offset) }
        }
    }

    /** A float input, in fp16 when the NPU graph takes fp16. */
    private fun floatTensor(s: OrtSession, name: String, data: FloatArray, shape: LongArray): OnnxTensor {
        quant[name]?.let { return quantTensor(it, data, shape) }
        if (typeOf(s, name) != OnnxJavaType.FLOAT16) return OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)
        val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
        val sb = bb.asShortBuffer()
        for (v in data) sb.put(Half.toHalf(v))
        return OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.FLOAT16)
    }

    private fun timeTensor(s: OrtSession, name: String, t: Int): OnnxTensor = if (quant[name] != null)
        quantTensor(quant[name]!!, floatArrayOf(t.toFloat()), longArrayOf(1)) else when (typeOf(s, name)) {
        OnnxJavaType.FLOAT -> OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArrayOf(t.toFloat())), longArrayOf(1))
        OnnxJavaType.FLOAT16 -> floatTensor(s, name, floatArrayOf(t.toFloat()), longArrayOf(1))
        OnnxJavaType.INT64 -> OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(longArrayOf(t.toLong())), longArrayOf(1))
        else -> OnnxTensor.createTensor(env, IntBuffer.wrap(intArrayOf(t)), longArrayOf(1))
    }

    /** Where the first step's time went: NPU (QNN) vs CPU, and the heaviest CPU operations. */
    private fun summarize(path: String) {
        val f = File(path)
        val arr = JSONArray(f.readText())
        f.delete()
        var npu = 0L; var cpu = 0L; var nNpu = 0; var nCpu = 0
        val cpuOps = HashMap<String, Long>()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            if (e.optString("cat") != "Node") continue
            val args = e.optJSONObject("args") ?: continue
            val prov = args.optString("provider")
            if (!e.optString("name").endsWith("_kernel_time")) continue
            val dur = e.optLong("dur")
            if (prov.startsWith("QNN")) { npu += dur; nNpu++ } else {
                cpu += dur; nCpu++
                val op = args.optString("op_name")
                cpuOps[op] = (cpuOps[op] ?: 0L) + dur
            }
        }
        val tot = (npu + cpu).coerceAtLeast(1)
        val top = cpuOps.entries.sortedByDescending { it.value }.take(4).joinToString(", ") { "${it.key} ${it.value * 100 / tot}%" }
        report = (report ?: "") + " · tiempo NPU ${npu * 100 / tot}% ($nNpu partes) / CPU ${cpu * 100 / tot}% ($nCpu partes)" +
            (if (top.isNotEmpty()) " · CPU: $top" else "") + qnnLog()
    }

    /** Average step time, once a few steps ran. */
    fun stepSummary(): String? = if (steps > 0) "paso ${"%.1f".format(stepMs / 1000f / steps)} s" else null

    fun close() {
        try { session?.close() } catch (_: Throwable) { }
        session = null
        shape = ""
    }

    companion object {
        @Volatile private var current: NpuUnet? = null

        /** The open NPU UNet for [dir] (kept between pictures), creating it if needed. */
        @Synchronized fun get(ctx: Context, dir: File): NpuUnet {
            current?.let { if (it.dir == dir) return it; it.close() }
            return NpuUnet(ctx.applicationContext, dir).also { current = it }
        }

        /** Frees the NPU (and its memory): leaving the screen, switching models or to GPU/CPU. */
        @Synchronized fun releaseAll() {
            current?.close()
            current = null
        }

        /** True when the NPU version of [id] was compiled in the server (the only kind the app offers now). */
        fun isPrecompiled(ctx: Context, id: String): Boolean = dirFor(ctx, id)?.let { File(it, "unet_npu_ctx.onnx").exists() } == true

        /** The NPU version of [id] lives in its own folder "<id>-npu". */
        fun dirFor(ctx: Context, id: String): File? =
            // don't use SdModel.dir here: it creates the folder, and an empty folder hides the
            // model from the download list
            File(ctx.filesDir, "models/$id-npu").takeIf {
                File(it, ".complete").exists() && (File(it, "unet_npu_ctx.onnx").exists() || File(it, "unet_npu.onnx").exists())
            }

        /** Sizes the NPU version was made for (width x height). */
        fun sizes(ctx: Context, id: String): List<Pair<Int, Int>> = try {
            File(ctx.filesDir, "models/$id-npu/info.txt").readLines().firstOrNull { it.startsWith("npu_sizes=") }
                ?.substringAfter("=")?.split(",")?.mapNotNull { s ->
                    val p = s.trim().split("x"); if (p.size == 2) p[0].toInt() to p[1].toInt() else null
                } ?: emptyList()
        } catch (t: Throwable) { emptyList() }

        /**
         * The NPU-side libraries ("Skel", Hexagon code) ship as assets (they aren't ARM code, so
         * they don't belong in lib/); copy them out once and tell the DSP loader where they are.
         */
        fun prepareDsp(ctx: Context) {
            val out = File(ctx.filesDir, "qnn").apply { mkdirs() }
            try {
                for (name in ctx.assets.list("qnn").orEmpty()) {
                    val f = File(out, name)
                    // replace it when the app brings another version (different size)
                    val want = try { ctx.assets.openFd("qnn/$name").use { it.length } } catch (_: Throwable) { -1L }
                    if (f.exists() && f.length() > 0 && (want < 0 || f.length() == want)) continue
                    val tmp = File(out, "$name.tmp")
                    ctx.assets.open("qnn/$name").use { i -> tmp.outputStream().use { i.copyTo(it) } }
                    tmp.renameTo(f)
                }
            } catch (t: Throwable) { Log.w("Nitido", "qnn assets", t) }
            val path = listOf(out.path, ctx.applicationInfo.nativeLibraryDir,
                "/vendor/dsp/cdsp", "/vendor/lib/rfsa/adsp", "/system/lib/rfsa/adsp", "/dsp").joinToString(";")
            try { Os.setenv("ADSP_LIBRARY_PATH", path, true) } catch (_: Throwable) { }
            try { Os.setenv("DSP_LIBRARY_PATH", path, true) } catch (_: Throwable) { }
        }

        /** Recent QNN / ONNX Runtime messages of this app, to explain a failure or a CPU fallback. */
        fun qnnLog(): String = try {
            val p = ProcessBuilder("logcat", "-d", "-v", "brief", "--pid=${Process.myPid()}", "-t", "400").redirectErrorStream(true).start()
            val lines = p.inputStream.bufferedReader().readLines().filter {
                (it.contains("QNN", true) || it.contains("onnxruntime", true) || it.contains("qnn", false)) &&
                    (it.startsWith("E") || it.startsWith("W"))
            }.map { it.substringAfter("): ").take(160) }.distinct().takeLast(3)
            if (lines.isEmpty()) "" else "\n" + lines.joinToString("\n")
        } catch (t: Throwable) { "" }
    }
}
