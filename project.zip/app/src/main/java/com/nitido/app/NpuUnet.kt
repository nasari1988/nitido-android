package com.nitido.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import android.content.Context
import android.os.Process
import android.os.SystemClock
import android.system.Os
import android.util.Log
import org.json.JSONArray
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.TensorInfo
import android.util.Half
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer

/**
 * Runs a model's UNet on the Qualcomm NPU (Hexagon) with ONNX Runtime's QNN execution provider.
 *
 * The NPU needs fixed sizes, so there is one compiled session per picture size. The first time a
 * size is used, QNN compiles the model for this phone's NPU (takes a while) and the result is kept
 * in the app's files, so later runs start in seconds. The session stays open between pictures
 * (see [get]) and is closed with [releaseAll] when leaving the screen or switching models.
 */
class NpuUnet private constructor(private val ctx: Context, val dir: File) : SdNative.NpuUnet {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    val stamp = stampOf(dir)
    private var session: OrtSession? = null
    private var shape = ""
    private var profiling = false
    private var steps = 0
    private var stepMs = 0L
    @Volatile var lastError: String? = null
        private set
    /** Short summary for the screen: where the time went, load time, step time. */
    @Volatile var report: String? = null
        private set

    private val model = File(dir, "unet_npu.onnx")
    /** Compiled for the NPU in the server (QAIRT): the phone only loads it. One per size
     *  (unet_npu_ctx_512x768.onnx…); the square one keeps the plain name. */
    private val precompiled = File(dir, "unet_npu_ctx.onnx")

    private fun ctxFor(h: Int, w: Int): File {
        val f = File(dir, "unet_npu_ctx_${w * 8}x${h * 8}.onnx")
        return if (f.exists()) f else precompiled
    }

    private fun cacheFile(h: Int, w: Int) = File(dir, "qnn_ctx_${w * 8}x${h * 8}.onnx")

    /** True once this size was compiled for the NPU (next runs start fast). */
    fun isCompiled(width: Int, height: Int) = isXl || ctxFor(height / 8, width / 8).exists() || cacheFile(height / 8, width / 8).exists()

    private fun open(h: Int, w: Int): OrtSession {
        val key = "${h}x$w"
        session?.let { if (shape == key) return it }
        close()
        prepareDsp(ctx)
        val cache = cacheFile(h, w)
        val opts = OrtSession.SessionOptions()
        opts.setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
        // the few ops the NPU lacks run on the CPU; the heavy rest stays on the NPU
        opts.addConfigEntry("session.disable_cpu_ep_fallback", "0")
        opts.setIntraOpNumThreads(4)
        opts.setSymbolicDimensionValue("h", h.toLong())
        opts.setSymbolicDimensionValue("w", w.toLong())
        // time per operation and where it ran (NPU or CPU), for the first step only
        val prof = File(ctx.cacheDir, "npu_prof").path
        opts.enableProfiling(prof)
        opts.addQnn(mapOf(
            "backend_path" to "libQnnHtp.so",
            "htp_performance_mode" to "burst",
            "htp_graph_finalization_optimization_mode" to "3",
            "enable_htp_fp16_precision" to "1",
        ))
        val t0 = SystemClock.elapsedRealtime()
        val pre = ctxFor(h, w)
        quant = readQuant(File(pre.path + ".json"))
        val fromCache = cache.exists() || pre.exists()
        val s = try {
            if (pre.exists()) env.createSession(pre.path, opts)
            else if (cache.exists()) env.createSession(cache.path, opts) else {
                // compile for this phone's NPU and keep the result next to the model
                opts.addConfigEntry("ep.context_enable", "1")
                opts.addConfigEntry("ep.context_embed_mode", "0")
                opts.addConfigEntry("ep.context_file_path", cache.path)
                env.createSession(model.path, opts)
            }
        } catch (t: Throwable) {
            if (cache.exists() && !pre.exists()) { cache.delete() }   // a bad cache: compile again next time
            throw t
        }
        val loadS = (SystemClock.elapsedRealtime() - t0) / 1000
        session = s
        shape = key
        profiling = true
        steps = 0
        stepMs = 0
        report = "carga ${loadS}s (${if (fromCache) "ya preparada" else "preparada ahora; guardada=" + (if (cache.exists()) "sí" else "no")})"
        return s
    }

    override fun run(sample: FloatArray, channels: Int, timestep: Int, h: Int, emb: FloatArray, out: FloatArray): Boolean {
        return try {
            val w = sample.size / (2 * channels * h)
            val s = open(h, w)
            val embDim = emb.size / (2 * 77)
            val t0 = SystemClock.elapsedRealtime()
            val names = s.inputNames.toList()
            fun pick(vararg keys: String) = names.firstOrNull { n -> keys.any { n.contains(it, true) } } ?: keys[0]
            val nSample = pick("sample"); val nTime = pick("timestep", "time"); val nEmb = pick("encoder", "hidden")
            val tS = floatTensor(s, nSample, sample, longArrayOf(2, channels.toLong(), h.toLong(), w.toLong()))
            val tT = timeTensor(s, nTime, timestep)
            val tE = floatTensor(s, nEmb, emb, longArrayOf(2, 77, embDim.toLong()))
            try {
                NpuMeter.begin()
                (try { s.run(mapOf(nSample to tS, nTime to tT, nEmb to tE)) } finally { NpuMeter.end() }).use { r ->
                    val o = r.get(0) as OnnxTensor
                    val qo = quant[s.outputNames.first()]
                    if (qo != null) dequant(qo, o, out)
                    else if ((o.info as TensorInfo).type == OnnxJavaType.FLOAT16) {
                        val bb = o.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                        for (i in out.indices) out[i] = Half.toFloat(bb.get(i))
                    } else o.floatBuffer.get(out, 0, out.size)
                }
            } finally { tS.close(); tT.close(); tE.close() }
            steps++
            stepMs += SystemClock.elapsedRealtime() - t0
            if (profiling) {
                profiling = false
                try { summarize(s.endProfiling()) } catch (t: Throwable) { Log.w("Nitido", "NPU profile", t) }
            }
            true
        } catch (t: Throwable) {
            lastError = (t.message ?: t.javaClass.simpleName) + qnnLog()
            Log.e("Nitido", "NPU", t)
            false
        }
    }

    // ---- SDXL (experimental): the UNet in 4 parts, each its own compiled graph, batch 1 ----

    private class XlPart(val s: OrtSession, val q: Map<String, Quant>)
    private var xl: List<XlPart>? = null
    private var xlSteps = 0
    private var xlMs = LongArray(4)

    /** True when this folder holds SDXL's NPU parts. */
    val isXl get() = File(dir, "sdxl_p1_ctx.onnx").exists()

    private fun openXl(): List<XlPart> {
        xl?.let { return it }
        close()
        prepareDsp(ctx)
        val t0 = SystemClock.elapsedRealtime()
        val parts = (1..4).map { i ->
            val f = File(dir, "sdxl_p${i}_ctx.onnx")
            val o = OrtSession.SessionOptions().apply {
                setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                addConfigEntry("session.disable_cpu_ep_fallback", "0")
                addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
            }
            val ts = SystemClock.elapsedRealtime()
            val sess = env.createSession(f.path, o)
            JobLog.add("NPU SDXL: parte $i abierta en ${(SystemClock.elapsedRealtime() - ts) / 1000f} s · entradas ${sess.inputNames.joinToString()}")
            XlPart(sess, readQuant(File(f.path + ".json")))
        }
        report = "SDXL en 4 partes · carga ${(SystemClock.elapsedRealtime() - t0) / 1000}s"
        xl = parts
        try { selfTest(parts) } catch (t: Throwable) { JobLog.error("NPU SDXL: autoprueba", t) }
        xlSteps = 0; xlMs = LongArray(4)
        return parts
    }

    /** Runs one part: float inputs by name (shapes from the graph), float outputs by name. */
    private fun runPart(p: XlPart, feeds: Map<String, FloatArray>): Map<String, FloatArray> {
        val tensors = HashMap<String, OnnxTensor>()
        try {
            for ((n, data) in feeds) {
                val info = p.s.inputInfo[n]?.info as? TensorInfo ?: throw IllegalStateException("la parte no tiene la entrada $n")
                val shape = info.shape
                val q = p.q[n]
                tensors[n] = if (q != null) quantTensor(q, data, shape)
                    else if (info.type == OnnxJavaType.INT64) OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(LongArray(data.size) { data[it].toLong() }), shape)
                    else OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)
            }
            NpuMeter.begin()
            val r = try { p.s.run(tensors) } finally { NpuMeter.end() }
            r.use {
                val out = HashMap<String, FloatArray>()
                for ((n, v) in it) {
                    val o = v as OnnxTensor
                    val shp = (o.info as TensorInfo).shape
                    val size = shp.fold(1L) { a, b -> a * b }.toInt()
                    var arr = FloatArray(size)
                    val q = p.q[n]
                    if (q != null) dequant(q, o, arr) else o.floatBuffer.get(arr, 0, size)
                    // the compiler may hand a 4-D output channels-last ([1,H,W,C], seen on part 2's
                    // h_out): put it back in the [1,C,H,W] order the next part reads
                    if (shp.size == 4 && shp[1] == shp[2] && shp[3] > shp[1]) {
                        arr = toChannelsFirst(arr, shp[1].toInt(), shp[2].toInt(), shp[3].toInt())
                        if (nhwcSeen.add(n)) JobLog.add("NPU SDXL: $n venía con los canales al final ${shp.contentToString()}; se reacomoda")
                    }
                    out[n] = arr
                }
                return out
            }
        } finally { tensors.values.forEach { it.close() } }
    }

    private val nhwcSeen = HashSet<String>()

    /** [H,W,C] -> [C,H,W]. */
    private fun toChannelsFirst(a: FloatArray, h: Int, w: Int, c: Int): FloatArray {
        val o = FloatArray(a.size)
        val hw = h * w
        for (i in 0 until hw) { val b = i * c; for (ch in 0 until c) o[ch * hw + i] = a[b + ch] }
        return o
    }

    /**
     * Runs the 4 parts on a known example (sdxl_ref_in.bin) and logs, per output, how far it is from
     * the computer's float result: mean, deviation, and the error at 64 fixed places as stored and as
     * if the tensor came with its dimensions in another order (channels last). Finds the broken part.
     */
    private fun selfTest(parts: List<XlPart>) {
        val jf = File(dir, "sdxl_ref.json"); val bf = File(dir, "sdxl_ref_in.bin")
        if (!jf.exists() || !bf.exists()) {
            // small (about 1 MB): fetched by itself, without downloading the model again
            try {
                for (f in listOf(jf, bf)) {
                    val url = "https://github.com/nasari1988/nitido-android/releases/download/modelo-${dir.name}/${f.name}"
                    val tmp = File(dir, f.name + ".part")
                    java.net.URL(url).openStream().use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
                    tmp.renameTo(f)
                }
                JobLog.add("NPU SDXL: ejemplo de referencia descargado")
            } catch (t: Throwable) {
                JobLog.add("NPU SDXL: sin ejemplo de referencia (${t.javaClass.simpleName}); autoprueba omitida"); return
            }
        }
        val j = org.json.JSONObject(jf.readText())
        val sizes = j.getJSONArray("sizes")
        val bb = java.nio.ByteBuffer.wrap(bf.readBytes()).order(java.nio.ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        fun take(n: Int) = FloatArray(n).also { bb.get(it) }
        val sample = take(sizes.getInt(0)); val ehs = take(sizes.getInt(1)); val te = take(sizes.getInt(2))
        val ids = j.getJSONArray("time_ids").let { a -> FloatArray(a.length()) { a.getDouble(it).toFloat() } }
        val outs = j.getJSONObject("outputs")
        val t0 = SystemClock.elapsedRealtime()
        val a = runPart(parts[0], mapOf("sample" to sample, "timestep" to floatArrayOf(j.getDouble("timestep").toFloat()),
            "encoder_hidden_states" to ehs, "text_embeds" to te, "time_ids" to ids))
        val got = HashMap<String, FloatArray>()
        for ((n, v) in a) got["p1.$n"] = v
        val e = a.getValue("emb")
        val h2 = runPart(parts[1], mapOf("h" to a.getValue("h"), "emb" to e, "encoder_hidden_states" to ehs,
            "s7" to a.getValue("s7"), "s8" to a.getValue("s8"))).values.first()
        got["p2.h_out"] = h2
        val h3 = runPart(parts[2], mapOf("h" to h2, "emb" to e, "encoder_hidden_states" to ehs,
            "s3" to a.getValue("s3"), "s4" to a.getValue("s4"), "s5" to a.getValue("s5"), "s6" to a.getValue("s6"))).values.first()
        got["p3.h_out"] = h3
        got["p4.out_sample"] = runPart(parts[3], mapOf("h" to h3, "emb" to e, "s0" to a.getValue("s0"), "s1" to a.getValue("s1"), "s2" to a.getValue("s2"))).values.first()
        JobLog.add("NPU SDXL: autoprueba con el ejemplo de referencia (${SystemClock.elapsedRealtime() - t0} ms)")
        // the input/output names as the parts report them, to compare with the graph
        for ((i, p) in parts.withIndex())
            JobLog.add("  parte ${i + 1}: entradas ${p.s.inputInfo.map { (n, v) -> n + (v.info as? TensorInfo)?.shape?.contentToString() }.joinToString()}" +
                " · salidas ${p.s.outputInfo.map { (n, v) -> n + (v.info as? TensorInfo)?.shape?.contentToString() }.joinToString()}")
        for (key in outs.keys()) {
            val r = outs.getJSONObject(key)
            val g = got[key]
            if (g == null) { JobLog.add("  $key: no salió"); continue }
            val shp = r.getJSONArray("shape").let { s -> IntArray(s.length()) { s.getInt(it) } }
            val idx = r.getJSONArray("idx"); val ref = r.getJSONArray("val")
            var mean = 0.0; for (v in g) mean += v; mean /= g.size
            var sd = 0.0; for (v in g) sd += (v - mean) * (v - mean); sd = Math.sqrt(sd / g.size)
            val rs = r.getDouble("std").coerceAtLeast(1e-6)
            var err = 0.0; var errT = 0.0
            val nchw = shp.size == 4
            for (k in 0 until idx.length()) {
                val i = idx.getLong(k).toInt(); val want = ref.getDouble(k)
                if (i < g.size) err += Math.abs(g[i] - want)
                if (nchw) {   // the same element if the tensor were channels-last
                    val c = shp[1]; val hh = shp[2]; val ww = shp[3]
                    val ci = i / (hh * ww); val rem = i % (hh * ww); val y = rem / ww; val x = rem % ww
                    val ti = (y * ww + x) * c + ci
                    if (ti < g.size) errT += Math.abs(g[ti] - want)
                }
            }
            err /= idx.length() * rs; errT /= idx.length() * rs
            JobLog.add(String.format(java.util.Locale.US, "  %s: media %.3f (debe %.3f) · desv. %.3f (debe %.3f) · error %.2f%s · tamaño %d (debe %d)",
                key, mean, r.getDouble("mean"), sd, r.getDouble("std"), err,
                if (nchw) String.format(java.util.Locale.US, " · si fuera canales al final %.2f", errT) else "",
                g.size, shp.fold(1) { x, y -> x * y }))
        }
        JobLog.add("  (error = diferencia media en desviaciones; menos de 0.1 es bueno, más de 0.5 está roto)")
    }

    override fun runXl(sample: FloatArray, timestep: Int, h: Int, emb: FloatArray, pooled: FloatArray, timeIds: FloatArray, out: FloatArray): Boolean {
        return try {
            val parts = openXl()
            val one = sample.size / 2; val e1 = emb.size / 2; val p1 = pooled.size / 2; val t1 = timeIds.size / 2
            // row 0 = negative (free), row 1 = prompt (guided): one after the other, batch 1
            for (b in 0 until 2) {
                var t0 = SystemClock.elapsedRealtime()
                val ehs = emb.copyOfRange(b * e1, (b + 1) * e1)
                val a = runPart(parts[0], mapOf(
                    "sample" to sample.copyOfRange(b * one, (b + 1) * one), "timestep" to floatArrayOf(timestep.toFloat()),
                    "encoder_hidden_states" to ehs, "text_embeds" to pooled.copyOfRange(b * p1, (b + 1) * p1),
                    "time_ids" to timeIds.copyOfRange(b * t1, (b + 1) * t1)))
                xlMs[0] += SystemClock.elapsedRealtime() - t0; t0 = SystemClock.elapsedRealtime()
                val e = a.getValue("emb")
                val h2 = runPart(parts[1], mapOf("h" to a.getValue("h"), "emb" to e, "encoder_hidden_states" to ehs,
                    "s7" to a.getValue("s7"), "s8" to a.getValue("s8"))).values.first()
                xlMs[1] += SystemClock.elapsedRealtime() - t0; t0 = SystemClock.elapsedRealtime()
                val h3 = runPart(parts[2], mapOf("h" to h2, "emb" to e, "encoder_hidden_states" to ehs,
                    "s3" to a.getValue("s3"), "s4" to a.getValue("s4"), "s5" to a.getValue("s5"), "s6" to a.getValue("s6"))).values.first()
                xlMs[2] += SystemClock.elapsedRealtime() - t0; t0 = SystemClock.elapsedRealtime()
                val o = runPart(parts[3], mapOf("h" to h3, "emb" to e, "s0" to a.getValue("s0"), "s1" to a.getValue("s1"), "s2" to a.getValue("s2"))).values.first()
                xlMs[3] += SystemClock.elapsedRealtime() - t0
                System.arraycopy(o, 0, out, b * one, minOf(one, o.size))
            }
            xlSteps++
            if (xlSteps == 1) {
                var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE; var bad = 0
                for (v in out) if (!v.isFinite()) bad++ else { if (v < lo) lo = v; if (v > hi) hi = v }
                JobLog.add("NPU SDXL: primer paso · partes ${xlMs.joinToString(" / ") { "${it} ms" }} · ruido %.2f a %.2f".format(java.util.Locale.US, lo, hi) +
                    if (bad > 0) " · $bad no válidos" else "")
            }
            report = "SDXL en 4 partes · paso %.1f s".format(java.util.Locale.US, xlMs.sum() / 1000f / xlSteps)
            true
        } catch (t: Throwable) {
            lastError = (t.message ?: t.javaClass.simpleName) + qnnLog()
            JobLog.error("NPU SDXL", t)
            false
        }
    }

    private fun typeOf(s: OrtSession, name: String): OnnxJavaType? =
        (s.inputInfo[name]?.info as? TensorInfo)?.type

    /** Quantized NPU tensors (W8A16 graphs): name -> (QNN type, scale, offset), from the server's JSON. */
    private class Quant(val type: Int, val scale: Float, val offset: Int)
    private var quant: Map<String, Quant> = emptyMap()

    private fun readQuant(f: File): Map<String, Quant> {
        return try {
            val j = org.json.JSONObject(f.readText()).optJSONObject("quant") ?: return emptyMap()
            j.keys().asSequence().mapNotNull { k ->
                val q = j.getJSONObject(k)
                if (!q.has("scale")) null else k to Quant(q.getInt("qnn_type"), q.getDouble("scale").toFloat(), q.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }
    }

    /** float -> the NPU's integers: q = round(x / scale) - offset (QNN: x = scale * (q + offset)). */
    private fun quantTensor(q: Quant, data: FloatArray, shape: LongArray): OnnxTensor {
        val inv = 1f / q.scale
        return if (q.type == 0x0408 || q.type == 0x0308) {
            val bb = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
            val lo = if (q.type == 0x0408) 0 else -128; val hi = if (q.type == 0x0408) 255 else 127
            for (v in data) bb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toByte())
            bb.rewind()
            OnnxTensor.createTensor(env, bb, shape, if (q.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
        } else {
            val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
            val sb = bb.asShortBuffer()
            val lo = if (q.type == 0x0416) 0 else -32768; val hi = if (q.type == 0x0416) 65535 else 32767
            for (v in data) sb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toShort())
            OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
        }
    }

    private fun dequant(q: Quant, o: OnnxTensor, out: FloatArray) {
        val bb = o.byteBuffer.order(ByteOrder.nativeOrder())
        if (q.type == 0x0408 || q.type == 0x0308) {
            for (i in out.indices) { val b = bb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0408) b and 0xFF else b) + q.offset) }
        } else {
            val sb = bb.asShortBuffer()
            for (i in out.indices) { val v = sb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0416) v and 0xFFFF else v) + q.offset) }
        }
    }

    /** A float input, in fp16 when the NPU graph takes fp16. */
    private fun floatTensor(s: OrtSession, name: String, data: FloatArray, shape: LongArray): OnnxTensor {
        quant[name]?.let { return quantTensor(it, data, shape) }
        if (typeOf(s, name) != OnnxJavaType.FLOAT16) return OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)
        val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
        val sb = bb.asShortBuffer()
        for (v in data) sb.put(Half.toHalf(v))
        return OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.FLOAT16)
    }

    private fun timeTensor(s: OrtSession, name: String, t: Int): OnnxTensor = if (quant[name] != null)
        quantTensor(quant[name]!!, floatArrayOf(t.toFloat()), longArrayOf(1)) else when (typeOf(s, name)) {
        OnnxJavaType.FLOAT -> OnnxTensor.createTensor(env, FloatBuffer.wrap(floatArrayOf(t.toFloat())), longArrayOf(1))
        OnnxJavaType.FLOAT16 -> floatTensor(s, name, floatArrayOf(t.toFloat()), longArrayOf(1))
        OnnxJavaType.INT64 -> OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(longArrayOf(t.toLong())), longArrayOf(1))
        else -> OnnxTensor.createTensor(env, IntBuffer.wrap(intArrayOf(t)), longArrayOf(1))
    }

    /** Where the first step's time went: NPU (QNN) vs CPU, and the heaviest CPU operations. */
    private fun summarize(path: String) {
        val f = File(path)
        val arr = JSONArray(f.readText())
        f.delete()
        var npu = 0L; var cpu = 0L; var nNpu = 0; var nCpu = 0
        val cpuOps = HashMap<String, Long>()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            if (e.optString("cat") != "Node") continue
            val args = e.optJSONObject("args") ?: continue
            val prov = args.optString("provider")
            if (!e.optString("name").endsWith("_kernel_time")) continue
            val dur = e.optLong("dur")
            if (prov.startsWith("QNN")) { npu += dur; nNpu++ } else {
                cpu += dur; nCpu++
                val op = args.optString("op_name")
                cpuOps[op] = (cpuOps[op] ?: 0L) + dur
            }
        }
        val tot = (npu + cpu).coerceAtLeast(1)
        val top = cpuOps.entries.sortedByDescending { it.value }.take(4).joinToString(", ") { "${it.key} ${it.value * 100 / tot}%" }
        report = (report ?: "") + " · tiempo NPU ${npu * 100 / tot}% ($nNpu partes) / CPU ${cpu * 100 / tot}% ($nCpu partes)" +
            (if (top.isNotEmpty()) " · CPU: $top" else "") +
            // QNN's messages only matter when part of the work fell back to the CPU (normal runs print harmless notices)
            (if (cpu > 0) qnnLog() else "")
    }

    /** Average step time, once a few steps ran. */
    fun stepSummary(): String? = if (xlSteps > 0) "paso ${"%.1f".format(xlMs.sum() / 1000f / xlSteps)} s" else if (steps > 0) "paso ${"%.1f".format(stepMs / 1000f / steps)} s" else null

    /** The VAE decoder compiled for the NPU (vae_npu_ctx{_WxH}.onnx), one per picture size, kept open. */
    private var vae: NpuTile? = null
    private var vaeTag: String? = null
    /** Sizes whose NPU decoder is missing or failed: the GPU decodes them (asked once per size). */
    private val vaeNo = HashSet<String>()

    /** Latent [1,4,h,w] (already divided by the VAE scale) -> picture [1,3,8h,8w] in -1..1, on the NPU. */
    override fun decode(latent: FloatArray, h: Int, w: Int, out: FloatArray): Boolean {
        val tag = if (h == w) "" else "_${w * 8}x${h * 8}"
        if (tag in vaeNo) return false
        return try {
            if (vaeTag != tag) {
                vae?.close(); vae = null; vaeTag = null
                val f = File(dir, "vae_npu_ctx$tag.onnx")
                if (!f.exists() || !File(dir, "vae_npu$tag.bin").exists()) {
                    vaeNo += tag
                    JobLog.add("NPU: este modelo no trae decodificador NPU para ${w * 8}×${h * 8} (se decodifica en la GPU)")
                    return false
                }
                val opened = NpuTile.openPrecompiled(ctx, f, "vae$tag")
                if (opened == null) {
                    vaeNo += tag
                    JobLog.notice("NPU: el decodificador no abrió: ${NpuTile.lastError}")
                    return false
                }
                vae = opened
                vaeTag = tag
            }
            val t0 = SystemClock.elapsedRealtime()
            val ok = vae!!.run(latent, out)
            // a broken decode (NaN, far out of range) falls back to the GPU
            var bad = 0; var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE
            for (v in out) { if (!v.isFinite()) bad++ else { if (v < lo) lo = v; if (v > hi) hi = v } }
            JobLog.add("NPU: decodificado en ${SystemClock.elapsedRealtime() - t0} ms · rango %.2f a %.2f".format(java.util.Locale.US, lo, hi) +
                (if (bad > 0) " · $bad no válidos" else ""))
            if (!ok || bad > 0 || lo < -3f || hi > 3f) {
                vaeNo += tag
                JobLog.notice("NPU: el decodificado salió mal; esta imagen y las siguientes de este tamaño se decodifican en la GPU")
                false
            } else true
        } catch (t: Throwable) {
            vaeNo += tag
            JobLog.error("Decodificar en la NPU", t)
            false
        }
    }

    fun close() {
        xl?.forEach { try { it.s.close() } catch (_: Throwable) { } }
        xl = null
        try { session?.close() } catch (_: Throwable) { }
        session = null
        shape = ""
        vae?.close(); vae = null; vaeTag = null
    }

    companion object {
        @Volatile private var current: NpuUnet? = null

        /** The open NPU UNet for [dir] (kept between pictures), creating it if needed. */
        @Synchronized fun get(ctx: Context, dir: File): NpuUnet {
            current?.let { if (it.dir == dir && it.stamp == stampOf(dir)) return it; it.close() }
            return NpuUnet(ctx.applicationContext, dir).also { current = it }
        }

        /** Changes when the model's files are downloaded again (then the open copy is stale). */
        private fun stampOf(dir: File): Long =
            listOf("sdxl_p1.bin", "unet_npu.bin", ".complete").sumOf { File(dir, it).lastModified() }

        /** Frees the NPU (and its memory): leaving the screen, switching models or to GPU/CPU. */
        @Synchronized fun releaseAll() {
            current?.close()
            current = null
        }

        /** True when the NPU version of [id] was compiled in the server (the only kind the app offers now). */
        fun isPrecompiled(ctx: Context, id: String): Boolean = dirFor(ctx, id)?.let {
            File(it, "unet_npu_ctx.onnx").exists() || File(it, "sdxl_p1_ctx.onnx").exists() } == true

        /** The NPU version of [id] lives in its own folder "<id>-npu"; the 8-bit and 16-bit
         *  versions of a model share it ("realistic-vision-6-8" -> "realistic-vision-6-npu"). */
        fun dirFor(ctx: Context, id: String): File? =
            // don't use SdModel.dir here: it creates the folder, and an empty folder hides the
            // model from the download list
            listOf(id, id.removeSuffix("-8"), id.removeSuffix("-16")).distinct().map { File(ctx.filesDir, "models/$it-npu") }
                .firstOrNull {
                    File(it, ".complete").exists() && (File(it, "unet_npu_ctx.onnx").exists() || File(it, "unet_npu.onnx").exists() ||
                        File(it, "sdxl_p1_ctx.onnx").exists())
                }

        /** Sizes the NPU version was made for (width x height). */
        fun sizes(ctx: Context, id: String): List<Pair<Int, Int>> = try {
            File(dirFor(ctx, id) ?: throw IllegalStateException("sin NPU"), "info.txt").readLines().firstOrNull { it.startsWith("npu_sizes=") }
                ?.substringAfter("=")?.split(",")?.mapNotNull { s ->
                    val p = s.trim().split("x"); if (p.size == 2) p[0].toInt() to p[1].toInt() else null
                } ?: emptyList()
        } catch (t: Throwable) { emptyList() }

        /**
         * The NPU-side libraries ("Skel", Hexagon code) ship as assets (they aren't ARM code, so
         * they don't belong in lib/); copy them out once and tell the DSP loader where they are.
         */
        fun prepareDsp(ctx: Context) {
            val out = File(ctx.filesDir, "qnn").apply { mkdirs() }
            try {
                for (name in ctx.assets.list("qnn").orEmpty()) {
                    val f = File(out, name)
                    // replace it when the app brings another version (different size)
                    val want = try { ctx.assets.openFd("qnn/$name").use { it.length } } catch (_: Throwable) { -1L }
                    if (f.exists() && f.length() > 0 && (want < 0 || f.length() == want)) continue
                    val tmp = File(out, "$name.tmp")
                    ctx.assets.open("qnn/$name").use { i -> tmp.outputStream().use { i.copyTo(it) } }
                    tmp.renameTo(f)
                }
            } catch (t: Throwable) { Log.w("Nitido", "qnn assets", t) }
            val path = listOf(out.path, ctx.applicationInfo.nativeLibraryDir,
                "/vendor/dsp/cdsp", "/vendor/lib/rfsa/adsp", "/system/lib/rfsa/adsp", "/dsp").joinToString(";")
            try { Os.setenv("ADSP_LIBRARY_PATH", path, true) } catch (_: Throwable) { }
            try { Os.setenv("DSP_LIBRARY_PATH", path, true) } catch (_: Throwable) { }
        }

        /** Recent QNN / ONNX Runtime messages of this app, to explain a failure or a CPU fallback. */
        fun qnnLog(): String = try {
            val p = ProcessBuilder("logcat", "-d", "-v", "brief", "--pid=${Process.myPid()}", "-t", "400").redirectErrorStream(true).start()
            val lines = p.inputStream.bufferedReader().readLines().filter {
                (it.contains("QNN", true) || it.contains("onnxruntime", true) || it.contains("qnn", false)) &&
                    (it.startsWith("E") || it.startsWith("W"))
            }.map { it.substringAfter("): ").take(160) }.distinct().takeLast(3)
            if (lines.isEmpty()) "" else "\n" + lines.joinToString("\n")
        } catch (t: Throwable) { "" }
    }
}
