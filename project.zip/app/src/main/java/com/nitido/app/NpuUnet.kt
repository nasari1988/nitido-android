package com.nitido.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.system.Os
import android.util.Log
import java.io.File
import java.nio.FloatBuffer
import java.nio.IntBuffer

/**
 * Runs a model's UNet on the Qualcomm NPU (Hexagon) with ONNX Runtime's QNN execution provider.
 *
 * The NPU needs fixed sizes, so there is one compiled session per picture size. The first time a
 * size is used, QNN compiles the model for this phone's NPU (takes a while) and the result is kept
 * in the app's files, so later runs start in seconds.
 */
class NpuUnet(private val ctx: Context, private val dir: File) : SdNative.NpuUnet {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var session: OrtSession? = null
    private var shape = ""
    @Volatile var lastError: String? = null
        private set

    private val model = File(dir, "unet_npu.onnx")

    private fun cacheFile(h: Int, w: Int) = File(dir, "qnn_ctx_${w * 8}x${h * 8}.onnx")

    /** True once this size was compiled for the NPU (next runs start fast). */
    fun isCompiled(width: Int, height: Int) = cacheFile(height / 8, width / 8).exists()

    private fun open(h: Int, w: Int): OrtSession {
        val key = "${h}x$w"
        session?.let { if (shape == key) return it }
        close()
        // the NPU side (DSP) looks for its libraries here
        try { Os.setenv("ADSP_LIBRARY_PATH", ctx.applicationInfo.nativeLibraryDir, true) } catch (_: Throwable) { }
        val cache = cacheFile(h, w)
        val opts = OrtSession.SessionOptions()
        opts.addConfigEntry("session.disable_cpu_ep_fallback", "1")
        opts.setSymbolicDimensionValue("h", h.toLong())
        opts.setSymbolicDimensionValue("w", w.toLong())
        val qnn = mapOf(
            "backend_path" to "libQnnHtp.so",
            "htp_performance_mode" to "burst",
            "htp_graph_finalization_optimization_mode" to "3",
            "enable_htp_weight_sharing" to "0",
        )
        opts.addQnn(qnn)
        val s = if (cache.exists()) {
            env.createSession(cache.path, opts)
        } else {
            // compile for this phone's NPU and keep the result next to the model
            opts.addConfigEntry("ep.context_enable", "1")
            opts.addConfigEntry("ep.context_embed_mode", "0")
            opts.addConfigEntry("ep.context_file_path", cache.path)
            env.createSession(model.path, opts)
        }
        session = s
        shape = key
        return s
    }

    override fun run(sample: FloatArray, channels: Int, timestep: Int, h: Int, emb: FloatArray, out: FloatArray): Boolean {
        return try {
            val w = sample.size / (2 * channels * h)
            val s = open(h, w)
            val embDim = emb.size / (2 * 77)
            OnnxTensor.createTensor(env, FloatBuffer.wrap(sample), longArrayOf(2, channels.toLong(), h.toLong(), w.toLong())).use { tS ->
                OnnxTensor.createTensor(env, IntBuffer.wrap(intArrayOf(timestep)), longArrayOf(1)).use { tT ->
                    OnnxTensor.createTensor(env, FloatBuffer.wrap(emb), longArrayOf(2, 77, embDim.toLong())).use { tE ->
                        s.run(mapOf("sample" to tS, "timestep" to tT, "encoder_hidden_states" to tE)).use { r ->
                            val o = r.get(0) as OnnxTensor
                            o.floatBuffer.get(out, 0, out.size)
                        }
                    }
                }
            }
            true
        } catch (t: Throwable) {
            lastError = t.message ?: t.javaClass.simpleName
            Log.e("Nitido", "NPU", t)
            false
        }
    }

    fun close() {
        try { session?.close() } catch (_: Throwable) { }
        session = null
        shape = ""
    }

    companion object {
        /** The NPU version of [id] lives in its own folder "<id>-npu". */
        fun dirFor(ctx: Context, id: String): File? =
            SdModel.dir(ctx, "$id-npu").takeIf { SdModel.isReady(ctx, "$id-npu") && File(it, "unet_npu.onnx").exists() }

        /** Sizes the NPU version was calibrated for (width x height). */
        fun sizes(ctx: Context, id: String): List<Pair<Int, Int>> = try {
            File(SdModel.dir(ctx, "$id-npu"), "info.txt").readLines().firstOrNull { it.startsWith("npu_sizes=") }
                ?.substringAfter("=")?.split(",")?.mapNotNull { s ->
                    val p = s.trim().split("x"); if (p.size == 2) p[0].toInt() to p[1].toInt() else null
                } ?: emptyList()
        } catch (t: Throwable) { emptyList() }
    }
}
