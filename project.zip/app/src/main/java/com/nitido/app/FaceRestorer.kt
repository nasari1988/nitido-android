package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Face restoration with GFPGAN v1.4 (LiteRT build, Apache-2.0).
 * Faces are found with ML Kit (on-device), aligned to the FFHQ 512 template from their
 * five landmarks, restored, and blended back with a soft edge.
 *
 * Create and use on one thread (GPU delegate requirement).
 */
class FaceRestorer(
    context: Context,
    useGpu: Boolean,
    /** Optional CodeFormer (restoration pack): better on very old or damaged faces. */
    codeFormer: File? = null,
    /** CodeFormer only: 0 = sharpest (may change features), 1 = most faithful to the original face. */
    private val fidelity: Float = 0.7f,
) : AutoCloseable {

    private var gpu: GpuDelegate? = null
    private var interpreter: Interpreter? = null
    private var cf: MnnTile? = null
    val usedGpu: Boolean
    private val inBuf = ByteBuffer.allocateDirect(3 * N * 4).order(ByteOrder.nativeOrder())
    private val outBuf = ByteBuffer.allocateDirect(3 * N * 4).order(ByteOrder.nativeOrder())

    init {
        var gpuOk = false
        if (codeFormer != null) {
            cf = try { MnnTile(context, codeFormer.absolutePath, useGpu, precise = true).also { gpuOk = useGpu } }
                 catch (t: Throwable) { if (!useGpu) throw t; MnnTile(context, codeFormer.absolutePath, false, precise = true) }
        } else interpreter = if (useGpu) {
            val file = modelFile(context)
            try {
                val d = GpuDelegate()
                gpu = d
                Interpreter(file, Interpreter.Options().addDelegate(d)).also { gpuOk = true }
            } catch (t: Throwable) {
                gpu?.close(); gpu = null
                Interpreter(file, Interpreter.Options().setNumThreads(4))
            }
        } else {
            Interpreter(modelFile(context), Interpreter.Options().setNumThreads(4))
        }
        usedGpu = gpuOk
    }

    /** Restores every face in [image] in place. Returns how many faces were restored. */
    fun restoreAll(image: Bitmap, onProgress: (Int, Int) -> Unit, cancelled: () -> Boolean): Int {
        val faces = detect(image)
        var done = 0
        for ((i, pts) in faces.withIndex()) {
            if (cancelled()) break
            onProgress(i, faces.size)
            restoreOne(image, pts)
            done++
        }
        onProgress(faces.size, faces.size)
        return done
    }

    /** Five landmarks per face in image order: eye left, eye right, nose, mouth left, mouth right. */
    private fun detect(image: Bitmap): List<Array<PointF>> {
        // ML Kit is fast enough on a downscaled copy; landmarks are scaled back up.
        val long = maxOf(image.width, image.height)
        val k = if (long > 1600) 1600f / long else 1f
        val small = if (k < 1f) Bitmap.createScaledBitmap(image, (image.width * k).toInt(), (image.height * k).toInt(), true) else image
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setMinFaceSize(0.05f)
                .build()
        )
        try {
            val faces = Tasks.await(detector.process(InputImage.fromBitmap(small, 0)))
            return faces.mapNotNull { f ->
                val l = listOf(FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE, FaceLandmark.NOSE_BASE,
                    FaceLandmark.MOUTH_LEFT, FaceLandmark.MOUTH_RIGHT).map { f.getLandmark(it)?.position }
                if (l.any { it == null }) return@mapNotNull null
                val p = l.map { PointF(it!!.x / k, it.y / k) }
                // Order by position in the picture, independent of which side ML Kit calls "left".
                val eyes = listOf(p[0], p[1]).sortedBy { it.x }
                val mouth = listOf(p[3], p[4]).sortedBy { it.x }
                arrayOf(eyes[0], eyes[1], p[2], mouth[0], mouth[1])
            }
        } finally {
            detector.close()
            if (small !== image) small.recycle()
        }
    }

    private fun restoreOne(image: Bitmap, pts: Array<PointF>) {
        // image -> template similarity transform (least squares)
        val m = similarity(pts, TEMPLATE)
        val face = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        Canvas(face).apply {
            drawColor(Color.BLACK)
            drawBitmap(image, m, Paint(Paint.FILTER_BITMAP_FLAG))
        }

        val px = IntArray(N)
        face.getPixels(px, 0, S, 0, 0, S, S)
        val inF = inBuf.asFloatBuffer()
        for (i in 0 until N) {
            val c = px[i]
            inF.put(i, Color.red(c) / 127.5f - 1f)
            inF.put(N + i, Color.green(c) / 127.5f - 1f)
            inF.put(2 * N + i, Color.blue(c) / 127.5f - 1f)
        }
        val o = FloatArray(3 * N)
        val c = cf
        if (c != null) {
            // CodeFormer: RGB plus a 4th channel holding the fidelity weight
            val x = FloatArray(4 * N)
            inF.rewind(); inF.get(x, 0, 3 * N)
            java.util.Arrays.fill(x, 3 * N, 4 * N, fidelity.coerceIn(0f, 1f))
            if (!c.run(x, o)) throw IllegalStateException("CodeFormer failed")
        } else {
            inBuf.rewind(); outBuf.rewind()
            interpreter!!.run(inBuf, outBuf)
            outBuf.rewind()
            outBuf.asFloatBuffer().get(o)
        }

        // CodeFormer/GFPGAN return the face in their own tone (often orange or pale): give it back
        // the original face's average color, measured on the middle of the face.
        run {
            val m = FloatArray(6); var cnt = 0
            for (y in 160 until 400) for (x in 150 until 362) {
                val i = y * S + x
                val c = px[i]
                if (c and 0xFFFFFF == 0) continue   // outside the photo
                m[0] += Color.red(c) / 127.5f - 1f; m[1] += Color.green(c) / 127.5f - 1f; m[2] += Color.blue(c) / 127.5f - 1f
                m[3] += o[i]; m[4] += o[N + i]; m[5] += o[2 * N + i]
                cnt++
            }
            if (cnt > 1000) for (ch in 0 until 3) {
                val shift = (m[ch] - m[3 + ch]) / cnt
                for (i in 0 until N) o[ch * N + i] += shift
            }
        }

        // Restored face with a feathered alpha edge so it blends into the photo.
        for (y in 0 until S) for (x in 0 until S) {
            val i = y * S + x
            // Only the face itself (an oval over forehead, eyes, cheeks, mouth and chin) is pasted:
            // pasting the whole square also pasted a second, sharper copy of the hair and ears
            // next to the blurry original ones, which looked like a double outline or a shadow.
            val dx = (x - OVAL_CX) / OVAL_RX
            val dy = (y - OVAL_CY) / OVAL_RY
            val d = kotlin.math.sqrt(dx * dx + dy * dy)
            val t = ((1f - d) / OVAL_FEATHER).coerceIn(0f, 1f)
            val oval = t * t * (3f - 2f * t)   // smooth step
            val edge = min(min(x, S - 1 - x), min(y, S - 1 - y)).toFloat()
            val a = minOf(oval, ((edge - 8f) / FEATHER).coerceIn(0f, 1f))
            px[i] = Color.argb((a * 255).toInt(), to8(o[i]), to8(o[N + i]), to8(o[2 * N + i]))
        }
        face.setPixels(px, 0, S, 0, 0, S, S)

        val inv = Matrix()
        m.invert(inv)
        Canvas(image).drawBitmap(face, inv, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        face.recycle()
    }

    private fun to8(v: Float) = ((v + 1f) * 127.5f + 0.5f).toInt().coerceIn(0, 255)

    override fun close() {
        interpreter?.close(); interpreter = null
        cf?.close(); cf = null
        gpu?.close()
        gpu = null
    }

    companion object {
        private const val S = 512
        private const val N = S * S
        private const val FEATHER = 48f
        // face oval in the 512 FFHQ template (eyes at y≈240, mouth at y≈371)
        private const val OVAL_CX = 256f
        private const val OVAL_CY = 300f
        private const val OVAL_RX = 168f
        private const val OVAL_RY = 205f
        private const val OVAL_FEATHER = 0.35f
        private const val URL_MODEL = "https://huggingface.co/litert-community/GFPGAN-v1.4-LiteRT/resolve/main/gfpgan_fp16.tflite"
        const val APPROX_MB = 431

        /** FFHQ 512 five-point template used by GFPGAN (facexlib). */
        private val TEMPLATE = arrayOf(
            PointF(192.98138f, 239.94708f), PointF(318.90277f, 240.1936f), PointF(256.63416f, 314.01935f),
            PointF(201.26117f, 371.41043f), PointF(313.08905f, 371.15118f)
        )

        fun modelFile(ctx: Context) = File(ctx.filesDir, "gfpgan_fp16.tflite")
        fun isReady(ctx: Context) = modelFile(ctx).let { it.exists() && it.length() > 100_000_000 }

        /** Least-squares similarity (rotation + uniform scale + translation) mapping [src] onto [dst]. */
        fun similarity(src: Array<PointF>, dst: Array<PointF>): Matrix {
            val n = src.size
            var sx = 0f; var sy = 0f; var dx = 0f; var dy = 0f
            for (i in 0 until n) { sx += src[i].x; sy += src[i].y; dx += dst[i].x; dy += dst[i].y }
            sx /= n; sy /= n; dx /= n; dy /= n
            var a = 0f; var b = 0f; var den = 0f
            for (i in 0 until n) {
                val px = src[i].x - sx; val py = src[i].y - sy
                val qx = dst[i].x - dx; val qy = dst[i].y - dy
                a += px * qx + py * qy
                b += px * qy - py * qx
                den += px * px + py * py
            }
            if (den < 1e-6f) den = 1e-6f
            a /= den; b /= den
            // [a -b tx; b a ty]
            val tx = dx - (a * sx - b * sy)
            val ty = dy - (b * sx + a * sy)
            return Matrix().apply { setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f)) }
        }

        /** Downloads the GFPGAN model once, resuming a partial download. */
        fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) {
            val target = modelFile(ctx)
            val part = File(target.path + ".part")
            var attempt = 0
            while (true) {
                try {
                    fetch(part, cancelled, onProgress)
                    break
                } catch (e: IOException) {
                    attempt++
                    if (attempt >= 5) throw e
                    Thread.sleep(2000L * attempt)
                }
            }
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) throw IOException("No se pudo guardar el modelo")
        }

        private fun fetch(part: File, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) {
            val have = if (part.exists()) part.length() else 0L
            val conn = (URL(URL_MODEL).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 20_000
                readTimeout = 60_000
                if (have > 0) setRequestProperty("Range", "bytes=$have-")
            }
            try {
                val code = conn.responseCode
                if (code == 416) return
                val partial = code == HttpURLConnection.HTTP_PARTIAL
                if (code != HttpURLConnection.HTTP_OK && !partial) throw IOException("HTTP $code")
                val total = (if (partial) have else 0L) + conn.contentLengthLong.coerceAtLeast(0)
                var got = if (partial) have else 0L
                conn.inputStream.use { input ->
                    FileOutputStream(part, partial).use { out ->
                        val buf = ByteArray(256 * 1024)
                        var last = 0L
                        while (true) {
                            if (cancelled()) throw InterruptedException()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            if (got - last > 2_000_000) { onProgress(got, total); last = got }
                        }
                    }
                }
                onProgress(got, total)
            } finally {
                conn.disconnect()
            }
        }
    }
}
