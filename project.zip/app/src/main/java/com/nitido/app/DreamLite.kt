package com.nitido.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.SystemClock
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Locale
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * DreamLite-mobile (ByteDance, 2026; weights CC BY-NC 4.0, personal use) as the instruction editor of
 * Editar › paso 1. The reader (Qwen3-VL) looks at the photo and the order together; the UNet on the NPU
 * draws the edit in 4 steps next to the photo's own latents ([new | photo] side by side); a tiny VAE
 * goes between pixels and latents. Packs: lector-dreamlite (reader) + dreamlite-npu (the rest).
 */
object DreamLite {
    const val PACK = "dreamlite-npu"
    private const val HID = 2048

    fun dir(ctx: Context): File = SdModel.dir(ctx, PACK)

    fun tag(w: Int, h: Int) = if (w == 1024 && h == 1024) "" else "_${w}x$h"

    /** The sizes compiled for the NPU (1024×1024 first). */
    fun sizes(ctx: Context): List<Pair<Int, Int>> {
        val d = dir(ctx)
        if (!File(d, ".complete").exists()) return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        if (File(d, "dl_unet_ctx.onnx").exists()) out += 1024 to 1024
        d.listFiles()?.forEach { f ->
            Regex("""dl_unet_(\d+)x(\d+)_ctx\.onnx""").matchEntire(f.name)?.let { out += it.groupValues[1].toInt() to it.groupValues[2].toInt() }
        }
        return out
    }

    fun isReady(ctx: Context) = DreamReader.isReady(ctx) && sizes(ctx).isNotEmpty() &&
        File(dir(ctx), "dl_vae_enc.onnx").exists() && File(dir(ctx), "dl_tok_vocab.json").exists()

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) {
        if (!DreamReader.isReady(ctx)) DreamReader.download(ctx, cancelled, onProgress)
        SdModel.download(ctx, PACK, cancelled, onProgress)
    }

    @Volatile private var checkedRemote = false

    /** Sizes published after this phone downloaded DreamLite (e.g. the faster 768×768). Network; once per app run. */
    fun newSizes(ctx: Context): List<String> {
        if (checkedRemote || !isReady(ctx)) return emptyList()
        checkedRemote = true
        return try {
            val txt = java.net.URL("https://github.com/nasari1988/nitido-android/releases/download/modelo-$PACK/files.txt").readText()
            Regex("""dl_unet_(\d+x\d+)_ctx\.onnx""").findAll(txt).map { it.groupValues[1] }
                .filter { !File(dir(ctx), "dl_unet_${it}_ctx.onnx").exists() }.toList()
        } catch (t: Throwable) { emptyList() }
    }

    private var tok: QwenTokenizer? = null
    /** The time split is measured once per app start (it slows that run a little). */
    private var profiled = false
    private fun tokenizer(ctx: Context): QwenTokenizer = tok ?: QwenTokenizer(File(dir(ctx), "dl_tok_vocab.json"), File(dir(ctx), "dl_tok_merges.txt")).also { tok = it }

    private fun cpu(f: File): OrtSession = OrtEnvironment.getEnvironment().createSession(f.path, OrtSession.SessionOptions().apply {
        setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 8))
        setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
    })

    private fun planes(bmp: Bitmap): FloatArray {
        val n = bmp.width * bmp.height
        val px = IntArray(n); bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val f = FloatArray(3 * n)
        for (i in 0 until n) { val p = px[i]; f[i] = Color.red(p) / 255f; f[n + i] = Color.green(p) / 255f; f[2 * n + i] = Color.blue(p) / 255f }
        return f
    }

    private fun toBitmap(f: FloatArray, w: Int, h: Int): Bitmap {
        val n = w * h
        val px = IntArray(n) { i ->
            fun c(v: Float) = (v * 255f + 0.5f).toInt().coerceIn(0, 255)
            Color.rgb(c(f[i]), c(f[n + i]), c(f[2 * n + i]))
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun vae(file: File, input: String, data: FloatArray, shape: LongArray): Pair<FloatArray, LongArray> {
        val env = OrtEnvironment.getEnvironment()
        cpu(file).use { s ->
            OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape).use { t ->
                s.run(mapOf(input to t)).use { r ->
                    val o = r[0] as OnnxTensor
                    val b = o.floatBuffer
                    return FloatArray(b.remaining()).also { b.get(it) } to (o.info as ai.onnxruntime.TensorInfo).shape
                }
            }
        }
    }

    /** FlowMatch sigmas for 4 steps with DreamLite's dynamic (exponential) shift for this latent size. */
    fun sigmas(latH: Int, latW: Int, steps: Int = 4): FloatArray {
        val seq = latH * latW / 4.0
        val m = (1.15 - 0.5) / (4096 - 256); val b = 0.5 - m * 256
        val mu = seq * m + b
        return FloatArray(steps + 1) { i ->
            if (i == steps) 0f else {
                val s = 1.0 - i * (1.0 - 1.0 / steps) / (steps - 1)        // linspace(1, 1/steps, steps)
                (exp(mu) / (exp(mu) + (1 / s - 1))).toFloat()
            }
        }
    }

    /**
     * The photo edited by [orderEn] (English). Returns the edited picture at the NPU size closest to the
     * photo's shape (the caller fits it back). Blocking.
     */
    fun edit(ctx: Context, photo: Bitmap, orderEn: String, seed: Int, say: (String, Int) -> Unit, stop: () -> Boolean): Bitmap {
        val d = dir(ctx)
        val r0 = photo.width.toFloat() / photo.height
        // the photo's shape first; among sizes of about that shape, the smallest (each step's time grows
        // with the picture's area: 1024×1024 takes ~14 s a step on the NPU, 768×768 about half)
        val all = sizes(ctx)
        val best = all.minOfOrNull { (a, b) -> Math.abs(Math.log((a.toFloat() / b / r0).toDouble())) } ?: error("DreamLite no está descargado")
        val (W, H) = all.filter { (a, b) -> Math.abs(Math.log((a.toFloat() / b / r0).toDouble())) <= best + 0.12 }.minByOrNull { it.first * it.second }!!
        val tag = tag(W, H)
        val meta = JSONObject(File(d, "dl_test$tag.json").readText())
        val tk = meta.getJSONObject("tokens")
        val lmax = meta.getInt("lmax")
        fun ints(a: org.json.JSONArray) = IntArray(a.length()) { a.getInt(it) }
        val before = ints(tk.getJSONArray("before")); val tail = ints(tk.getJSONArray("tail"))
        val p0 = tk.getInt("image_start"); val drop = tk.getInt("drop")
        val t0 = SystemClock.elapsedRealtime()

        // 1. the reader: template + " <order>", the photo at 512×512
        say(ctx.getString(R.string.dl_reading), 2)
        val instr = tokenizer(ctx).encode(" " + orderEn.trim())
        val ids = before + instr + tail
        val L = ids.size
        if (L - drop > lmax) error("la orden es demasiado larga (${L - drop} piezas, caben $lmax)")
        val pix512 = planes(Bitmap.createScaledBitmap(photo, 512, 512, true))
        val hid = DreamReader.encode(ctx, pix512, ids, DreamReader.positions(L, p0), p0, stop)
        val n = L - drop
        val ehs = FloatArray(lmax * HID); System.arraycopy(hid, drop * HID, ehs, 0, n * HID)
        val mask = FloatArray(lmax) { if (it < n) 1f else 0f }
        JobLog.add("DreamLite: orden «$orderEn» · ${instr.size} piezas · texto para el dibujo $n de $lmax")
        if (stop()) throw InterruptedException()

        // 2. the photo's latents (tiny VAE on the processor)
        say(ctx.getString(R.string.dl_drawing, 0), 5)
        val inPix = planes(Bitmap.createScaledBitmap(photo, W, H, true))
        val (img, ish) = vae(File(d, "dl_vae_enc.onnx"), "pixels", inPix, longArrayOf(1, 3, H.toLong(), W.toLong()))
        val lh = ish[2].toInt(); val lw = ish[3].toInt()

        // 3. 4 steps on the NPU: [new | photo] side by side, Euler on the flow
        val rnd = java.util.Random(seed.toLong())
        var lat = FloatArray(4 * lh * lw) { rnd.nextGaussian().toFloat() }
        val sg = sigmas(lh, lw)
        val tUnet = SystemClock.elapsedRealtime()
        val gf = File(d, "dl_unet${tag}_ctx.onnx")
        val graph = try { NpuGraph(gf) } catch (e: Throwable) {
            // seen once after other NPU work: free the NPU completely and try again, keeping what QNN said
            JobLog.notice("DreamLite: la NPU no lo abrió a la primera (${e.message?.take(80)}); la libero y reintento" + NpuUnet.qnnLog())
            try { NpuUnet.releaseAll() } catch (_: Throwable) { }
            try { if (SdNative.loadError == null) SdNative.release() } catch (_: Throwable) { }
            System.gc(); Thread.sleep(1000)
            try { NpuGraph(gf) } catch (e2: Throwable) { throw IllegalStateException("la NPU no abrió DreamLite: ${e2.message?.take(120)}" + NpuUnet.qnnLog(), e2) }
        }
        graph.use { g ->
            JobLog.add("DreamLite: modelo abierto en la NPU en ${(SystemClock.elapsedRealtime() - tUnet) / 1000f} s · ${W}×$H")
            for (i in 0 until 4) {
                if (stop()) throw InterruptedException()
                val side = FloatArray(4 * lh * 2 * lw)
                for (c in 0 until 4) for (y in 0 until lh) {
                    System.arraycopy(lat, (c * lh + y) * lw, side, (c * lh + y) * 2 * lw, lw)
                    System.arraycopy(img, (c * lh + y) * lw, side, (c * lh + y) * 2 * lw + lw, lw)
                }
                val ts = SystemClock.elapsedRealtime()
                val v = g.run(mapOf("sample" to side, "timestep" to floatArrayOf(sg[i] * 1000f), "ehs" to ehs, "mask" to mask,
                    "time_ids" to floatArrayOf(W.toFloat(), H.toFloat())))["noise"] ?: error("el modelo no devolvió nada")
                val dt = sg[i + 1] - sg[i]
                lat = FloatArray(lat.size) { k -> lat[k] + dt * v[k] }
                say(ctx.getString(R.string.dl_drawing, (i + 1) * 25), 10 + (i + 1) * 20)
                if (i == 0) {
                    JobLog.add("DreamLite: paso 1 en ${SystemClock.elapsedRealtime() - ts} ms (σ ${"%.3f".format(Locale.US, sg[0])}→${"%.3f".format(Locale.US, sg[1])})")
                }
            }
        }

        // 4. back to pixels
        val (out, osh) = vae(File(d, "dl_vae_dec.onnx"), "latents", lat, longArrayOf(1, 4, lh.toLong(), lw.toLong()))
        val res = toBitmap(out, osh[3].toInt(), osh[2].toInt())
        JobLog.add("DreamLite: editado en ${(SystemClock.elapsedRealtime() - t0) / 1000f} s · ${res.width}×${res.height}")
        return res
    }

    /** Checks against the server: the tokenizer, the step schedule, and one UNet step. Blocking. */
    fun selfTest(ctx: Context, stop: () -> Boolean): String {
        val d = dir(ctx)
        val meta = JSONObject(File(d, "dl_test.json").readText())
        // tokenizer
        val tk = tokenizer(ctx)
        val checks = meta.getJSONArray("token_checks")
        for (k in 0 until checks.length()) {
            val c = checks.getJSONObject(k)
            val want = c.getJSONArray("ids").let { a -> IntArray(a.length()) { a.getInt(it) } }
            val got = tk.encode(c.getString("text"))
            if (!got.contentEquals(want)) error("el tokenizador separa distinto «${c.getString("text")}»: ${got.joinToString()} contra ${want.joinToString()}")
        }
        // the schedule
        val steps = meta.getJSONArray("steps")
        val s0 = steps.getJSONObject(0)
        val sz = meta.getJSONArray("size"); val W = sz.getInt(0); val H = sz.getInt(1)
        val sg = sigmas(H / 8, W / 8)
        for (i in 0 until 4) {
            val want = steps.getJSONObject(i).getDouble("timestep")
            if (Math.abs(sg[i] * 1000 - want) > 0.5) error("los pasos no coinciden: ${sg[i] * 1000} contra $want")
        }
        // one step of the UNet against the server's float answer
        val blob = ByteBuffer.wrap(File(d, "dl_test.f16").readBytes()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        fun arr(o: org.json.JSONArray): FloatArray { val off = o.getInt(0); val len = o.getInt(1); return FloatArray(len) { android.util.Half.toFloat(blob.get(off + it)) } }
        val lmax = meta.getInt("lmax")
        val valid = s0.getInt("valid")
        val t = SystemClock.elapsedRealtime()
        val got = NpuGraph(File(d, "dl_unet_ctx.onnx")).use { g ->
            if (stop()) throw InterruptedException()
            g.run(mapOf("sample" to arr(s0.getJSONArray("sample")), "timestep" to floatArrayOf(s0.getDouble("timestep").toFloat()),
                "ehs" to arr(s0.getJSONArray("ehs")), "mask" to FloatArray(lmax) { if (it < valid) 1f else 0f },
                "time_ids" to s0.getJSONArray("time_ids").let { a -> FloatArray(a.length()) { a.getDouble(it).toFloat() } }))["noise"]!!
        }
        val want = arr(s0.getJSONArray("out"))
        var dot = 0.0; var a2 = 0.0; var b2 = 0.0
        for (k in want.indices) { dot += got[k] * want[k]; a2 += got[k] * got[k]; b2 += want[k] * want[k] }
        val cos = dot / (sqrt(a2) * sqrt(b2) + 1e-9)
        val line = String.format(Locale.US, "tokenizador ✓ · pasos ✓ · un paso del modelo en la NPU %.1f s · parecido %.4f",
            (SystemClock.elapsedRealtime() - t) / 1000f, cos)
        JobLog.add("DreamLite: $line")
        if (cos < 0.95) error("el modelo en la NPU se aleja del original (parecido ${"%.3f".format(Locale.US, cos)})")
        return line
    }
}
