package com.nitido.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

/**
 * The chosen options, always visible as tappable labels under the picture. Tapping a label opens
 * a small selector with only that option's controls (the screen's own views, moved there), right
 * above the labels; tapping it again, or another label, closes it. Labels that are simple on/off
 * switches toggle straight away.
 */
class OptionBar(private val ctx: Context, private val labels: ChipGroup, private val panel: OptionPanel) {

    private class Opt(
        val chip: Chip, val title: String, val text: () -> String, val section: List<View>,
        val on: () -> Boolean, val shown: () -> Boolean, val tap: (() -> Unit)?, val closeOnPick: Boolean,
        val icon: String?,
    )

    /** A small symbol in front of each label, by its title (the same in every screen). */
    private val icons: Map<String, String> = listOf(
        R.string.label_scale to "⤢", R.string.label_model to "◆", R.string.label_engine to "⚡",
        R.string.opt_faces_short to "☺", R.string.opt_deblur_short to "◎",
        R.string.sd_model to "▣", R.string.sd_label_photo to "▨", R.string.sd_label_format to "▯",
        R.string.sd_label_backend to "⚡", R.string.sd_steps to "≡", R.string.sd_guidance to "◐", R.string.opt_more_title to "⋯",
        R.string.opt_crop to "✂", R.string.opt_color to "◐", R.string.opt_denoise to "∷", R.string.opt_colorize to "◑",
        R.string.opt_detail to "✦", R.string.proc_title to "⚡", R.string.restore_marks to "✎", R.string.adjust_title to "⚙",
        R.string.mask_tool to "✎", R.string.mask_size to "●", R.string.mask_auto to "✦", R.string.log_title to "☰",
    ).associate { (id, sym) -> ctx.getString(id) to sym }

    private val opts = mutableListOf<Opt>()
    private var open: Opt? = null
    /** Called when the selector opens or closes (screens hide their prompt while it is open). */
    var onOpenChanged: ((Boolean) -> Unit)? = null

    private val fg = ContextCompat.getColor(ctx, R.color.fg)
    private val off = ContextCompat.getColor(ctx, R.color.muted)
    private val line = ContextCompat.getColor(ctx, R.color.line_hi)
    private val accent = ContextCompat.getColor(ctx, R.color.accent)
    private val chipBg = ContextCompat.getColor(ctx, R.color.stage)

    init {
        panel.visibility = View.GONE
        panel.onTouched = { picked ->
            refresh()
            // one choice made (a button, or a slider let go): the selector goes away by itself
            if (picked && open?.closeOnPick == true) close()
        }
    }

    /**
     * One label. [section]: the views its selector shows (moved out of their place in the layout).
     * [tap]: instead of a selector, do this (switches, pickers). [on]: false shows it greyed (off).
     * [shown]: hide the label when it doesn't apply (default: while any of its views is visible).
     */
    fun add(title: String, text: () -> String, section: List<View> = emptyList(), on: () -> Boolean = { true },
            shown: (() -> Boolean)? = null, closeOnPick: Boolean = true, tap: (() -> Unit)? = null) {
        val chip = Chip(ctx).apply {
            isCheckable = false
            setEnsureMinTouchTargetSize(false)
            chipBackgroundColor = ColorStateList.valueOf(chipBg)
            chipCornerRadius = 99f
            textSize = 12.5f
        }
        val box = panelBox(title)
        for (v in section) {
            (v.parent as? ViewGroup)?.removeView(v)
            box.addView(v)
        }
        val o = Opt(chip, title, text, if (section.isEmpty()) emptyList() else listOf(box), on,
            shown ?: { section.isEmpty() || section.any { it.visibility != View.GONE } }, tap, closeOnPick, icons[title])
        chip.setOnClickListener {
            when {
                o.tap != null -> { close(); o.tap.invoke(); refresh() }
                open === o -> close()
                else -> show(o)
            }
        }
        opts += o
        labels.addView(chip)
        refresh()
    }

    private fun panelBox(title: String) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
        addView(TextView(ctx).apply { text = title; textSize = 11f; setTextColor(off) })
        panel.content.addView(this)
    }

    private fun show(o: Opt) {
        open?.section?.forEach { it.visibility = View.GONE }
        open = o
        o.section.forEach { it.visibility = View.VISIBLE }
        panel.visibility = View.VISIBLE
        onOpenChanged?.invoke(true)
        refresh()
    }

    fun close() {
        if (open == null) return
        open?.section?.forEach { it.visibility = View.GONE }
        open = null
        panel.visibility = View.GONE
        onOpenChanged?.invoke(false)
        refresh()
    }

    fun isOpen() = open != null

    /** Re-reads every label (call after changing options from code). */
    fun refresh() {
        for (o in opts) {
            val vis = try { o.shown() } catch (t: Throwable) { true }
            o.chip.visibility = if (vis) View.VISIBLE else View.GONE
            val raw = try { o.text() } catch (t: Throwable) { o.title }
            val isOn = try { o.on() } catch (t: Throwable) { true }
            o.chip.setTextColor(if (isOn) fg else off)
            o.chip.text = if (o.icon == null) raw else {
                // the symbol in the accent color (grey when the option is off); "\uFE0E" keeps it a plain
                // symbol instead of a color emoji
                val body = raw.removePrefix(o.icon).trimStart()
                android.text.SpannableString(o.icon + "\uFE0E  " + body).apply {
                    setSpan(android.text.style.ForegroundColorSpan(if (isOn) accent else line), 0, o.icon.length + 1,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            val active = open === o
            o.chip.chipStrokeColor = ColorStateList.valueOf(if (active) accent else line)
            o.chip.chipStrokeWidth = ctx.resources.displayMetrics.density * (if (active) 2f else 1f)
        }
        if (open != null && open?.chip?.visibility != View.VISIBLE) close()
    }
}

/** The little selector above the labels; any touch inside refreshes the labels a moment later. */
class OptionPanel @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {
    val content: LinearLayout = LinearLayout(context).apply { orientation = VERTICAL }
    /** Called after a touch ends: false right away (refresh), true a moment later (a choice was made). */
    var onTouched: ((Boolean) -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())

    init {
        orientation = VERTICAL
        // a tall selector (color adjustments) scrolls inside, so the picture above stays big
        addView(android.widget.ScrollView(context).apply {
            isFillViewport = false
            addView(content, android.widget.FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    /** At most ~40% of the screen's height. */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val cap = (resources.displayMetrics.heightPixels * 0.40f).toInt()
        val mode = MeasureSpec.getMode(heightMeasureSpec)
        val size = MeasureSpec.getSize(heightMeasureSpec)
        val maxH = if (mode == MeasureSpec.UNSPECIFIED) cap else minOf(size, cap)
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            h.removeCallbacksAndMessages(null)
            h.postDelayed({ onTouched?.invoke(false) }, 120)
            if (ev.actionMasked == MotionEvent.ACTION_UP) h.postDelayed({ onTouched?.invoke(true) }, 350)
        }
        return super.dispatchTouchEvent(ev)
    }
}
