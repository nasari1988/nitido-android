package com.nitido.app

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.slider.Slider

/**
 * The pieces of the new screens (the mockups «Nítido: nueva experiencia»): one look for every
 * screen. Rows with a segmented choice or a switch, the orange dot of «solo para esta foto», the
 * chips of what ✦ will do, the cream ✦ button with its time, and the sheets.
 */
object Kit {
    const val ORANGE = 0xFFE8A04A.toInt()
    private const val ORANGE_BG = 0xFF2A2014.toInt()
    private const val ORANGE_LINE = 0xFF5A4220.toInt()
    private const val ORANGE_TEXT = 0xFFF0D2A6.toInt()
    private const val ROW_LINE = 0xFF1F2923.toInt()
    private const val CHIP_ON_BG = 0xFF203126.toInt()
    private const val CHIP_ON_TEXT = 0xFFDDEBD9.toInt()
    private const val CHIP_OFF_TEXT = 0xFF7F887F.toInt()

    private fun dp(c: Context, v: Int) = Ui.dp(c, v)
    private fun col(c: Context, id: Int) = Ui.color(c, id)

    /** Title bar: ← (or ˅), the title, and an optional pill on the right. */
    fun header(c: Context, title: String, onBack: () -> Unit, right: String? = null, onRight: (() -> Unit)? = null): LinearLayout {
        val row = Ui.row(c).apply { minimumHeight = dp(c, 48) }
        row.addView(TextView(c).apply {
            text = "←"; textSize = 22f; setTextColor(col(c, R.color.fg)); gravity = Gravity.CENTER
            contentDescription = "Volver"
            setOnClickListener { onBack() }
        }, LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)))
        row.addView(Ui.text(c, title, 20f, R.color.fg, bold = true).apply { tag = "title" }, LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) row.addView(pill(c, right, onRight ?: {}).apply { tag = "right" })
        return row
    }

    /** A small outlined pill button («Otra foto», «Sencillo»). */
    fun pill(c: Context, s: String, onClick: () -> Unit) = TextView(c).apply {
        text = s; textSize = 13f; setTextColor(col(c, R.color.fg2)); gravity = Gravity.CENTER
        setPadding(dp(c, 12), 0, dp(c, 12), 0); minHeight = dp(c, 36); minWidth = dp(c, 44)
        background = Ui.round(c, 0, 18, col(c, R.color.line))
        setOnClickListener { onClick() }
    }

    /** Small grey heading over a group of rows («Limpiar», «Caras y detalle»). */
    fun section(c: Context, s: String) = Ui.text(c, s, 12f, R.color.muted).apply { setPadding(0, dp(c, 12), 0, dp(c, 2)) }

    /** The orange dot (a change for this photo only), as text to put before a label. */
    fun dotted(c: Context, s: CharSequence, dot: Boolean): CharSequence {
        if (!dot) return s
        val b = SpannableStringBuilder("● ").append(s)
        b.setSpan(ForegroundColorSpan(ORANGE), 0, 1, 0)
        b.setSpan(android.text.style.RelativeSizeSpan(0.7f), 0, 1, 0)
        return b
    }

    /** A row: label (with an optional small line under it) on the left, a control on the right. */
    fun row(c: Context, label: CharSequence, sub: String?, control: View?): LinearLayout {
        val r = Ui.row(c).apply {
            minimumHeight = dp(c, 48)
            setPadding(0, dp(c, 6), 0, dp(c, 6))
            background = android.graphics.drawable.LayerDrawable(arrayOf(android.graphics.drawable.ColorDrawable(ROW_LINE))).apply {
                setLayerHeight(0, 1); setLayerGravity(0, Gravity.TOP)
            }
        }
        val texts = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui.text(c, label, 14f, R.color.fg).apply { tag = "label" })
        texts.addView(Ui.text(c, sub ?: "", 11f, R.color.muted).apply { tag = "sub"; visibility = if (sub == null) View.GONE else View.VISIBLE })
        r.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        if (control != null) r.addView(control)
        return r
    }

    fun setRow(r: LinearLayout, label: CharSequence, sub: String?) {
        r.findViewWithTag<TextView>("label")?.text = label
        r.findViewWithTag<TextView>("sub")?.apply { text = sub ?: ""; visibility = if (sub == null) View.GONE else View.VISIBLE }
    }

    /**
     * Segmented choice: [options] as small pills; [selected] in green, or in orange when it differs
     * from what the preferences say ([base]).
     */
    class Seg(c: Context, val options: List<String>, private val onPick: (Int) -> Unit) : LinearLayout(c) {
        var selected = 0; private set
        var base = 0
        private val views = ArrayList<TextView>()
        init {
            orientation = HORIZONTAL
            for ((i, o) in options.withIndex()) {
                val t = TextView(c).apply {
                    text = o; textSize = 12f; gravity = Gravity.CENTER
                    setPadding(dp(c, 9), 0, dp(c, 9), 0); minHeight = dp(c, 32)
                    setOnClickListener { set(i); onPick(i) }
                }
                views += t
                addView(t, LayoutParams(-2, -2).apply { marginStart = if (i == 0) 0 else dp(c, 4) })
            }
            paint()
        }
        fun set(i: Int) { selected = i.coerceIn(0, options.size - 1); paint() }
        private fun paint() {
            for ((i, t) in views.withIndex()) {
                val on = i == selected
                val temp = on && selected != base
                t.setTextColor(when { temp -> 0xFF1E1408.toInt(); on -> col(context, R.color.bg); else -> col(context, R.color.fg2) })
                t.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                t.background = Ui.round(context, when { temp -> ORANGE; on -> col(context, R.color.accent); else -> 0 }, 16,
                    if (on) null else col(context, R.color.line_hi))
            }
        }
    }

    /** A switch in the app's colors. */
    fun switch(c: Context, on: Boolean, onChange: (Boolean) -> Unit) =
        com.google.android.material.materialswitch.MaterialSwitch(c).apply {
            isChecked = on; setOnCheckedChangeListener { _, v -> onChange(v) }
        }

    /** A slider row: label and value on top, the slider under it, marks under that. */
    fun slider(c: Context, label: String, from: Float, to: Float, value: Float, marks: String?, fmt: (Float) -> String, onChange: (Float) -> Unit): LinearLayout {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 6)) }
        val top = Ui.row(c)
        top.addView(Ui.text(c, label, 14f, R.color.fg).apply { tag = "label" }, LinearLayout.LayoutParams(0, -2, 1f))
        val v = Ui.text(c, fmt(value), 13f, R.color.accent, bold = true)
        top.addView(v)
        box.addView(top)
        box.addView(Slider(c).apply {
            valueFrom = from; valueTo = to; stepSize = 1f; this.value = value.coerceIn(from, to)
            addOnChangeListener { _, x, user -> v.text = fmt(x); if (user) onChange(x) }
            tag = "slider"
        })
        if (marks != null) box.addView(Ui.text(c, marks, 10f, R.color.muted))
        return box
    }

    /** A chip of what ✦ will do: on (green), off (struck through), with the orange dot when changed for this photo. */
    fun stepChip(c: Context, s: String, onClick: () -> Unit) = TextView(c).apply {
        textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(c, 12), 0, dp(c, 12), 0); minHeight = dp(c, 36)
        tag = s
        setOnClickListener { onClick() }
    }

    fun paintChip(t: TextView, on: Boolean, temp: Boolean) {
        val c = t.context
        t.text = dotted(c, t.tag as String, temp)
        t.paintFlags = if (on) t.paintFlags and android.graphics.Paint.STRIKE_THRU_TEXT_FLAG.inv() else t.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
        t.setTextColor(if (on) CHIP_ON_TEXT else CHIP_OFF_TEXT)
        t.background = Ui.round(c, if (on) CHIP_ON_BG else col(c, R.color.chip), 18, if (on) col(c, R.color.accent) else col(c, R.color.line_hi))
    }

    /** Chips that wrap onto more lines. */
    fun flow(c: Context) = com.google.android.material.chip.ChipGroup(c).apply {
        chipSpacingHorizontal = dp(c, 8); chipSpacingVertical = dp(c, 8)
    }

    /** «● N cambios solo para esta foto: … · Deshacer» (orange banner). */
    fun tempBanner(c: Context, onUndo: () -> Unit): LinearLayout {
        val r = Ui.row(c).apply {
            setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
            background = Ui.round(c, ORANGE_BG, 12, ORANGE_LINE)
        }
        r.addView(TextView(c).apply { textSize = 12f; setTextColor(ORANGE_TEXT); tag = "text" }, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(TextView(c).apply {
            text = "Deshacer"; textSize = 12f; setTextColor(ORANGE_TEXT); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6)); background = Ui.round(c, 0, 16, 0xFF8A6A3A.toInt())
            setOnClickListener { onUndo() }
        })
        return r
    }

    fun setBanner(b: LinearLayout, text: String?) {
        b.visibility = if (text == null) View.GONE else View.VISIBLE
        b.findViewWithTag<TextView>("text")?.text = dotted(b.context, text ?: "", true)
    }

    /** «● N cambios solo para esta foto      ⚙ Avanzado» line above the ✦ button. */
    fun advancedLine(c: Context, onClick: () -> Unit): LinearLayout {
        val r = Ui.row(c).apply { setPadding(dp(c, 2), dp(c, 6), dp(c, 2), dp(c, 6)); setOnClickListener { onClick() } }
        r.addView(Ui.text(c, "", 13f, R.color.fg2).apply { tag = "text" }, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(Ui.text(c, "⚙ Avanzado", 13f, R.color.accent, bold = true))
        return r
    }

    fun setAdvancedLine(r: LinearLayout, changes: Int, summary: String) {
        r.findViewWithTag<TextView>("text")?.text = if (changes > 0)
            dotted(r.context, if (changes == 1) "1 cambio solo para esta foto" else "$changes cambios solo para esta foto", true) else summary
    }

    /** A full-height sheet (Avanzado): a title bar, scrolling rows, and a bottom area. */
    class Sheet(c: Context, title: String, rightText: String?, onRight: (() -> Unit)?) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(c)
        val rows = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), 0, dp(c, 12), dp(c, 8)) }
        val top = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), 0, dp(c, 12), 0) }
        val bottom = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 14)) }
        init {
            val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.color(c, R.color.bg)) }
            root.addView(header(c, title, { dialog.dismiss() }, rightText, onRight?.let { r -> { dialog.dismiss(); r() } }).apply {
                setPadding(dp(c, 4), dp(c, 6), dp(c, 12), 0)
            })
            root.addView(top)
            root.addView(android.widget.ScrollView(c).apply { addView(rows) }, LinearLayout.LayoutParams(-1, 0, 1f))
            root.addView(bottom)
            dialog.setContentView(root, ViewGroup.LayoutParams(-1, (c.resources.displayMetrics.heightPixels * 0.94f).toInt()))
            dialog.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
            dialog.behavior.skipCollapsed = true
        }
        fun show() = dialog.show()
    }

    /** A row of square action buttons (Resultado): icon over a word. */
    fun action(c: Context, icon: String, s: String, onClick: () -> Unit) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        minimumHeight = dp(c, 56)
        background = Ui.round(c, 0xFF141A16.toInt(), 14, col(c, R.color.line_hi))
        addView(Ui.text(c, icon, 16f, R.color.fg).apply { gravity = Gravity.CENTER })
        addView(Ui.text(c, s, 12f, R.color.fg, bold = true).apply { gravity = Gravity.CENTER })
        setOnClickListener { onClick() }
    }

    fun frameLp(gravity: Int, margin: Int, c: Context) = FrameLayout.LayoutParams(-2, -2, gravity).apply { val m = dp(c, margin); setMargins(m, m, m, m) }
}
