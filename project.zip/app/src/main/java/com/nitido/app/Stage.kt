package com.nitido.app

import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * The rule of every screen: the picture (or video) first, across the whole width at its own shape;
 * the controls under it, scrolling only if they don't fit; the main button always visible at the
 * bottom. Only a very tall picture is limited, so the order and the button always show.
 */
object Stage {
    /** The tallest the picture may be: this part of the screen's height. */
    private const val MAX_SHARE = 0.60f
    private const val MIN_SHARE = 0.28f

    /**
     * Rearranges [panel] (a vertical LinearLayout holding [stage]): the views after [stage] go into a
     * scroll under it, [pinned] (direct children of [panel]) stay below the scroll. [size] gives the
     * shown picture's width and height (null: nothing shown yet, then a 4:3 frame).
     */
    fun arrange(panel: LinearLayout, stage: View, pinned: List<View>, size: () -> Pair<Int, Int>?) {
        val idx = panel.indexOfChild(stage)
        if (idx < 0) return
        val after = (idx + 1 until panel.childCount).map { panel.getChildAt(it) }
        val col = LinearLayout(panel.context).apply { orientation = LinearLayout.VERTICAL }
        val keep = ArrayList<View>()
        for (v in after) {
            panel.removeView(v)
            if (v in pinned) { keep += v; continue }
            val lp = v.layoutParams as? LinearLayout.LayoutParams
            if (lp != null && lp.weight > 0f && lp.height == 0) { lp.weight = 0f; lp.height = ViewGroup.LayoutParams.WRAP_CONTENT }
            col.addView(v)
        }
        val sv = ScrollView(panel.context).apply { isVerticalScrollBarEnabled = false; addView(col, ViewGroup.LayoutParams(-1, -2)) }
        panel.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        for (v in keep) panel.addView(v)
        (stage.layoutParams as? LinearLayout.LayoutParams)?.let { it.weight = 0f; it.height = 1; stage.layoutParams = it }
        // follow the shown picture's shape
        stage.viewTreeObserver.addOnPreDrawListener { !fit(stage, size()) }
    }

    /** True when the height changed (that frame is skipped: the next one has the right size). */
    private fun fit(stage: View, s: Pair<Int, Int>?): Boolean {
        val w = stage.width
        if (w <= 0) return false
        val screen = stage.resources.displayMetrics.heightPixels
        val (pw, ph) = s?.takeIf { it.first > 0 && it.second > 0 } ?: (4 to 3)
        val want = (w.toLong() * ph / pw).toInt().coerceIn((screen * MIN_SHARE).toInt(), (screen * MAX_SHARE).toInt())
        val lp = stage.layoutParams ?: return false
        if (Math.abs(lp.height - want) <= 2) return false
        lp.height = want; stage.layoutParams = lp
        return true
    }
}
