package com.nitido.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ajustes: Calidad (Rápido / Equilibrado / Máxima), the gallery, the fingerprint, the end-of-job
 * notice, the space taken by models and temporary files, "Enviar reporte", Modo avanzado and the
 * version. Everything technical lives in Modo avanzado.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var modelsSize: TextView
    private lateinit var tempSize: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 16), Ui.dp(context, 8), Ui.dp(context, 16), Ui.dp(context, 24))
        }
        col.addView(Kit.header(this, getString(R.string.settings_title), { finish() }))
        // ✦ Mis preferencias first (mockup 5)
        col.addView(Ui.row(this).apply {
            setPadding(Ui.dp(context, 14), Ui.dp(context, 12), Ui.dp(context, 14), Ui.dp(context, 12))
            background = Ui.round(context, 0xFF141A16.toInt(), 14, Ui.color(context, R.color.accent))
            val t = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            t.addView(Ui.text(context, "✦ " + getString(R.string.qa_title), 15f, R.color.fg, bold = true))
            t.addView(Ui.text(context, getString(R.string.kit_prefs_sub), 12f, R.color.muted))
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.text(context, "›", 18f, R.color.muted))
            setOnClickListener { startActivity(Intent(this@SettingsActivity, QuickActionsActivity::class.java)) }
        }, Ui.lp(this, 6))

        val space = box(col, R.string.set_space)
        modelsSize = Ui.text(this, "", 13f, R.color.accent)
        space.addView(item(R.string.set_models, modelsSize) { startActivity(Intent(this, ModelsActivity::class.java)) })
        tempSize = Ui.text(this, "", 13f, R.color.accent)
        space.addView(item(R.string.set_free, tempSize) { freeTemp() })

        val perf = box(col, R.string.kit_performance)
        val opts = listOf("fast" to R.string.set_q_fast, "balanced" to R.string.set_q_balanced, "max" to R.string.set_q_max)
        val qNote = getString(when (Prefs.quality(this)) { "fast" -> R.string.set_q_fast_note; "max" -> R.string.set_q_max_note; else -> R.string.set_q_balanced_note })
        lateinit var qRow: LinearLayout
        val seg = Kit.Seg(this, opts.map { getString(it.second) }) { i ->
            val k = opts[i].first
            Prefs.setQuality(this, k)
            Kit.setRow(qRow, getString(R.string.set_quality), getString(when (k) { "fast" -> R.string.set_q_fast_note; "max" -> R.string.set_q_max_note; else -> R.string.set_q_balanced_note }))
            JobLog.add("Ajustes: calidad $k")
        }
        val qi = opts.indexOfFirst { it.first == Prefs.quality(this) }.coerceAtLeast(0)
        seg.base = qi; seg.set(qi)
        qRow = Kit.row(this, getString(R.string.set_quality), qNote, seg)
        perf.addView(qRow)

        val res = box(col, R.string.kit_results_sec)
        res.addView(Kit.row(this, getString(R.string.set_autosave), null, Kit.switch(this, Prefs.autosave(this)) { Prefs.setAutosave(this, it) }))
        res.addView(Kit.row(this, getString(R.string.set_lock), null, Kit.switch(this, Prefs.lockResults(this)) { Prefs.setLockResults(this, it) }))
        res.addView(Kit.row(this, getString(R.string.set_notify), null, Kit.switch(this, Prefs.notifyDone(this)) { Prefs.setNotifyDone(this, it) }))
        res.addView(item(R.string.set_registry, null) { startActivity(Intent(this, OriginActivity::class.java)) })

        val help = box(col, R.string.set_help)
        help.addView(item(R.string.set_report, null) { Ui.sendReport(this) })
        help.addView(item(R.string.set_log, null) { LogDialog.show(this) })
        help.addView(item(R.string.set_autotest, null) { startActivity(Intent(this, AutoTestActivity::class.java)) })
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (t: Throwable) { "?" }
        col.addView(Ui.text(this, getString(R.string.set_about, ver), 13f, R.color.muted).apply { gravity = Gravity.CENTER }, Ui.lp(this, 24))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col) })
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val (m, t) = withContext(Dispatchers.IO) {
                val models = ModelCatalog.local(this@SettingsActivity).sumOf { ModelCatalog.sizeOnPhone(this@SettingsActivity, it) }
                models to junkFiles().sumOf { dirSize(it) }
            }
            modelsSize.text = ModelCatalog.mb(m)
            tempSize.text = getString(R.string.set_temp, ModelCatalog.mb(t))
        }
    }

    private fun junkFiles(): List<java.io.File> {
        val last = getSharedPreferences("nitido", MODE_PRIVATE).getString("last_result", null)
        val junk = Regex("""(sd_.*\.jpg|sd_refined_.*|timelapse_.*\.mp4|refine_tile\.jpg|detail_tile\.jpg|reimagine\.png|video_out\.mp4|npu_prof|.*\.tmp)""")
        return cacheDir.listFiles()?.filter { junk.matches(it.name) && it.absolutePath != last } ?: emptyList()
    }

    private fun dirSize(f: java.io.File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    /** Temporary files only: the pictures being worked on and old previews (never models or results). */
    private fun freeTemp() {
        if (BgWork.busy) { android.widget.Toast.makeText(this, R.string.set_free_busy, android.widget.Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            val freed = withContext(Dispatchers.IO) {
                var n = 0L
                // only leftovers of earlier jobs; the photo being restored, the last Crear result,
                // the last video and the processors' tuning caches (they make jobs start faster) stay
                for (f in junkFiles()) { val sz = dirSize(f); if (f.deleteRecursively()) n += sz }
                n
            }
            JobLog.add("Ajustes: liberados ${ModelCatalog.mb(freed)} de temporales")
            android.widget.Toast.makeText(this@SettingsActivity, getString(R.string.set_freed, ModelCatalog.mb(freed)), android.widget.Toast.LENGTH_SHORT).show()
            onResume()
        }
    }

    /** A titled box of rows (mockup 5). */
    private fun box(col: LinearLayout, title: Int): LinearLayout {
        col.addView(Ui.text(this, getString(title), 12f, R.color.muted), Ui.lp(this, 16))
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 14), Ui.dp(context, 2), Ui.dp(context, 14), Ui.dp(context, 2))
            background = Ui.round(context, 0xFF141A16.toInt(), 14, Ui.color(context, R.color.line))
        }
        col.addView(b, Ui.lp(this, 4))
        return b
    }

    private fun section(col: LinearLayout, title: Int) =
        col.addView(Ui.text(this, getString(title), 13f, R.color.muted), Ui.lp(this, 20))

    private fun switch(label: Int, on: Boolean, set: (Boolean) -> Unit) = MaterialSwitch(this).apply {
        text = getString(label); isChecked = on; textSize = 15f
        setTextColor(Ui.color(context, R.color.fg))
        setOnCheckedChangeListener { _, v -> set(v) }
    }

    private fun item(label: Int, right: TextView?, onClick: () -> Unit) = Ui.row(this).apply {
        setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 14))
        addView(Ui.text(context, getString(label), 15f), LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) addView(right)
        addView(Ui.text(context, "  ›", 18f, R.color.muted))
        setOnClickListener { onClick() }
    }
}
