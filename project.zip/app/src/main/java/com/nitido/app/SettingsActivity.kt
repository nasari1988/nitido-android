package com.nitido.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ajustes: Calidad (Rápido / Equilibrado / Máxima), the gallery, the fingerprint, the end-of-job
 * notice, the space taken by models and temporary files, "Enviar reporte", Modo avanzado and the
 * version. Everything technical lives in Modo avanzado.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var modelsSize: TextView
    private lateinit var tempSize: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 16), Ui.dp(context, 8), Ui.dp(context, 16), Ui.dp(context, 24))
        }
        val head = Ui.row(this)
        head.addView(Ui.text(this, "←", 22f).apply { setPadding(Ui.dp(context, 6), Ui.dp(context, 6), Ui.dp(context, 14), Ui.dp(context, 6)); setOnClickListener { finish() } })
        head.addView(Ui.text(this, getString(R.string.settings_title), 19f, bold = true))
        col.addView(head)

        section(col, R.string.set_quality)
        val q = Ui.chipRow(this)
        val opts = listOf("fast" to R.string.set_q_fast, "balanced" to R.string.set_q_balanced, "max" to R.string.set_q_max)
        val chips = mutableListOf<TextView>()
        val qNote = Ui.text(this, "", 12f, R.color.muted)
        fun note(k: String) { qNote.text = getString(when (k) { "fast" -> R.string.set_q_fast_note; "max" -> R.string.set_q_max_note; else -> R.string.set_q_balanced_note }) }
        for ((k, l) in opts) {
            chips += Ui.chip(this, getString(l), Prefs.quality(this) == k) {
                Prefs.setQuality(this, k); chips.forEachIndexed { i, c -> Ui.setChip(c, opts[i].first == k) }; note(k)
                JobLog.add("Ajustes: calidad $k")
            }
        }
        chips.forEach { q.addView(it) }
        col.addView(q, Ui.lp(this, 4)); col.addView(qNote, Ui.lp(this, 4)); note(Prefs.quality(this))

        col.addView(switch(R.string.set_autosave, Prefs.autosave(this)) { Prefs.setAutosave(this, it) }, Ui.lp(this, 12))
        col.addView(switch(R.string.set_lock, Prefs.lockResults(this)) { Prefs.setLockResults(this, it) }, Ui.lp(this, 4))
        col.addView(switch(R.string.set_notify, Prefs.notifyDone(this)) { Prefs.setNotifyDone(this, it) }, Ui.lp(this, 4))

        section(col, R.string.set_space)
        modelsSize = Ui.text(this, "", 13f, R.color.muted)
        col.addView(item(R.string.set_models, modelsSize) { startActivity(Intent(this, ModelsActivity::class.java)) })
        tempSize = Ui.text(this, "", 13f, R.color.muted)
        col.addView(item(R.string.set_free, tempSize) { freeTemp() })

        section(col, R.string.set_help)
        col.addView(item(R.string.set_report, null) { Ui.sendReport(this) })
        col.addView(item(R.string.set_log, null) { LogDialog.show(this) })
        col.addView(item(R.string.set_autotest, null) { startActivity(Intent(this, AutoTestActivity::class.java)) })
        col.addView(switch(R.string.set_advanced, Prefs.advanced(this)) {
            Prefs.setAdvanced(this, it); JobLog.add("Ajustes: modo avanzado " + if (it) "sí" else "no")
        }, Ui.lp(this, 4))
        col.addView(Ui.text(this, getString(R.string.set_advanced_note), 12f, R.color.muted))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (t: Throwable) { "?" }
        col.addView(Ui.text(this, getString(R.string.set_about, ver), 13f, R.color.muted).apply { gravity = Gravity.CENTER }, Ui.lp(this, 24))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col) })
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val (m, t) = withContext(Dispatchers.IO) {
                val models = ModelCatalog.local(this@SettingsActivity).sumOf { ModelCatalog.sizeOnPhone(this@SettingsActivity, it) }
                models to junkFiles().sumOf { dirSize(it) }
            }
            modelsSize.text = ModelCatalog.mb(m)
            tempSize.text = getString(R.string.set_temp, ModelCatalog.mb(t))
        }
    }

    private fun junkFiles(): List<java.io.File> {
        val last = getSharedPreferences("nitido", MODE_PRIVATE).getString("last_result", null)
        val junk = Regex("""(sd_.*\.jpg|sd_refined_.*|timelapse_.*\.mp4|refine_tile\.jpg|detail_tile\.jpg|reimagine\.png|video_out\.mp4|npu_prof|.*\.tmp)""")
        return cacheDir.listFiles()?.filter { junk.matches(it.name) && it.absolutePath != last } ?: emptyList()
    }

    private fun dirSize(f: java.io.File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    /** Temporary files only: the pictures being worked on and old previews (never models or results). */
    private fun freeTemp() {
        if (BgWork.busy) { android.widget.Toast.makeText(this, R.string.set_free_busy, android.widget.Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            val freed = withContext(Dispatchers.IO) {
                var n = 0L
                // only leftovers of earlier jobs; the photo being restored, the last Crear result,
                // the last video and the processors' tuning caches (they make jobs start faster) stay
                for (f in junkFiles()) { val sz = dirSize(f); if (f.deleteRecursively()) n += sz }
                n
            }
            JobLog.add("Ajustes: liberados ${ModelCatalog.mb(freed)} de temporales")
            android.widget.Toast.makeText(this@SettingsActivity, getString(R.string.set_freed, ModelCatalog.mb(freed)), android.widget.Toast.LENGTH_SHORT).show()
            onResume()
        }
    }

    private fun section(col: LinearLayout, title: Int) =
        col.addView(Ui.text(this, getString(title), 13f, R.color.muted), Ui.lp(this, 20))

    private fun switch(label: Int, on: Boolean, set: (Boolean) -> Unit) = MaterialSwitch(this).apply {
        text = getString(label); isChecked = on; textSize = 15f
        setTextColor(Ui.color(context, R.color.fg))
        setOnCheckedChangeListener { _, v -> set(v) }
    }

    private fun item(label: Int, right: TextView?, onClick: () -> Unit) = Ui.row(this).apply {
        setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 14))
        addView(Ui.text(context, getString(label), 15f), LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) addView(right)
        addView(Ui.text(context, "  ›", 18f, R.color.muted))
        setOnClickListener { onClick() }
    }
}
