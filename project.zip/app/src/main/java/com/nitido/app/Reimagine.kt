package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.Locale

/**
 * ✦ Reimaginar (Restaurar's last, optional step): the restored photo redrawn with an SDXL model on
 * the NPU (RealVisXL Lightning by default) from the photo itself, changing [strength] of it: skin,
 * hair and cloth get real texture and the colors come alive. Faces can be redrawn once more on
 * their own, larger, and blended back. The photo is fitted whole (never cropped): padded to the
 * NPU's nearest shape and cut back afterwards.
 */
object Reimagine {
    private const val PROMPT = "high quality restored photograph, realistic natural skin texture, detailed hair, " +
        "natural colors, sharp focus, professional photo"
    private const val PROMPT_FACE = "close-up portrait photo, realistic natural skin texture, detailed eyes, " +
        "natural expression, sharp focus"
    private const val NEGATIVE = "blurry, lowres, painting, drawing, cartoon, 3d render, plastic skin, deformed, " +
        "disfigured, extra fingers, watermark, text, oversaturated"

    /** Installed SDXL models with their NPU version, the photographic ones first (RealVisXL Lightning). */
    fun models(ctx: Context): List<String> {
        val dirs = File(ctx.filesDir, "models").listFiles().orEmpty()
        return dirs.filter { it.name.endsWith("-npu") && File(it, "sdxl_p1_ctx.onnx").exists() && File(it, ".complete").exists() }
            .map { it.name.removeSuffix("-npu") }
            .filter { SdModel.isReady(ctx, it) }
            .sortedByDescending { (if ("realvis" in it) 2 else 0) + (if ("lightning" in it) 1 else 0) }
    }

    fun isFast(id: String) = Regex("lightning|turbo|lcm|hyper", RegexOption.IGNORE_CASE).containsMatchIn(id)

    /**
     * Redraws [src] ([strength] 0.1..0.7). Faces again on their own when [faces]. Returns null when
     * cancelled or nothing could be done; [say] gets progress text.
     */
    fun run(ctx: Context, src: Bitmap, modelId: String, strength: Float, faces: Boolean,
            cancelled: () -> Boolean, say: (String, Float) -> Unit): Bitmap? {
        val npuDir = NpuUnet.dirFor(ctx, modelId) ?: run { JobLog.notice("Reimaginar: $modelId no tiene versión NPU"); return null }
        val sizes = NpuUnet.sizes(ctx, modelId).ifEmpty { listOf(1024 to 1024) }
        val npu = NpuUnet.get(ctx.applicationContext, npuDir)
        SdNative.setNpu(npu)
        val t0 = SystemClock.elapsedRealtime()
        JobLog.add(String.format(Locale.US, "Reimaginar con %s · %.0f %% de cambio%s", modelId, strength * 100, if (faces) " · caras aparte" else ""))
        val whole = redraw(ctx, src, modelId, sizes, strength, PROMPT, 11, cancelled) { p -> say(ctx.getString(R.string.reim_whole, p), p / 100f * (if (faces) 0.6f else 1f)) }
            ?: return null
        var out = whole
        if (faces && !cancelled()) {
            val boxes = faceBoxes(out)
            JobLog.add("Reimaginar: ${boxes.size} caras")
            for ((i, box) in boxes.withIndex()) {
                if (cancelled()) break
                out = redrawFace(ctx, out, box, modelId, sizes, (strength * 0.8f).coerceIn(0.15f, 0.5f), cancelled) { p ->
                    say(ctx.getString(R.string.reim_face, i + 1, boxes.size, p), 0.6f + 0.4f * (i + p / 100f) / boxes.size)
                } ?: out
            }
        }
        JobLog.add("Reimaginar listo en ${(SystemClock.elapsedRealtime() - t0) / 1000} s")
        return out
    }

    /** The whole picture through SDXL at the NPU size with its shape; padded, never cropped. */
    private fun redraw(ctx: Context, src: Bitmap, modelId: String, sizes: List<Pair<Int, Int>>, strength: Float, prompt: String,
                       seed: Int, cancelled: () -> Boolean, progress: (Int) -> Unit): Bitmap? {
        val r = src.width.toFloat() / src.height
        val (w, h) = sizes.minByOrNull { (w, h) -> Math.abs(Math.log((w.toFloat() / h / r).toDouble())) } ?: (1024 to 1024)
        // fit inside w×h; the rest filled with the picture's own edge, stretched (no hard border)
        val k = minOf(w.toFloat() / src.width, h.toFloat() / src.height)
        val fw = (src.width * k).toInt().coerceAtLeast(1); val fh = (src.height * k).toInt().coerceAtLeast(1)
        val ox = (w - fw) / 2; val oy = (h - fh) / 2
        val canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(canvasBmp)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(src, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), p)   // stretched, behind
        c.drawBitmap(src, null, RectF(ox.toFloat(), oy.toFloat(), (ox + fw).toFloat(), (oy + fh).toFloat()), p)
        val res = generate(ctx, modelId, canvasBmp, w, h, strength, prompt, seed, cancelled, progress) ?: return null
        val cut = Bitmap.createBitmap(res, ox, oy, fw, fh)
        return Bitmap.createScaledBitmap(cut, src.width, src.height, true)
    }

    /** One face: a square around it (with room), redrawn at the NPU's square size, blended back softly. */
    private fun redrawFace(ctx: Context, img: Bitmap, face: Rect, modelId: String, sizes: List<Pair<Int, Int>>, strength: Float,
                           cancelled: () -> Boolean, progress: (Int) -> Unit): Bitmap? {
        val side = (maxOf(face.width(), face.height()) * 1.8f).toInt().coerceAtMost(minOf(img.width, img.height))
        if (side < 48) return null
        val cx = face.centerX(); val cy = face.centerY()
        val x0 = (cx - side / 2).coerceIn(0, img.width - side); val y0 = (cy - side / 2).coerceIn(0, img.height - side)
        val crop = Bitmap.createBitmap(img, x0, y0, side, side)
        val sq = sizes.firstOrNull { it.first == it.second } ?: (1024 to 1024)
        val big = Bitmap.createScaledBitmap(crop, sq.first, sq.second, true)
        val res = generate(ctx, modelId, big, sq.first, sq.second, strength, PROMPT_FACE, 23, cancelled, progress) ?: return null
        val back = Bitmap.createScaledBitmap(res, side, side, true)
        // blend with a soft round edge so no seam shows
        val out = img.copy(Bitmap.Config.ARGB_8888, true)
        val a = IntArray(side * side); val b = IntArray(side * side)
        out.getPixels(a, 0, side, x0, y0, side, side)
        back.getPixels(b, 0, side, 0, 0, side, side)
        val half = side / 2f
        for (y in 0 until side) for (x in 0 until side) {
            val d = Math.hypot((x - half + 0.5).toDouble(), (y - half + 0.5).toDouble()).toFloat() / half
            val wgt = ((1f - d) / 0.35f).coerceIn(0f, 1f)   // full inside 65 % of the radius, fading to the edge
            if (wgt <= 0f) continue
            val i = y * side + x
            val p0 = a[i]; val p1 = b[i]
            fun mix(sh: Int) = ((((p0 shr sh) and 0xFF) * (1 - wgt) + ((p1 shr sh) and 0xFF) * wgt) + 0.5f).toInt()
            a[i] = (0xFF shl 24) or (mix(16) shl 16) or (mix(8) shl 8) or mix(0)
        }
        out.setPixels(a, 0, side, x0, y0, side, side)
        return out
    }

    private fun generate(ctx: Context, modelId: String, input: Bitmap, w: Int, h: Int, strength: Float, prompt: String, seed: Int,
                         cancelled: () -> Boolean, progress: (Int) -> Unit): Bitmap? {
        val fast = isFast(modelId)
        val outFile = File(ctx.cacheDir, "reimagine.png")
        outFile.delete()
        val n = w * h
        val px = IntArray(n)
        input.getPixels(px, 0, w, 0, 0, w, h)
        val f = FloatArray(3 * n)
        for (i in 0 until n) {
            val p = px[i]
            f[i] = ((p shr 16) and 0xFF) / 127.5f - 1f
            f[n + i] = ((p shr 8) and 0xFF) / 127.5f - 1f
            f[2 * n + i] = (p and 0xFF) / 127.5f - 1f
        }
        // img2img runs only the last part of the steps: give it enough so a low change still has 2-3
        val steps = if (fast) 8 else 25
        val code = SdNative.generate(
            SdModel.dir(ctx, modelId).absolutePath, ctx.cacheDir.absolutePath, SdNative.BACKEND_OPENCL,
            0, true, w, h, steps, seed, outFile.absolutePath, prompt, NEGATIVE,
            f, strength, if (fast) 1.5f else 5f, 0f, null, null, SdNative.PREVIEW_NONE, SdNative.SAMPLER_DPM,
            object : SdNative.Listener {
                override fun onProgress(pct: Int) { progress(pct) }
                override fun onPreview(rgb: ByteArray, width: Int, height: Int) {}
                override fun onCool() { HeatGuard.waitIfHot(ctx, { cancelled() || SdNative.isCancelled() }) }
            })
        JobLog.add("Reimaginar ${w}×$h: código $code · ${SdNative.lastTimings().take(200)}")
        if (code != 0 || !outFile.exists()) return null
        return BitmapFactory.decodeFile(outFile.absolutePath)
    }

    /** Face boxes (ML Kit), largest first, at most 6. */
    private fun faceBoxes(img: Bitmap): List<Rect> {
        val long = maxOf(img.width, img.height)
        val k = if (long > 1600) 1600f / long else 1f
        val small = if (k < 1f) Bitmap.createScaledBitmap(img, (img.width * k).toInt(), (img.height * k).toInt(), true) else img
        val det = FaceDetection.getClient(FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setMinFaceSize(0.05f).build())
        return try {
            Tasks.await(det.process(InputImage.fromBitmap(small, 0))).map { f ->
                val r = f.boundingBox
                Rect((r.left / k).toInt(), (r.top / k).toInt(), (r.right / k).toInt(), (r.bottom / k).toInt())
            }.sortedByDescending { it.width() * it.height() }.take(6)
        } catch (t: Throwable) { JobLog.error("Reimaginar: caras", t); emptyList() } finally { det.close() }
    }
}
