package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import java.io.File
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * The pose of the person in a photo (ML Kit, on the phone) drawn the way the pose ControlNet was
 * trained: OpenPose's 18 joints, coloured limbs on black (xinsir's thicker lines, the same drawing as
 * ci/control_pose_export.py).
 */
object PoseImage {

    private val LIMBS = arrayOf(2 to 3, 2 to 6, 3 to 4, 4 to 5, 6 to 7, 7 to 8, 2 to 9, 9 to 10, 10 to 11, 2 to 12, 12 to 13,
        13 to 14, 2 to 1, 1 to 15, 15 to 17, 1 to 16, 16 to 18)
    private val COLORS = arrayOf(intArrayOf(255, 0, 0), intArrayOf(255, 85, 0), intArrayOf(255, 170, 0), intArrayOf(255, 255, 0),
        intArrayOf(170, 255, 0), intArrayOf(85, 255, 0), intArrayOf(0, 255, 0), intArrayOf(0, 255, 85), intArrayOf(0, 255, 170),
        intArrayOf(0, 255, 255), intArrayOf(0, 170, 255), intArrayOf(0, 85, 255), intArrayOf(0, 0, 255), intArrayOf(85, 0, 255),
        intArrayOf(170, 0, 255), intArrayOf(255, 0, 255), intArrayOf(255, 0, 170), intArrayOf(255, 0, 85))

    /** OpenPose's 18 joints, in 0..1 of [photo], or null when no body was found. Blocking. */
    fun joints(photo: Bitmap): Array<FloatArray?>? {
        val det = PoseDetection.getClient(AccuratePoseDetectorOptions.Builder()
            .setDetectorMode(AccuratePoseDetectorOptions.SINGLE_IMAGE_MODE).build())
        return try {
            val long = maxOf(photo.width, photo.height)
            val k = if (long > 1280) 1280f / long else 1f
            val img = if (k < 1f) Bitmap.createScaledBitmap(photo, (photo.width * k).toInt(), (photo.height * k).toInt(), true) else photo
            val pose = Tasks.await(det.process(InputImage.fromBitmap(img, 0)))
            fun p(type: Int): FloatArray? = pose.getPoseLandmark(type)?.takeIf { it.inFrameLikelihood > 0.5f }?.let {
                val x = it.position.x / img.width; val y = it.position.y / img.height
                if (x in 0f..1f && y in 0f..1f) floatArrayOf(x, y) else null
            }
            val rs = p(PoseLandmark.RIGHT_SHOULDER); val ls = p(PoseLandmark.LEFT_SHOULDER)
            val neck = if (rs != null && ls != null) floatArrayOf((rs[0] + ls[0]) / 2, (rs[1] + ls[1]) / 2) else null
            val j = arrayOf(p(PoseLandmark.NOSE), neck, rs, p(PoseLandmark.RIGHT_ELBOW), p(PoseLandmark.RIGHT_WRIST),
                ls, p(PoseLandmark.LEFT_ELBOW), p(PoseLandmark.LEFT_WRIST),
                p(PoseLandmark.RIGHT_HIP), p(PoseLandmark.RIGHT_KNEE), p(PoseLandmark.RIGHT_ANKLE),
                p(PoseLandmark.LEFT_HIP), p(PoseLandmark.LEFT_KNEE), p(PoseLandmark.LEFT_ANKLE),
                p(PoseLandmark.RIGHT_EYE), p(PoseLandmark.LEFT_EYE), p(PoseLandmark.RIGHT_EAR), p(PoseLandmark.LEFT_EAR))
            if (j.count { it != null } < 6) null else j
        } catch (t: Throwable) {
            JobLog.error("Pose", t); null
        } finally { det.close() }
    }

    /** The skeleton at [w]×[h]. */
    fun draw(j: Array<FloatArray?>, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp); c.drawColor(Color.BLACK)
        val ratio = if (maxOf(w, h) < 500) 1f else if (maxOf(w, h) < 1000) 2f else 3f
        val stick = 4f * ratio
        val paint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        for ((i, l) in LIMBS.withIndex()) {
            val a = j[l.first - 1] ?: continue; val b = j[l.second - 1] ?: continue
            val x1 = a[0] * w; val y1 = a[1] * h; val x2 = b[0] * w; val y2 = b[1] * h
            val len = hypot(x2 - x1, y2 - y1) / 2; val ang = atan2(y2 - y1, x2 - x1)
            val mx = (x1 + x2) / 2; val my = (y1 + y2) / 2
            val path = Path()
            for (k in 0 until 36) {
                val t = (2 * Math.PI * k / 36).toFloat()
                val ex = len * cos(t); val ey = stick * sin(t)
                val px = mx + ex * cos(ang) - ey * sin(ang); val py = my + ex * sin(ang) + ey * cos(ang)
                if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            val col = COLORS[i]
            paint.color = Color.rgb((col[0] * 0.6f).toInt(), (col[1] * 0.6f).toInt(), (col[2] * 0.6f).toInt())
            c.drawPath(path, paint)
        }
        for ((i, p) in j.withIndex()) {
            p ?: continue
            val col = COLORS[i]
            paint.color = Color.rgb(col[0], col[1], col[2])
            c.drawCircle(p[0] * w, p[1] * h, 4f * ratio, paint)
        }
        return bmp
    }

    /** [bmp] as the ControlNet's input: [1,3,H,W], 0..1. */
    fun toInput(bmp: Bitmap): FloatArray {
        val n = bmp.width * bmp.height
        val px = IntArray(n); bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val f = FloatArray(3 * n)
        for (i in 0 until n) {
            val p = px[i]
            f[i] = Color.red(p) / 255f; f[n + i] = Color.green(p) / 255f; f[2 * n + i] = Color.blue(p) / 255f
        }
        return f
    }
}

/** The pose ControlNet's NPU files (one compiled graph per size), downloaded on first use. */
object ControlPose {
    const val PACK = "control-pose-npu"

    fun dir(ctx: Context): File = File(ctx.filesDir, "models/$PACK")

    fun tag(w: Int, h: Int) = if (w == 1024 && h == 1024) "" else "_${w}x$h"

    fun hasSize(ctx: Context, w: Int, h: Int): Boolean {
        val d = dir(ctx)
        return File(d, ".complete").exists() && File(d, "control_pose${tag(w, h)}_ctx.onnx").exists() &&
            File(d, "control_pose${tag(w, h)}.bin").exists()
    }

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
        SdModel.download(ctx, PACK, cancelled, onProgress)
}
