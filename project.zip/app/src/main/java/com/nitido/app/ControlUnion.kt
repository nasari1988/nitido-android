package com.nitido.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.nio.FloatBuffer

/**
 * ControlNet Union ProMax (pose + depth, xinsir, Apache-2.0) on the NPU, and Depth Anything V2 Small
 * (Apache-2.0) on the processor to make the depth picture. With both guides SDXL keeps where arms,
 * legs and head go and also the body's volume (waist, hips), so a new garment doesn't reshape the figure.
 * Pack "control-union-npu", downloaded on first use (Wi-Fi).
 */
object ControlUnion {
    const val PACK = "control-union-npu"

    fun dir(ctx: Context): File = File(ctx.filesDir, "models/$PACK")

    fun file(ctx: Context, w: Int, h: Int) = File(dir(ctx), "control_union${ControlPose.tag(w, h)}_ctx.onnx")

    fun hasSize(ctx: Context, w: Int, h: Int): Boolean {
        val d = dir(ctx)
        return File(d, ".complete").exists() && file(ctx, w, h).exists() &&
            File(d, "control_union${ControlPose.tag(w, h)}.bin").exists() && File(d, "depth_small.onnx").exists()
    }

    fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
        SdModel.download(ctx, PACK, cancelled, onProgress)

    /**
     * The depth picture of [photo] at [w]×[h] as the ControlNet's input (3 planes 0..1, near = white).
     * Inside [soften] (0..1 per pixel at [w]×[h], e.g. the old garment) the depth is smoothed a lot, so
     * the old clothes' folds and volume are not copied; the body's outline stays.
     */
    fun depth(ctx: Context, photo: Bitmap, w: Int, h: Int, soften: FloatArray? = null): FloatArray {
        val n = 518
        val small = Bitmap.createScaledBitmap(photo, n, n, true)
        val px = IntArray(n * n); small.getPixels(px, 0, n, 0, 0, n, n)
        val inp = FloatArray(3 * n * n)
        for (i in 0 until n * n) {
            val p = px[i]
            inp[i] = ((p shr 16) and 0xFF) / 255f; inp[n * n + i] = ((p shr 8) and 0xFF) / 255f; inp[2 * n * n + i] = (p and 0xFF) / 255f
        }
        val env = OrtEnvironment.getEnvironment()
        val t0 = android.os.SystemClock.elapsedRealtime()
        val d = env.createSession(File(dir(ctx), "depth_small.onnx").path, OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
        }).use { s ->
            OnnxTensor.createTensor(env, FloatBuffer.wrap(inp), longArrayOf(1, 3, n.toLong(), n.toLong())).use { t ->
                s.run(mapOf("pixels" to t)).use { r ->
                    val b = (r[0] as OnnxTensor).floatBuffer
                    FloatArray(b.remaining()).also { b.get(it) }
                }
            }
        }
        // to the guide's size (bilinear), then smooth inside the old garment
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val fy = ((y + 0.5f) * n / h - 0.5f).coerceIn(0f, n - 1f); val y0 = fy.toInt(); val y1 = minOf(n - 1, y0 + 1); val ay = fy - y0
            for (x in 0 until w) {
                val fx = ((x + 0.5f) * n / w - 0.5f).coerceIn(0f, n - 1f); val x0 = fx.toInt(); val x1 = minOf(n - 1, x0 + 1); val ax = fx - x0
                out[y * w + x] = (d[y0 * n + x0] * (1 - ax) + d[y0 * n + x1] * ax) * (1 - ay) + (d[y1 * n + x0] * (1 - ax) + d[y1 * n + x1] * ax) * ay
            }
        }
        if (soften != null) {
            val blurred = boxBlur(out, w, h, maxOf(4, h / 40))
            for (i in out.indices) { val k = soften[i].coerceIn(0f, 1f); out[i] = out[i] * (1 - k) + blurred[i] * k }
        }
        JobLog.add("Profundidad: medida en ${android.os.SystemClock.elapsedRealtime() - t0} ms" + if (soften != null) " · suavizada dentro de la prenda vieja" else "")
        val planes = FloatArray(3 * w * h)
        for (i in 0 until w * h) { val v = out[i].coerceIn(0f, 1f); planes[i] = v; planes[w * h + i] = v; planes[2 * w * h + i] = v }
        return planes
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(src.size); val out = FloatArray(src.size)
        for (y in 0 until h) {
            var sum = 0f; var c = 0
            for (x in -r..r) if (x in 0 until w) { sum += src[y * w + x]; c++ }
            for (x in 0 until w) {
                tmp[y * w + x] = sum / c
                val a = x - r; val b = x + r + 1
                if (a >= 0) { sum -= src[y * w + a]; c-- }
                if (b < w) { sum += src[y * w + b]; c++ }
            }
        }
        for (x in 0 until w) {
            var sum = 0f; var c = 0
            for (y in -r..r) if (y in 0 until h) { sum += tmp[y * w + x]; c++ }
            for (y in 0 until h) {
                out[y * w + x] = sum / c
                val a = y - r; val b = y + r + 1
                if (a >= 0) { sum -= tmp[a * w + x]; c-- }
                if (b < h) { sum += tmp[b * w + x]; c++ }
            }
        }
        return out
    }
}
