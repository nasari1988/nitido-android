package com.nitido.app

import java.io.File
import java.text.Normalizer

/**
 * Qwen's tokenizer (byte-level BPE, the same as the one DreamLite's reader was trained with), for the
 * instruction text only: the template around it comes already split from the server. Files: the
 * pack's dl_tok_vocab.json and dl_tok_merges.txt. Checked against the server's own split on start.
 */
class QwenTokenizer(vocabFile: File, mergesFile: File) {
    private val vocab = HashMap<String, Int>(160_000)
    private val ranks = HashMap<String, Int>(160_000)
    private val cache = HashMap<String, IntArray>()

    init {
        // vocab.json is one big flat object {"token": id, ...}: read it with a small hand parser
        // (org.json on 150 000 keys is slow and needs a lot of memory)
        val s = vocabFile.readText()
        var i = s.indexOf('{') + 1
        val sb = StringBuilder()
        while (i < s.length) {
            while (i < s.length && s[i] != '"' && s[i] != '}') i++
            if (i >= s.length || s[i] == '}') break
            i++; sb.setLength(0)
            while (s[i] != '"') {
                if (s[i] == '\\') {
                    i++
                    when (s[i]) {
                        'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r'); 'b' -> sb.append('\b'); 'f' -> sb.append('\u000c')
                        'u' -> { sb.append(s.substring(i + 1, i + 5).toInt(16).toChar()); i += 4 }
                        else -> sb.append(s[i])
                    }
                } else sb.append(s[i])
                i++
            }
            i++
            while (s[i] == ':' || s[i] == ' ') i++
            var j = i; while (s[j].isDigit()) j++
            vocab[sb.toString()] = s.substring(i, j).toInt()
            i = j
        }
        var r = 0
        mergesFile.forEachLine { line ->
            if (line.startsWith("#version") || line.isBlank()) return@forEachLine
            ranks[line] = r++
        }
    }

    val size get() = vocab.size

    fun encode(text: String): IntArray {
        val norm = Normalizer.normalize(text, Normalizer.Form.NFC)
        val out = ArrayList<Int>()
        val m = PRE.matcher(norm)
        while (m.find()) {
            val word = m.group()
            val mapped = buildString { for (b in word.toByteArray(Charsets.UTF_8)) append(BYTE2CHAR[b.toInt() and 0xFF]) }
            val ids = cache.getOrPut(mapped) { bpe(mapped) }
            ids.forEach { out += it }
        }
        return out.toIntArray()
    }

    private fun bpe(word: String): IntArray {
        var parts = word.map { it.toString() }.toMutableList()
        while (parts.size > 1) {
            var best = -1; var bestRank = Int.MAX_VALUE
            for (k in 0 until parts.size - 1) {
                val rk = ranks[parts[k] + " " + parts[k + 1]] ?: continue
                if (rk < bestRank) { bestRank = rk; best = k }
            }
            if (best < 0) break
            val a = parts[best]; val b = parts[best + 1]
            val merged = ArrayList<String>(parts.size)
            var k = 0
            while (k < parts.size) {
                if (k < parts.size - 1 && parts[k] == a && parts[k + 1] == b) { merged += a + b; k += 2 } else { merged += parts[k]; k++ }
            }
            parts = merged
        }
        return IntArray(parts.size) { vocab[parts[it]] ?: throw IllegalStateException("pieza sin número: ${parts[it]}") }
    }

    companion object {
        /** Qwen2's pre-split: contractions, letters with one leading non-letter, single digits, punctuation, spaces. */
        private val PRE = java.util.regex.Pattern.compile(
            "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+")

        /** GPT-2's byte -> printable character table. */
        private val BYTE2CHAR: CharArray = run {
            val bs = ArrayList<Int>()
            bs += ('!'.code..'~'.code); bs += ('¡'.code..'¬'.code); bs += ('®'.code..'ÿ'.code)
            val cs = ArrayList(bs)
            var n = 0
            for (b in 0 until 256) if (b !in bs) { bs += b; cs += 256 + n; n++ }
            val t = CharArray(256)
            for (k in bs.indices) t[bs[k]] = cs[k].toChar()
            t
        }
    }
}
