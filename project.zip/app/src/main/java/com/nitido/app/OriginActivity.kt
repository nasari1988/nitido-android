package com.nitido.app

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ajustes › Registro de imágenes IA: how many pictures Crear has registered as invented, the three
 * switches (register, inherit in edits, show the label) and «Borrar el registro».
 */
class OriginActivity : AppCompatActivity() {

    private lateinit var count: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 16), Ui.dp(context, 8), Ui.dp(context, 16), Ui.dp(context, 24))
        }
        val head = Ui.row(this)
        head.addView(Ui.text(this, "←", 22f).apply {
            setPadding(Ui.dp(context, 6), Ui.dp(context, 6), Ui.dp(context, 14), Ui.dp(context, 6))
            contentDescription = "Volver"
            setOnClickListener { finish() }
        })
        head.addView(Ui.text(this, getString(R.string.reg_title), 19f, bold = true))
        col.addView(head)

        count = Ui.text(this, "", 15f, R.color.after, bold = true).apply {
            background = Ui.round(context, Ui.color(context, R.color.stage), 16, Ui.color(context, R.color.line))
            val pd = Ui.dp(context, 16); setPadding(pd, pd, pd, pd)
        }
        col.addView(count, Ui.lp(this, 12))

        col.addView(switch(R.string.reg_record, R.string.reg_record_sub, ImageOrigin.recordOn(this)) { ImageOrigin.setRecordOn(this, it) }, Ui.lp(this, 16))
        col.addView(switch(R.string.reg_inherit, R.string.reg_inherit_sub, ImageOrigin.inheritOn(this)) { ImageOrigin.setInheritOn(this, it) }, Ui.lp(this, 12))
        col.addView(switch(R.string.reg_badge, R.string.reg_badge_sub, ImageOrigin.badgeOn(this)) { ImageOrigin.setBadgeOn(this, it) }, Ui.lp(this, 12))

        col.addView(Ui.text(this, getString(R.string.reg_clear), 15f, R.color.bad).apply {
            setPadding(0, Ui.dp(context, 18), 0, Ui.dp(context, 14))
            setOnClickListener {
                MaterialAlertDialogBuilder(this@OriginActivity)
                    .setTitle(R.string.reg_clear)
                    .setMessage(R.string.reg_clear_ask)
                    .setPositiveButton(R.string.reg_clear) { _, _ -> ImageOrigin.clear(this@OriginActivity); refresh() }
                    .setNegativeButton(R.string.close, null)
                    .show()
            }
        }, Ui.lp(this, 12))
        col.addView(Ui.text(this, getString(R.string.reg_note), 12f, R.color.muted).apply { setLineSpacing(0f, 1.2f) }, Ui.lp(this, 4))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col) })
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val (n, bytes) = withContext(Dispatchers.IO) { ImageOrigin.count(applicationContext) to ImageOrigin.bytes(applicationContext) }
            count.text = getString(R.string.reg_count, n, if (bytes < 1_000_000) "${(bytes + 999) / 1000} KB" else ModelCatalog.mb(bytes))
        }
    }

    private fun switch(label: Int, sub: Int, on: Boolean, set: (Boolean) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(MaterialSwitch(context).apply {
            text = getString(label); isChecked = on; textSize = 15f
            setTextColor(Ui.color(context, R.color.fg))
            setOnCheckedChangeListener { _, v -> set(v); JobLog.add("Registro IA: ${getString(label)} = $v") }
        })
        addView(Ui.text(context, getString(sub), 12f, R.color.muted))
    }
}
