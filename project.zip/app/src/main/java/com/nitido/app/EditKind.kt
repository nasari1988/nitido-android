package com.nitido.app

/**
 * What an Editar order changes, read from its words (Spanish or English): it decides the zone that is
 * redrawn. Shown to the person as «Se entiende como…», who can correct it for this edit.
 */
enum class EditKind(val label: Int, val note: Int) {
    CLOTHES(R.string.kind_clothes, R.string.kind_clothes_note),
    BACKGROUND(R.string.kind_background, R.string.kind_background_note),
    HEAD(R.string.kind_head, R.string.kind_head_note),
    CLOTHES_BG(R.string.kind_clothes_bg, R.string.kind_clothes_bg_note),
    WHOLE(R.string.kind_whole, R.string.kind_whole_note),
    /** Undressing: only on a picture invented by Crear (ImageOrigin); refused on real photos. */
    NUDE(R.string.kind_nude, R.string.kind_nude_note);

    companion object {
        private fun rx(s: String) = Regex("""(?<![\p{L}])($s)""", RegexOption.IGNORE_CASE)

        val CLOTHES_RX = rx("dress|shirt|t-shirt|pants|trousers|jeans|skirt|jacket|coat|cloth|outfit|suit|sportswear|uniform|" +
            "sweater|hoodie|shorts|bikini|swimsuit|swimwear|top\\b|blouse|gown|lingerie|tuxedo|vest|kimono|wear|" +
            "vestido|ropa|traje|camisa|playera|pantal|jean|falda|chamarra|chaqueta|abrigo|sudadera|short|blusa|uniforme|" +
            "deportiv|bañador|ba[ñn]o|lencer|smoking|chaleco|saco\\b|prenda")
        val BACKGROUND_RX = rx("background|backdrop|sky|beach|forest|city|street|room|studio|mountain|sea\\b|ocean|garden|" +
            "fondo|cielo|playa|bosque|ciudad|calle|cuarto|habitaci|estudio|monta|mar\\b|oc[eé]ano|jard[ií]n|paisaje|escenario|lugar")
        val HEAD_RX = rx("glasses|sunglasses|hat|cap\\b|earring|necklace|makeup|lipstick|hairstyle|hair|beard|mustache|crown|" +
            "lentes|gafas|anteojos|sombrero|gorra|arete|collar|maquillaje|labial|peinado|cabello|pelo|barba|bigote|corona|tiara")
        val WHOLE_RX = rx("night|sunset|sunrise|winter|snow|rain|fog|painting|anime|cartoon|vintage|style|sketch|watercolor|" +
            "noche|atardecer|amanecer|invierno|nieve|lluvia|niebla|pintura|caricatura|dibujo|acuarela|estilo|antigua|retro")
        /** Orders that want sleeves: then the arms are redrawn too. */
        val SLEEVES_RX = rx("sleeve|jacket|coat|sweater|hoodie|long-sleeve|suit\\b|kimono|manga|chamarra|chaqueta|abrigo|su[eé]ter|sudadera|saco\\b")

        fun classify(text: String): EditKind {
            if (ImageOrigin.isNude(text)) return NUDE
            // «ropa de playa», «traje de baño», «beachwear»: clothes, not a beach background
            val order = text.replace(Regex("""(?i)(ropa|traje|vestido|outfit|clothes|wear)\s+(de|for the|for)\s+(playa|baño|beach|swimming)"""), "$1")
                .replace(Regex("""(?i)beachwear"""), "swimwear")
            val c = CLOTHES_RX.containsMatchIn(order)
            val b = BACKGROUND_RX.containsMatchIn(order)
            val h = HEAD_RX.containsMatchIn(order)
            val w = WHOLE_RX.containsMatchIn(order)
            return when {
                c && b -> CLOTHES_BG
                c -> CLOTHES
                b && !w -> BACKGROUND
                h -> HEAD
                b -> BACKGROUND
                else -> WHOLE
            }
        }

        fun byName(s: String?): EditKind? = values().firstOrNull { it.name == s }
    }
}
