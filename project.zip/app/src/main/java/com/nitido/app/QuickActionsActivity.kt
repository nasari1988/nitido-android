package com.nitido.app

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * Ajustes › Acciones rápidas: what each ✦ button does when tapped, one switch per step, saved at
 * once. The tools read the same keys (RestoreActivity: "restore" s_*, VideoActivity: "video",
 * GenerateActivity: "nitido" q_*), so changing one here is what the button does next time.
 */
class QuickActionsActivity : AppCompatActivity() {

    /** One switch: prefs file, key, default, label, note. */
    class Opt(val file: String, val key: String, val def: Boolean, val label: Int, val note: Int? = null)

    companion object {
        val RESTORE = listOf(
            Opt("restore", "s_color", true, R.string.qa_color),
            Opt("restore", "s_denoise", true, R.string.qa_grain),
            Opt("restore", "s_marks", true, R.string.qa_marks),
            Opt("restore", "s_colorize", true, R.string.qa_colorize, R.string.qa_colorize_note),
            Opt("restore", "s_deblur", true, R.string.qa_deblur, R.string.qa_deblur_note),
            Opt("restore", "s_real", true, R.string.qa_real),
            Opt("restore", "s_reim", false, R.string.qa_reim, R.string.qa_reim_note),
            Opt("restore", "s_up2", true, R.string.qa_up2),
            Opt("restore", "s_faces", true, R.string.qa_faces),
        )
        val VIDEO = listOf(
            Opt("video", "q_clean", true, R.string.qa_clean, R.string.qa_clean_note),
            Opt("video", "q_fluid", true, R.string.qa_fluid, R.string.qa_fluid_note),
            Opt("video", "antiflicker", true, R.string.qa_flicker),
            Opt("video", "denoise", true, R.string.qa_vgrain),
            Opt("video", "hevc", true, R.string.qa_hevc, R.string.qa_hevc_note),
        )
        val EDIT = listOf(
            Opt("nitido", "q_polish", true, R.string.qa_polish, R.string.qa_polish_note),
            Opt("nitido", "q_pose", true, R.string.qa_pose, R.string.qa_pose_note),
            Opt("nitido", "q_keep", true, R.string.qa_keep, R.string.qa_keep_note),
            Opt("nitido", "q_editfaces", true, R.string.qa_editfaces),
        )

        fun on(ctx: Context, o: Opt) = ctx.getSharedPreferences(o.file, MODE_PRIVATE).getBoolean(o.key, o.def)
        fun on(ctx: Context, file: String, key: String): Boolean =
            (RESTORE + VIDEO + EDIT).firstOrNull { it.file == file && it.key == key }?.let { on(ctx, it) } ?: true
    }

    private val switches = ArrayList<Pair<Opt, MaterialSwitch>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 16), Ui.dp(context, 8), Ui.dp(context, 16), Ui.dp(context, 24))
        }
        val head = Ui.row(this)
        head.addView(Ui.text(this, "←", 22f).apply { setPadding(Ui.dp(context, 6), Ui.dp(context, 6), Ui.dp(context, 14), Ui.dp(context, 6)); setOnClickListener { finish() } })
        head.addView(Ui.text(this, getString(R.string.qa_title), 19f, bold = true))
        col.addView(head)
        col.addView(Ui.text(this, getString(R.string.qa_note), 12f, R.color.muted), Ui.lp(this, 4))
        col.addView(section(R.string.qa_restore, RESTORE), Ui.lp(this, 12))
        col.addView(section(R.string.qa_video, VIDEO), Ui.lp(this, 12))
        col.addView(section(R.string.qa_edit, EDIT), Ui.lp(this, 12))
        col.addView(Ui.text(this, getString(R.string.qa_reset), 14f, R.color.accent).apply {
            gravity = android.view.Gravity.CENTER
            setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 8))
            setOnClickListener { reset() }
        }, Ui.lp(this, 4))
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col) })
    }

    private fun section(title: Int, opts: List<Opt>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(context, 12), Ui.dp(context, 6), Ui.dp(context, 12), Ui.dp(context, 6))
        background = GradientDrawable().apply {
            setColor(Ui.color(context, R.color.stage)); cornerRadius = Ui.dp(context, 14).toFloat()
            setStroke(Ui.dp(context, 1), Ui.color(context, R.color.line))
        }
        addView(Ui.text(context, getString(title), 15f, bold = true).apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 4)) })
        for (o in opts) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8))
            }
            val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(Ui.text(context, getString(o.label), 14f))
            o.note?.let { texts.addView(Ui.text(context, getString(it), 11f, R.color.muted)) }
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            val sw = MaterialSwitch(context).apply {
                isChecked = on(context, o)
                setOnCheckedChangeListener { _, v ->
                    getSharedPreferences(o.file, MODE_PRIVATE).edit().putBoolean(o.key, v).apply()
                    JobLog.add("Acciones rápidas: ${getString(o.label)} " + if (v) "sí" else "no")
                }
            }
            switches += o to sw
            row.addView(sw)
            addView(row)
        }
    }

    private fun reset() {
        for ((o, sw) in switches) {
            getSharedPreferences(o.file, MODE_PRIVATE).edit().putBoolean(o.key, o.def).apply()
            sw.isChecked = o.def
        }
        JobLog.add("Acciones rápidas: vueltas a las recomendadas")
        android.widget.Toast.makeText(this, R.string.qa_reset_done, android.widget.Toast.LENGTH_SHORT).show()
    }
}
