package com.nitido.app

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * Ajustes › Acciones rápidas: what each ✦ button does when tapped, one switch per step, saved at
 * once. The tools read the same keys (RestoreActivity: "restore" s_*, VideoActivity: "video",
 * GenerateActivity: "nitido" q_*), so changing one here is what the button does next time.
 */
class QuickActionsActivity : AppCompatActivity() {

    /** One switch: prefs file, key, default, label, note. */
    class Opt(val file: String, val key: String, val def: Boolean, val label: Int, val note: Int? = null)

    /** One choice among levels (chips): prefs file, key, default value, label, the values and their names. */
    class Choice(val file: String, val key: String, val def: Int, val label: Int, val values: IntArray, val names: List<String>, val note: Int? = null)

    companion object {
        val RESTORE = listOf(
            Opt("restore", "s_color", true, R.string.qa_color),
            Opt("restore", "s_denoise", true, R.string.qa_grain),
            Opt("restore", "s_marks", true, R.string.qa_marks),
            Opt("restore", "s_colorize", true, R.string.qa_colorize, R.string.qa_colorize_note),
            Opt("restore", "s_deblur", true, R.string.qa_deblur, R.string.qa_deblur_note),
            Opt("restore", "s_real", true, R.string.qa_real),
            Opt("restore", "s_reim", false, R.string.qa_reim, R.string.qa_reim_note),
            Opt("restore", "s_crop", true, R.string.qa_crop),
            Opt("restore", "s_detail", false, R.string.qa_detail, R.string.qa_detail_note),
            Opt("restore", "s_faces", true, R.string.qa_faces),
            Opt("restore", "s_faces_osd", true, R.string.qa_faces_osd, R.string.qa_faces_osd_note),
        )
        val VIDEO = listOf(
            Opt("video", "q_clean", true, R.string.qa_clean, R.string.qa_clean_note),
            Opt("video", "q_fluid", true, R.string.qa_fluid, R.string.qa_fluid_note),
            Opt("video", "antiflicker", true, R.string.qa_flicker),
            Opt("video", "denoise", true, R.string.qa_vgrain),
            Opt("video", "hevc", true, R.string.qa_hevc, R.string.qa_hevc_note),
        )
        val EDIT = listOf(
            Opt("nitido", "q_dreamlite", true, R.string.qa_dreamlite, R.string.qa_dreamlite_note),
            Opt("nitido", "q_polish", true, R.string.qa_polish, R.string.qa_polish_note),
            Opt("nitido", "q_pose", true, R.string.qa_pose, R.string.qa_pose_note),
            Opt("nitido", "q_depth", true, R.string.qa_depth, R.string.qa_depth_note),

            Opt("nitido", "q_keep", true, R.string.qa_keep, R.string.qa_keep_note),
            Opt("nitido", "q_editfaces", true, R.string.qa_editfaces),
        )

        fun on(ctx: Context, o: Opt) = ctx.getSharedPreferences(o.file, MODE_PRIVATE).getBoolean(o.key, o.def)
        val RESTORE_CH = listOf(
            Choice("restore", "s_scale", 2, R.string.qa_up2, intArrayOf(1, 2, 4), listOf("×1", "×2", "×4")),
            Choice("restore", "s_deblur_amt", 80, R.string.qa_deblur_amt, intArrayOf(60, 80, 100), listOf("Suave", "Medio", "Fuerte")),
            Choice("restore", "s_real_pct", 100, R.string.qa_real_pct, intArrayOf(80, 100, 110), listOf("Suave", "Normal", "Más")),
            Choice("restore", "s_fid", 70, R.string.qa_fid, intArrayOf(50, 70, 90), listOf("Arreglar", "Normal", "Más fiel"), R.string.qa_fid_note),
        )
        val VIDEO_CH = listOf(
            Choice("video", "q_scale", 2, R.string.qa_vscale, intArrayOf(2, 4), listOf("×2", "×4")),
            Choice("video", "q_sharp", 1, R.string.qa_vsharp, intArrayOf(0, 1, 2), listOf("Baja", "Media", "Alta")),
            Choice("video", "q_frames", 0, R.string.qa_vframes, intArrayOf(0, 1), listOf("Todos", "La mitad")),
            Choice("video", "q_deint", 0, R.string.qa_vdeint, intArrayOf(0, 1, 2), listOf("Auto", "Sí", "No"), R.string.qa_vdeint_note),
        )
        val EDIT_CH = listOf(
            Choice("nitido", "edit_amount", 1, R.string.edit_amount, intArrayOf(0, 1, 2), listOf("Suave", "Normal", "Fuerte")),
            Choice("nitido", "edit_realism", 1, R.string.qa_realism_end, intArrayOf(0, 1, 2), listOf("No", "Normal", "Más"), R.string.qa_realism_end_note),
        )

        /**
         * ⚙ Avanzado's changes «solo para esta edición»: "file/key" -> value. They win over the saved
         * preferences until [clearTemp] (a new photo, Deshacer, or leaving the screen).
         */
        val temp = HashMap<String, Any>()
        fun setTemp(file: String, key: String, v: Any) { temp["$file/$key"] = v }
        fun clearTemp(file: String) { temp.keys.removeAll { it.startsWith("$file/") } }

        /** The saved level of a [Choice] (its default when never set). */
        fun pick(ctx: Context, file: String, key: String): Int {
            (temp["$file/$key"] as? Int)?.let { return it }
            return saved(ctx, file, key)
        }

        /** The level saved in Mis preferencias (without ⚙ Avanzado's change for this time). */
        fun saved(ctx: Context, file: String, key: String): Int {
            val c = (RESTORE_CH + VIDEO_CH + EDIT_CH).firstOrNull { it.file == file && it.key == key }
            return ctx.getSharedPreferences(file, MODE_PRIVATE).getInt(key, c?.def ?: 0)
        }

        fun on(ctx: Context, file: String, key: String): Boolean {
            (temp["$file/$key"] as? Boolean)?.let { return it }
            return savedOn(ctx, file, key)
        }

        fun savedOn(ctx: Context, file: String, key: String): Boolean =
            (RESTORE + VIDEO + EDIT).firstOrNull { it.file == file && it.key == key }?.let { on(ctx, it) } ?: true
    }

    private val switches = ArrayList<Pair<Opt, MaterialSwitch>>()
    private val choices = ArrayList<Pair<Choice, Kit.Seg>>()
    private var colorSlider: com.google.android.material.slider.Slider? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 14), Ui.dp(context, 8), Ui.dp(context, 14), Ui.dp(context, 24))
        }
        col.addView(Kit.header(this, getString(R.string.qa_title), { finish() }))
        col.addView(Ui.text(this, getString(R.string.qa_note), 13f, R.color.muted), Ui.lp(this, 2))
        col.addView(section(R.string.qa_restore, RESTORE, RESTORE_CH, open = true, extra = { box ->
            val v = getSharedPreferences("restore", MODE_PRIVATE).getInt("s_color_pct", 81)
            val sl = Kit.slider(this, getString(R.string.kit_color_strength), 50f, 120f, v.toFloat(), getString(R.string.kit_color_marks), { "${it.toInt()} %" }) { x ->
                getSharedPreferences("restore", MODE_PRIVATE).edit().putInt("s_color_pct", x.toInt()).apply()
                JobLog.add("Mis preferencias: intensidad del color ${x.toInt()} %")
            }
            colorSlider = sl.findViewWithTag("slider")
            box.addView(sl)
        }), Ui.lp(this, 10))
        col.addView(section(R.string.qa_video, VIDEO, VIDEO_CH), Ui.lp(this, 10))
        col.addView(section(R.string.qa_edit, EDIT, EDIT_CH), Ui.lp(this, 10))
        col.addView(link(getString(R.string.qa_models)) { startActivity(android.content.Intent(this, ModelsActivity::class.java)) }, Ui.lp(this, 10))
        col.addView(Ui.text(this, getString(R.string.qa_reset), 14f, R.color.accent).apply {
            gravity = android.view.Gravity.CENTER
            setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 8))
            setOnClickListener { reset() }
        }, Ui.lp(this, 4))
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col) })
    }

    /** A card that opens another screen («Modelos por objetivo»). */
    private fun link(title: String, onClick: () -> Unit) = Ui.row(this).apply {
        setPadding(Ui.dp(context, 14), Ui.dp(context, 14), Ui.dp(context, 14), Ui.dp(context, 14))
        background = Ui.round(context, 0xFF141A16.toInt(), 14, Ui.color(context, R.color.line))
        addView(Ui.text(context, title, 15f, R.color.fg, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
        addView(Ui.text(context, "›", 18f, R.color.muted))
        setOnClickListener { onClick() }
    }

    /**
     * One ✦ button's card (mockup 2): its title and a summary of what it does; tapping opens its
     * rows (switches and levels). Restaurar opens by itself.
     */
    private fun section(title: Int, opts: List<Opt>, levels: List<Choice> = emptyList(), open: Boolean = false,
                        extra: ((LinearLayout) -> Unit)? = null) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(context, 14), Ui.dp(context, 10), Ui.dp(context, 14), Ui.dp(context, 10))
        background = Ui.round(context, 0xFF141A16.toInt(), 14, Ui.color(context, if (open) R.color.accent else R.color.line))
        val head = Ui.row(context)
        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui.text(context, "✦ " + getString(title), 15f, R.color.fg, bold = true))
        val sum = Ui.text(context, "", 12f, R.color.muted)
        texts.addView(sum)
        head.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val arrow = Ui.text(context, if (open) "˅" else "›", 18f, R.color.muted)
        head.addView(arrow)
        addView(head)
        val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; visibility = if (open) View.VISIBLE else View.GONE }
        fun summary() {
            val on = opts.filter { on(context, it) }.map { getString(it.label) }
            val lv = levels.map { c -> c.names.getOrNull(c.values.indexOf(pick(context, c.file, c.key))) ?: "" }
            sum.text = (on.take(4) + lv).joinToString(" · ")
            sum.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        head.setOnClickListener {
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            arrow.text = if (body.visibility == View.VISIBLE) "˅" else "›"
            background = Ui.round(context, 0xFF141A16.toInt(), 14, Ui.color(context, if (body.visibility == View.VISIBLE) R.color.accent else R.color.line))
            summary()
        }
        for (o in opts) {
            val sw = Kit.switch(context, on(context, o)) { v ->
                getSharedPreferences(o.file, MODE_PRIVATE).edit().putBoolean(o.key, v).apply()
                JobLog.add("Mis preferencias: ${getString(o.label)} " + if (v) "sí" else "no")
                summary()
            }
            switches += o to sw
            body.addView(Kit.row(context, getString(o.label), o.note?.let { getString(it) }, sw))
        }
        for (c in levels) {
            val seg = Kit.Seg(context, c.names) { i ->
                getSharedPreferences(c.file, MODE_PRIVATE).edit().putInt(c.key, c.values[i]).apply()
                JobLog.add("Mis preferencias: ${getString(c.label)} ${c.names[i]}")
                summary()
            }
            val cur = c.values.indexOf(pick(context, c.file, c.key)).coerceAtLeast(0)
            seg.base = cur; seg.set(cur)
            choices += c to seg
            body.addView(Kit.row(context, getString(c.label), c.note?.let { getString(it) }, seg))
        }
        extra?.invoke(body)
        addView(body)
        summary()
    }

    private fun reset() {
        for ((o, sw) in switches) {
            getSharedPreferences(o.file, MODE_PRIVATE).edit().putBoolean(o.key, o.def).apply()
            sw.isChecked = o.def
        }
        for ((c, seg) in choices) {
            getSharedPreferences(c.file, MODE_PRIVATE).edit().putInt(c.key, c.def).apply()
            val i = c.values.indexOf(c.def).coerceAtLeast(0); seg.base = i; seg.set(i)
        }
        getSharedPreferences("restore", MODE_PRIVATE).edit().putInt("s_color_pct", 81).apply()
        colorSlider?.value = 81f
        JobLog.add("Mis preferencias: vueltas a las recomendadas")
        android.widget.Toast.makeText(this, R.string.qa_reset_done, android.widget.Toast.LENGTH_SHORT).show()
    }
}
