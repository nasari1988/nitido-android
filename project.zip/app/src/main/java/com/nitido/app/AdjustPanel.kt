package com.nitido.app

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

/**
 * Retoques finales, the same on every result: two tabs (Luz: brillo, contraste, sombras; Color:
 * calidez azul↔amarillo, tono verde↔rosa, intensidad gris↔vivo, "Toca algo blanco", "Color
 * automático"), "Original B/N" when the photo was colorized, and "Restablecer".
 * The panel only edits the values; the screen redraws its preview when [onChange] is called.
 */
class AdjustPanel(
    private val a: Activity,
    /** The result as it came out (the touches are measured on it). */
    private val source: () -> Bitmap?,
    private val get: () -> PhotoAdjust.Values,
    private val onChange: (PhotoAdjust.Values) -> Unit,
    /** Asks the picture to give the next tap's point (0..1, 0..1). */
    private val pickPoint: ((Float, Float) -> Unit) -> Unit,
    /** Whether "Original B/N" makes sense (the photo was black and white). */
    private val canBw: () -> Boolean,
) : LinearLayout(a) {

    private val sliders = mutableListOf<Pair<Slider, (PhotoAdjust.Values) -> Int>>()
    private val luz = LinearLayout(a).apply { orientation = VERTICAL }
    private val color = LinearLayout(a).apply { orientation = VERTICAL }
    private val tabLuz: TextView
    private val tabColor: TextView
    private val tabBw: TextView
    private val tabSepia: TextView
    private val hint = Ui.text(a, "", 12f, R.color.muted)
    private var page = 0

    init {
        orientation = VERTICAL
        val tabs = Ui.chipRow(a)
        tabLuz = Ui.chip(a, a.getString(R.string.adj_tab_light), true) { show(0) }
        tabColor = Ui.chip(a, a.getString(R.string.adj_tab_color)) { show(1) }
        tabBw = Ui.chip(a, a.getString(R.string.adj_bw)) {
            set(get().copy(bw = !get().bw, sepia = false))
        }
        tabSepia = Ui.chip(a, a.getString(R.string.adj_sepia)) {
            set(get().copy(sepia = !get().sepia, bw = false))
        }
        val reset = Ui.chip(a, a.getString(R.string.adjust_reset)) { set(PhotoAdjust.Values()); hint.text = "" }
        for (v in listOf(tabLuz, tabColor, tabBw, tabSepia, reset)) tabs.addView(v)
        addView(tabs)

        slider(luz, R.string.adjust_brightness, null, null, null, { it.brightness }) { v, x -> v.copy(brightness = x) }
        slider(luz, R.string.adjust_contrast, null, null, null, { it.contrast }) { v, x -> v.copy(contrast = x) }
        slider(luz, R.string.adj_shadows, null, null, null, { it.shadows }) { v, x -> v.copy(shadows = x) }

        slider(color, R.string.adj_warmth, R.string.adj_blue, R.string.adj_yellow, intArrayOf(0xFF378ADD.toInt(), 0xFF8A8A80.toInt(), 0xFFEF9F27.toInt()), { it.warmth }) { v, x -> v.copy(warmth = x) }
        slider(color, R.string.adj_tint, R.string.adj_green, R.string.adj_pink, intArrayOf(0xFF639922.toInt(), 0xFF8A8A80.toInt(), 0xFFD4537E.toInt()), { it.tint }) { v, x -> v.copy(tint = x) }
        slider(color, R.string.adj_intensity, R.string.adj_gray, R.string.adj_vivid, null, { it.saturation }) { v, x -> v.copy(saturation = x) }
        val btns = Ui.row(a)
        btns.addView(Ui.outlineButton(a, a.getString(R.string.adj_pick_white)) { pickWhite() },
            LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(a, 8) })
        btns.addView(Ui.outlineButton(a, a.getString(R.string.adj_auto_color)) { autoColor() }, LayoutParams(0, -2, 1f))
        color.addView(btns, Ui.lp(a, 4))

        addView(luz, Ui.lp(a, 6)); addView(color, Ui.lp(a, 6)); addView(hint, Ui.lp(a, 2))
        show(0)
    }

    private fun set(v: PhotoAdjust.Values) { onChange(v); sync() }

    private fun show(p: Int) {
        page = p
        Ui.setChip(tabLuz, p == 0); Ui.setChip(tabColor, p == 1)
        luz.visibility = if (p == 0) View.VISIBLE else View.GONE
        color.visibility = if (p == 1) View.VISIBLE else View.GONE
    }

    /** Sliders and chips show the current values (after a new result, a reset, a rotation…). */
    fun sync() {
        val v = get()
        for ((s, of) in sliders) { val x = of(v).toFloat().coerceIn(-100f, 100f); if (s.value != x) s.value = x }
        tabBw.visibility = if (canBw()) View.VISIBLE else View.GONE
        tabSepia.visibility = tabBw.visibility
        Ui.setChip(tabBw, v.bw); Ui.setChip(tabSepia, v.sepia)
    }

    private fun slider(box: LinearLayout, label: Int, left: Int?, right: Int?, gradient: IntArray?,
                       of: (PhotoAdjust.Values) -> Int, put: (PhotoAdjust.Values, Int) -> PhotoAdjust.Values) {
        val r = Ui.row(a)
        r.addView(Ui.text(a, a.getString(label), 13f, R.color.fg2), LayoutParams(Ui.dp(a, 78), -2))
        if (left != null) r.addView(Ui.text(a, a.getString(left), 11f, R.color.muted))
        val s = Slider(a).apply {
            valueFrom = -100f; valueTo = 100f; stepSize = 1f; value = 0f
            setLabelFormatter { x -> x.roundToInt().let { if (it > 0) "+$it" else "$it" } }
            addOnChangeListener { _, x, fromUser -> if (fromUser) onChange(put(get(), x.roundToInt())) }
        }
        r.addView(s, LayoutParams(0, -2, 1f))
        if (right != null) r.addView(Ui.text(a, a.getString(right), 11f, R.color.muted))
        box.addView(r)
        if (gradient != null) {
            // where each end goes, as a thin colored strip under the slider
            box.addView(View(a).apply {
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, gradient).apply { cornerRadius = Ui.dp(a, 2).toFloat() }
            }, LayoutParams(-1, Ui.dp(a, 4)).apply {
                marginStart = Ui.dp(a, 78 + 40); marginEnd = Ui.dp(a, 52); bottomMargin = Ui.dp(a, 4)
            })
        }
        sliders += s to of
    }

    private fun pickWhite() {
        hint.text = a.getString(R.string.adj_pick_hint)
        pickPoint { fx, fy ->
            val src = source() ?: return@pickPoint
            val x = (fx * src.width).roundToInt().coerceIn(0, src.width - 1)
            val y = (fy * src.height).roundToInt().coerceIn(0, src.height - 1)
            val (r, g, b) = PhotoAdjust.sample(src, x, y, maxOf(2, src.width / 300))
            if (maxOf(r, g, b) < 25f) { hint.text = a.getString(R.string.adj_pick_dark); return@pickPoint }
            val (kr, kg, kb) = PhotoAdjust.neutralGains(r, g, b)
            // the gains replace the warmth / tint the user may have tried before
            set(get().copy(gainR = kr, gainG = kg, gainB = kb, warmth = 0, tint = 0))
            hint.text = a.getString(R.string.adj_pick_done)
            JobLog.add(String.format(java.util.Locale.US, "Retoque: blanco tocado (%.0f, %.0f, %.0f) → ganancias %.2f %.2f %.2f", r, g, b, kr, kg, kb))
        }
    }

    private fun autoColor() {
        val src = source() ?: return
        val (kr, kg, kb) = PhotoAdjust.autoGains(src)
        set(get().copy(gainR = kr, gainG = kg, gainB = kb, warmth = 0, tint = 0))
        hint.text = a.getString(if (kr == 1f && kg == 1f && kb == 1f) R.string.adj_auto_none else R.string.adj_auto_done)
        JobLog.add(String.format(java.util.Locale.US, "Retoque: color automático → ganancias %.2f %.2f %.2f", kr, kg, kb))
    }
}
