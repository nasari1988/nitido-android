package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

enum class Engine(val label: String) { GPU("GPU"), NPU("NPU"), CPU("CPU") }

/**
 * Real-ESRGAN General x4v3 running on-device with TensorFlow Lite.
 * The model has a fixed input size (e.g. 128×128), so images are processed
 * in overlapping tiles and stitched back together.
 *
 * Must be created and used on the same thread (required by the GPU delegate).
 */
class Upscaler(
    context: Context,
    requested: Engine,
    private val modelFile: String = MODEL_FILE,
    private val pad: Int = 8,
) : AutoCloseable {

    private var gpu: GpuDelegate? = null
    private var nnapi: NnApiDelegate? = null
    private val interpreter: Interpreter
    val engine: Engine

    private val nchw: Boolean
    private val inH: Int
    private val inW: Int
    private val outH: Int
    private val outW: Int
    val factor: Int

    private val inBuf: ByteBuffer
    private val inF: FloatBuffer
    private val outBuf: ByteBuffer
    private val outArr: FloatArray

    init {
        val model = loadModel(context)
        var used = requested
        val interp = try {
            build(model, requested)
        } catch (t: Throwable) {
            closeDelegates()
            used = Engine.CPU
            build(model, Engine.CPU)
        }
        interpreter = interp
        engine = used

        val inShape = interpreter.getInputTensor(0).shape()
        val outShape = interpreter.getOutputTensor(0).shape()
        nchw = inShape[1] == 3
        if (nchw) { inH = inShape[2]; inW = inShape[3]; outH = outShape[2]; outW = outShape[3] }
        else { inH = inShape[1]; inW = inShape[2]; outH = outShape[1]; outW = outShape[2] }
        factor = outH / inH

        inBuf = ByteBuffer.allocateDirect(inH * inW * 3 * 4).order(ByteOrder.nativeOrder())
        inF = inBuf.asFloatBuffer()
        outBuf = ByteBuffer.allocateDirect(outH * outW * 3 * 4).order(ByteOrder.nativeOrder())
        outArr = FloatArray(outH * outW * 3)
    }

    private fun build(model: MappedByteBuffer, e: Engine): Interpreter {
        val opts = Interpreter.Options()
        when (e) {
            Engine.GPU -> {
                val d = GpuDelegate()
                gpu = d
                opts.addDelegate(d)
            }
            Engine.NPU -> {
                val o = NnApiDelegate.Options()
                    .setAllowFp16(true)
                    .setExecutionPreference(NnApiDelegate.Options.EXECUTION_PREFERENCE_SUSTAINED_SPEED)
                val d = NnApiDelegate(o)
                nnapi = d
                opts.addDelegate(d)
            }
            Engine.CPU -> opts.setNumThreads(4)
        }
        val interp = Interpreter(model, opts)
        // Run once so a delegate that cannot handle the model fails here, not mid-image.
        val shape = interp.getInputTensor(0).shape()
        val outShape = interp.getOutputTensor(0).shape()
        val i = ByteBuffer.allocateDirect(shape.fold(4) { a, b -> a * b }).order(ByteOrder.nativeOrder())
        val o = ByteBuffer.allocateDirect(outShape.fold(4) { a, b -> a * b }).order(ByteOrder.nativeOrder())
        interp.run(i, o)
        return interp
    }

    private fun loadModel(context: Context): MappedByteBuffer {
        context.assets.openFd(modelFile).use { fd ->
            FileInputStream(fd.fileDescriptor).use { fis ->
                return fis.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
            }
        }
    }

    /**
     * Run the model over [src] in tiles. [scale] is the output scale (1, 2 or 4) and must
     * divide the model's own factor; extra resolution is averaged down.
     */
    fun upscale(src: Bitmap, scale: Int, onProgress: (Float) -> Unit, cancelled: () -> Boolean): Bitmap? {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val f = factor
        val div = f / scale
        val PAD = pad
        val stepW = inW - 2 * PAD
        val stepH = inH - 2 * PAD
        val cols = (w + stepW - 1) / stepW
        val rows = (h + stepH - 1) / stepH
        val total = cols * rows
        val out = Bitmap.createBitmap(w * scale, h * scale, Bitmap.Config.ARGB_8888)
        val tile = IntArray((stepW * scale) * (stepH * scale))
        val plane = outH * outW
        var done = 0

        for (r in 0 until rows) for (c in 0 until cols) {
            if (cancelled()) return null
            val x0 = c * stepW
            val y0 = r * stepH
            val cw = minOf(stepW, w - x0)
            val ch = minOf(stepH, h - y0)

            // Fill the input tile, clamping coordinates at the image border.
            val inPlane = inH * inW
            for (y in 0 until inH) {
                val sy = (y0 - PAD + y).coerceIn(0, h - 1)
                for (x in 0 until inW) {
                    val sx = (x0 - PAD + x).coerceIn(0, w - 1)
                    val p = px[sy * w + sx]
                    val rr = Color.red(p) / 255f
                    val gg = Color.green(p) / 255f
                    val bb = Color.blue(p) / 255f
                    if (nchw) {
                        val i = y * inW + x
                        inF.put(i, rr); inF.put(inPlane + i, gg); inF.put(2 * inPlane + i, bb)
                    } else {
                        val i = (y * inW + x) * 3
                        inF.put(i, rr); inF.put(i + 1, gg); inF.put(i + 2, bb)
                    }
                }
            }

            inBuf.rewind()
            outBuf.rewind()
            interpreter.run(inBuf, outBuf)
            outBuf.rewind()
            outBuf.asFloatBuffer().get(outArr)

            // Copy the tile's core (without padding) into the result.
            val tw = cw * scale
            val th = ch * scale
            for (ty in 0 until th) {
                for (tx in 0 until tw) {
                    var rs = 0f; var gs = 0f; var bs = 0f
                    for (dy in 0 until div) for (dx in 0 until div) {
                        val oy = PAD * f + ty * div + dy
                        val ox = PAD * f + tx * div + dx
                        if (nchw) {
                            val i = oy * outW + ox
                            rs += outArr[i]; gs += outArr[plane + i]; bs += outArr[2 * plane + i]
                        } else {
                            val i = (oy * outW + ox) * 3
                            rs += outArr[i]; gs += outArr[i + 1]; bs += outArr[i + 2]
                        }
                    }
                    val n = (div * div).toFloat()
                    tile[ty * tw + tx] = Color.rgb(to8(rs / n), to8(gs / n), to8(bs / n))
                }
            }
            out.setPixels(tile, 0, tw, x0 * scale, y0 * scale, tw, th)

            done++
            onProgress(done.toFloat() / total)
        }
        return out
    }

    private fun to8(v: Float): Int = (v * 255f + 0.5f).toInt().coerceIn(0, 255)

    private fun closeDelegates() {
        gpu?.close(); gpu = null
        nnapi?.close(); nnapi = null
    }

    override fun close() {
        interpreter.close()
        closeDelegates()
    }

    companion object {
        const val MODEL_FILE = "realesrgan_x4.tflite"
        const val MODEL_X4PLUS = "realesrgan_x4plus.tflite"
        const val MODEL_DEBLUR = "nafnet_deblur.tflite"
    }
}
