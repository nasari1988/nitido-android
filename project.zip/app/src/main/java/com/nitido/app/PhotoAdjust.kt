package com.nitido.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.roundToInt

/**
 * Manual finishing touches on a restored photo: brightness, contrast, saturation, warmth
 * (color temperature), tint and sharpness. All values go from -100 to 100 (sharpness 0..100);
 * 0 = unchanged. Colors are one ColorMatrix pass (fast); sharpness is an unsharp mask.
 */
object PhotoAdjust {

    data class Values(
        val brightness: Int = 0, val contrast: Int = 0, val saturation: Int = 0,
        val warmth: Int = 0, val tint: Int = 0, val sharpness: Int = 0,
        /** Lifts (+) or deepens (-) only the dark parts, -100..100. */
        val shadows: Int = 0,
        /** Back to black and white (a colorized photo's original look). */
        val bw: Boolean = false,
        /** A warm old-photo tone instead of colors (a colorized photo's other option). */
        val sepia: Boolean = false,
        /** White balance from "Toca algo blanco" / "Color automático": gain per channel (1 = unchanged). */
        val gainR: Float = 1f, val gainG: Float = 1f, val gainB: Float = 1f,
    ) {
        val isNeutral get() = this == Values()
    }

    /**
     * Gains that make the color [r],[g],[b] (0..255, what should be white or gray) neutral, keeping
     * its brightness; each gain kept within 0.6..1.6 so one tap can't wreck the photo.
     */
    fun neutralGains(r: Float, g: Float, b: Float): Triple<Float, Float, Float> {
        val y = 0.299f * r + 0.587f * g + 0.114f * b
        fun k(c: Float) = (y / maxOf(1f, c)).coerceIn(0.6f, 1.6f)
        return Triple(k(r), k(g), k(b))
    }

    /** Average color of a (2*[rad]+1)² square around ([x],[y]) of [bmp]. */
    fun sample(bmp: Bitmap, x: Int, y: Int, rad: Int): Triple<Float, Float, Float> {
        var r = 0L; var g = 0L; var b = 0L; var n = 0
        for (yy in (y - rad).coerceAtLeast(0)..(y + rad).coerceAtMost(bmp.height - 1))
            for (xx in (x - rad).coerceAtLeast(0)..(x + rad).coerceAtMost(bmp.width - 1)) {
                val p = bmp.getPixel(xx, yy); r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
            }
        n = maxOf(1, n)
        return Triple(r.toFloat() / n, g.toFloat() / n, b.toFloat() / n)
    }

    /**
     * "Color automático": the cast measured on the mid-tones (gray world, ignoring very dark,
     * very bright and very colorful pixels), as gains. Small casts only; a sunset stays a sunset.
     */
    fun autoGains(bmp: Bitmap): Triple<Float, Float, Float> {
        val s = previewOf(bmp, 512)
        val px = IntArray(s.width * s.height); s.getPixels(px, 0, s.width, 0, 0, s.width, s.height)
        var r = 0.0; var g = 0.0; var b = 0.0; var n = 0
        for (p in px) {
            val R = (p shr 16) and 255; val G = (p shr 8) and 255; val B = p and 255
            val mx = maxOf(R, G, B); val mn = minOf(R, G, B)
            if (mx < 30 || mn > 235 || mx - mn > 90) continue
            r += R; g += G; b += B; n++
        }
        if (n < 100) return Triple(1f, 1f, 1f)
        val (kr, kg, kb) = neutralGains((r / n).toFloat(), (g / n).toFloat(), (b / n).toFloat())
        // only part of the way: gray world overshoots on photos that really are warm or green
        fun soft(k: Float) = (1f + (k - 1f) * 0.7f).coerceIn(0.8f, 1.25f)
        return Triple(soft(kr), soft(kg), soft(kb))
    }

    fun matrix(v: Values): ColorMatrix {
        val m = ColorMatrix()
        // white balance first (it corrects the photo's colors; the rest are tastes on top)
        m.setScale(v.gainR, v.gainG, v.gainB, 1f)
        // saturation: 0 = gray, 1 = same, 2 = twice as vivid
        m.postConcat(ColorMatrix().apply { setSaturation(if (v.bw || v.sepia) 0f else 1f + v.saturation / 100f) })
        // sepia: the gray tinted warm-brown (more in the mid tones than in the whites)
        if (v.sepia) m.postConcat(ColorMatrix(floatArrayOf(
            1.07f, 0f, 0f, 0f, 8f,
            0f, 0.98f, 0f, 0f, 2f,
            0f, 0f, 0.82f, 0f, -6f,
            0f, 0f, 0f, 1f, 0f)))
        // warmth: more red / less blue; tint: green <-> magenta
        val w = v.warmth / 100f * 0.18f
        val t = v.tint / 100f * 0.12f
        m.postConcat(ColorMatrix(floatArrayOf(
            1f + w + t * 0.5f, 0f, 0f, 0f, 0f,
            0f, 1f - t, 0f, 0f, 0f,
            0f, 0f, 1f - w + t * 0.5f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )))
        // contrast around the middle gray, then brightness as a lift
        val k = 1f + v.contrast / 100f * 0.6f
        val off = 128f * (1f - k) + v.brightness / 100f * 70f
        m.postConcat(ColorMatrix(floatArrayOf(
            k, 0f, 0f, 0f, off,
            0f, k, 0f, 0f, off,
            0f, 0f, k, 0f, off,
            0f, 0f, 0f, 1f, 0f,
        )))
        return m
    }

    /** A new bitmap with [v] applied ([src] is left as is). */
    fun apply(src: Bitmap, v: Values, isCancelled: () -> Boolean = { false }): Bitmap? {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrix(v))
        })
        if (v.shadows != 0 && !shadows(out, v.shadows / 100f, isCancelled)) return null
        if (v.sharpness > 0) {
            // the blur radius follows the picture's size, so the preview and the saved file look alike
            val r = maxOf(1, (maxOf(src.width, src.height) / 1600f).roundToInt())
            if (!sharpen(out, v.sharpness / 100f * 1.5f, r, isCancelled)) return null
        }
        return out
    }

    /**
     * Shadows in place: a curve that moves the dark tones only (strongest around 20 % gray, nothing
     * above ~70 %), the same on the three channels so colors don't shift.
     */
    private fun shadows(bmp: Bitmap, amount: Float, isCancelled: () -> Boolean): Boolean {
        val lut = IntArray(256) { i ->
            val x = i / 255f
            val w = (1f - x / 0.7f).coerceIn(0f, 1f).let { it * it }   // weight: 1 at black, 0 from 70 %
            val y = if (amount > 0) x + amount * 0.45f * w * (1f - x) * (x * 4f).coerceAtMost(1f)
                    else x + amount * 0.45f * w * x
            (y * 255f).roundToInt().coerceIn(0, 255)
        }
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        if (isCancelled()) return false
        for (i in px.indices) {
            val p = px[i]
            px[i] = (p and -0x1000000) or (lut[(p shr 16) and 255] shl 16) or (lut[(p shr 8) and 255] shl 8) or lut[p and 255]
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return true
    }

    /** Unsharp mask in place: x + amount * (x - blur(x)), blur = box of radius [r] (two passes). */
    private fun sharpen(bmp: Bitmap, amount: Float, r: Int, isCancelled: () -> Boolean): Boolean {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val blur = IntArray(w * h)
        val tmp = IntArray(w * h)
        boxH(px, tmp, w, h, r)
        if (isCancelled()) return false
        boxV(tmp, blur, w, h, r)
        if (isCancelled()) return false
        for (i in px.indices) {
            val a = px[i]; val bl = blur[i]
            fun ch(s: Int): Int {
                val x = (a shr s) and 255; val y = (bl shr s) and 255
                return (x + amount * (x - y)).roundToInt().coerceIn(0, 255)
            }
            px[i] = (a and -0x1000000) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return true
    }

    private fun boxH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val n = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0; var sg = 0; var sb = 0
            for (k in -r..r) { val p = src[row + k.coerceIn(0, w - 1)]; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255 }
            for (x in 0 until w) {
                dst[row + x] = ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val pOut = src[row + (x - r).coerceIn(0, w - 1)]
                val pIn = src[row + (x + r + 1).coerceIn(0, w - 1)]
                sr += ((pIn shr 16) and 255) - ((pOut shr 16) and 255)
                sg += ((pIn shr 8) and 255) - ((pOut shr 8) and 255)
                sb += (pIn and 255) - (pOut and 255)
            }
        }
    }

    private fun boxV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val n = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0; var sg = 0; var sb = 0
            for (k in -r..r) { val p = src[k.coerceIn(0, h - 1) * w + x]; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255 }
            for (y in 0 until h) {
                dst[y * w + x] = ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val pOut = src[(y - r).coerceIn(0, h - 1) * w + x]
                val pIn = src[(y + r + 1).coerceIn(0, h - 1) * w + x]
                sr += ((pIn shr 16) and 255) - ((pOut shr 16) and 255)
                sg += ((pIn shr 8) and 255) - ((pOut shr 8) and 255)
                sb += (pIn and 255) - (pOut and 255)
            }
        }
    }

    /** A smaller copy for the live preview (adjusting a 16 MP picture on every slider move is slow). */
    fun previewOf(src: Bitmap, maxSide: Int = 1600): Bitmap {
        val s = maxOf(src.width, src.height)
        if (s <= maxSide) return src
        val f = maxSide.toFloat() / s
        return Bitmap.createScaledBitmap(src, (src.width * f).roundToInt(), (src.height * f).roundToInt(), true)
    }
}
