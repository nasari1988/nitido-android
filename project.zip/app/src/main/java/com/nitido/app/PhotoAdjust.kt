package com.nitido.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.roundToInt

/**
 * Manual finishing touches on a restored photo: brightness, contrast, saturation, warmth
 * (color temperature), tint and sharpness. All values go from -100 to 100 (sharpness 0..100);
 * 0 = unchanged. Colors are one ColorMatrix pass (fast); sharpness is an unsharp mask.
 */
object PhotoAdjust {

    data class Values(
        val brightness: Int = 0, val contrast: Int = 0, val saturation: Int = 0,
        val warmth: Int = 0, val tint: Int = 0, val sharpness: Int = 0,
    ) {
        val isNeutral get() = this == Values()
    }

    fun matrix(v: Values): ColorMatrix {
        val m = ColorMatrix()
        // saturation: 0 = gray, 1 = same, 2 = twice as vivid
        m.setSaturation(1f + v.saturation / 100f)
        // warmth: more red / less blue; tint: green <-> magenta
        val w = v.warmth / 100f * 0.18f
        val t = v.tint / 100f * 0.12f
        m.postConcat(ColorMatrix(floatArrayOf(
            1f + w + t * 0.5f, 0f, 0f, 0f, 0f,
            0f, 1f - t, 0f, 0f, 0f,
            0f, 0f, 1f - w + t * 0.5f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )))
        // contrast around the middle gray, then brightness as a lift
        val k = 1f + v.contrast / 100f * 0.6f
        val off = 128f * (1f - k) + v.brightness / 100f * 70f
        m.postConcat(ColorMatrix(floatArrayOf(
            k, 0f, 0f, 0f, off,
            0f, k, 0f, 0f, off,
            0f, 0f, k, 0f, off,
            0f, 0f, 0f, 1f, 0f,
        )))
        return m
    }

    /** A new bitmap with [v] applied ([src] is left as is). */
    fun apply(src: Bitmap, v: Values, isCancelled: () -> Boolean = { false }): Bitmap? {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrix(v))
        })
        if (v.sharpness > 0) {
            // the blur radius follows the picture's size, so the preview and the saved file look alike
            val r = maxOf(1, (maxOf(src.width, src.height) / 1600f).roundToInt())
            if (!sharpen(out, v.sharpness / 100f * 1.5f, r, isCancelled)) return null
        }
        return out
    }

    /** Unsharp mask in place: x + amount * (x - blur(x)), blur = box of radius [r] (two passes). */
    private fun sharpen(bmp: Bitmap, amount: Float, r: Int, isCancelled: () -> Boolean): Boolean {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val blur = IntArray(w * h)
        val tmp = IntArray(w * h)
        boxH(px, tmp, w, h, r)
        if (isCancelled()) return false
        boxV(tmp, blur, w, h, r)
        if (isCancelled()) return false
        for (i in px.indices) {
            val a = px[i]; val bl = blur[i]
            fun ch(s: Int): Int {
                val x = (a shr s) and 255; val y = (bl shr s) and 255
                return (x + amount * (x - y)).roundToInt().coerceIn(0, 255)
            }
            px[i] = (a and -0x1000000) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return true
    }

    private fun boxH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val n = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0; var sg = 0; var sb = 0
            for (k in -r..r) { val p = src[row + k.coerceIn(0, w - 1)]; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255 }
            for (x in 0 until w) {
                dst[row + x] = ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val pOut = src[row + (x - r).coerceIn(0, w - 1)]
                val pIn = src[row + (x + r + 1).coerceIn(0, w - 1)]
                sr += ((pIn shr 16) and 255) - ((pOut shr 16) and 255)
                sg += ((pIn shr 8) and 255) - ((pOut shr 8) and 255)
                sb += (pIn and 255) - (pOut and 255)
            }
        }
    }

    private fun boxV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val n = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0; var sg = 0; var sb = 0
            for (k in -r..r) { val p = src[k.coerceIn(0, h - 1) * w + x]; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255 }
            for (y in 0 until h) {
                dst[y * w + x] = ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val pOut = src[(y - r).coerceIn(0, h - 1) * w + x]
                val pIn = src[(y + r + 1).coerceIn(0, h - 1) * w + x]
                sr += ((pIn shr 16) and 255) - ((pOut shr 16) and 255)
                sg += ((pIn shr 8) and 255) - ((pOut shr 8) and 255)
                sb += (pIn and 255) - (pOut and 255)
            }
        }
    }

    /** A smaller copy for the live preview (adjusting a 16 MP picture on every slider move is slow). */
    fun previewOf(src: Bitmap, maxSide: Int = 1600): Bitmap {
        val s = maxOf(src.width, src.height)
        if (s <= maxSide) return src
        val f = maxSide.toFloat() / s
        return Bitmap.createScaledBitmap(src, (src.width * f).roundToInt(), (src.height * f).roundToInt(), true)
    }
}
