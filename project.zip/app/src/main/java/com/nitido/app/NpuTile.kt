package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.util.Log
import java.io.File
import java.nio.FloatBuffer

/**
 * A small fixed-size picture model (one tile in, one tile out) on the phone's NPU, with ONNX
 * Runtime's QNN provider. The models are Qualcomm's own 8-bit versions (AI Hub, "onnx-w8a8"),
 * shipped in assets/npu/<name>/. The first run compiles them for this NPU (a few seconds, they're
 * small) and keeps the result next to them, so later runs start right away.
 */
class NpuTile private constructor(
    private val session: OrtSession, val inShape: LongArray, val outShape: LongArray,
    private val qIn: Quant? = null, private val qOut: Quant? = null,
) : AutoCloseable {

    /** A quantized in/out of a graph compiled in the server (W8A16): QNN type, x = scale * (q + offset). */
    class Quant(val type: Int, val scale: Float, val offset: Int)

    private val env = OrtEnvironment.getEnvironment()
    private val inName = session.inputNames.first()

    /** [input] in the model's layout and size, values 0..1; writes the model's output into [out]. */
    fun run(input: FloatBuffer, out: FloatArray): Boolean {
        input.rewind()
        val t = if (qIn != null) quantTensor(qIn, input) else OnnxTensor.createTensor(env, input, inShape)
        t.use {
            NpuMeter.begin()
            try {
                session.run(mapOf(inName to t)).use { r ->
                    val o = r.get(0) as OnnxTensor
                    if (qOut != null) dequant(qOut, o, out)
                    else o.floatBuffer.get(out, 0, minOf(out.size, o.floatBuffer.remaining()))
                }
            } finally { NpuMeter.end() }
        }
        return true
    }

    /** float -> the NPU's integers: q = round(x / scale) - offset. */
    private fun quantTensor(q: Quant, data: FloatBuffer): OnnxTensor {
        val inv = 1f / q.scale
        val n = data.remaining()
        return if (q.type == 0x0408 || q.type == 0x0308) {
            val bb = java.nio.ByteBuffer.allocateDirect(n).order(java.nio.ByteOrder.nativeOrder())
            val lo = if (q.type == 0x0408) 0 else -128; val hi = if (q.type == 0x0408) 255 else 127
            for (i in 0 until n) bb.put((Math.round(data.get(i) * inv) - q.offset).coerceIn(lo, hi).toByte())
            bb.rewind()
            OnnxTensor.createTensor(env, bb, inShape, if (q.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
        } else {
            val bb = java.nio.ByteBuffer.allocateDirect(n * 2).order(java.nio.ByteOrder.nativeOrder())
            val sb = bb.asShortBuffer()
            val lo = if (q.type == 0x0416) 0 else -32768; val hi = if (q.type == 0x0416) 65535 else 32767
            for (i in 0 until n) sb.put((Math.round(data.get(i) * inv) - q.offset).coerceIn(lo, hi).toShort())
            OnnxTensor.createTensor(env, bb, inShape, OnnxJavaType.INT16)
        }
    }

    private fun dequant(q: Quant, o: OnnxTensor, out: FloatArray) {
        val bb = o.byteBuffer.order(java.nio.ByteOrder.nativeOrder())
        if (q.type == 0x0408 || q.type == 0x0308) {
            val n = minOf(out.size, bb.remaining())
            for (i in 0 until n) { val b = bb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0408) b and 0xFF else b) + q.offset) }
        } else {
            val sb = bb.asShortBuffer()
            val n = minOf(out.size, sb.remaining())
            for (i in 0 until n) { val v = sb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0416) v and 0xFFFF else v) + q.offset) }
        }
    }

    fun run(input: FloatArray, out: FloatArray): Boolean = run(FloatBuffer.wrap(input), out)

    override fun close() { try { session.close() } catch (_: Throwable) { } }

    companion object {
        /** Why the last [open] gave no NPU model (shown to the user and in the log). */
        @Volatile var lastError: String? = null
            private set

        /** The NPU version of a Mejorar model, if this build carries one. */
        fun assetFor(modelFile: String): String? = when (modelFile) {
            Upscaler.MODEL_FILE -> "npu/x4v3"
            Upscaler.MODEL_X4PLUS -> "npu/x4plus"
            Upscaler.MODEL_QSR -> "npu/qsr"
            else -> null
        }

        fun has(ctx: Context, modelFile: String): Boolean =
            assetFor(modelFile)?.let { a -> try { ctx.assets.list(a)?.any { it.endsWith(".onnx") } == true } catch (_: Throwable) { false } } == true

        /** Opens [modelFile]'s NPU version, or null (no NPU version, or the NPU refused it). */
        fun open(ctx: Context, modelFile: String): NpuTile? {
            lastError = null
            val asset = assetFor(modelFile) ?: return null.also { lastError = "este modelo no tiene versión NPU" }
            return try {
                val dir = File(ctx.filesDir, asset).apply { mkdirs() }
                // copy the model out of the APK once (ONNX Runtime reads it, and its weights file, from disk)
                for (name in ctx.assets.list(asset).orEmpty()) {
                    val f = File(dir, name)
                    val want = try { ctx.assets.openFd("$asset/$name").use { it.length } } catch (_: Throwable) { -1L }
                    if (f.exists() && f.length() > 0 && (want < 0 || f.length() == want)) continue
                    val tmp = File(dir, "$name.tmp")
                    ctx.assets.open("$asset/$name").use { i -> tmp.outputStream().use { i.copyTo(it) } }
                    tmp.renameTo(f)
                }
                val model = dir.listFiles()?.firstOrNull { it.name.endsWith(".onnx") && !it.name.startsWith("ctx") }
                    ?: return null.also { lastError = "la app no trae el archivo NPU de $asset" }
                openFile(ctx, model, asset, fp16 = false)
            } catch (t: Throwable) {
                Log.w("Nitido", "NPU tile $asset", t)
                lastError = (t.message ?: t.javaClass.simpleName).take(300) + NpuUnet.qnnLog()
                null
            }
        }

        /**
         * Opens a graph compiled in the server for this NPU ("<name>_ctx.onnx", an EPContext wrapper
         * pointing at its .bin, with "<name>_ctx.onnx.json" giving the scale/offset of its integer
         * in/out). Nothing compiles on the phone. Null (with [lastError]) when the NPU says no.
         */
        fun openPrecompiled(ctx: Context, wrapper: File, tag: String): NpuTile? {
            lastError = null
            return try {
                NpuUnet.prepareDsp(ctx)
                val t0 = android.os.SystemClock.elapsedRealtime()
                val opts = OrtSession.SessionOptions().apply {
                    setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                    addConfigEntry("session.disable_cpu_ep_fallback", "0")
                    addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
                }
                val s = OrtEnvironment.getEnvironment().createSession(wrapper.path, opts)
                val q = readQuant(File(wrapper.path + ".json"))
                val inName = s.inputNames.first(); val outName = s.outputNames.first()
                val inInfo = s.inputInfo.values.first().info as TensorInfo
                val outInfo = s.outputInfo.values.first().info as TensorInfo
                val secs = (android.os.SystemClock.elapsedRealtime() - t0) / 1000f
                JobLog.add("NPU: $tag abierto en ${"%.1f".format(java.util.Locale.US, secs)} s · entrada ${inInfo.type} ${inInfo.shape.joinToString("×")}" +
                    (q[inName]?.let { " (escala ${it.scale}, offset ${it.offset})" } ?: "") + " · salida ${outInfo.type} ${outInfo.shape.joinToString("×")}" +
                    (q[outName]?.let { " (escala ${it.scale}, offset ${it.offset})" } ?: ""))
                if (inInfo.type != OnnxJavaType.FLOAT && q[inName] == null || outInfo.type != OnnxJavaType.FLOAT && q[outName] == null) {
                    lastError = "entrada/salida ${inInfo.type}/${outInfo.type} sin escala en ${wrapper.name}.json"
                    s.close(); return null
                }
                NpuTile(s, inInfo.shape, outInfo.shape, q[inName], q[outName])
            } catch (t: Throwable) {
                Log.w("Nitido", "NPU $tag", t)
                lastError = (t.message ?: t.javaClass.simpleName).take(400) + NpuUnet.qnnLog()
                JobLog.notice("NPU: $tag no abrió: $lastError")
                null
            }
        }

        private fun readQuant(f: File): Map<String, Quant> = try {
            val j = org.json.JSONObject(f.readText()).optJSONObject("quant")
            if (j == null) emptyMap() else j.keys().asSequence().mapNotNull { k ->
                val o = j.getJSONObject(k)
                if (!o.has("scale")) null else k to Quant(o.getInt("qnn_type"), o.getDouble("scale").toFloat(), o.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }

        /**
         * Opens any single-input, single-output ONNX model file on the NPU. [fp16]: a float model
         * (run in 16 bits on the NPU, as Qualcomm does with its float models); otherwise an 8-bit
         * (QDQ) one. The compiled copy is kept next to the model (named after its size), so only
         * the first run waits for the compilation. Null (with [lastError]) when the NPU says no.
         */
        fun openModel(ctx: Context, model: File, tag: String, fp16: Boolean): NpuTile? {
            lastError = null
            return try { openFile(ctx, model, tag, fp16) } catch (t: Throwable) {
                Log.w("Nitido", "NPU $tag", t)
                lastError = (t.message ?: t.javaClass.simpleName).take(300) + NpuUnet.qnnLog()
                JobLog.notice("NPU: $tag no abrió: $lastError")
                null
            }
        }

        private fun openFile(ctx: Context, model: File, tag: String, fp16: Boolean): NpuTile? {
                val dir = model.parentFile!!
                val base = model.name.removeSuffix(".onnx")
                // the compiled copy belongs to this exact model file: a new model in a new app version
                // (or an old copy with integer in/out) is compiled again
                val key = model.length().toString() + "_" + (File(dir, "$base.data").takeIf { it.exists() }?.length() ?: 0)
                val pre = "ctx_npu_${base}_"
                val cache = File(dir, "$pre$key.onnx")
                dir.listFiles()?.filter { (it.name.startsWith(pre) || it.name.startsWith("ctx_npu_") && it.name.count { c -> c == '_' } == 3) && it.name != cache.name }?.forEach { it.delete() }
                NpuUnet.prepareDsp(ctx)
                val env = OrtEnvironment.getEnvironment()
                fun options(compile: Boolean) = OrtSession.SessionOptions().apply {
                    setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                    addConfigEntry("session.disable_cpu_ep_fallback", "0")
                    if (compile) {
                        addConfigEntry("ep.context_enable", "1")
                        addConfigEntry("ep.context_embed_mode", "1")
                        addConfigEntry("ep.context_file_path", cache.path)
                    }
                    addQnn(mapOf(
                        "backend_path" to "libQnnHtp.so",
                        "htp_performance_mode" to "burst",
                        "htp_graph_finalization_optimization_mode" to "3",
                    ) + (if (fp16) mapOf("enable_htp_fp16_precision" to "1") else emptyMap()))
                }
                fun session(): OrtSession = try {
                    if (cache.exists()) env.createSession(cache.path, options(false)) else env.createSession(model.path, options(true))
                } catch (t: Throwable) {
                    cache.delete()   // a bad cache: compile again next time
                    throw t
                }
                fun isFloat(x: OrtSession) =
                    (x.inputInfo.values.first().info as TensorInfo).type == OnnxJavaType.FLOAT &&
                        (x.outputInfo.values.first().info as TensorInfo).type == OnnxJavaType.FLOAT
                val compiled = !cache.exists()
                val t0 = android.os.SystemClock.elapsedRealtime()
                var s = session()
                if (!isFloat(s) && cache.exists()) {   // a stale compiled copy: compile the model again
                    s.close(); cache.delete(); s = session()
                }
                val inInfo = s.inputInfo.values.first().info as TensorInfo
                val outInfo = s.outputInfo.values.first().info as TensorInfo
                if (inInfo.type != OnnxJavaType.FLOAT || outInfo.type != OnnxJavaType.FLOAT) {
                    lastError = "entrada/salida ${inInfo.type}/${outInfo.type}, se esperaba FLOAT"
                    Log.w("Nitido", "NPU $tag has non-float io: ${inInfo.type} ${outInfo.type}")
                    s.close(); return null
                }
                Log.i("Nitido", "NPU $tag in ${inInfo.shape.joinToString("x")} out ${outInfo.shape.joinToString("x")}")
                val secs = (android.os.SystemClock.elapsedRealtime() - t0) / 1000f
                JobLog.add("NPU: $tag ${if (compiled) "preparado por primera vez" else "abierto"} en ${"%.1f".format(java.util.Locale.US, secs)} s" +
                    (if (fp16) " (16 bits)" else ""))
                return NpuTile(s, inInfo.shape, outInfo.shape)
        }
    }
}
