package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.util.Log
import java.io.File
import java.nio.FloatBuffer

/**
 * A small fixed-size picture model (one tile in, one tile out) on the phone's NPU, with ONNX
 * Runtime's QNN provider. The models are Qualcomm's own 8-bit versions (AI Hub, "onnx-w8a8"),
 * shipped in assets/npu/<name>/. The first run compiles them for this NPU (a few seconds, they're
 * small) and keeps the result next to them, so later runs start right away.
 */
class NpuTile private constructor(private val session: OrtSession, val inShape: LongArray, val outShape: LongArray) : AutoCloseable {

    private val env = OrtEnvironment.getEnvironment()
    private val inName = session.inputNames.first()

    /** [input] in the model's layout and size, values 0..1; writes the model's output into [out]. */
    fun run(input: FloatBuffer, out: FloatArray): Boolean {
        input.rewind()
        OnnxTensor.createTensor(env, input, inShape).use { t ->
            NpuMeter.begin()
            try {
                session.run(mapOf(inName to t)).use { r ->
                    val o = r.get(0) as OnnxTensor
                    o.floatBuffer.get(out, 0, minOf(out.size, o.floatBuffer.remaining()))
                }
            } finally { NpuMeter.end() }
        }
        return true
    }

    fun run(input: FloatArray, out: FloatArray): Boolean = run(FloatBuffer.wrap(input), out)

    override fun close() { try { session.close() } catch (_: Throwable) { } }

    companion object {
        /** Why the last [open] gave no NPU model (shown to the user and in the log). */
        @Volatile var lastError: String? = null
            private set

        /** The NPU version of a Mejorar model, if this build carries one. */
        fun assetFor(modelFile: String): String? = when (modelFile) {
            Upscaler.MODEL_FILE -> "npu/x4v3"
            Upscaler.MODEL_X4PLUS -> "npu/x4plus"
            else -> null
        }

        fun has(ctx: Context, modelFile: String): Boolean =
            assetFor(modelFile)?.let { a -> try { ctx.assets.list(a)?.any { it.endsWith(".onnx") } == true } catch (_: Throwable) { false } } == true

        /** Opens [modelFile]'s NPU version, or null (no NPU version, or the NPU refused it). */
        fun open(ctx: Context, modelFile: String): NpuTile? {
            lastError = null
            val asset = assetFor(modelFile) ?: return null.also { lastError = "este modelo no tiene versión NPU" }
            return try {
                val dir = File(ctx.filesDir, asset).apply { mkdirs() }
                // copy the model out of the APK once (ONNX Runtime reads it, and its weights file, from disk)
                for (name in ctx.assets.list(asset).orEmpty()) {
                    val f = File(dir, name)
                    val want = try { ctx.assets.openFd("$asset/$name").use { it.length } } catch (_: Throwable) { -1L }
                    if (f.exists() && f.length() > 0 && (want < 0 || f.length() == want)) continue
                    val tmp = File(dir, "$name.tmp")
                    ctx.assets.open("$asset/$name").use { i -> tmp.outputStream().use { i.copyTo(it) } }
                    tmp.renameTo(f)
                }
                val model = dir.listFiles()?.firstOrNull { it.name.endsWith(".onnx") && !it.name.startsWith("ctx") }
                    ?: return null.also { lastError = "la app no trae el archivo NPU de $asset" }
                openFile(ctx, model, asset, fp16 = false)
            } catch (t: Throwable) {
                Log.w("Nitido", "NPU tile $asset", t)
                lastError = (t.message ?: t.javaClass.simpleName).take(300) + NpuUnet.qnnLog()
                null
            }
        }

        /**
         * Opens any single-input, single-output ONNX model file on the NPU. [fp16]: a float model
         * (run in 16 bits on the NPU, as Qualcomm does with its float models); otherwise an 8-bit
         * (QDQ) one. The compiled copy is kept next to the model (named after its size), so only
         * the first run waits for the compilation. Null (with [lastError]) when the NPU says no.
         */
        fun openModel(ctx: Context, model: File, tag: String, fp16: Boolean): NpuTile? {
            lastError = null
            return try { openFile(ctx, model, tag, fp16) } catch (t: Throwable) {
                Log.w("Nitido", "NPU $tag", t)
                lastError = (t.message ?: t.javaClass.simpleName).take(300) + NpuUnet.qnnLog()
                null
            }
        }

        private fun openFile(ctx: Context, model: File, tag: String, fp16: Boolean): NpuTile? {
                val dir = model.parentFile!!
                val base = model.name.removeSuffix(".onnx")
                // the compiled copy belongs to this exact model file: a new model in a new app version
                // (or an old copy with integer in/out) is compiled again
                val key = model.length().toString() + "_" + (File(dir, "$base.data").takeIf { it.exists() }?.length() ?: 0)
                val pre = "ctx_npu_${base}_"
                val cache = File(dir, "$pre$key.onnx")
                dir.listFiles()?.filter { (it.name.startsWith(pre) || it.name.startsWith("ctx_npu_") && it.name.count { c -> c == '_' } == 3) && it.name != cache.name }?.forEach { it.delete() }
                NpuUnet.prepareDsp(ctx)
                val env = OrtEnvironment.getEnvironment()
                fun options(compile: Boolean) = OrtSession.SessionOptions().apply {
                    setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                    addConfigEntry("session.disable_cpu_ep_fallback", "0")
                    if (compile) {
                        addConfigEntry("ep.context_enable", "1")
                        addConfigEntry("ep.context_embed_mode", "1")
                        addConfigEntry("ep.context_file_path", cache.path)
                    }
                    addQnn(mapOf(
                        "backend_path" to "libQnnHtp.so",
                        "htp_performance_mode" to "burst",
                        "htp_graph_finalization_optimization_mode" to "3",
                    ) + (if (fp16) mapOf("enable_htp_fp16_precision" to "1") else emptyMap()))
                }
                fun session(): OrtSession = try {
                    if (cache.exists()) env.createSession(cache.path, options(false)) else env.createSession(model.path, options(true))
                } catch (t: Throwable) {
                    cache.delete()   // a bad cache: compile again next time
                    throw t
                }
                fun isFloat(x: OrtSession) =
                    (x.inputInfo.values.first().info as TensorInfo).type == OnnxJavaType.FLOAT &&
                        (x.outputInfo.values.first().info as TensorInfo).type == OnnxJavaType.FLOAT
                var s = session()
                if (!isFloat(s) && cache.exists()) {   // a stale compiled copy: compile the model again
                    s.close(); cache.delete(); s = session()
                }
                val inInfo = s.inputInfo.values.first().info as TensorInfo
                val outInfo = s.outputInfo.values.first().info as TensorInfo
                if (inInfo.type != OnnxJavaType.FLOAT || outInfo.type != OnnxJavaType.FLOAT) {
                    lastError = "entrada/salida ${inInfo.type}/${outInfo.type}, se esperaba FLOAT"
                    Log.w("Nitido", "NPU $tag has non-float io: ${inInfo.type} ${outInfo.type}")
                    s.close(); return null
                }
                Log.i("Nitido", "NPU $tag in ${inInfo.shape.joinToString("x")} out ${outInfo.shape.joinToString("x")}")
                return NpuTile(s, inInfo.shape, outInfo.shape)
        }
    }
}
