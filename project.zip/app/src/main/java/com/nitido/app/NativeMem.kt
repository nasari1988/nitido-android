package com.nitido.app

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.IdentityHashMap

/**
 * Big buffers outside the Java heap. On Android, ByteBuffer.allocateDirect is counted in the app's
 * 512 MB Java limit (that is what ran Limpiar video out of memory); these come from the native
 * library instead and must be given back with [free].
 */
object NativeMem {
    private val native = Collections.newSetFromMap(IdentityHashMap<ByteBuffer, Boolean>())

    @Synchronized fun alloc(bytes: Int): ByteBuffer {
        val b = if (SdNative.loadError == null) try { SdNative.allocDirect(bytes.toLong()) } catch (t: Throwable) { null } else null
        if (b == null) {
            JobLog.add("Memoria: ${bytes / 1_000_000} MB en Java (la memoria nativa no respondió)")
            return ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder())
        }
        native += b
        return b.order(ByteOrder.nativeOrder())
    }

    /** Gives [b] back (only buffers made by [alloc] outside Java; nothing for the others). */
    @Synchronized fun free(b: ByteBuffer) {
        if (native.remove(b)) try { SdNative.freeDirect(b) } catch (_: Throwable) { }
    }
}
