package com.nitido.app

import android.os.SystemClock

/**
 * How busy Nítido keeps the NPU, the same way [GpuMeter] does for the GPU: Android doesn't let
 * apps read the Hexagon NPU's load, so every UNet step sent to it is timed.
 */
object NpuMeter {
    private val lock = Any()
    private var busyMs = 0L
    private var active = 0
    private var activeSince = 0L
    @Volatile var lastUse = 0L
        private set
    /** Duration of the last step on the NPU (ms), 0 before the first one. */
    @Volatile var lastStepMs = 0L
        private set

    fun begin() = synchronized(lock) {
        if (active++ == 0) activeSince = SystemClock.elapsedRealtime()
        lastUse = SystemClock.elapsedRealtime()
    }

    fun end() = synchronized(lock) {
        val now = SystemClock.elapsedRealtime()
        if (--active == 0) { busyMs += now - activeSince; lastStepMs = now - activeSince }
        if (active < 0) active = 0
        lastUse = now
    }

    fun busyMs(): Long = synchronized(lock) {
        busyMs + if (active > 0) SystemClock.elapsedRealtime() - activeSince else 0L
    }

    /** True while a picture is being made on the NPU (a step ran in the last few seconds). */
    fun inUse(): Boolean = SystemClock.elapsedRealtime() - lastUse < 4000
}
