package com.nitido.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * What happened during the current (or last) job, line by line with the time: shown in the
 * processing screen ("Registro") and kept after the job ends so it can be copied.
 */
object JobLog {
    class Line(val time: String, val text: String, val level: Int)   // 0 info, 1 notice, 2 error

    private val lines = ArrayList<Line>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    @Volatile var version = 0
        private set

    /**
     * Where each line is also written as it happens, so the log survives when Android closes the
     * app in the middle of a job (memory, heat…). Set by the first deviceLine / attach call.
     */
    @Volatile private var live: File? = null

    /** A second copy that start() doesn't clear (the autotest's whole log, over many jobs). */
    @Volatile var tee: File? = null

    fun attach(ctx: Context) { if (live == null) live = File(ctx.applicationContext.filesDir, "last_log.txt") }

    /** Set while a job runs (BgWork.start … finish): if it is still there at the next job, Android closed the app mid-job. */
    private fun openFlag() = live?.parentFile?.let { File(it, "job_open") }

    @Synchronized fun start(title: String) {
        // the last job never finished (Android closed the app: memory, heat…): keep how it ended
        var before: List<String> = emptyList()
        try {
            val f = openFlag()
            if (f != null && f.exists()) before = live?.takeIf { it.exists() }?.readLines()?.filter { it.isNotBlank() }?.takeLast(15) ?: emptyList()
            f?.writeText(title)
        } catch (t: Throwable) { }
        lines.clear()
        try { live?.writeText("") } catch (t: Throwable) { }
        add(title)
        if (before.isNotEmpty()) {
            add("La vez anterior la app se cerró a media tarea (Android la cerró, casi siempre por falta de memoria). Así terminó:", 1)
            for (l in before) add("   · $l")
        }
    }

    /** The job ended normally (BgWork.finish). */
    fun jobEnded() { try { openFlag()?.delete() } catch (t: Throwable) { } }

    @Synchronized fun add(text: String, level: Int = 0) {
        if (text.isBlank()) return
        if (lines.isNotEmpty() && lines.last().text == text) return
        val l = Line(fmt.format(Date()), text.trim(), level)
        lines += l
        if (lines.size > 400) lines.removeAt(1)
        try { live?.appendText("${l.time} ${l.text}\n") } catch (t: Throwable) { }
        try { tee?.appendText("${l.time} ${l.text}\n") } catch (t: Throwable) { }
        version++
    }

    fun notice(text: String) = add(text, 1)

    /** App version, phone, Android and free memory (first line of every job). */
    fun deviceLine(ctx: Context): String {
        attach(ctx)
        val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (t: Throwable) { "?" }
        val mi = android.app.ActivityManager.MemoryInfo()
        try { ctx.getSystemService(android.app.ActivityManager::class.java).getMemoryInfo(mi) } catch (t: Throwable) { }
        val rt = Runtime.getRuntime()
        return "Nítido $ver · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} · Android ${android.os.Build.VERSION.RELEASE}" +
            " · memoria libre ${mi.availMem / 1_000_000} MB de ${mi.totalMem / 1_000_000} MB · app ${(rt.totalMemory() - rt.freeMemory()) / 1_000_000}/${rt.maxMemory() / 1_000_000} MB"
    }

    /** An error with the first lines of where it happened. */
    fun error(where: String, t: Throwable) {
        val trace = t.stackTrace.take(6).joinToString(" ← ") { "${it.fileName}:${it.lineNumber}" }
        add("$where: ${t.javaClass.simpleName}: ${t.message ?: ""} [$trace]" + (t.cause?.let { " · causa: ${it.javaClass.simpleName}: ${it.message}" } ?: ""), 2)
    }
    fun error(text: String) = add(text, 2)

    @Synchronized fun snapshot(): List<Line> = ArrayList(lines)

    fun notices() = snapshot().count { it.level == 1 }
    fun errors() = snapshot().count { it.level == 2 }

    @Synchronized fun asText(): String = lines.joinToString("\n") { "${it.time} ${it.text}" }

    private fun file(ctx: Context) = File(ctx.filesDir, "last_log.txt")

    @Synchronized fun save(ctx: Context) {
        try { file(ctx).writeText(asText()) } catch (t: Throwable) { }
    }

    /** The log of the last finished job, if any. */
    fun saved(ctx: Context): String? = try { file(ctx).takeIf { it.exists() }?.readText() } catch (t: Throwable) { null }
}
