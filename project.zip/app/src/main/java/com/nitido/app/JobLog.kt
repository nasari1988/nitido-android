package com.nitido.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * What happened during the current (or last) job, line by line with the time: shown in the
 * processing screen ("Registro") and kept after the job ends so it can be copied.
 */
object JobLog {
    class Line(val time: String, val text: String, val level: Int)   // 0 info, 1 notice, 2 error

    private val lines = ArrayList<Line>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    @Volatile var version = 0
        private set

    @Synchronized fun start(title: String) {
        lines.clear()
        add(title)
    }

    @Synchronized fun add(text: String, level: Int = 0) {
        if (text.isBlank()) return
        if (lines.isNotEmpty() && lines.last().text == text) return
        lines += Line(fmt.format(Date()), text.trim(), level)
        if (lines.size > 400) lines.removeAt(1)
        version++
    }

    fun notice(text: String) = add(text, 1)
    fun error(text: String) = add(text, 2)

    @Synchronized fun snapshot(): List<Line> = ArrayList(lines)

    fun notices() = snapshot().count { it.level == 1 }
    fun errors() = snapshot().count { it.level == 2 }

    @Synchronized fun asText(): String = lines.joinToString("\n") { "${it.time} ${it.text}" }

    private fun file(ctx: Context) = File(ctx.filesDir, "last_log.txt")

    @Synchronized fun save(ctx: Context) {
        try { file(ctx).writeText(asText()) } catch (t: Throwable) { }
    }

    /** The log of the last finished job, if any. */
    fun saved(ctx: Context): String? = try { file(ctx).takeIf { it.exists() }?.readText() } catch (t: Throwable) { null }
}
