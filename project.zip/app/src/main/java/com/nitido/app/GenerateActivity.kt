package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityGenerateBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt
import kotlin.random.Random

class GenerateActivity : AppCompatActivity() {

    private lateinit var b: ActivityGenerateBinding
    private var job: Job? = null
    @Volatile private var cancel = false
    private var lastImage: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGenerateBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.back.setOnClickListener { finish() }
        b.download.setOnClickListener { if (job?.isActive == true) stop() else download() }
        b.generate.setOnClickListener { if (job?.isActive != true) generate() }
        b.save.setOnClickListener { save() }
        b.upscale.setOnClickListener {
            val f = lastImage ?: return@setOnClickListener
            startActivity(Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_PATH, f.absolutePath)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        b.steps.addOnChangeListener { _, v, _ -> b.stepsValue.text = v.roundToInt().toString() }
        b.stepsValue.text = b.steps.value.roundToInt().toString()
        b.deleteModel.setOnClickListener {
            if (job?.isActive == true) return@setOnClickListener
            if (SdNative.loadError == null) SdNative.release()
            SdModel.delete(this); refreshState()
        }
        b.save.isEnabled = false
        b.upscale.isEnabled = false
        refreshState()
    }

    private fun refreshState() {
        val ready = SdModel.isReady(this)
        b.setupCard.visibility = if (ready) View.GONE else View.VISIBLE
        b.createPanel.visibility = if (ready) View.VISIBLE else View.GONE
        b.deleteModel.visibility = if (ready) View.VISIBLE else View.GONE
        if (!ready) b.dlStatus.text = getString(R.string.sd_dl_intro)
    }

    private fun stop() { cancel = true }

    private fun download() {
        cancel = false
        b.download.text = getString(R.string.stop)
        b.dlProgress.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        job = lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    SdModel.download(this@GenerateActivity, { cancel }) { done ->
                        runOnUiThread {
                            val p = done.toFloat() / SdModel.TOTAL
                            b.dlProgress.progress = (p * 1000).roundToInt()
                            b.dlStatus.text = getString(R.string.sd_dl_progress, done / 1_000_000, SdModel.TOTAL / 1_000_000)
                        }
                    }
                    null
                } catch (e: InterruptedException) {
                    getString(R.string.sd_dl_paused)
                } catch (t: Throwable) {
                    getString(R.string.sd_dl_error, t.message ?: t.javaClass.simpleName)
                }
            }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.download.text = getString(R.string.sd_download)
            b.dlProgress.visibility = View.INVISIBLE
            if (err != null) b.dlStatus.text = err else refreshState()
        }
    }

    private fun generate() {
        val prompt = b.prompt.text?.toString()?.trim().orEmpty()
        if (prompt.isEmpty()) { b.genStatus.text = getString(R.string.sd_need_prompt); return }
        val steps = b.steps.value.roundToInt()
        val gpu = b.backendGroup.checkedButtonId != R.id.sdCpu
        val seed = Random.nextInt(1, Int.MAX_VALUE)
        val out = File(cacheDir, "sd_${System.currentTimeMillis()}.jpg")

        SdNative.loadError?.let { b.genStatus.text = getString(R.string.sd_failed, it.toString()); return }

        b.generate.isEnabled = false
        b.save.isEnabled = false
        b.upscale.isEnabled = false
        b.genProgress.progress = 0
        b.genProgress.visibility = View.VISIBLE
        b.genStatus.text = getString(R.string.sd_loading)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val t0 = SystemClock.elapsedRealtime()

        job = lifecycleScope.launch {
            val code = withContext(Dispatchers.Default) {
                try {
                    SdNative.generate(
                        SdModel.dir(this@GenerateActivity).absolutePath,
                        if (gpu) SdNative.BACKEND_OPENCL else SdNative.BACKEND_CPU,
                        steps, seed, out.absolutePath, prompt
                    ) { pct ->
                        val el = (SystemClock.elapsedRealtime() - t0) / 1000
                        runOnUiThread {
                            b.genProgress.progress = pct * 10
                            b.genStatus.text = getString(R.string.sd_progress, pct, el)
                        }
                    }
                } catch (t: Throwable) {
                    -1
                }
            }
            val ok = code == 0 && out.exists() && out.length() > 0
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.generate.isEnabled = true
            b.genProgress.visibility = View.INVISIBLE
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            if (ok) {
                val bmp = BitmapFactory.decodeFile(out.absolutePath)
                b.result.setImageBitmap(bmp)
                lastImage = out
                b.save.isEnabled = true
                b.upscale.isEnabled = true
                b.genStatus.text = getString(R.string.sd_done, secs, if (gpu) "GPU" else "CPU", seed)
            } else {
                val why = when (code) {
                    1 -> "no se creó el motor"
                    2 -> "no cargó el modelo (¿descarga incompleta? bórralo y descárgalo de nuevo)"
                    3 -> "falló la generación"
                    else -> "error interno ($code)"
                }
                b.genStatus.text = getString(R.string.sd_failed, why)
            }
        }
    }

    private fun save() {
        val f = lastImage ?: return
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return@withContext false
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "nitido_ia_${System.currentTimeMillis() / 1000}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    true
                } catch (t: Throwable) { false }
            }
            b.genStatus.text = getString(if (ok) R.string.saved else R.string.err_save)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cancel = true
    }
}
