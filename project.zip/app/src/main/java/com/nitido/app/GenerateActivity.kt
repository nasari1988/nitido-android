package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.nitido.app.databinding.ActivityGenerateBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

class GenerateActivity : AppCompatActivity() {

    private lateinit var b: ActivityGenerateBinding
    private var job: Job? = null
    @Volatile private var cancel = false
    private var lastImage: File? = null
    private var base: Bitmap? = null   // 512×512 photo to start from, if any
    private lateinit var model: SdModelInfo
    private val frames = mutableListOf<Bitmap>()   // one preview per step, then the final image
    private val handler = Handler(Looper.getMainLooper())
    private var playing: Runnable? = null

    private val prefs by lazy { getSharedPreferences("nitido", MODE_PRIVATE) }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadBase(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGenerateBinding.inflate(layoutInflater)
        setContentView(b.root)

        val saved = prefs.getString("model", null)
        model = SdModel.byId(saved ?: if (SdModel.isReady(this, "sd15")) "sd15" else null)

        b.back.setOnClickListener { finish() }
        b.modelPick.setOnClickListener { chooseModel() }
        b.download.setOnClickListener { if (job?.isActive == true) cancel = true else download() }
        b.generate.setOnClickListener { if (job?.isActive != true) generate() }
        b.save.setOnClickListener { save() }
        b.upscale.setOnClickListener {
            val f = lastImage ?: return@setOnClickListener
            startActivity(Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_PATH, f.absolutePath)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        b.useResult.setOnClickListener {
            val f = lastImage ?: return@setOnClickListener
            BitmapFactory.decodeFile(f.absolutePath)?.let { setBase(it) }
        }
        b.pickBase.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        b.clearBase.setOnClickListener { setBase(null) }
        b.deleteModel.setOnClickListener {
            if (job?.isActive == true) return@setOnClickListener
            if (SdNative.loadError == null) SdNative.release()
            SdModel.delete(this, model.id)
            refreshModel()
        }

        bindSlider(b.steps, b.stepsValue) { it.roundToInt().toString() }
        bindSlider(b.strength, b.strengthValue) { "${it.roundToInt()}%" }
        bindSlider(b.guidance, b.guidanceValue) { String.format(Locale.US, "%.1f", it) }
        bindSlider(b.keep, b.keepValue) { String.format(Locale.US, "%.1f", it) }

        b.playTimelapse.setOnClickListener { if (playing != null) stopPlayback() else playTimelapse() }
        b.saveTimelapse.setOnClickListener { saveTimelapse() }

        b.save.isEnabled = false
        b.upscale.isEnabled = false
        b.useResult.isEnabled = false
        b.playTimelapse.isEnabled = false
        b.saveTimelapse.isEnabled = false
        refreshModel()
    }

    // ---------- timelapse ----------

    private fun playTimelapse() {
        if (frames.isEmpty()) return
        b.playTimelapse.text = getString(R.string.sd_stop_play)
        var i = 0
        val r = object : Runnable {
            override fun run() {
                b.result.setImageBitmap(frames[i])
                i++
                if (i < frames.size) handler.postDelayed(this, 160) else stopPlayback()
            }
        }
        playing = r
        handler.post(r)
    }

    private fun stopPlayback() {
        playing?.let { handler.removeCallbacks(it) }
        playing = null
        b.playTimelapse.text = getString(R.string.sd_play)
        frames.lastOrNull()?.let { b.result.setImageBitmap(it) }
    }

    private fun saveTimelapse() {
        if (frames.size < 2) return
        val list = frames.toList()
        b.saveTimelapse.isEnabled = false
        b.genStatus.text = getString(R.string.sd_making_video)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val tmp = File(cacheDir, "timelapse_${System.currentTimeMillis()}.mp4")
                    TimelapseVideo.writeMp4(list, tmp)
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "nitido_timelapse_${System.currentTimeMillis() / 1000}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Nitido")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { out -> tmp.inputStream().use { it.copyTo(out) } }
                    values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    tmp.delete()
                    true
                } catch (t: Throwable) { false }
            }
            b.saveTimelapse.isEnabled = true
            b.genStatus.text = getString(if (ok) R.string.sd_video_saved else R.string.sd_video_error)
        }
    }

    private fun bindSlider(s: Slider, label: TextView, fmt: (Float) -> String) {
        label.text = fmt(s.value)
        s.addOnChangeListener { _, v, _ -> label.text = fmt(v) }
    }

    // ---------- models ----------

    private fun chooseModel() {
        if (job?.isActive == true) return
        val items = SdModel.ALL.map {
            val state = if (SdModel.isReady(this, it.id)) getString(R.string.sd_downloaded) else getString(R.string.sd_size, it.approxMb)
            "${it.name}\n${it.description} · $state"
        }.toTypedArray<CharSequence>()
        val current = SdModel.ALL.indexOfFirst { it.id == model.id }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.sd_model)
            .setSingleChoiceItems(items, current) { d, which ->
                model = SdModel.ALL[which]
                prefs.edit().putString("model", model.id).apply()
                d.dismiss()
                refreshModel()
            }
            .show()
    }

    private fun refreshModel() {
        val ready = SdModel.isReady(this, model.id)
        b.modelPick.text = getString(R.string.sd_model_button, model.name)
        b.modelDesc.text = model.description
        b.setupCard.visibility = if (ready) View.GONE else View.VISIBLE
        b.createPanel.visibility = if (ready) View.VISIBLE else View.GONE
        b.deleteModel.visibility = if (ready) View.VISIBLE else View.GONE
        b.deleteModel.text = getString(R.string.sd_delete_model, model.name)
        if (!ready) {
            b.setupTitle.text = getString(R.string.sd_setup_title, model.name)
            b.dlStatus.text = getString(R.string.sd_dl_intro, model.approxMb)
        }
        val editor = model.mode == 1
        b.promptLayout.hint = getString(if (editor) R.string.sd_instruction_hint else R.string.sd_prompt_hint)
        b.negativeLayout.visibility = if (editor) View.GONE else View.VISIBLE
        updatePhotoUi()
    }

    private fun download() {
        cancel = false
        val m = model
        b.download.text = getString(R.string.stop)
        b.dlProgress.visibility = View.VISIBLE
        b.modelPick.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        job = lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    SdModel.download(this@GenerateActivity, m.id, { cancel }) { done, total ->
                        runOnUiThread {
                            val p = if (total > 0) done.toFloat() / total else 0f
                            b.dlProgress.progress = (p * 1000).roundToInt()
                            b.dlStatus.text = getString(R.string.sd_dl_progress, done / 1_000_000, total / 1_000_000)
                        }
                    }
                    null
                } catch (e: InterruptedException) {
                    getString(R.string.sd_dl_paused)
                } catch (t: Throwable) {
                    getString(R.string.sd_dl_error, t.message ?: t.javaClass.simpleName)
                }
            }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.download.text = getString(R.string.sd_download)
            b.dlProgress.visibility = View.INVISIBLE
            b.modelPick.isEnabled = true
            if (err != null) b.dlStatus.text = err else refreshModel()
        }
    }

    // ---------- photo ----------

    /** Center-crop and scale a photo to the 512×512 the model works at. */
    private fun loadBase(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = maxOf(info.size.width, info.size.height)
                        if (long > 2048) {
                            val k = 2048f / long
                            dec.setTargetSize((info.size.width * k).roundToInt(), (info.size.height * k).roundToInt())
                        }
                    }
                    val side = minOf(src.width, src.height)
                    val crop = Rect((src.width - side) / 2, (src.height - side) / 2, (src.width + side) / 2, (src.height + side) / 2)
                    val out = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
                    Canvas(out).drawBitmap(src, crop, Rect(0, 0, 512, 512), Paint(Paint.FILTER_BITMAP_FLAG))
                    out
                } catch (t: Throwable) { null }
            }
            if (bmp == null) b.genStatus.text = getString(R.string.err_open) else setBase(bmp)
        }
    }

    private fun setBase(bmp: Bitmap?) {
        base = bmp
        b.baseThumb.setImageBitmap(bmp)
        if (bmp != null) b.result.setImageBitmap(bmp)
        updatePhotoUi()
    }

    private fun updatePhotoUi() {
        val has = base != null
        val editor = model.mode == 1
        b.baseThumb.visibility = if (has) View.VISIBLE else View.GONE
        b.clearBase.visibility = if (has) View.VISIBLE else View.GONE
        b.pickBase.text = getString(
            when {
                has -> R.string.sd_change_base
                editor -> R.string.sd_pick_base_required
                else -> R.string.sd_pick_base
            })
        b.strengthRow.visibility = if (has && !editor) View.VISIBLE else View.GONE
        b.keepRow.visibility = if (editor) View.VISIBLE else View.GONE
        b.photoHint.visibility = if (has || editor) View.VISIBLE else View.GONE
        b.photoHint.text = getString(if (editor) R.string.sd_keep_hint else R.string.sd_strength_hint)
        b.promptLayout.helperText = getString(
            when {
                editor -> R.string.sd_instruction_help
                has -> R.string.sd_edit_prompt_help
                else -> R.string.sd_prompt_help
            })
    }

    /** Channel-first RGB floats in [-1, 1], as the VAE encoder expects. */
    private fun toModelInput(bmp: Bitmap): FloatArray {
        val n = 512 * 512
        val px = IntArray(n)
        bmp.getPixels(px, 0, 512, 0, 0, 512, 512)
        val f = FloatArray(3 * n)
        for (i in 0 until n) {
            val p = px[i]
            f[i] = ((p shr 16) and 0xFF) / 127.5f - 1f
            f[n + i] = ((p shr 8) and 0xFF) / 127.5f - 1f
            f[2 * n + i] = (p and 0xFF) / 127.5f - 1f
        }
        return f
    }

    // ---------- generate ----------

    private fun generate() {
        val m = model
        val prompt = b.prompt.text?.toString()?.trim().orEmpty()
        if (prompt.isEmpty()) { b.genStatus.text = getString(R.string.sd_need_prompt); return }
        if (m.mode == 1 && base == null) { b.genStatus.text = getString(R.string.sd_need_photo); return }
        SdNative.loadError?.let { b.genStatus.text = getString(R.string.sd_failed, it.toString()); return }

        val negative = if (m.mode == 1) "" else b.negative.text?.toString()?.trim().orEmpty()
        val steps = b.steps.value.roundToInt()
        val gpu = b.backendGroup.checkedButtonId != R.id.sdCpu
        val seed = Random.nextInt(1, Int.MAX_VALUE)
        val out = File(cacheDir, "sd_${System.currentTimeMillis()}.jpg")
        val input = base?.let { toModelInput(it) }
        val strength = b.strength.value / 100f
        val guidance = b.guidance.value
        val keep = b.keep.value
        val previewMode = if (b.hqTimelapse.isChecked) SdNative.PREVIEW_FULL else SdNative.PREVIEW_FAST
        stopPlayback()
        frames.clear()
        base?.let { frames.add(it) }
        b.playTimelapse.isEnabled = false
        b.saveTimelapse.isEnabled = false

        b.generate.isEnabled = false
        b.modelPick.isEnabled = false
        b.save.isEnabled = false
        b.upscale.isEnabled = false
        b.useResult.isEnabled = false
        b.genProgress.progress = 0
        b.genProgress.visibility = View.VISIBLE
        b.genStatus.text = getString(R.string.sd_loading)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val t0 = SystemClock.elapsedRealtime()

        job = lifecycleScope.launch {
            val code = withContext(Dispatchers.Default) {
                try {
                    SdModel.ensureEncoder(this@GenerateActivity, m.id)
                    SdNative.generate(
                        SdModel.dir(this@GenerateActivity, m.id).absolutePath,
                        cacheDir.absolutePath,
                        if (gpu) SdNative.BACKEND_OPENCL else SdNative.BACKEND_CPU,
                        m.mode, steps, seed, out.absolutePath, prompt, negative,
                        input, strength, guidance, keep, previewMode,
                        object : SdNative.Listener {
                            override fun onProgress(pct: Int) {
                                val el = (SystemClock.elapsedRealtime() - t0) / 1000
                                runOnUiThread {
                                    b.genProgress.progress = pct * 10
                                    b.genStatus.text = getString(R.string.sd_progress, pct, el)
                                }
                            }

                            override fun onPreview(rgb: ByteArray, size: Int) {
                                val bmp = TimelapseVideo.toBitmap(rgb, size)
                                runOnUiThread {
                                    frames.add(bmp)
                                    b.result.setImageBitmap(bmp)
                                }
                            }
                        }
                    )
                } catch (t: Throwable) {
                    -1
                }
            }
            val ok = code == 0 && out.exists() && out.length() > 0
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.generate.isEnabled = true
            b.modelPick.isEnabled = true
            b.genProgress.visibility = View.INVISIBLE
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            if (ok) {
                b.result.setImageBitmap(BitmapFactory.decodeFile(out.absolutePath))
                lastImage = out
                b.save.isEnabled = true
                b.upscale.isEnabled = true
                b.useResult.isEnabled = true
                b.playTimelapse.isEnabled = frames.size > 1
                b.saveTimelapse.isEnabled = frames.size > 1
                b.genStatus.text = getString(R.string.sd_done, secs, if (gpu) "GPU" else "CPU", seed)
            } else {
                val why = when (code) {
                    2 -> getString(R.string.sd_err_load)
                    3 -> getString(R.string.sd_err_run)
                    4 -> getString(R.string.sd_no_encoder)
                    else -> getString(R.string.sd_err_internal, code)
                }
                b.genStatus.text = getString(R.string.sd_failed, why)
            }
        }
    }

    private fun save() {
        val f = lastImage ?: return
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return@withContext false
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "nitido_ia_${System.currentTimeMillis() / 1000}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    true
                } catch (t: Throwable) { false }
            }
            b.genStatus.text = getString(if (ok) R.string.saved else R.string.err_save)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPlayback()
        cancel = true
    }
}
