package com.nitido.app

import android.content.ContentValues
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.widget.LinearLayout
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.nitido.app.databinding.ActivityGenerateBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

class GenerateActivity : AppCompatActivity() {

    private lateinit var b: ActivityGenerateBinding
    private lateinit var proc: ProcessScreen
    private var job: Job? = null
    @Volatile private var cancel = false
    private var lastImage: File? = null
    private var base: Bitmap? = null   // photo to start from (any shape), if any
    /** [base] is a picture invented by Crear (in the registry of AI pictures); false = a real photo. */
    private var baseAi = false
    /** The last result is an AI picture (made from text only, or an edit of one). */
    private var lastAi = false
    private lateinit var model: SdModelInfo
    private val frames = mutableListOf<Bitmap>()   // one preview per step, then the final image
    private val handler = Handler(Looper.getMainLooper())
    private var playing: Runnable? = null

    private val prefs by lazy { getSharedPreferences("nitido", MODE_PRIVATE) }

    private var zoneMask: Bitmap? = null   // painted area to redraw (same size as base), if any

    private val maskLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            zoneMask = MaskHolder.mask
            updatePhotoUi()
            base?.let { showZonePreview(it) }
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadBase(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGenerateBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.setAdvanced(this, false)   // every screen opens simple, with Mis preferencias
        // the picture across the whole width at its own shape; the order right under it (not over it)
        b.root.post {
            val stage = b.result.parent as android.view.ViewGroup
            (b.promptLayout.parent as? android.view.ViewGroup)?.let { pl ->
                if (pl === stage) {
                    stage.removeView(b.promptLayout)
                    b.createPanel.addView(b.promptLayout, b.createPanel.indexOfChild(stage) + 1,
                        LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@GenerateActivity, 8) })
                }
            }
            val pin = (b.generate.parent as? View)?.takeIf { it.parent === b.createPanel }
            Stage.arrange(b.createPanel, stage, listOfNotNull(pin)) { b.result.drawable?.let { it.intrinsicWidth to it.intrinsicHeight } }
        }
        // while the keyboard is open, the controls under the picture step aside: the picture and the text
        // being typed keep the free space (they were squeezed to a thin strip and the text was hidden)
        b.root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect(); b.root.getWindowVisibleDisplayFrame(r)
            val full = b.root.rootView.height
            val open = full - r.bottom > full * 0.15f
            if (open != keyboardOpen) { keyboardOpen = open; onKeyboard(open) }
        }
        proc = ProcessScreen(this) { stopWork() }

        val saved = prefs.getString("model", null)
        model = SdModel.byId(this, saved ?: if (SdModel.isReady(this, "sd15")) "sd15" else null)

        // GPU test options (remembered)
        b.gpuTuneGroup.check(if (prefs.getInt("gpu_tune", 0) == 1) R.id.tuneWide else R.id.tuneFast)
        b.gpuMemGroup.check(if (prefs.getInt("gpu_mem", 0) == 1) R.id.memNormal else R.id.memLow)
        b.gpuTuneGroup.addOnButtonCheckedListener { _, id, on -> if (on) prefs.edit().putInt("gpu_tune", if (id == R.id.tuneWide) 1 else 0).apply() }
        b.gpuMemGroup.addOnButtonCheckedListener { _, id, on -> if (on) prefs.edit().putInt("gpu_mem", if (id == R.id.memNormal) 1 else 0).apply() }

        b.back.setOnClickListener { finish() }
        b.modelPick.setOnClickListener { chooseModel() }
        b.download.setOnClickListener { if (job?.isActive == true) cancel = true else download() }
        b.generate.setOnClickListener { if (job?.isActive == true) stopWork() else generate() }
        b.save.setOnClickListener { save() }
        b.upscale.setOnClickListener {
            val f = lastImage ?: return@setOnClickListener
            startActivity(Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_PATH, f.absolutePath)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        b.useResult.setOnClickListener {
            val f = lastImage ?: return@setOnClickListener
            BitmapFactory.decodeFile(f.absolutePath)?.let { setBase(it, lastAi) }
        }
        b.pickBase.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        b.clearBase.setOnClickListener { setBase(null) }
        b.paintZone.setOnClickListener {
            val photo = base ?: return@setOnClickListener
            MaskHolder.photo = photo
            MaskHolder.mask = zoneMask
            maskLauncher.launch(Intent(this, MaskActivity::class.java))
        }
        b.clearZone.setOnClickListener { zoneMask = null; updatePhotoUi(); base?.let { b.result.setImageBitmap(it) } }
        b.deleteModel.setOnClickListener {
            if (job?.isActive == true) return@setOnClickListener
            if (SdNative.loadError == null) SdNative.release()
            SdModel.delete(this, model.id)
            if (SdModel.customIds(this).contains(model.id)) {
                SdModel.removeCustom(this, model.id)
                model = SdModel.ALL.first()
                prefs.edit().putString("model", model.id).apply()
            }
            refreshModel()
        }

        bindSlider(b.steps, b.stepsValue) { it.roundToInt().toString() }
        b.steps.addOnChangeListener { _, v, fromUser ->
            if (fromUser && v > 50) b.genStatus.text = getString(R.string.sd_steps_note)
        }
        bindSlider(b.strength, b.strengthValue) { "${it.roundToInt()}%" }
        bindSlider(b.guidance, b.guidanceValue) { String.format(Locale.US, "%.1f", it) }
        bindSlider(b.keep, b.keepValue) { String.format(Locale.US, "%.1f", it) }

        b.refine.setOnClickListener { if (job?.isActive == true) stopWork() else refine() }
        b.refine.isEnabled = false
        b.playTimelapse.setOnClickListener { if (playing != null) stopPlayback() else playTimelapse() }
        b.saveTimelapse.setOnClickListener { saveTimelapse() }

        b.save.isEnabled = false
        b.upscale.isEnabled = false
        b.useResult.isEnabled = false
        b.playTimelapse.isEnabled = false
        b.saveTimelapse.isEnabled = false
        refreshModel()

        // show the last result again if this screen was closed while working in the background
        prefs.getString("last_result", null)?.let { File(it) }?.takeIf { it.exists() }?.let { f ->
            lastImage = f
            lastAi = prefs.getBoolean("last_result_ai", false)
            resultBmp = BitmapFactory.decodeFile(f.absolutePath)
            b.result.setImageBitmap(resultBmp)
            showOrigin(lastAi)
            b.save.isEnabled = true; b.upscale.isEnabled = true; b.useResult.isEnabled = true; b.refine.isEnabled = true
            if (!BgWork.busy) prefs.getString("last_status", null)?.let { b.genStatus.text = it }
        }
        b.backendGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked || restoringBackend || !::model.isInitialized) return@addOnButtonCheckedListener
            val v = when (id) { R.id.sdNpu -> "npu"; R.id.sdCpu -> "cpu"; else -> "gpu" }
            prefs.edit().putString("backend_${model.id}", v).apply()
        }
        setupOptions()
        LogDialog.addTo(this, opts)
        (b.result.parent as? android.widget.FrameLayout)?.let { f ->
            FullscreenActivity.addButton(this, f) { null to (b.result.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap }
        }
        askBackgroundPermissions()
        CrashReport.showIfNeeded(this)
        tool = intent.getStringExtra(EXTRA_MODE) ?: prefs.getString("tool", MODE_CREATE) ?: MODE_CREATE
        buildSimple()
        applyMode()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val m = intent.getStringExtra(EXTRA_MODE) ?: return
        // while a picture is being made the screen stays on its tool
        if (m != tool && job?.isActive != true) { tool = m; applyMode() }
    }

    // ---------- the chosen options, as labels under the picture ----------

    private lateinit var opts: OptionBar
    private var restoringBackend = false
    private val optTick = Handler(Looper.getMainLooper())

    private fun setupOptions() {
        opts = OptionBar(this, b.optLabels, b.optPanel)
        opts.onOpenChanged = { open -> b.promptLayout.visibility = if (open) View.GONE else View.VISIBLE }
        val holder = b.optHolder
        val samplerLabel = holder.getChildAt(holder.indexOfChild(b.samplerGroup) - 1)
        opts.add(getString(R.string.sd_model), { model.name }, shown = { true }, tap = { b.modelPick.performClick() })
        opts.add(getString(R.string.sd_label_photo), {
            when {
                base == null -> getString(R.string.opt_no_photo)
                zoneMask != null -> getString(R.string.opt_zone)
                else -> getString(R.string.opt_photo)
            }
        }, listOf(b.baseThumb.parent as View, b.zoneRow, b.strengthRow, b.keepRow, b.photoHint), on = { base != null }, shown = { true }, closeOnPick = false)
        opts.add(getString(R.string.sd_label_format), {
            getString(when (b.formatGroup.checkedButtonId) {
                R.id.fmtPortrait -> R.string.opt_portrait
                R.id.fmtLandscape -> R.string.opt_landscape
                else -> R.string.opt_square
            }) + if (b.bigSize.isChecked && b.bigSize.visibility == View.VISIBLE) " · " + getString(R.string.opt_big) else ""
        }, listOf(b.formatRow, b.formatNote, b.bigSize))
        opts.add(getString(R.string.sd_label_backend), {
            when (b.backendGroup.checkedButtonId) { R.id.sdNpu -> "⚡ NPU"; R.id.sdCpu -> "CPU"; else -> "GPU" }
        }, listOf(b.backendGroup))
        opts.add(getString(R.string.sd_steps), { getString(R.string.opt_steps, b.steps.value.roundToInt()) }, listOf(b.steps.parent as View))
        opts.add(getString(R.string.sd_guidance), { getString(R.string.opt_guidance, String.format(Locale.US, "%.1f", b.guidance.value)) },
            listOf(b.guidance.parent as View))
        opts.add(getString(R.string.opt_more_title), { getString(R.string.opt_more) },
            listOf(b.negativeLayout, b.weightsTip, samplerLabel, b.samplerGroup, b.hqTimelapse, b.playTimelapse.parent as View,
                b.useResult, b.gpuTestTitle, b.gpuTuneGroup, b.gpuMemGroup, b.deleteModel), on = { false }, shown = { true }, closeOnPick = false)
    }

    override fun onResume() {
        super.onResume()
        if (::simpleBox.isInitialized && (simple != !Prefs.advanced(this)) && job?.isActive != true) applyMode()
        // options also change from code (model picked, photo chosen…): keep the labels in step
        optTick.removeCallbacksAndMessages(null)
        val r = object : Runnable { override fun run() { if (::opts.isInitialized) opts.refresh(); optTick.postDelayed(this, 1000) } }
        optTick.post(r)
    }

    override fun onPause() {
        super.onPause()
        optTick.removeCallbacksAndMessages(null)
    }

    /** Out of sight and idle: give back the NPU and GPU memory so Android doesn't close the app. */
    override fun onStop() {
        super.onStop()
        if (job?.isActive != true && !BgWork.busy) {
            NpuUnet.releaseAll()
            try { if (SdNative.loadError == null) SdNative.release() } catch (_: Throwable) { }
            shrinkFrames()
        }
    }

    /**
     * The timelapse keeps one picture per step (an SDXL picture is 4 MB each): out of sight they're
     * kept at most 640 px (the last one, on screen and saved, stays whole), so HyperOS is less likely
     * to close Nítido in the background to free memory.
     */
    private fun shrinkFrames() {
        var freed = 0L
        for (i in 0 until frames.size - 1) {
            val f = frames[i]
            val k = 640f / maxOf(f.width, f.height)
            if (k >= 1f) continue
            val small = Bitmap.createScaledBitmap(f, (f.width * k).toInt().coerceAtLeast(1), (f.height * k).toInt().coerceAtLeast(1), true)
            freed += f.byteCount - small.byteCount
            frames[i] = small   // (not recycled: the photo it started from may still be in use)
        }
        if (freed > 0) JobLog.add("En segundo plano: timelapse reducido (${freed / 1_000_000} MB liberados)")
    }

    // ---------- background ----------

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    /** Notification permission (Android 13+) and, once, a tip about Xiaomi's battery saver. */
    private fun askBackgroundPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (!prefs.getBoolean("bg_tip_shown", false)) {
            prefs.edit().putBoolean("bg_tip_shown", true).apply()
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.bg_tip_title)
                .setMessage(R.string.bg_tip_body)
                .setPositiveButton(R.string.bg_tip_open) { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    } catch (_: Throwable) { }
                }
                .setNegativeButton(R.string.bg_tip_later, null)
                .show()
        }
    }

    private fun stopWork() {
        cancel = true
        if (SdNative.loadError == null) SdNative.cancel()
        b.genStatus.text = getString(R.string.stopping)
    }

    private fun startBg(titleRes: Int) {
        BgWork.start(this, getString(titleRes), GenerateActivity::class.java) {
            cancel = true
            if (SdNative.loadError == null) SdNative.cancel()
        }
    }

    // ---------- size ----------

    /** Output size for a new picture: square, or 512×768 / 768×512 on models that allow it. */
    private fun chosenSize(dynamic: Boolean, sdxl: Boolean): Pair<Int, Int> = when {
        !dynamic -> 512 to 512
        sdxl -> when (b.formatGroup.checkedButtonId) {
            R.id.fmtPortrait -> 896 to 1152
            R.id.fmtLandscape -> 1152 to 896
            else -> 1024 to 1024
        }
        b.bigSize.isChecked -> when (b.formatGroup.checkedButtonId) {
            // SD 1.5 "large": ~1.5–2× the pixels; fine-tuned models handle it well
            R.id.fmtPortrait -> 640 to 960
            R.id.fmtLandscape -> 960 to 640
            else -> 768 to 768
        }
        else -> when (b.formatGroup.checkedButtonId) {
            R.id.fmtPortrait -> 512 to 768
            R.id.fmtLandscape -> 768 to 512
            else -> 512 to 512
        }
    }

    /** Size that matches a photo's shape: sides multiples of 64, long side up to 768. */
    private fun sizeForPhoto(w: Int, h: Int, sdxl: Boolean): Pair<Int, Int> {
        val ratio = w.toFloat() / h
        val big = !sdxl && b.bigSize.isChecked
        val sq = if (sdxl) 1024 else if (big) 768 else 512
        val long = if (sdxl) 1024 else if (big) 960 else 768   // SDXL: keep photo edits at most 1024 px for memory
        val minSide = if (sdxl) 768 else 384
        if (ratio in 0.85f..1.18f) return sq to sq
        return if (ratio > 1f) long to ((long / ratio / 64f).roundToInt() * 64).coerceIn(minSide, long)
        else ((long * ratio / 64f).roundToInt() * 64).coerceIn(minSide, long) to long
    }

    /**
     * The instruction editor was trained at 512 px: larger sizes are slower and it starts repeating
     * bodies and objects. Longest side 512, the photo's shape kept (sides in steps of 64).
     */
    private fun editorSize(w: Int, h: Int): Pair<Int, Int> {
        val ratio = w.toFloat() / h
        if (ratio in 0.85f..1.18f) return 512 to 512
        return if (ratio > 1f) 512 to ((512 / ratio / 64f).roundToInt() * 64).coerceIn(320, 512)
        else ((512 * ratio / 64f).roundToInt() * 64).coerceIn(320, 512) to 512
    }

    // ---------- timelapse ----------

    private fun playTimelapse() {
        if (frames.isEmpty()) return
        b.playTimelapse.text = getString(R.string.sd_stop_play)
        var i = 0
        val r = object : Runnable {
            override fun run() {
                b.result.setImageBitmap(frames[i])
                i++
                if (i < frames.size) handler.postDelayed(this, 160) else stopPlayback()
            }
        }
        playing = r
        handler.post(r)
    }

    private fun stopPlayback() {
        playing?.let { handler.removeCallbacks(it) }
        playing = null
        b.playTimelapse.text = getString(R.string.sd_play)
        frames.lastOrNull()?.let { b.result.setImageBitmap(it) }
    }

    private fun saveTimelapse() {
        if (frames.size < 2) return
        val list = frames.toList()
        b.saveTimelapse.isEnabled = false
        b.genStatus.text = getString(R.string.sd_making_video)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val tmp = File(cacheDir, "timelapse_${System.currentTimeMillis()}.mp4")
                    TimelapseVideo.writeMp4(list, tmp)
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "nitido_timelapse_${System.currentTimeMillis() / 1000}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Nitido")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { out -> tmp.inputStream().use { it.copyTo(out) } }
                    values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    tmp.delete()
                    true
                } catch (t: Throwable) { false }
            }
            b.saveTimelapse.isEnabled = true
            b.genStatus.text = getString(if (ok) R.string.sd_video_saved else R.string.sd_video_error)
        }
    }

    private fun bindSlider(s: Slider, label: TextView, fmt: (Float) -> String) {
        label.text = fmt(s.value)
        s.addOnChangeListener { _, v, _ -> label.text = fmt(v) }
    }


    // ---------- the simple screens: Crear imagen / Editar con palabras ----------

    /** MODE_CREATE or MODE_EDIT (Inicio's two tools on this screen). */
    private var tool = MODE_CREATE
    private var simple = true
    private lateinit var simpleBox: android.widget.LinearLayout
    private var keyboardOpen = false
    private val hiddenForKeyboard = mutableListOf<View>()

    /** Typing the order or «Cómo debe verse» in Editar (simple screen). */
    private fun lookTyping(): Boolean {
        if (!simple || tool != MODE_EDIT || !::lookInput.isInitialized) return false
        val f = currentFocus
        return f === lookInput || f === b.prompt || b.promptLayout.hasFocus()
    }

    private fun onKeyboard(open: Boolean) {
        if (open && lookTyping()) {
            // rule 4: the picture first, then both boxes: the order (over the picture's bottom) and
            // «Cómo debe verse» right under it; the rest folds away until the keyboard closes
            val list = mutableListOf<View>(b.optPanel, b.optLabels, b.genStatus)
            if (::simpleBox.isInitialized) list += listOf(simpleBox, simpleSub, backSimple)
            for (v in list) if (v.visibility == View.VISIBLE) { v.visibility = View.GONE; hiddenForKeyboard += v }
            showLook(lookWanted)
            return
        }
        if (!open && ::lookInput.isInitialized) {
            for (v in hiddenForKeyboard) v.visibility = View.VISIBLE
            hiddenForKeyboard.clear()
            // what was typed in «Cómo debe verse» keeps it open
            showLook(lookWanted || !lookInput.text.isNullOrBlank())
            return
        }
        if (open) {
            // only while typing the order itself are the controls under it hidden; in any other box
            // («Cómo debe verse», Qué evitar…) everything stays and the box is scrolled into view
            val f = currentFocus
            if (f == null || (f !== b.prompt && f.parent?.parent !== b.promptLayout && !b.promptLayout.hasFocus())) {
                f?.post { f.requestRectangleOnScreen(android.graphics.Rect(0, 0, f.width, f.height), false) }
                return
            }
            (b.promptLayout.parent?.parent as? android.widget.ScrollView)?.post { (b.promptLayout.parent?.parent as? android.widget.ScrollView)?.smoothScrollTo(0, 0) }
            val list = mutableListOf<View>(b.optPanel, b.optLabels)
            if (::simpleBox.isInitialized) list += listOf(simpleBox, simpleSub, backSimple)
            for (v in list) if (v.visibility == View.VISIBLE) { v.visibility = View.GONE; hiddenForKeyboard += v }
        } else {
            for (v in hiddenForKeyboard) v.visibility = View.VISIBLE
            hiddenForKeyboard.clear()
        }
    }
    private lateinit var createChips: android.widget.LinearLayout
    private lateinit var editChips: android.widget.LinearLayout
    private lateinit var formatChips: com.google.android.material.chip.ChipGroup
    private lateinit var simpleSub: TextView
    private var modelLine: TextView? = null

    /** "Modelo: X (automático) · Cambiar" under the chips of Crear / Editar. */
    private var negLine: TextView? = null

    private fun updateNegLine() {
        val l = negLine ?: return
        val txt = getString(R.string.neg_line, getString(if (Negative.isFactory(this, tool)) R.string.neg_factory else R.string.neg_custom))
        l.text = android.text.SpannableStringBuilder(txt).apply {
            append("  ")
            val st = length; append(getString(R.string.simple_model_change))
            setSpan(android.text.style.ForegroundColorSpan(getColor(R.color.accent)), st, length, 0)
        }
    }

    /** The sheet to edit «Qué evitar»: the list, quick additions, Restablecer and Listo. */
    private fun showNegativeSheet() {
        val dp = resources.displayMetrics.density
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val field = android.widget.EditText(this).apply {
            setText(Negative.text(this@GenerateActivity, tool))
            textSize = 14f; setTextColor(getColor(R.color.fg)); minLines = 3; maxLines = 7
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = Ui.round(this@GenerateActivity, getColor(R.color.stage_hi), 10, getColor(R.color.accent))
            setPadding((10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt())
        }
        val quick = Ui.chipRow(this)
        fun fillQuick() {
            quick.removeAllViews()
            val have = Negative.items(field.text.toString().lowercase()).toSet()
            for (q in Negative.QUICK) if (q !in have) quick.addView(Ui.chip(this, "+ $q") {
                val cur = field.text.toString().trim().trimEnd(',')
                field.setText(if (cur.isEmpty()) q else "$cur, $q"); field.setSelection(field.text.length)
                fillQuick()
            })
        }
        fillQuick()
        val sheet = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
            addView(Ui.text(this@GenerateActivity, getString(R.string.neg_title), 17f, R.color.fg, bold = true))
            addView(Ui.text(this@GenerateActivity, getString(R.string.neg_sub), 12f, R.color.muted), Ui.lp(this@GenerateActivity, 2))
            if (tool == MODE_EDIT && ::model.isInitialized && model.mode == 1)
                addView(Ui.text(this@GenerateActivity, getString(R.string.neg_sub_editor), 12f, R.color.after), Ui.lp(this@GenerateActivity, 4))
            addView(field, Ui.lp(this@GenerateActivity, 10))
            addView(quick, Ui.lp(this@GenerateActivity, 8))
            val row = Ui.row(this@GenerateActivity)
            row.addView(Ui.text(this@GenerateActivity, "↺  " + getString(R.string.neg_reset), 14f, R.color.accent).apply {
                setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
                setOnClickListener { field.setText(Negative.factory(this@GenerateActivity)); fillQuick() }
            }, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(com.google.android.material.button.MaterialButton(this@GenerateActivity).apply {
                text = getString(R.string.neg_done); isAllCaps = false; cornerRadius = (20 * dp).toInt()
                backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cta))
                setTextColor(getColor(R.color.on_cta))
                setOnClickListener { dialog.dismiss() }
            })
            addView(row, Ui.lp(this@GenerateActivity, 10))
        }
        dialog.setOnDismissListener {
            val before = Negative.text(this, tool)
            Negative.save(this, tool, field.text.toString())
            if (before != Negative.text(this, tool)) JobLog.add("Qué evitar (${if (tool == MODE_EDIT) "Editar" else "Crear"}): «${Negative.text(this, tool)}»")
            updateNegLine()
        }
        dialog.setContentView(sheet)
        dialog.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    private fun updateModelLine() {
        updateNegLine()
        val l = modelLine ?: return
        if (!::model.isInitialized) return
        val auto = prefs.getString("model_$tool", null) == null
        val txt = getString(R.string.simple_model_line, model.name, getString(if (auto) R.string.simple_model_auto else R.string.simple_model_mine))
        val change = getString(R.string.simple_model_change)
        l.text = android.text.SpannableStringBuilder(txt).apply {
            append("  ")
            val st = length; append(change)
            setSpan(android.text.style.ForegroundColorSpan(getColor(R.color.accent)), st, length, 0)
        }
    }
    private lateinit var finishRow: android.widget.LinearLayout
    private lateinit var adjustPanel: AdjustPanel
    private val styleViews = mutableListOf<TextView>()
    private val formatViews = mutableListOf<Pair<TextView, Int>>()
    /** The last picture as it came out, its retoques and where it was saved by itself. */
    private var resultBmp: Bitmap? = null
    private var adjust = PhotoAdjust.Values()
    private var savedUri: Uri? = null
    private var adjustJob: Job? = null
    private lateinit var backSimple: TextView

    /** In Modo avanzado: a link back to the simple screen (the switch is also in Ajustes). */
    private fun simpleLink(onBack: () -> Unit) = Ui.text(this, getString(R.string.back_to_simple), 14f, R.color.accent).apply {
        gravity = android.view.Gravity.CENTER
        setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8))
        setOnClickListener { Prefs.setAdvanced(context, false); JobLog.add("Volver a lo sencillo"); onBack() }
    }

    /** Crear's styles: label, words added to the description, models that suit it (best first). */
    private class Style(val label: Int, val words: String, val models: List<String>)
    private val styles = listOf(
        Style(R.string.style_photo, "photo, realistic, natural light, highly detailed, 35mm", listOf("realvis", "juggernaut", "sdxl", "dreamshaper")),
        Style(R.string.style_illustration, "illustration, digital art, vibrant colors, clean lines", listOf("anime", "dreamshaper")),
        Style(R.string.style_portrait, "portrait photo, realistic, soft light, sharp focus, detailed skin", listOf("realvis", "juggernaut", "sdxl", "dreamshaper")),
        Style(R.string.style_landscape, "landscape photo, wide angle, golden hour, highly detailed", listOf("realvis", "juggernaut", "sdxl", "dreamshaper")),
    )
    private var style = 0

    /** Editar's ideas: label, the instruction in English (what the editor model understands). */
    private val ideas = listOf(
        R.string.idea_white_bg to "make the background plain white",
        R.string.idea_blue_sky to "make the sky clear blue",
        R.string.idea_night to "make it night time",
        R.string.idea_snow to "add snow",
        R.string.idea_painting to "make it look like an oil painting",
        R.string.idea_red_dress to "make the dress red",
    )
    private var ideaEnglish: String? = null
    private lateinit var dreamLine: TextView

    private fun offerDream() {
        Ui.askDownload(this, "DreamLite", if (DreamLite.isReady(this)) "~650 MB" else "~3.4 GB", onYes = {
            dreamLine.isEnabled = false
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        DreamLite.download(applicationContext, { isFinishing }) { done, total ->
                            val pct = if (total > 0) (done * 100 / total).toInt() else 0
                            runOnUiThread { dreamLine.text = getString(R.string.dl_downloading, pct) }
                        }
                        true
                    } catch (t: Throwable) { JobLog.error("DreamLite: descarga", t); false }
                }
                dreamLine.isEnabled = true
                if (ok && DreamLite.isReady(this@GenerateActivity)) { dreamLine.visibility = View.GONE; b.genStatus.text = getString(R.string.dl_ready) }
                else dreamLine.text = getString(R.string.dl_offer_retry)
            }
        })
    }
    private lateinit var lookToggle: TextView
    private lateinit var lookInput: android.widget.EditText
    private lateinit var lookNote: TextView
    /** «Cómo debe verse» in English for the job being started (step 2 only); null = from the order. */
    private var lookEnglish: String? = null

    /** The person opened «Cómo debe verse» (it shows only in Editar, simple screen). */
    private var lookWanted = false

    private fun showLook(open: Boolean) {
        lookWanted = open
        val shown = (open || (keyboardOpen && lookTyping())) && simple && tool == MODE_EDIT
        lookInput.visibility = if (shown) View.VISIBLE else View.GONE
        lookNote.visibility = if (shown && !keyboardOpen) View.VISIBLE else View.GONE
        lookToggle.text = getString(if (open) R.string.edit_look_toggle_open else R.string.edit_look_toggle)
    }

    /**
     * One box with everything ("cambiar el vestido por ropa deportiva, leggings negros con textura"):
     * the first part is the order for the editor, the rest goes to «Cómo debe verse».
     */
    private fun splitOrder(typed: String): Pair<String, String?> {
        val m = Regex("""^(.{6,}?)(?:,\s*|\s+con\s+|\s+with\s+)(.{3,})$""", RegexOption.IGNORE_CASE).find(typed.trim()) ?: return typed to null
        return m.groupValues[1].trim() to m.groupValues[2].trim()
    }

    private fun buildSimple() {
        style = prefs.getInt("style", 0).coerceIn(0, styles.size - 1)
        val panel = b.createPanel
        simpleBox = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        // Crear: style and shape
        createChips = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val st = Ui.chipRow(this)
        styles.forEachIndexed { i, sty ->
            val c = Ui.chip(this, getString(sty.label), i == style) { pickStyle(i) }
            styleViews += c; st.addView(c)
        }
        createChips.addView(st)
        formatChips = Ui.chipRow(this)
        for ((label, id) in listOf(R.string.fmt_portrait to R.id.fmtPortrait, R.string.fmt_square to R.id.fmtSquare, R.string.fmt_landscape to R.id.fmtLandscape)) {
            val c = Ui.chip(this, getString(label), b.formatGroup.checkedButtonId == id) {
                b.formatGroup.check(id); syncFormat()
            }
            formatViews += c to id; formatChips.addView(c)
        }
        createChips.addView(formatChips, Ui.lp(this, 6))
        simpleBox.addView(createChips)
        // Editar: ideas and "Señalar dónde"
        editChips = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val ib = Ui.chipRow(this)
        for ((label, en) in ideas) ib.addView(Ui.chip(this, getString(label)) {
            b.prompt.setText(getString(label)); ideaEnglish = en
        })
        editChips.addView(ib)
        // DreamLite: understands the order much better; offered here until it is on the phone
        dreamLine = Ui.text(this, getString(R.string.dl_offer), 13f, R.color.accent).apply {
            setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 2))
            setOnClickListener { offerDream() }
        }
        editChips.addView(dreamLine)
        dreamLine.visibility = if (QuickActionsActivity.on(this, "nitido", "q_dreamlite") && !DreamLite.isReady(this)) View.VISIBLE else View.GONE
        if (DreamLite.isReady(this) && QuickActionsActivity.on(this, "nitido", "q_dreamlite")) lifecycleScope.launch {
            val more = withContext(Dispatchers.IO) { DreamLite.newSizes(applicationContext) }
            if (more.isNotEmpty()) {
                JobLog.add("DreamLite: hay tamaños nuevos para bajar: ${more.joinToString()}")
                dreamLine.text = getString(R.string.dl_offer_more, more.joinToString(", ") { it.replace("x", "×") })
                dreamLine.visibility = View.VISIBLE
            }
        }
        // «Cómo debe verse»: details only for step 2 (SDXL); the editor (step 1) gets the short order
        lookToggle = Ui.text(this, getString(R.string.edit_look_toggle), 14f, R.color.accent).apply {
            setPadding(0, Ui.dp(context, 10), 0, Ui.dp(context, 4))
            setOnClickListener { showLook(!lookWanted) }
        }
        editChips.addView(lookToggle)
        lookInput = android.widget.EditText(this).apply {
            hint = getString(R.string.edit_look_hint)
            setText(prefs.getString("edit_look", "") ?: "")
            textSize = 14f; setTextColor(getColor(R.color.fg)); setHintTextColor(getColor(R.color.muted))
            minLines = 2; maxLines = 4
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = Ui.round(this@GenerateActivity, getColor(R.color.stage_hi), 10, getColor(R.color.accent))
            val pd = Ui.dp(context, 10); setPadding(pd, pd, pd, pd)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b1: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b1: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: android.text.Editable?) { prefs.edit().putString("edit_look", e?.toString().orEmpty()).apply() }
            })
        }
        // rule 4: «Cómo debe verse» sits right under the picture, next to the order, so both stay in
        // view while typing (everything else folds away and the picture takes what is left)
        val frame = b.result.parent as android.view.View
        b.createPanel.addView(lookInput, b.createPanel.indexOfChild(frame) + 1,
            android.widget.LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@GenerateActivity, 6) })
        lookNote = Ui.text(this, getString(R.string.edit_look_note), 12f, R.color.muted).apply { setPadding(0, Ui.dp(context, 4), 0, 0) }
        editChips.addView(lookNote)
        showLook(!lookInput.text.isNullOrBlank())
        // «Se entiende como…»: what the order changes (from its words), corrected with a tap for this edit
        kindLine = Ui.text(this, "", 13f, R.color.muted).apply {
            setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 2))
            setOnClickListener { chooseKind() }
        }
        editChips.addView(kindLine, 0)
        freeLine = Ui.text(this, getString(R.string.origin_free_line), 12f, R.color.after).apply {
            setPadding(0, Ui.dp(context, 2), 0, Ui.dp(context, 2))
            visibility = View.GONE
        }
        editChips.addView(freeLine, 1)
        showKind()
        // Cuánto cambiar, «Pulir con» and the rest live in ⚙ Avanzado (mockup 11); the simple screen
        // shows them in one line; «Señalar dónde» is a button on the photo's corner
        polishLine = Ui.text(this, "", 13f, R.color.accent)
        showPolishLine()
        editAdv = Kit.advancedLine(this) { showEditAdvanced() }
        editChips.addView(editAdv, Ui.lp(this, 8))
        simpleBox.addView(editChips)
        // the model: chosen automatically, but the user can pick one (remembered per tool)
        modelLine = Ui.text(this, "", 13f, R.color.muted).apply {
            setPadding(0, Ui.dp(context, 10), 0, Ui.dp(context, 2))
            setOnClickListener { chooseModel() }
        }
        simpleBox.addView(modelLine)
        // «Qué evitar»: the negative text, folded into one line (opens a sheet)
        negLine = Ui.text(this, "", 13f, R.color.muted).apply {
            setPadding(0, Ui.dp(context, 4), 0, Ui.dp(context, 2))
            setOnClickListener { showNegativeSheet() }
        }
        simpleBox.addView(negLine)
        // ⚙ Avanzado: every control, for this work only (Mis preferencias is what stays)
        crAdvLink = Ui.text(this, getString(R.string.adv_link), 14f, R.color.accent)
        crAdv = Kit.advancedLine(this) { showCreateAdvanced() }
        simpleBox.addView(crAdv, Ui.lp(this, 8))
        simpleBox.addView(crAdvLink.apply {
            setPadding(0, Ui.dp(context, 10), 0, Ui.dp(context, 4))
            setOnClickListener { Prefs.setAdvanced(this@GenerateActivity, true); JobLog.add("⚙ Avanzado (solo esta vez)"); applyMode() }
        })
        // the finish: retoques (folded) and Guardar
        adjustPanel = AdjustPanel(this, { resultBmp }, { adjust }, { v -> adjust = v; previewAdjust() }, { cb -> pickOnResult(cb) }, { false })
        adjustPanel.visibility = View.GONE
        simpleBox.addView(adjustPanel, Ui.lp(this, 6))
        finishRow = Ui.row(this)
        finishRow.addView(Ui.outlineButton(this, getString(R.string.simple_touch_up)) {
            adjustPanel.visibility = if (adjustPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            adjustPanel.sync()
        }, android.widget.LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(this@GenerateActivity, 8) })
        finishRow.addView(Ui.outlineButton(this, getString(R.string.save)) { save() }, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        simpleBox.addView(finishRow, Ui.lp(this, 6))
        panel.addView(simpleBox, panel.indexOfChild(b.optPanel))
        simpleSub = Ui.text(this, "", 12f, R.color.muted).apply { gravity = android.view.Gravity.CENTER }
        panel.addView(simpleSub, panel.indexOfChild(b.generate) + 1)
        backSimple = simpleLink { applyMode() }
        panel.addView(backSimple, panel.indexOfChild(simpleSub) + 1)
        b.prompt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(t: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(t: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                // a typed instruction replaces the chosen idea's English
                if (ideaEnglish != null && ideas.none { getString(it.first) == e?.toString() }) ideaEnglish = null
                kindOverride = null
                showKind()
            }
        })
        // a tap on the picture with no photo yet (Editar) opens the gallery
        b.result.setOnClickListener { if (simple && tool == MODE_EDIT && base == null) pickPhoto() }
    }

    private fun pickPhoto() = picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    /** Simple or advanced (Ajustes), and the tool's own look and model. */
    private fun applyMode() {
        simple = !Prefs.advanced(this)
        prefs.edit().putString("tool", tool).apply()
        for (v in listOf(b.optPanel, b.optLabels, b.refine, b.upscale)) Ui.gone(v, simple)
        Ui.gone(simpleBox, !simple); Ui.gone(simpleSub, !simple); Ui.gone(backSimple, simple)
        findViewById<TextView>(R.id.title)?.text = getString(when {
            !simple -> R.string.sd_title
            tool == MODE_EDIT -> R.string.home_edit
            else -> R.string.home_create
        })
        if (simple) {
            createChips.visibility = if (tool == MODE_CREATE) View.VISIBLE else View.GONE
            editChips.visibility = if (tool == MODE_EDIT) View.VISIBLE else View.GONE
            // Editar (new screens): model, «Qué evitar» and the old ⚙ link are inside ⚙ Avanzado
            val ed = tool == MODE_EDIT
            modelLine?.visibility = if (ed) View.GONE else View.VISIBLE
            negLine?.visibility = if (ed) View.GONE else View.VISIBLE
            if (::crAdvLink.isInitialized) crAdvLink.visibility = View.GONE
            modelLine?.visibility = View.GONE; negLine?.visibility = View.GONE
            crAdv?.visibility = if (ed) View.GONE else View.VISIBLE
            if (!ed) { crBase = crState(); showCreateSummary() }
            showEditSummary(); showPointButton()
            pickModelForTool()
            // Crear starts from text only; Editar needs a photo
            if (tool == MODE_CREATE && base != null && job?.isActive != true) setBase(null)
        }
        if (::lookInput.isInitialized) showLook(lookWanted)
        showFreeLine()
        renderSimple()
    }

    /** The best model on the phone for the tool (and Crear's style); the recommended one if none. */
    private fun pickModelForTool() {
        val local = ModelCatalog.imageModels(this)
        val mine = prefs.getString("model_$tool", null)?.takeIf { it in local && SdModel.isReady(this, it) }
        val id = if (mine != null) mine else if (tool == MODE_EDIT) {
            local.firstOrNull { SdModel.readMode(this, it) == 1 || it.contains("pix2pix") } ?: "pix2pix"
        } else {
            val text = local.filter { SdModel.readMode(this, it) == 0 && !it.contains("pix2pix") && !it.contains("inpainting") && ModelCatalog.autoOk(it) }
            styles[style].models.firstNotNullOfOrNull { k -> text.firstOrNull { it.contains(k, ignoreCase = true) } }
                ?: text.firstOrNull() ?: "dreamshaper8"
        }
        if (!::model.isInitialized || model.id != id) {
            JobLog.add("${getString(if (tool == MODE_EDIT) R.string.home_edit else R.string.home_create)}: modelo ${ModelCatalog.displayName(id)}")
            useModel(id)
        }
        updateModelLine()
        // Calidad: the steps for normal models (fast models keep their own few steps)
        if (!isFastModel()) b.steps.value = when (Prefs.quality(this)) { "fast" -> 15f; "max" -> 35f; else -> 25f }.coerceAtLeast(b.steps.valueFrom)
    }

    private fun pickStyle(i: Int) {
        style = i
        prefs.edit().putInt("style", i).apply()
        styleViews.forEachIndexed { k, v -> Ui.setChip(v, k == i) }
        pickModelForTool()
        renderSimple()
    }

    private fun syncFormat() {
        val dyn = b.formatGroup.isEnabled
        formatChips.visibility = if (dyn) View.VISIBLE else View.GONE
        for ((v, id) in formatViews) Ui.setChip(v, b.formatGroup.checkedButtonId == id)
    }

    private fun renderSimple() {
        if (!::simpleBox.isInitialized) return
        if (!simple) { b.generate.text = getString(if (runningMode != null) R.string.stop else R.string.sd_generate); return }
        val busy = runningMode != null
        val has = lastImage != null && resultBmp != null
        finishRow.visibility = if (has && !busy) View.VISIBLE else View.GONE
        if (!has || busy) adjustPanel.visibility = View.GONE
        syncFormat()
        b.generate.text = getString(when {
            busy -> R.string.stop
            tool == MODE_EDIT && base == null -> R.string.simple_pick_photo
            tool == MODE_EDIT -> R.string.simple_apply
            else -> R.string.simple_create
        })
        b.promptLayout.hint = getString(if (tool == MODE_EDIT) R.string.simple_edit_hint else R.string.simple_create_hint)
        b.promptLayout.helperText = null
        simpleSub.text = getString(if (tool == MODE_EDIT) R.string.simple_edit_sub else R.string.simple_create_sub)
    }

    /** ✦ Crear / ✦ Aplicar: the photo first (Editar), the text in English, the style's words. */
    private fun simpleGenerate() {
        if (tool == MODE_EDIT && base == null) { pickPhoto(); return }
        if (!SdModel.isReady(this, model.id)) {
            // the real size, from the model's page (the built-in figure if offline)
            val id = model.id
            lifecycleScope.launch {
                val bytes = withContext(Dispatchers.IO) { try { ModelCatalog.fetchRemote().firstOrNull { it.id == id }?.sizeBytes } catch (t: Throwable) { null } }
                Ui.askDownload(this@GenerateActivity, getString(if (tool == MODE_EDIT) R.string.home_edit else R.string.home_create),
                    bytes?.let { "~" + ModelCatalog.mb(it) } ?: "~${model.approxMb} MB", onYes = { download() })
            }
            return
        }
        var typed = b.prompt.text?.toString()?.trim().orEmpty()
        if (typed.isEmpty()) { b.genStatus.text = getString(R.string.sd_need_prompt); return }
        // Editar in two steps: details belong to step 2 only (the editor bends things when given them)
        var look: String? = null
        if (tool == MODE_EDIT && model.mode == 1 && ::lookInput.isInitialized) {
            look = lookInput.text?.toString()?.trim()?.ifEmpty { null }
            if (look == null && ideaEnglish == null) {
                val (order, rest) = splitOrder(typed)
                if (rest != null) {
                    typed = order; look = rest
                    b.prompt.setText(order); lookInput.setText(rest); showLook(true)
                    JobLog.add("Editar: separé tu texto · orden «$order» · cómo debe verse «$rest»")
                }
            }
        }
        val idea = ideaEnglish
        b.genStatus.text = getString(R.string.simple_translating)
        b.generate.isEnabled = false
        lifecycleScope.launch {
            val en = idea ?: withContext(Dispatchers.IO) {
                if (model.mode == 1) Translate.toInstruction(typed) else Translate.toEnglish(typed)
            }
            lookEnglish = look?.let { l -> withContext(Dispatchers.IO) { Translate.toEnglish(l) } }
            if (lookEnglish != null) JobLog.add("Paso 1 (editor): «$en» · paso 2 (SDXL): «$lookEnglish»")
            // the editor (pix2pix) has no use for it; every other model reads the user's «Qué evitar»
            val negative = if (model.mode == 1) "" else withContext(Dispatchers.IO) { Negative.english(applicationContext, tool) }
            b.generate.isEnabled = true
            val prompt = if (tool == MODE_CREATE) "$en, ${styles[style].words}" else en
            generate(prompt, negative)
            renderSimple()
        }
    }

    /** The retoques on the shown picture (a smaller copy while moving the sliders). */
    private fun previewAdjust() {
        val src = resultBmp ?: return
        val v = adjust
        adjustJob?.cancel()
        adjustJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(60)
            val shown = withContext(Dispatchers.Default) { if (v.isNeutral) src else PhotoAdjust.apply(PhotoAdjust.previewOf(src), v) }
            if (adjust == v && shown != null) b.result.setImageBitmap(shown)
        }
    }

    /** "Toca algo blanco" on the result (fitCenter): the next tap's point as fractions of the picture. */
    private fun pickOnResult(cb: (Float, Float) -> Unit) {
        b.result.setOnTouchListener { v, e ->
            if (e.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val d = (v as android.widget.ImageView).drawable ?: return@setOnTouchListener false
            val inv = android.graphics.Matrix(); v.imageMatrix.invert(inv)
            val pt = floatArrayOf(e.x - v.paddingLeft, e.y - v.paddingTop); inv.mapPoints(pt)
            v.setOnTouchListener(null)
            val fx = pt[0] / d.intrinsicWidth; val fy = pt[1] / d.intrinsicHeight
            if (fx in 0f..1f && fy in 0f..1f) cb(fx, fy)
            true
        }
    }

    // ---------- models ----------

    private var polishLine: TextView? = null

    /**
     * How much the person is in the same place in [a] and [b] (0..1, overlap of the two silhouettes),
     * or null when it can't tell (no person found).
     */
    private fun framingKept(a: Bitmap, b: Bitmap): Float? = try {
        val s = 256
        val pa = BodyParts.of(applicationContext, Bitmap.createScaledBitmap(a, s, s * a.height / a.width, true))
        val pb = BodyParts.of(applicationContext, Bitmap.createScaledBitmap(b, s, s * a.height / a.width, true))
        if (pa == null || pb == null) null else {
            var inter = 0; var uni = 0
            for (y in 0 until 64) for (x in 0 until 64) {
                val u = (x + 0.5f) / 64; val v = (y + 0.5f) / 64
                val ia = pa.at(u, v) != BodyParts.BACKGROUND; val ib = pb.at(u, v) != BodyParts.BACKGROUND
                if (ia && ib) inter++; if (ia || ib) uni++
            }
            if (uni < 40) null else inter.toFloat() / uni
        }
    } catch (t: Throwable) { null }
    private var kindLine: TextView? = null
    private var editAdv: android.widget.LinearLayout? = null
    private lateinit var crAdvLink: TextView
    private var pointBtn: TextView? = null
    private var crAdv: android.widget.LinearLayout? = null
    /** Crear's values with the preferences (to mark what changed for this image). */
    private var crBase: Map<String, String> = emptyMap()
    /** «Se entiende como» corrected by the person, for this edit only (null = from the order's words). */
    private var kindOverride: EditKind? = null

    private fun currentKind(): EditKind = kindOverride ?: EditKind.classify(b.prompt.text?.toString().orEmpty())

    private fun showKind() {
        val l = kindLine ?: return
        val typed = b.prompt.text?.toString()?.trim().orEmpty()
        if (tool != MODE_EDIT || typed.isEmpty()) { l.visibility = View.GONE; return }
        val k = currentKind()
        showFreeLine()
        if (k == EditKind.NUDE && base != null && !baseAi) {
            val how = getString(R.string.origin_how)
            val t2 = getString(R.string.kind_line, getString(k.label), getString(R.string.origin_blocked_kind)) + "  ·  " + how
            l.text = android.text.SpannableString(t2).apply {
                setSpan(android.text.style.ForegroundColorSpan(getColor(R.color.warn)), 0, t2.length - how.length, 0)
                setSpan(android.text.style.ForegroundColorSpan(getColor(R.color.accent)), t2.length - how.length, t2.length, 0)
            }
            l.setOnClickListener { showOriginSheet(false) }
            l.visibility = View.VISIBLE
            return
        }
        l.setOnClickListener { chooseKind() }
        val txt = getString(R.string.kind_line, getString(k.label), getString(k.note)) + "  ·  " + getString(R.string.kind_change)
        l.text = android.text.SpannableString(txt).apply {
            val a = txt.lastIndexOf(getString(R.string.kind_change))
            setSpan(android.text.style.ForegroundColorSpan(getColor(R.color.accent)), a, txt.length, 0)
            val b0 = txt.indexOf(getString(k.label))
            setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), b0, b0 + getString(k.label).length, 0)
        }
        l.visibility = View.VISIBLE
    }

    /** «Se entiende como»: Ropa, Fondo, Cabeza, Ropa y fondo, Toda la foto (this edit only). */
    /** «Se entiende como» (mockup 7): the kinds as cards, the current one checked; for this edit only. */
    private fun chooseKind() {
        if (job?.isActive == true) return
        val sh = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            setPadding(Ui.dp(context, 16), Ui.dp(context, 14), Ui.dp(context, 16), Ui.dp(context, 18))
        }
        col.addView(Ui.text(this, getString(R.string.kind_pick_title), 18f, R.color.fg, bold = true))
        val typed = b.prompt.text?.toString()?.trim().orEmpty()
        col.addView(Ui.text(this, if (typed.isNotEmpty()) getString(R.string.kit_kind_order, typed) else getString(R.string.kind_pick_sub), 13f, R.color.muted), Ui.lp(this, 4))
        val cur = currentKind()
        for (k in EditKind.values().filter { it != EditKind.NUDE || baseAi }) {
            val on = k == cur
            val card = Ui.row(this).apply {
                setPadding(Ui.dp(context, 14), Ui.dp(context, 12), Ui.dp(context, 14), Ui.dp(context, 12))
                background = Ui.round(context, if (on) 0xFF1A2A1E.toInt() else getColor(R.color.chip), 14, if (on) getColor(R.color.accent) else getColor(R.color.line))
                setOnClickListener { kindOverride = k; JobLog.add("Se entiende como: elegiste «${getString(k.label)}»"); showKind(); showEditSummary(); sh.dismiss() }
            }
            val t = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
            t.addView(Ui.text(this, getString(k.label), 15f, R.color.fg, bold = true))
            t.addView(Ui.text(this, getString(k.note), 12f, R.color.muted))
            card.addView(t, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            if (on) card.addView(Ui.text(this, "✓", 18f, R.color.accent, bold = true))
            col.addView(card, Ui.lp(this, 8))
        }
        col.addView(Ui.bigButton(this, getString(R.string.kit_ready)) { sh.dismiss() }, Ui.lp(this, 12))
        sh.setContentView(android.widget.ScrollView(this).apply { addView(col) })
        sh.show()
    }

    // ---------- the new Crear (mockups 8 and 12) ----------

    private fun fmtNow() = when (b.formatGroup.checkedButtonId) { R.id.fmtPortrait -> "3:4"; R.id.fmtLandscape -> "4:3"; else -> "1:1" }
    private fun backendNow() = when (b.backendGroup.checkedButtonId) { R.id.sdNpu -> "NPU"; R.id.sdCpu -> "CPU"; else -> "GPU" }

    private fun crState(): Map<String, String> = linkedMapOf(
        "modelo" to (if (::model.isInitialized) model.id else ""),
        "forma" to fmtNow(),
        "pasos" to "${b.steps.value.roundToInt()}",
        "guía" to String.format(Locale.US, "%.1f", b.guidance.value),
        "método" to if (b.samplerGroup.checkedButtonId == R.id.smpPlms) "PLMS" else "DPM++",
        "procesador" to backendNow())

    private fun crChanges() = crState().let { now -> now.keys.filter { crBase.isNotEmpty() && now[it] != crBase[it] } }

    /** «Realista adultos · 3:4 · NPU      ⚙ Avanzado». */
    private fun showCreateSummary() {
        val l = crAdv ?: return
        val parts = listOf(if (::model.isInitialized) ModelCatalog.displayName(model.id) else "", fmtNow(), backendNow()).filter { it.isNotBlank() }
        Kit.setAdvancedLine(l, crChanges().size, parts.joinToString(" · "))
    }

    private fun showCreateAdvanced() {
        if (job?.isActive == true) return
        val sh = Kit.Sheet(this, getString(R.string.kit_create_adv), getString(R.string.kit_simple), {})
        lateinit var banner: android.widget.LinearLayout
        fun refresh() {
            val c = crChanges()
            Kit.setBanner(banner, if (c.isEmpty()) null else (if (c.size == 1) "1 cambio" else "${c.size} cambios") + " solo para esta imagen: " + c.joinToString(", ") + ".")
            showCreateSummary()
        }
        banner = Kit.tempBanner(this) { sh.dialog.dismiss(); pickModelForTool(); crBase = crState(); showCreateSummary(); showCreateAdvanced() }
        sh.top.addView(banner, Ui.lp(this, 4))
        val typed = b.prompt.text?.toString()?.trim().orEmpty()
        if (typed.isNotEmpty()) sh.top.addView(Ui.text(this, typed, 14f, R.color.fg).apply {
            setPadding(Ui.dp(context, 12), Ui.dp(context, 10), Ui.dp(context, 12), Ui.dp(context, 10))
            background = Ui.round(context, 0xFF141A16.toInt(), 12, getColor(R.color.line))
        }, Ui.lp(this, 6))
        val r = sh.rows
        r.addView(Kit.section(this, getString(R.string.kit_sec_model)))
        r.addView(Kit.row(this, getString(R.string.kit_model), null, Ui.text(this, (if (::model.isInitialized) ModelCatalog.displayName(model.id) else "") + " ›", 13f, R.color.accent, bold = true).apply {
            maxWidth = Ui.dp(context, 180); setOnClickListener { sh.dialog.dismiss(); chooseModel() }
        }))
        val forms = listOf(R.id.fmtPortrait to "3:4", R.id.fmtSquare to "1:1", R.id.fmtLandscape to "4:3")
        r.addView(Kit.row(this, getString(R.string.kit_shape), null, Kit.Seg(this, forms.map { it.second }) { i -> b.formatGroup.check(forms[i].first); syncFormat(); refresh() }.apply {
            base = forms.indexOfFirst { it.second == crBase["forma"] }.coerceAtLeast(0); set(forms.indexOfFirst { it.second == fmtNow() }.coerceAtLeast(0))
        }))
        r.addView(Kit.section(this, getString(R.string.kit_sec_draw)))
        r.addView(Kit.slider(this, getString(R.string.sd_steps), b.steps.valueFrom, b.steps.valueTo, b.steps.value, null, { "${it.toInt()}" }) { b.steps.value = it.coerceIn(b.steps.valueFrom, b.steps.valueTo); refresh() })
        r.addView(Kit.slider(this, getString(R.string.sd_guidance), b.guidance.valueFrom * 10, b.guidance.valueTo * 10, b.guidance.value * 10, null,
            { String.format(Locale.US, "%.1f", it / 10f) }) {
                val g = b.guidance; val st = g.stepSize
                val v = (it / 10f).coerceIn(g.valueFrom, g.valueTo)
                g.value = if (st > 0f) (g.valueFrom + Math.round((v - g.valueFrom) / st) * st).coerceIn(g.valueFrom, g.valueTo) else v
                refresh()
            })
        r.addView(Kit.row(this, getString(R.string.kit_method), null, Kit.Seg(this, listOf("DPM++", "PLMS")) { i -> b.samplerGroup.check(if (i == 0) R.id.smpDpm else R.id.smpPlms); refresh() }.apply {
            base = if (crBase["método"] == "PLMS") 1 else 0; set(if (b.samplerGroup.checkedButtonId == R.id.smpPlms) 1 else 0)
        }))
        val backs = listOf(R.id.sdNpu to "NPU", R.id.sdGpu to "GPU", R.id.sdCpu to "CPU")
        r.addView(Kit.row(this, getString(R.string.proc_title), null, Kit.Seg(this, backs.map { it.second }) { i -> b.backendGroup.check(backs[i].first); refresh() }.apply {
            base = backs.indexOfFirst { it.second == crBase["procesador"] }.coerceAtLeast(0); set(backs.indexOfFirst { it.second == backendNow() }.coerceAtLeast(0))
        }))
        r.addView(Kit.section(this, getString(R.string.kit_sec_texts)))
        r.addView(Kit.row(this, getString(R.string.kit_avoid), null, Ui.text(this, getString(R.string.kit_edit) + " ›", 13f, R.color.accent, bold = true).apply {
            setOnClickListener { sh.dialog.dismiss(); showNegativeSheet() }
        }))
        sh.bottom.addView(Ui.text(this, getString(R.string.kit_forever), 13f, R.color.accent, bold = true).apply {
            gravity = android.view.Gravity.CENTER; setPadding(0, Ui.dp(context, 4), 0, Ui.dp(context, 8))
            setOnClickListener { sh.dialog.dismiss(); startActivity(Intent(this@GenerateActivity, QuickActionsActivity::class.java)) }
        })
        sh.bottom.addView(Ui.bigButton(this, b.generate.text.toString()) { sh.dialog.dismiss(); b.generate.performClick() })
        sh.dialog.setOnDismissListener { showCreateSummary() }
        refresh()
        sh.show()
    }

    // ---------- the new Editar (mockups 6 and 11) ----------

    private fun amountName(i: Int) = getString(listOf(R.string.edit_amount_soft, R.string.edit_amount_normal, R.string.edit_amount_strong)[i.coerceIn(0, 2)])

    /** «● N cambios solo para esta edición» or «Normal · Lustify · pose y forma · Realismo». */
    private fun showEditSummary() {
        val l = editAdv ?: return
        val n = QuickActionsActivity.temp.keys.count { it.startsWith("nitido/") } + (if (kindOverride != null) 1 else 0)
        val parts = mutableListOf(amountName(EditPolish.amount(this)))
        (EditPolish.fillModel(this) ?: EditPolish.pickModel(this))?.let { parts += ModelCatalog.displayName(it) }
        if (QuickActionsActivity.on(this, "nitido", "q_pose")) parts += if (QuickActionsActivity.on(this, "nitido", "q_depth")) "pose y forma" else "pose"
        if (EditPolish.realism(this) > 0) parts += "Realismo"
        Kit.setAdvancedLine(l, n, parts.joinToString(" · "))
    }

    /** «✎ Señalar dónde» on the photo's top-left corner (Editar, with a photo). */
    private fun showPointButton() {
        val frame = b.result.parent as? android.widget.FrameLayout ?: return
        val v = pointBtn ?: Ui.text(this, getString(R.string.kit_point), 13f, R.color.fg, bold = true).apply {
            setPadding(Ui.dp(context, 12), Ui.dp(context, 8), Ui.dp(context, 12), Ui.dp(context, 8))
            background = Ui.round(context, 0xB80A0D0B.toInt(), 18)
            setOnClickListener { b.paintZone.performClick() }
            frame.addView(this, Kit.frameLp(android.view.Gravity.TOP or android.view.Gravity.START, 10, context))
            pointBtn = this
        }
        v.visibility = if (simple && tool == MODE_EDIT && base != null) View.VISIBLE else View.GONE
        // the origin label goes under it
        (originBadge?.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let { lp ->
            lp.topMargin = Ui.dp(this, if (v.visibility == View.VISIBLE) 56 else 10); originBadge?.layoutParams = lp
        }
    }

    /** ⚙ Avanzado of Editar (mockup 11): every control; changes are for this edit only. */
    private fun showEditAdvanced() {
        if (job?.isActive == true) return
        val sh = Kit.Sheet(this, getString(R.string.kit_edit_adv), getString(R.string.kit_simple), {})
        lateinit var banner: android.widget.LinearLayout
        fun refresh() {
            val n = QuickActionsActivity.temp.keys.count { it.startsWith("nitido/") } + (if (kindOverride != null) 1 else 0)
            Kit.setBanner(banner, if (n == 0) null else (if (n == 1) "1 cambio" else "$n cambios") + " solo para esta edición. Al terminar vuelve a tus preferencias.")
            showEditSummary()
        }
        banner = Kit.tempBanner(this) { QuickActionsActivity.clearTemp("nitido"); kindOverride = null; showKind(); sh.dialog.dismiss(); showEditAdvanced() }
        sh.top.addView(banner, Ui.lp(this, 4))
        fun sw(key: String, label: String, sub: String?) = Kit.row(this, label, sub, Kit.switch(this, QuickActionsActivity.on(this, "nitido", key)) { v ->
            if (v == QuickActionsActivity.savedOn(this, "nitido", key)) QuickActionsActivity.temp.remove("nitido/$key") else QuickActionsActivity.setTemp("nitido", key, v)
            refresh()
        })
        fun seg(key: String, names: List<String>, values: List<Int>): Kit.Seg {
            val g = Kit.Seg(this, names) { i ->
                val v = values[i]
                if (v == QuickActionsActivity.saved(this, "nitido", key)) QuickActionsActivity.temp.remove("nitido/$key") else QuickActionsActivity.setTemp("nitido", key, v)
                refresh()
            }
            g.base = values.indexOf(QuickActionsActivity.saved(this, "nitido", key)).coerceAtLeast(0)
            g.set(values.indexOf(QuickActionsActivity.pick(this, "nitido", key)).coerceAtLeast(0))
            return g
        }
        val r = sh.rows
        r.addView(Kit.section(this, getString(R.string.kit_sec_what)))
        r.addView(Kit.row(this, getString(R.string.kit_kind), null, Ui.text(this, getString(currentKind().label) + " ›", 13f, R.color.accent, bold = true).apply {
            setOnClickListener { sh.dialog.dismiss(); chooseKind() }
        }))
        r.addView(Kit.row(this, getString(R.string.kit_fill_with), getString(R.string.kit_fill_sub),
            Ui.text(this, ((EditPolish.fillModel(this) ?: EditPolish.pickModel(this))?.let { ModelCatalog.displayName(it) } ?: getString(R.string.polish_none)) + " ›", 13f, R.color.accent, bold = true).apply {
                maxWidth = Ui.dp(context, 170); setOnClickListener { sh.dialog.dismiss(); choosePolish() }
            }))
        r.addView(Kit.row(this, getString(R.string.edit_amount), null,
            seg("edit_amount", listOf(amountName(0), amountName(1), amountName(2)), listOf(0, 1, 2))))
        r.addView(sw("q_dreamlite", getString(R.string.qa_dreamlite), getString(R.string.qa_dreamlite_note)))
        r.addView(sw("q_polish", getString(R.string.qa_polish), getString(R.string.qa_polish_note)))
        r.addView(Kit.section(this, getString(R.string.kit_sec_keep)))
        r.addView(sw("q_pose", getString(R.string.qa_pose), getString(R.string.qa_pose_note)))
        r.addView(sw("q_depth", getString(R.string.qa_depth), getString(R.string.qa_depth_note)))
        r.addView(sw("q_keep", getString(R.string.qa_keep), getString(R.string.qa_keep_note)))
        r.addView(sw("q_editfaces", getString(R.string.qa_editfaces), null))
        r.addView(Kit.section(this, getString(R.string.kit_sec_texts)))
        r.addView(Kit.row(this, getString(R.string.kit_look), getString(R.string.kit_look_sub), Ui.text(this, getString(if (lookWanted) R.string.kit_open else R.string.kit_add), 13f, R.color.accent, bold = true).apply {
            setOnClickListener { sh.dialog.dismiss(); showLook(true); lookInput.requestFocus() }
        }))
        r.addView(Kit.row(this, getString(R.string.kit_avoid), null, Ui.text(this, getString(R.string.kit_edit) + " ›", 13f, R.color.accent, bold = true).apply {
            setOnClickListener { sh.dialog.dismiss(); showNegativeSheet() }
        }))
        r.addView(Kit.row(this, getString(R.string.kit_point_row), getString(R.string.kit_point_sub), Ui.text(this, getString(R.string.kit_open) + " ›", 13f, R.color.accent, bold = true).apply {
            setOnClickListener { sh.dialog.dismiss(); if (base == null) pickPhoto() else b.paintZone.performClick() }
        }))
        r.addView(Kit.section(this, getString(R.string.kit_sec_end)))
        r.addView(Kit.row(this, getString(R.string.qa_realism_end), getString(R.string.qa_realism_end_note),
            seg("edit_realism", listOf("No", "Normal", "Más"), listOf(0, 1, 2))))
        sh.bottom.addView(Ui.text(this, getString(R.string.kit_forever), 13f, R.color.accent, bold = true).apply {
            gravity = android.view.Gravity.CENTER; setPadding(0, Ui.dp(context, 4), 0, Ui.dp(context, 8))
            setOnClickListener { sh.dialog.dismiss(); startActivity(Intent(this@GenerateActivity, QuickActionsActivity::class.java)) }
        })
        sh.bottom.addView(Ui.bigButton(this, b.generate.text.toString()) { sh.dialog.dismiss(); b.generate.performClick() })
        sh.dialog.setOnDismissListener { showEditSummary() }
        refresh()
        sh.show()
    }

    // ---------- origin: a real photo or a picture invented by Crear ----------

    private var originBadge: TextView? = null
    private var freeLine: TextView? = null

    /** The negative text for a real photo also keeps nudity away (fill models such as Lustify). */
    private fun safeNegative(neg: String, realPhoto: Boolean): String =
        if (!realPhoto) neg else listOf(neg, ImageOrigin.REAL_PHOTO_NEGATIVE).filter { it.isNotBlank() }.joinToString(", ")

    /** Made from text only (Crear), or an edit of a listed picture: it goes into the registry. */
    private fun resultIsAi(textOnly: Boolean, fromAi: Boolean): Boolean =
        (textOnly && ImageOrigin.recordOn(this)) || (fromAi && ImageOrigin.inheritOn(this))

    /** The corner label on the picture: «✦ IA · creada en Nítido» or «Foto»; [ai] null hides it. */
    private fun showOrigin(ai: Boolean? = if (base != null) baseAi else null) {
        val frame = b.result.parent as? android.widget.FrameLayout ?: return
        val v = originBadge ?: Ui.text(this, "", 13f, R.color.fg, bold = true).apply {
            val pd = Ui.dp(context, 10)
            setPadding(pd, Ui.dp(context, 7), pd, Ui.dp(context, 7))
            setOnClickListener { showOriginSheet(tag as? Boolean ?: false) }
            frame.addView(this, android.widget.FrameLayout.LayoutParams(-2, -2, android.view.Gravity.TOP or android.view.Gravity.START).apply {
                val m = Ui.dp(context, 10); setMargins(m, m, m, m)
            })
            originBadge = this
        }
        if (ai == null || !ImageOrigin.badgeOn(this)) { v.visibility = View.GONE; return }
        v.tag = ai
        v.text = getString(if (ai) R.string.origin_ai else R.string.origin_photo)
        v.setTextColor(getColor(if (ai) R.color.after else R.color.fg))
        v.background = Ui.round(this, 0xC70A0D0B.toInt(), 18, if (ai) getColor(R.color.after) else null)
        v.visibility = View.VISIBLE
        v.bringToFront()
    }

    /** Under «Se entiende como»: the reminder that an AI picture has no restriction. */
    private fun showFreeLine() {
        val f = freeLine ?: return
        f.visibility = if (tool == MODE_EDIT && base != null && baseAi) View.VISIBLE else View.GONE
    }

    /** An order that undresses a real photo: not done; other garments are offered instead. */
    private fun showBlocked() {
        val alts = listOf(R.string.origin_alt_swimsuit, R.string.origin_alt_sport, R.string.origin_alt_red)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.origin_blocked_title)
            .setMessage(getString(R.string.origin_blocked_body))
            .setItems(alts.map { getString(it) }.toTypedArray()) { _, i ->
                b.prompt.setText(getString(R.string.kind_clothes_alt, getString(alts[i]).lowercase(Locale.ROOT)))
                ideaEnglish = null; kindOverride = null; showKind()
            }
            .setNeutralButton(R.string.origin_how) { _, _ -> showOriginSheet(false) }
            .setNegativeButton(R.string.close, null)
            .show()
        b.genStatus.text = getString(R.string.origin_blocked_title)
    }

    /** «¿Cómo lo sabe Nítido?»: the picture's origin and the four rules. */
    private fun showOriginSheet(ai: Boolean) {
        val dp = resources.displayMetrics.density
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            setPadding((18 * dp).toInt(), (16 * dp).toInt(), (18 * dp).toInt(), (20 * dp).toInt())
        }
        col.addView(Ui.text(this, getString(if (ai) R.string.origin_sheet_ai else R.string.origin_sheet_photo), 18f,
            if (ai) R.color.after else R.color.fg, bold = true))
        col.addView(Ui.text(this, getString(if (ai) R.string.origin_sheet_ai_sub else R.string.origin_sheet_photo_sub), 13f, R.color.muted), Ui.lp(this, 2))
        col.addView(Ui.text(this, getString(R.string.origin_how), 15f, R.color.fg, bold = true), Ui.lp(this, 16))
        col.addView(Ui.text(this, getString(R.string.origin_rules), 13f, R.color.fg2).apply { setLineSpacing(0f, 1.25f) }, Ui.lp(this, 6))
        col.addView(Ui.text(this, getString(R.string.origin_open_registry), 15f, R.color.accent).apply {
            setPadding(0, (14 * dp).toInt(), 0, (6 * dp).toInt())
            setOnClickListener { dialog.dismiss(); startActivity(Intent(this@GenerateActivity, OriginActivity::class.java)) }
        })
        col.addView(Ui.bigButton(this, getString(R.string.origin_ok)) { dialog.dismiss() }, Ui.lp(this, 10))
        dialog.setContentView(android.widget.ScrollView(this).apply { addView(col) })
        dialog.show()
    }

    private fun showPolishLine() {
        val id = EditPolish.pickModel(this)
        val fill = EditPolish.fillModel(this)
        polishLine?.text = getString(R.string.polish_with, (fill?.let { ModelCatalog.displayName(it) + " + " } ?: "") +
            (id?.let { ModelCatalog.displayName(it) } ?: getString(R.string.polish_none)))
    }

    /** «Pulir con»: the SDXL models that can polish; the ones without an NPU version shown gray. */
    private fun choosePolish() {
        if (job?.isActive == true) return
        val ok = EditPolish.choices(this)
        val off = EditPolish.withoutNpu(this)
        val cur = EditPolish.pickModel(this)
        val dp = resources.displayMetrics.density
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val list = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
        }
        list.addView(Ui.text(this, getString(R.string.polish_pick_title), 17f, R.color.fg, bold = true))
        list.addView(Ui.text(this, getString(R.string.polish_pick_sub), 12f, R.color.muted).apply { setPadding(0, 0, 0, (8 * dp).toInt()) })
        // the inpainting models fill an exact zone (ropa, fondo, cabeza); the others polish and do whole photos
        val fills = Reimagine.fillModels(this)
        if (fills.isNotEmpty()) {
            val curFill = EditPolish.fillModel(this)
            list.addView(Ui.text(this, getString(R.string.fill_pick_header), 13f, R.color.muted).apply { setPadding(0, (6 * dp).toInt(), 0, 0) })
            for (id in fills) list.addView(Ui.text(this, (if (id == curFill) "●  " else "○  ") + ModelCatalog.displayName(id), 15f, R.color.fg).apply {
                setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
                setOnClickListener { getSharedPreferences("nitido", MODE_PRIVATE).edit().putString("fill_model", id).apply(); showPolishLine(); dialog.dismiss() }
            })
            list.addView(Ui.text(this, getString(R.string.polish_pick_header), 13f, R.color.muted).apply { setPadding(0, (10 * dp).toInt(), 0, 0) })
        }
        if (ok.isEmpty()) list.addView(Ui.text(this, getString(R.string.polish_pick_empty), 14f, R.color.muted))
        for (id in ok) list.addView(Ui.text(this, (if (id == cur) "●  " else "○  ") + ModelCatalog.displayName(id) +
            (if (!SdModel.isSdxl(this, id)) "  · " + getString(R.string.polish_sd15) else if (Reimagine.isFast(id)) "" else "  · " + getString(R.string.polish_slow)), 15f, R.color.fg).apply {
            setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
            setOnClickListener { EditPolish.choose(this@GenerateActivity, id); showPolishLine(); dialog.dismiss() }
        })
        for (id in off) list.addView(Ui.text(this, "○  " + ModelCatalog.displayName(id) + "  · " + getString(R.string.polish_no_npu), 15f, R.color.muted).apply {
            setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt()); alpha = 0.6f
        })
        dialog.setContentView(android.widget.ScrollView(this).apply { addView(list) })
        dialog.show()
    }

    private fun chooseModel() {
        if (job?.isActive == true) return
        showCatalog()
    }

    /** Only the models on the phone, grouped by SD 8 bits, SD 16 bits and SDXL. More are in the Models screen. */
    private fun showCatalog() {
        val dp = resources.displayMetrics.density
        val list = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding((8 * dp).toInt(), (4 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
        }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        // a sheet from the bottom: title, the models on the phone in groups, more at the end
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sheet = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            setPadding((12 * dp).toInt(), (14 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt())
            addView(TextView(this@GenerateActivity).apply {
                text = getString(R.string.sd_pick_title); textSize = 17f; setTextColor(getColor(R.color.fg))
                setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding((8 * dp).toInt(), 0, 0, 0)
            })
            addView(TextView(this@GenerateActivity).apply {
                text = getString(R.string.sd_pick_sub); textSize = 12f; setTextColor(getColor(R.color.muted))
                setPadding((8 * dp).toInt(), 0, 0, (4 * dp).toInt())
            })
            addView(scroll)
        }
        dialog.setContentView(sheet)

        fun header(text: String) = list.addView(TextView(this).apply {
            this.text = text
            setTextColor(getColor(R.color.muted))
            textSize = 12f
            setPadding((8 * dp).toInt(), (14 * dp).toInt(), (8 * dp).toInt(), (4 * dp).toInt())
        })
        fun row(title: String, sub: String, current: Boolean = false, onClick: () -> Unit) = list.addView(TextView(this).apply {
            text = android.text.SpannableStringBuilder().apply {
                val start = length
                append(if (current) "●  $title" else "○  $title")
                setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, length, 0)
                append("\n")
                val s2 = length
                append(sub)
                setSpan(android.text.style.ForegroundColorSpan(getColor(R.color.muted)), s2, length, 0)
                setSpan(android.text.style.RelativeSizeSpan(0.88f), s2, length, 0)
            }
            setTextColor(getColor(R.color.fg))
            textSize = 15f
            setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(getColor(R.color.chip)); cornerRadius = 12 * dp
                setStroke(((if (current) 2 else 1) * dp).toInt(), getColor(if (current) R.color.accent else R.color.line_hi))
            }
            layoutParams = android.widget.LinearLayout.LayoutParams(-1, -2).apply { topMargin = (6 * dp).toInt() }
            setOnClickListener { dialog.dismiss(); onClick() }
        })

        if (simple) {
            val auto = prefs.getString("model_$tool", null) == null
            row(getString(R.string.simple_model_auto_title), getString(R.string.simple_model_auto_sub), current = auto) {
                prefs.edit().remove("model_$tool").apply(); pickModelForTool(); renderSimple()
            }
        }
        val all = ModelCatalog.imageModels(this)   // NPU versions go with their model; tool packs aren't image models
        if (all.isEmpty()) row(getString(R.string.cat_none), getString(R.string.cat_go_models)) { openModels() }
        // one line per model: when both base versions are on the phone, the 16-bit one (the current
        // one, if it is the 8-bit) stands for it
        fun fam(id: String) = id.removeSuffix("-16").removeSuffix("-8")
        fun is16(id: String) = SdModel.precision(this, id)?.startsWith("16") == true
        val local = all.groupBy { fam(it) }.values.map { ids ->
            ids.firstOrNull { it == model.id } ?: ids.firstOrNull { is16(it) } ?: ids.first()
        }
        val groups = local.groupBy { id ->
            when {
                SdModel.readMode(this, id) != 0 || id.contains("inpainting") || id.contains("pix2pix") -> 2
                SdModel.isSdxl(this, id) -> 1
                else -> 0
            }
        }
        val titles = listOf(R.string.models_tab_sd15, R.string.models_tab_sdxl, R.string.models_tag_editor)
        for (g in 0..2) {
            val ids = groups[g] ?: continue
            header(getString(titles[g]))
            for (id in ids.sortedBy { ModelCatalog.displayName(it).lowercase() }) {
                val extra = listOfNotNull(
                    ModelCatalog.description(id),
                    SdModel.lora(this, id)?.let { getString(R.string.cat_lora) },
                    if (SdModel.isDynamic(this, id) || SdModel.isSdxl(this, id)) null else getString(R.string.models_square_only),
                    if (is16(id)) "16 bits" else "8 bits",
                    if (NpuUnet.dirFor(this, id) != null) "NPU" else null,
                ).joinToString(" · ")
                row(SdModel.byId(this, id).name, extra, current = id == model.id && (!simple || prefs.getString("model_$tool", null) != null)) {
                    if (simple) {
                        prefs.edit().putString("model_$tool", id).apply()
                        JobLog.add("${getString(if (tool == MODE_EDIT) R.string.home_edit else R.string.home_create)}: modelo elegido ${ModelCatalog.displayName(id)}")
                    }
                    useModel(id)
                    if (simple) { pickModelForTool(); renderSimple() }
                }
            }
        }

        header(getString(R.string.cat_other))
        row(getString(R.string.cat_more_models), getString(R.string.cat_go_models)) { openModels() }
        row(getString(R.string.sd_add_model), getString(R.string.cat_add_by_name)) { addModel() }
        dialog.show()
    }

    private fun openModels() = startActivity(Intent(this, ModelsActivity::class.java))

    private fun useModel(id: String) {
        if (SdModel.ALL.none { it.id == id }) SdModel.addCustom(this, id)
        selectModel(SdModel.byId(this, id))
    }

    /** How to convert a recommended model, with the exact link and name ready to copy. */
    private fun showConvertHelp(r: Recommendation) {
        val clip = getSystemService(android.content.ClipboardManager::class.java)
        val msg = getString(R.string.cat_convert_steps, r.link, r.id, r.precision)
        MaterialAlertDialogBuilder(this)
            .setTitle(r.name)
            .setMessage(msg)
            .setPositiveButton(R.string.cat_open_github) { _, _ ->
                clip.setPrimaryClip(android.content.ClipData.newPlainText("enlace", r.link))
                android.widget.Toast.makeText(this, R.string.cat_link_copied, android.widget.Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ModelCatalog.CONVERT_PAGE))) } catch (_: Throwable) { }
            }
            .setNeutralButton(R.string.cat_copy_link) { _, _ ->
                clip.setPrimaryClip(android.content.ClipData.newPlainText("enlace", r.link))
                android.widget.Toast.makeText(this, R.string.cat_link_copied, android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun selectModel(m: SdModelInfo) {
        if (::model.isInitialized && m.id != model.id) NpuUnet.releaseAll()
        model = m
        prefs.edit().putString("model", model.id).apply()
        refreshModel()
    }

    private fun addModel() {
        val input = com.google.android.material.textfield.TextInputEditText(this).apply {
            hint = getString(R.string.sd_add_hint)
            setSingleLine()
        }
        val box = android.widget.FrameLayout(this).apply {
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.sd_add_title)
            .setMessage(R.string.sd_add_message)
            .setView(box)
            .setPositiveButton(R.string.sd_add_ok) { _, _ ->
                val id = SdModel.cleanId(input.text?.toString().orEmpty())
                if (id.isEmpty()) return@setPositiveButton
                SdModel.addCustom(this, id)
                selectModel(SdModel.byId(this, id))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Lightning / Turbo / LCM / Hyper: made for few steps and a low guidance (1-2); 7 burns them. */
    private fun isFastModel() = Regex("lightning|turbo|lcm|hyper", RegexOption.IGNORE_CASE).containsMatchIn(model.id + " " + model.name)

    /** The steps and guidance ranges for this model; a fast model gets 6 steps and guidance 1.5. */
    private fun tuneForModel() {
        val fast = isFastModel()
        if (fast) {
            b.steps.valueFrom = 4f
            b.guidance.valueFrom = 1f
            // the normal defaults (25 steps, guidance 7) don't suit it: its own, unless already set low
            if (b.guidance.value > 3f || b.steps.value > 12f) {
                b.steps.value = 6f
                b.guidance.value = 1.5f
                JobLog.add("${model.name}: modelo rápido · 6 pasos y guía 1.5 (los modelos Lightning/Turbo se queman con guía alta)")
            }
        } else {
            if (b.steps.value < 8f) b.steps.value = 25f
            if (b.guidance.value < 3f) b.guidance.value = 7f
            b.steps.valueFrom = 8f
            b.guidance.valueFrom = 3f
        }
    }

    private fun refreshModel() {
        tuneForModel()
        val ready = SdModel.isReady(this, model.id)
        b.modelPick.text = getString(R.string.sd_model_button, model.name)
        b.modelDesc.text = model.description
        b.setupCard.visibility = if (ready) View.GONE else View.VISIBLE
        b.createPanel.visibility = if (ready) View.VISIBLE else View.GONE
        // the model label lives in the generator; while the model isn't downloaded, show the picker itself
        b.modelPick.visibility = if (ready) View.GONE else View.VISIBLE
        if (::opts.isInitialized) opts.refresh()
        b.deleteModel.visibility = if (ready) View.VISIBLE else View.GONE
        b.deleteModel.text = getString(R.string.sd_delete_model, model.name)
        if (!ready) {
            b.setupTitle.text = getString(R.string.sd_setup_title, model.name)
            b.dlStatus.text = getString(R.string.sd_dl_intro, model.approxMb)
        }
        val editor = model.mode == 1
        val dyn = ready && SdModel.isDynamic(this, model.id)
        b.formatGroup.isEnabled = dyn
        for (i in 0 until b.formatGroup.childCount) b.formatGroup.getChildAt(i).isEnabled = dyn
        if (!dyn) b.formatGroup.check(R.id.fmtSquare)
        b.formatNote.visibility = if (ready && !dyn && !editor) View.VISIBLE else View.GONE
        val canBig = dyn && !editor && !SdModel.isSdxl(this, model.id)
        b.bigSize.visibility = if (canBig) View.VISIBLE else View.GONE
        if (!canBig) b.bigSize.isChecked = false
        b.formatRow.visibility = if (editor) View.GONE else View.VISIBLE
        b.promptLayout.hint = getString(if (editor) R.string.sd_instruction_hint else R.string.sd_prompt_hint)
        b.negativeLayout.visibility = if (editor) View.GONE else View.VISIBLE
        // NPU: only for models that have their NPU version downloaded (SD 1.5, text-to-image)
        // NPU only with versions compiled in the server (compiling on the phone needs >6 GB and overheats)
        val npuOk = ready && model.mode == 0 && NpuUnet.isPrecompiled(this, model.id)
        b.sdNpu.visibility = if (npuOk) View.VISIBLE else View.GONE
        b.sdNpu.isEnabled = npuOk
        restoringBackend = true
        if (!npuOk && b.backendGroup.checkedButtonId == R.id.sdNpu) b.backendGroup.check(R.id.sdGpu)
        // remembered per model; a model with NPU starts on the NPU until the user picks otherwise
        val saved = prefs.getString("backend_${model.id}", null)
        when {
            saved == "npu" && npuOk -> b.backendGroup.check(R.id.sdNpu)
            saved == "cpu" -> b.backendGroup.check(R.id.sdCpu)
            saved == "gpu" -> b.backendGroup.check(R.id.sdGpu)
            saved == null && npuOk -> b.backendGroup.check(R.id.sdNpu)
        }
        restoringBackend = false
        updatePhotoUi()
    }

    private fun download() {
        val m = model
        if (BgWork.downloading()) {
            b.dlStatus.text = getString(R.string.models_busy_dl, ModelCatalog.displayName(BgWork.dlId ?: "")); return
        }
        cancel = false
        b.download.text = getString(R.string.stop)
        b.dlProgress.visibility = View.VISIBLE
        b.modelPick.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        BgWork.startDownload(this, m.id, getString(R.string.notif_downloading), GenerateActivity::class.java) { cancel = true }
        job = BgWork.scope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    SdModel.download(this@GenerateActivity, m.id, { cancel }) { done, total ->
                        if (total > 0) BgWork.updateDownload(this@GenerateActivity,
                            getString(R.string.sd_dl_progress, done / 1_000_000, total / 1_000_000), (done * 100 / total).toInt())
                        runOnUiThread {
                            val p = if (total > 0) done.toFloat() / total else 0f
                            b.dlProgress.progress = (p * 1000).roundToInt()
                            b.dlStatus.text = getString(R.string.sd_dl_progress, done / 1_000_000, total / 1_000_000)
                        }
                    }
                    null
                } catch (e: InterruptedException) {
                    getString(R.string.sd_dl_paused)
                } catch (t: Throwable) {
                    getString(R.string.sd_dl_error, t.message ?: t.javaClass.simpleName)
                }
            }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            BgWork.finishDownload(this@GenerateActivity, if (err == null) getString(R.string.notif_done_dl) else null)
            b.download.text = getString(R.string.sd_download)
            b.dlProgress.visibility = View.INVISIBLE
            b.modelPick.isEnabled = true
            if (err != null) b.dlStatus.text = err else { model = SdModel.byId(this@GenerateActivity, m.id); refreshModel() }
        }
    }

    // ---------- photo ----------

    /** Load a photo (long side up to 2048 px). It is fitted into 512×512 at generation time. */
    private fun loadBase(uri: Uri) {
        lifecycleScope.launch {
            // its origin from its sha256 (the registry of AI pictures), never from the picture itself
            val ai = withContext(Dispatchers.IO) { ImageOrigin.isAi(applicationContext, uri) }
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = maxOf(info.size.width, info.size.height)
                        if (long > 2048) {
                            val k = 2048f / long
                            dec.setTargetSize((info.size.width * k).roundToInt(), (info.size.height * k).roundToInt())
                        }
                    }
                    src.copy(Bitmap.Config.ARGB_8888, false)
                } catch (t: Throwable) { null }
            }
            if (bmp == null) b.genStatus.text = getString(R.string.err_open) else {
                JobLog.add("Origen: " + if (ai) "imagen IA creada en Nítido (está en el registro)" else "foto real (no está en el registro)")
                setBase(bmp, ai)
            }
        }
    }

    private fun setBase(bmp: Bitmap?, ai: Boolean = false) {
        if (bmp !== base) { QuickActionsActivity.clearTemp("nitido"); kindOverride = null }
        base = bmp
        baseAi = bmp != null && ai
        zoneMask = null
        b.baseThumb.setImageBitmap(bmp)
        if (bmp != null) b.result.setImageBitmap(bmp)
        updatePhotoUi()
        renderSimple()
        showOrigin()
        showKind()
        showEditSummary(); showPointButton()
    }

    private fun updatePhotoUi() {
        val has = base != null
        val editor = model.mode == 1
        b.baseThumb.visibility = if (has) View.VISIBLE else View.GONE
        b.clearBase.visibility = if (has) View.VISIBLE else View.GONE
        b.pickBase.text = getString(
            when {
                has -> R.string.sd_change_base
                editor -> R.string.sd_pick_base_required
                else -> R.string.sd_pick_base
            })
        val inpaintModel = model.mode == 2
        val zone = has && zoneMask != null
        b.zoneRow.visibility = if (has) View.VISIBLE else View.GONE
        b.clearZone.visibility = if (zone) View.VISIBLE else View.GONE
        b.paintZone.text = getString(if (zone) R.string.paint_zone_edit else R.string.paint_zone)
        b.strengthRow.visibility = if (has && !editor && (!inpaintModel || zone)) View.VISIBLE else View.GONE
        b.keepRow.visibility = if (editor) View.VISIBLE else View.GONE
        b.photoHint.visibility = if (has || editor || inpaintModel) View.VISIBLE else View.GONE
        b.photoHint.text = getString(when {
            editor -> R.string.sd_keep_hint
            zone -> R.string.paint_zone_on
            inpaintModel -> R.string.sd_need_mask
            else -> R.string.sd_strength_hint
        })
        // only the special modes get a helper line (the picture keeps the space otherwise)
        b.promptLayout.helperText = when {
            editor -> getString(R.string.sd_instruction_help)
            zone -> getString(R.string.sd_inpaint_prompt_help)
            has -> getString(R.string.sd_edit_prompt_help)
            else -> null
        }
    }

    // ---------- zone (inpainting) ----------

    /** Everything a zone edit needs: the piece of the photo to work on and its masks. */
    private class ZonePlan(
        val crop: Rect, val w: Int, val h: Int, val box: Rect?,
        val image: FloatArray, val masked: FloatArray?, val latMask: FloatArray, val softCrop: Bitmap,
    )

    /** Soft-edged copy of a mask (blurred by shrinking and growing it back). */
    private fun soften(mask: Bitmap, factor: Int = 8): Bitmap {
        val small = Bitmap.createScaledBitmap(mask, maxOf(1, mask.width / factor), maxOf(1, mask.height / factor), true)
        return Bitmap.createScaledBitmap(small, mask.width, mask.height, true)
    }

    private fun alphas(bmp: Bitmap): IntArray {
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        for (i in px.indices) px[i] = px[i] ushr 24
        return px
    }

    /**
     * Cuts out the painted area with some margin, scales it to the model's size (so small areas get
     * full detail: "inpaint only masked"), and prepares the photo, masked photo and masks.
     */
    private fun planZone(photo: Bitmap, mask: Bitmap, dynamic: Boolean, sdxl: Boolean, inpaintModel: Boolean, change: Float,
                         npuSizes: List<Pair<Int, Int>> = emptyList()): ZonePlan? {
        val q = 4
        val sm = Bitmap.createScaledBitmap(mask, maxOf(1, mask.width / q), maxOf(1, mask.height / q), true)
        val a = alphas(sm)
        var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var x1 = -1; var y1 = -1
        for (y in 0 until sm.height) for (x in 0 until sm.width) if (a[y * sm.width + x] > 20) {
            if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y
        }
        if (x1 < 0) return null
        x0 *= q; y0 *= q; x1 = (x1 + 1) * q; y1 = (y1 + 1) * q
        val pad = maxOf(32, (maxOf(x1 - x0, y1 - y0) * 0.25f).roundToInt())
        var rect = Rect(maxOf(0, x0 - pad), maxOf(0, y0 - pad), minOf(photo.width, x1 + pad), minOf(photo.height, y1 + pad))
        if (rect.width() * rect.height() > 0.6f * photo.width * photo.height) rect = Rect(0, 0, photo.width, photo.height)
        // the NPU works only at its fixed sizes: take the one with the zone's shape and widen the
        // zone to exactly that shape (more photo around it), so nothing gets stretched
        val npuSize = if (dynamic && npuSizes.isNotEmpty()) {
            val r = rect.width().toFloat() / rect.height()
            npuSizes.minByOrNull { (w, h) -> Math.abs(Math.log((w.toFloat() / h / r).toDouble())) }!!
        } else null
        if (npuSize != null) {
            val want = npuSize.first.toFloat() / npuSize.second
            var w = rect.width(); var h = rect.height()
            if (w.toFloat() / h < want) w = minOf(photo.width, (h * want).roundToInt()) else h = minOf(photo.height, (w / want).roundToInt())
            // the photo edge stopped the widening: trim the other side instead
            if (w.toFloat() / h > want * 1.01f) w = (h * want).roundToInt() else if (w.toFloat() / h < want / 1.01f) h = (w / want).roundToInt()
            val cx = rect.centerX(); val cy = rect.centerY()
            val l = (cx - w / 2).coerceIn(0, photo.width - w); val t = (cy - h / 2).coerceIn(0, photo.height - h)
            rect = Rect(l, t, l + w, t + h)
        }

        val cropPhoto = Bitmap.createBitmap(photo, rect.left, rect.top, rect.width(), rect.height())
        val cropMask = Bitmap.createBitmap(mask, rect.left, rect.top, rect.width(), rect.height())
        val work: Bitmap; val workMask: Bitmap; val box: Rect?; val w: Int; val h: Int
        if (dynamic) {
            val sz = npuSize ?: sizeForPhoto(rect.width(), rect.height(), sdxl)
            w = sz.first; h = sz.second
            work = Bitmap.createScaledBitmap(cropPhoto, w, h, true)
            workMask = Bitmap.createScaledBitmap(cropMask, w, h, true)
            box = null
        } else {
            val (sq, r) = letterbox(cropPhoto)
            work = sq; box = r; w = 512; h = 512
            workMask = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
            Canvas(workMask).drawBitmap(cropMask, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
        }
        val image = toModelInput(work)
        val soft = alphas(soften(workMask, 16))
        var masked: FloatArray? = null
        if (inpaintModel) {
            // The photo the model "sees" around the zone. At 100% change the painted area is hidden
            // (gray), so the model invents something new; with less change it still sees what was
            // there, so it modifies it (same shape, new color/material) instead of replacing it.
            val hard = alphas(workMask)
            val n = w * h
            val keepOld = 1f - change.coerceIn(0f, 1f)
            masked = image.copyOf()
            for (i in 0 until n) if (hard[i] > 127) {
                masked[i] *= keepOld; masked[n + i] *= keepOld; masked[2 * n + i] *= keepOld
            }
        }
        // latent-size mask, a little wider than painted so edges blend
        val lat = Bitmap.createScaledBitmap(soften(workMask, 8), w / 8, h / 8, true)
        val la = alphas(lat)
        val latMask = FloatArray(la.size) { minOf(1f, la[it] / 255f * 1.6f) }
        val softCrop = soften(cropMask, 12)
        return ZonePlan(rect, w, h, box, image, masked, latMask, softCrop)
    }

    /** Puts the redrawn piece back into the full photo, only where painted, with soft edges. */
    private fun compositeZone(photo: Bitmap, plan: ZonePlan, out: Bitmap): Bitmap {
        val piece = Bitmap.createScaledBitmap(unbox(out, plan.box), plan.crop.width(), plan.crop.height(), true)
        val res = photo.copy(Bitmap.Config.ARGB_8888, true)
        val cw = plan.crop.width(); val ch = plan.crop.height()
        val orig = IntArray(cw * ch); res.getPixels(orig, 0, cw, plan.crop.left, plan.crop.top, cw, ch)
        val neu = IntArray(cw * ch); piece.getPixels(neu, 0, cw, 0, 0, cw, ch)
        val am = alphas(plan.softCrop)
        for (i in orig.indices) {
            val t = minOf(1f, am[i] / 255f * 1.3f)
            if (t <= 0f) continue
            val o = orig[i]; val n = neu[i]
            fun mix(s: Int) = (((o shr s) and 0xFF) * (1 - t) + ((n shr s) and 0xFF) * t).roundToInt()
            orig[i] = (0xFF shl 24) or (mix(16) shl 16) or (mix(8) shl 8) or mix(0)
        }
        res.setPixels(orig, 0, cw, plan.crop.left, plan.crop.top, cw, ch)
        return res
    }

    /** Shows the photo with the painted area tinted, so the user sees what will change. */
    private fun showZonePreview(photo: Bitmap) {
        val m = zoneMask ?: return
        val v = photo.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(v).drawBitmap(m, 0f, 0f, Paint().apply { alpha = 110 })
        b.result.setImageBitmap(v)
    }

    /**
     * The models work on 512×512. Instead of cutting the photo, fit all of it inside the square
     * and fill the borders with a soft, blurred stretch of the same photo (so the AI sees matching
     * colors there). Returns the square and where the photo sits in it.
     */
    /** [src] cut to the shape of [w]×[h] (centered) and scaled to it. */
    private fun cropTo(src: Bitmap, w: Int, h: Int): Bitmap {
        val want = w.toFloat() / h
        var cw = src.width; var ch = src.height
        if (cw.toFloat() / ch > want) cw = (ch * want).roundToInt().coerceAtMost(src.width) else ch = (cw / want).roundToInt().coerceAtMost(src.height)
        val cut = Bitmap.createBitmap(src, (src.width - cw) / 2, (src.height - ch) / 2, cw, ch)
        return Bitmap.createScaledBitmap(cut, w, h, true)
    }

    private fun letterbox(src: Bitmap): Pair<Bitmap, Rect> {
        val k = 512f / maxOf(src.width, src.height)
        val w = (src.width * k).roundToInt().coerceIn(1, 512)
        val h = (src.height * k).roundToInt().coerceIn(1, 512)
        val rect = Rect((512 - w) / 2, (512 - h) / 2, (512 - w) / 2 + w, (512 - h) / 2 + h)
        val out = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        val tiny = Bitmap.createScaledBitmap(src, 12, 12, true)
        c.drawBitmap(tiny, null, Rect(0, 0, 512, 512), p)
        tiny.recycle()
        c.drawBitmap(src, null, rect, p)
        return out to rect
    }

    /** Cut the photo's area back out of a square [bmp] (any size) using [rect] from [letterbox]. */
    private fun unbox(bmp: Bitmap, rect: Rect?): Bitmap {
        if (rect == null || (rect.width() >= 512 && rect.height() >= 512)) return bmp
        val k = bmp.width / 512f
        val l = (rect.left * k).roundToInt(); val t = (rect.top * k).roundToInt()
        val w = (rect.width() * k).roundToInt().coerceIn(1, bmp.width - l)
        val h = (rect.height() * k).roundToInt().coerceIn(1, bmp.height - t)
        return Bitmap.createBitmap(bmp, l, t, w, h)
    }

    /** Channel-first RGB floats in [-1, 1], as the VAE encoder expects. */
    private fun toModelInput(bmp: Bitmap): FloatArray {
        val n = bmp.width * bmp.height
        val px = IntArray(n)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val f = FloatArray(3 * n)
        for (i in 0 until n) {
            val p = px[i]
            f[i] = ((p shr 16) and 0xFF) / 127.5f - 1f
            f[n + i] = ((p shr 8) and 0xFF) / 127.5f - 1f
            f[2 * n + i] = (p and 0xFF) / 127.5f - 1f
        }
        return f
    }

    // ---------- generate ----------

    // ---------- prompt ----------

    /** Reads the prompt and the "avoid" text. Weights like (red dress:1.3) are handled by the engine. */
    private fun withPrompts(then: (prompt: String, negative: String) -> Unit) {
        val prompt = b.prompt.text?.toString()?.trim().orEmpty()
        if (prompt.isEmpty()) { b.genStatus.text = getString(R.string.sd_need_prompt); return }
        val negative = if (model.mode == 1) "" else b.negative.text?.toString()?.trim().orEmpty()
        then(prompt, negative)
    }

    /** Only one job at a time: if one is still running (maybe from before), say so and offer to stop it. */
    private fun busyGuard(): Boolean {
        if (!BgWork.busy) return false
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.busy_title)
            .setMessage(getString(R.string.busy_body, BgWork.currentTitle()))
            .setPositiveButton(R.string.stop) { _, _ -> BgWork.onStop?.invoke(); if (SdNative.loadError == null) SdNative.cancel() }
            .setNegativeButton(R.string.busy_wait, null)
            .show()
        return true
    }

    private fun generate() {
        if (busyGuard()) return
        if (simple) { simpleGenerate(); return }
        withPrompts { p, n -> generate(p, n) }
    }

    private fun generate(prompt: String, negative0: String) {
        val m = model
        // a real photo (not in the registry of AI pictures): never undressed, whatever the words or the kind
        val realPhoto = base != null && !baseAi
        if (realPhoto) {
            val typed = listOfNotNull(prompt, b.prompt.text?.toString(), lookEnglish,
                if (::lookInput.isInitialized && lookInput.visibility == View.VISIBLE) lookInput.text?.toString() else null)
            if (kindOverride == EditKind.NUDE || typed.any { ImageOrigin.isNude(it) }) {
                JobLog.add("Origen: orden rechazada, quitar la ropa no se hace en fotos reales")
                lookEnglish = null; kindOverride = null
                showBlocked()
                return
            }
        }
        val negative = safeNegative(negative0, realPhoto)
        if (SdModel.undoHalfBorrow(applicationContext, m.id)) try { SdNative.release() } catch (_: Throwable) { }
        if (m.mode == 1 && base == null) { b.genStatus.text = getString(R.string.sd_need_photo); return }
        if (m.mode == 2 && (base == null || zoneMask == null)) { b.genStatus.text = getString(R.string.sd_need_mask); return }
        SdNative.loadError?.let { b.genStatus.text = getString(R.string.sd_failed, it.toString()); return }

        // the instruction editor (pix2pix) gains nothing past ~20 steps: more only costs time
        // Editar con palabras in two steps: the editor only marks the change, SDXL (NPU) redraws it
        val polishId = if (m.mode == 1 && tool == MODE_EDIT && zoneMask == null &&
            QuickActionsActivity.on(this, "nitido", "q_polish")) EditPolish.pickModel(this) else null
        val polishLook = lookEnglish; lookEnglish = null
        // ropa, fondo, cabeza: the app knows the exact zone and an inpainting model fills it (no editor needed)
        val editKind = if (tool == MODE_EDIT) EditKind.classify(prompt + " " + b.prompt.text?.toString().orEmpty()).let { kindOverride ?: it } else EditKind.WHOLE
        val fillId = if (m.mode == 1 && tool == MODE_EDIT && base != null && zoneMask == null && editKind != EditKind.WHOLE)
            EditPolish.fillModel(this) else null
        if (tool == MODE_EDIT) JobLog.add("Se entiende como: ${getString(editKind.label)}" + (if (kindOverride != null) " (elegido por ti)" else "") +
            (fillId?.let { " · se rellena la zona exacta con ${ModelCatalog.displayName(it)}" } ?: ""))
        kindOverride = null
        // step 1 with DreamLite (reads the photo and the order together) when it is on the phone
        val useDream = fillId == null && m.mode == 1 && tool == MODE_EDIT && base != null && zoneMask == null &&
            QuickActionsActivity.on(this, "nitido", "q_dreamlite") && DreamLite.isReady(this)
        val steps = b.steps.value.roundToInt().let { if (polishId != null) minOf(it, 12) else if (m.mode == 1) minOf(it, 20) else it }
        val gpu = b.backendGroup.checkedButtonId != R.id.sdCpu
        var npuDir = if (b.backendGroup.checkedButtonId == R.id.sdNpu) NpuUnet.dirFor(this, m.id) else null
        if (npuDir != null && base != null && (m.mode != 0 || (zoneMask != null && !SdModel.isDynamic(this, m.id) && NpuUnet.sizes(this, m.id).none { it == 512 to 512 }))) {
            npuDir = null   // photo editors (pix2pix / inpainting) keep using the GPU; painted zones go to the NPU too
            b.genStatus.text = getString(R.string.npu_photo_gpu)
        }
        val npuSizes = if (npuDir != null) NpuUnet.sizes(this, m.id).ifEmpty { listOf(512 to 512) } else emptyList()
        val seed = Random.nextInt(1, Int.MAX_VALUE)
        val out = File(cacheDir, "sd_${System.currentTimeMillis()}.jpg")
        val dynamic = SdModel.isDynamic(this, m.id)
        val sdxl = SdModel.isSdxl(this, m.id)
        var size = chosenSize(dynamic, sdxl)
        var box: Rect? = null
        val photoForZone = base
        val zone = if (photoForZone != null && zoneMask != null)
            planZone(photoForZone, zoneMask!!, dynamic, sdxl, m.mode == 2, b.strength.value / 100f, npuSizes) else null
        if (zone != null && npuDir != null) JobLog.add("Zona en la NPU: ${zone.crop.width()}×${zone.crop.height()} de la foto → ${zone.w}×${zone.h}")
        if (photoForZone != null && zoneMask != null && zone == null) { b.genStatus.text = getString(R.string.mask_empty); return }
        if (zone != null) { size = zone.w to zone.h; box = zone.box }
        val input = if (zone != null) zone.image else base?.let { photo ->
            if (dynamic && npuDir != null) {
                // NPU: the fixed size closest to the photo's shape, the photo trimmed to match it
                val r = photo.width.toFloat() / photo.height
                size = npuSizes.minByOrNull { (w, h) -> Math.abs(Math.log((w.toFloat() / h / r).toDouble())) } ?: (512 to 512)
                toModelInput(cropTo(photo, size.first, size.second))
            } else if (dynamic) {
                // newer models: work directly at the photo's shape
                size = if (m.mode == 1) editorSize(photo.width, photo.height) else sizeForPhoto(photo.width, photo.height, sdxl)
                toModelInput(Bitmap.createScaledBitmap(photo, size.first, size.second, true))
            } else {
                // older square-only models: fit the whole photo inside 512×512
                val (sq, r) = letterbox(photo)
                box = r
                toModelInput(sq)
            }
        }
        if (npuDir != null) {
            // the NPU works at fixed sizes: pick the one with the same shape
            val sizes = npuSizes
            val (w0, h0) = size
            size = sizes.minByOrNull { (w, h) -> Math.abs(w.toFloat() / h - w0.toFloat() / h0) * 10 + Math.abs(w * h - w0 * h0) / 1e6f } ?: (512 to 512)
        }
        // keep the NPU session between pictures; free it when using the GPU/CPU (memory)
        val npu = npuDir?.let { NpuUnet.get(applicationContext, it) }
        if (npu == null) NpuUnet.releaseAll()
        val firstNpu = npu != null && !npu.isCompiled(size.first, size.second)
        val (outW, outH) = size
        val strength = b.strength.value / 100f
        val guidance = b.guidance.value
        val keep = b.keep.value
        val previewMode = if (b.hqTimelapse.isChecked) SdNative.PREVIEW_FULL else SdNative.PREVIEW_FAST
        cancel = false
        stopPlayback()
        frames.clear()
        base?.let { frames.add(it) }
        b.playTimelapse.isEnabled = false
        b.saveTimelapse.isEnabled = false

        b.generate.text = getString(R.string.stop)
        b.modelPick.isEnabled = false
        b.save.isEnabled = false
        b.upscale.isEnabled = false
        b.useResult.isEnabled = false
        b.refine.isEnabled = false
        b.genProgress.progress = 0
        b.genProgress.visibility = View.VISIBLE
        b.genStatus.text = getString(if (firstNpu) R.string.npu_first else R.string.sd_loading)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val t0 = SystemClock.elapsedRealtime()
        startBg(R.string.notif_generating)
        runningMode = tool
        proc.show(getString(R.string.proc_generating), base)
        proc.update(getString(R.string.proc_generating), 0, 1, 0f, 0f)

        JobLog.add("Modelo ${ModelCatalog.displayName(m.id)} · ${if (npu != null) "NPU" else if (gpu) "GPU" else "CPU"} · ${outW}×$outH · $steps pasos · guía ${"%.1f".format(guidance)}")
        JobLog.add("Texto: $prompt")
        if (negative.isNotBlank()) JobLog.add("Negativo: $negative")
        if (useDream) JobLog.add("Editar: paso 1 con DreamLite (lee la foto y la orden juntas)")
        if (polishId != null) JobLog.add("Editar en dos pasos: el editor marca el cambio, luego ${ModelCatalog.displayName(polishId)} lo redibuja · cuánto: ${listOf("suave", "normal", "fuerte")[EditPolish.amount(this)]}")
        // the result's origin: invented from text only, or an edit of a picture that is in the registry
        val textOnly = base == null && zoneMask == null
        val baseWasAi = base != null && baseAi
        job = BgWork.scope.launch {
            var usedSampler = sampler()
            var fellBack = false
            var usePrompt = prompt
            var useNegative = negative
            var filled = false
            val code = withContext(Dispatchers.Default) {
              if (fillId != null) {
                  val photo = base!!.let { p ->
                      val k = 2560f / maxOf(p.width, p.height)
                      if (k < 1f) Bitmap.createScaledBitmap(p, (p.width * k).roundToInt(), (p.height * k).roundToInt(), true) else p
                  }
                  try { SdNative.release() } catch (_: Throwable) { }
                  val r = try {
                      EditPolish.runFill(applicationContext, photo, prompt, polishLook, safeNegative(Negative.english(applicationContext, MODE_EDIT), realPhoto),
                          EditPolish.amount(applicationContext), editKind, fillId, { txt, pct ->
                              BgWork.update(this@GenerateActivity, txt, pct)
                              proc.update(getString(R.string.proc_generating), 0, 1, pct / 100f, pct / 100f, txt)
                              runOnUiThread { b.genProgress.progress = pct * 10; b.genStatus.text = txt }
                          }, { cancel }, { pv -> proc.preview(pv, true); runOnUiThread { b.result.setImageBitmap(pv) } })
                  } catch (t: Throwable) { JobLog.error("Rellenar", t); null }
                  if (cancel) return@withContext SdNative.CANCELLED
                  if (r != null) {
                      out.outputStream().use { r.image.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                      filled = true
                      return@withContext SdNative.OK
                  }
                  JobLog.notice("Editar: el relleno no funcionó; se usa el método anterior")
              }
              if (useDream) {
                  val dc = try {
                      SdNative.release()
                      // the guard: DreamLite sometimes changes the framing (a close-up of a new face, the person
                      // moved); such a result is not used: once more with another seed, then the old editor
                      var r: Bitmap? = null
                      for (attempt in 0..1) {
                          val got = DreamLite.edit(applicationContext, base!!, usePrompt, seed + attempt * 7919, { txt, pct ->
                              BgWork.update(this@GenerateActivity, txt, pct)
                              proc.update(getString(if (polishId != null) R.string.proc_step1 else R.string.proc_generating), 0, if (polishId != null) 2 else 1, pct / 100f, if (polishId != null) pct / 200f else pct / 100f)
                              runOnUiThread { b.genProgress.progress = pct * 10; b.genStatus.text = txt }
                          }, { cancel }, { pv -> proc.preview(pv, true); runOnUiThread { b.result.setImageBitmap(pv) } })
                          val same = framingKept(base!!, got)
                          if (same == null || same >= 0.5f) { r = got; break }
                          JobLog.notice("DreamLite cambió el encuadre (la persona coincide ${(same * 100).roundToInt()} % con tu foto)" +
                              if (attempt == 0) "; lo intento otra vez con otra semilla" else "; se usa el editor anterior")
                      }
                      if (r == null) throw IllegalStateException("DreamLite cambió el encuadre dos veces")
                      out.outputStream().use { Bitmap.createScaledBitmap(r, outW, outH, true).compress(Bitmap.CompressFormat.PNG, 100, it) }
                      SdNative.OK
                  } catch (e: InterruptedException) { SdNative.CANCELLED
                  } catch (t: Throwable) {
                      JobLog.error("DreamLite (se usa el editor anterior)", t); -1
                  }
                  if (dc == SdNative.OK || dc == SdNative.CANCELLED) return@withContext dc
              }
              var attempt = 0
              var c: Int
              SdNative.setNpu(npu)
              SdNative.setGpuOptions(0, 0)   // tested: wide tuning / normal memory gave the same speed
              do {
                c = try {
                    SdModel.ensureEncoder(this@GenerateActivity, m.id)
                    GpuMeter.track(gpu) { SdNative.generate(
                        SdModel.dir(this@GenerateActivity, m.id).absolutePath,
                        cacheDir.absolutePath,
                        if (gpu) SdNative.BACKEND_OPENCL else SdNative.BACKEND_CPU,
                        m.mode, dynamic, outW, outH, steps, seed, out.absolutePath,
                        // CLIP reads lowercase (the official tokenizer lowers it; MNN's doesn't)
                        usePrompt.lowercase(java.util.Locale.ROOT), useNegative.lowercase(java.util.Locale.ROOT),
                        input, strength, guidance, keep, zone?.masked, zone?.latMask, previewMode, usedSampler,
                        object : SdNative.Listener {
                            override fun onProgress(pct: Int) {
                                val el = (SystemClock.elapsedRealtime() - t0) / 1000
                                val txt = getString(R.string.sd_progress, pct, el)
                                BgWork.update(this@GenerateActivity, txt, pct)
                                proc.update(getString(if (polishId != null) R.string.proc_step1 else R.string.proc_generating), 0, if (polishId != null) 2 else 1, pct / 100f, if (polishId != null) pct / 200f else pct / 100f)
                                runOnUiThread {
                                    b.genProgress.progress = pct * 10
                                    b.genStatus.text = txt
                                }
                            }

                            override fun onPreview(rgb: ByteArray, width: Int, height: Int) {
                                val bmp = unbox(TimelapseVideo.toBitmap(rgb, width, height), box)
                                proc.preview(bmp, true)
                                runOnUiThread {
                                    frames.add(bmp)
                                    b.result.setImageBitmap(bmp)
                                }
                            }

                            override fun onCool() {
                                HeatGuard.waitIfHot(this@GenerateActivity, { SdNative.isCancelled() }) { why ->
                                    val txt = getString(R.string.sd_cooling, why)
                                    BgWork.update(this@GenerateActivity, txt, BgWork.jobPct)
                                    runOnUiThread { b.genStatus.text = txt }
                                }
                            }
                        }
                    ) }
                } catch (t: Throwable) {
                    JobLog.error("Crear falló", t)
                    -1
                }
                if (c != 0) try { SdNative.lastTimings().takeIf { it.isNotEmpty() }?.let { JobLog.add("Detalle: $it") } } catch (_: Throwable) {}
                // the text reader overflowed: once more with plain text (no weights, no accents or symbols)
                if (c == SdNative.BAD_TEXT && attempt == 0 && !cancel) {
                    usePrompt = plainText(prompt); useNegative = plainText(negative)
                    JobLog.notice("Reintento con el texto simplificado: «$usePrompt»")
                    runOnUiThread { b.genStatus.text = getString(R.string.sd_retry_text) }
                    attempt++
                    continue
                }
                // the decoder file gives invalid numbers even on the CPU: borrow another SD 1.5 model's and retry
                if (c == 10 && !cancel && SdModel.borrowDecoder(applicationContext, m.id)) {
                    SdNative.release()
                    runOnUiThread { b.genStatus.text = getString(R.string.sd_retry_decoder) }
                    attempt++
                    continue
                }
                // numbers overflowed with DPM++: try once more with the classic method
                if (c == SdNative.BAD_UNET && usedSampler == SdNative.SAMPLER_DPM && attempt == 0 && !cancel) {
                    usedSampler = SdNative.SAMPLER_PLMS
                    fellBack = true
                    runOnUiThread { frames.clear(); base?.let { frames.add(it) }; b.genStatus.text = getString(R.string.sd_retry_plms) }
                    attempt++
                    continue
                }
                break
              } while (true)
              SdNative.setNpu(null)
              c
            }
            val ok = code == 0 && out.exists() && out.length() > 0
            if (ok && zone != null && photoForZone != null) {
                // paste the redrawn area back into the whole photo
                withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(out.absolutePath)?.let { piece ->
                        val full = compositeZone(photoForZone, zone, piece)
                        out.outputStream().use { full.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    }
                }
            } else if (ok && !filled && photoForZone != null && zone == null && QuickActionsActivity.on(this@GenerateActivity, "nitido", "q_keep") &&
                (tool == MODE_EDIT || SdModel.readMode(this@GenerateActivity, model.id) == 1)) {
                // Editar con palabras: only what really changed comes from the edit; the rest stays the
                // original photo at its full size (the editor works at 512 px and bends what it redraws)
                withContext(Dispatchers.Default) {
                    // SDXL on the NPU and its readers take several GB: give them back before the full-size
                    // mix and the face model (Android closed the app here on a big photo)
                    try { NpuUnet.releaseAll(); if (SdNative.loadError == null) SdNative.release() } catch (t: Throwable) { }
                    JobLog.add("Editar: modelo liberado para mezclar · " + JobLog.deviceLine(applicationContext).substringAfter("memoria libre ").let { "memoria libre $it" })
                    BitmapFactory.decodeFile(out.absolutePath)?.let { sq ->
                        val cut = if (box != null) unbox(sq, box) else sq
                        val big = photoForZone.let { p ->
                            val k = 2560f / maxOf(p.width, p.height)
                            if (k < 1f) Bitmap.createScaledBitmap(p, (p.width * k).roundToInt(), (p.height * k).roundToInt(), true) else p
                        }
                        val polished = if (polishId != null) try {
                            val neg = safeNegative(Negative.english(applicationContext, MODE_EDIT), realPhoto)
                            EditPolish.run(applicationContext, big, cut, prompt, polishLook, neg, EditPolish.amount(applicationContext), { txt, pct ->
                                BgWork.update(this@GenerateActivity, txt, pct)
                                proc.update(getString(R.string.proc_polishing), 1, 2, pct / 100f, 0.5f + pct / 200f, txt)
                                runOnUiThread { b.genStatus.text = txt; b.genProgress.visibility = View.VISIBLE; b.genProgress.progress = pct * 10 }
                            }, { cancel }, { pv -> proc.preview(pv, true); runOnUiThread { b.result.setImageBitmap(pv) } }, polishId)
                        } catch (t: Throwable) { JobLog.error("Pulir con SDXL", t); null } else null
                        val r = if (polished != null) null else try { EditBlend.keepUnchanged(applicationContext, big, cut, QuickActionsActivity.on(applicationContext, "nitido", "q_editfaces")) } catch (t: Throwable) {
                            JobLog.error("Editar: mezcla con la original", t); null
                        }
                        out.outputStream().use { (polished?.image ?: r?.image ?: cut).compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    }
                }
            } else if (ok && box != null) {
                // keep only the photo's own area, at its own shape
                withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(out.absolutePath)?.let { sq ->
                        val cut = unbox(sq, box)
                        out.outputStream().use { cut.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    }
                }
            }
            proc.hide()
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.generate.text = getString(R.string.sd_generate)
            b.modelPick.isEnabled = true
            b.genProgress.visibility = View.INVISIBLE
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            runningMode = null
            renderSimple()
            BgWork.finish(this@GenerateActivity, when {
                ok -> getString(R.string.notif_done_image)
                code == SdNative.CANCELLED -> null
                else -> getString(R.string.notif_failed)
            })
            if (ok) {
                val shown = BitmapFactory.decodeFile(out.absolutePath)
                b.result.setImageBitmap(shown)
                lastImage = out
                lastAi = resultIsAi(textOnly, baseWasAi)
                prefs.edit().putBoolean("last_result_ai", lastAi).apply()
                if (lastAi) withContext(Dispatchers.IO) { ImageOrigin.register(applicationContext, out) }
                showOrigin(lastAi)
                JobLog.add(if (lastAi) "Origen: resultado registrado como imagen IA" else "Origen: el resultado no se registra (no es solo desde texto)")
                resultBmp = shown; adjust = PhotoAdjust.Values(); savedUri = null
                if (simple && Prefs.autosave(this@GenerateActivity) && shown != null) {
                    val name = (if (tool == MODE_EDIT) "nitido_editada_" else "nitido_ia_") + System.currentTimeMillis() / 1000
                    savedUri = withContext(Dispatchers.IO) { Gallery.saveImage(applicationContext, shown, name, ai = lastAi) }
                }
                prefs.edit().putString("last_result", out.absolutePath).apply()
                b.save.isEnabled = true
                b.upscale.isEnabled = true
                b.useResult.isEnabled = true
                b.refine.isEnabled = true
                b.playTimelapse.isEnabled = frames.size > 1
                b.saveTimelapse.isEnabled = frames.size > 1
                val gpuOpt = ""
                b.genStatus.text = if (simple) listOfNotNull(getString(R.string.simple_made, secs),
                        getString(R.string.simple_saved_auto).takeIf { savedUri != null },
                        getString(R.string.origin_registered).takeIf { lastAi && textOnly }).joinToString(" · ")
                    else getString(R.string.sd_done, secs, if (npu != null) "NPU" else if (gpu) "GPU" else "CPU", seed) + gpuOpt +
                    (if (npu != null) "\n" + listOfNotNull(npu.stepSummary(), npu.report).joinToString(" · ") else "") +
                    (try { SdNative.lastTimings().takeIf { it.isNotEmpty() }?.let { "\n$it" } ?: "" } catch (_: Throwable) { "" }) +
                    (if (fellBack) "\n" + getString(R.string.sd_used_plms) else "")
                // the screen may have been rebuilt meanwhile (rotation, leaving the app): keep the line
                prefs.edit().putString("last_status", b.genStatus.text.toString()).apply()
                for (l in b.genStatus.text.toString().split("\n")) JobLog.add(l)
                JobLog.save(this@GenerateActivity)
                renderSimple()
            } else {
                val why = when (code) {
                    2 -> getString(R.string.sd_err_load)
                    3 -> getString(R.string.sd_err_run)
                    4 -> getString(R.string.sd_no_encoder)
                    5 -> getString(R.string.sd_err_size)
                    6 -> getString(R.string.cancelled)
                    7 -> getString(R.string.sd_bad_text)
                    8 -> getString(R.string.sd_bad_photo)
                    9 -> getString(R.string.sd_bad_unet, if (gpu) "GPU" else "CPU")
                    10 -> getString(R.string.sd_bad_decode)
                    11 -> getString(R.string.npu_failed, npu?.lastError ?: "")
                    else -> getString(R.string.sd_err_internal, code)
                }
                b.genStatus.text = getString(R.string.sd_failed, why)
                if (code == SdNative.CANCELLED) JobLog.add(why) else JobLog.error(b.genStatus.text.toString())
                JobLog.save(this@GenerateActivity)
                renderSimple()
                val damaged = code == SdNative.BAD_TEXT &&
                    (try { SdNative.lastTimings() } catch (_: Throwable) { "" }).contains("en la CPU también inválido")
                if (damaged) {
                    // the same file gives invalid numbers on the GPU and on the CPU: the model's files on
                    // the phone are damaged (they are fine on the server); offer to download it again
                    JobLog.notice("El modelo ${ModelCatalog.displayName(m.id)} parece dañado en el teléfono: se ofrece volver a descargarlo")
                    com.google.android.material.dialog.MaterialAlertDialogBuilder(this@GenerateActivity)
                        .setTitle(R.string.damaged_title)
                        .setMessage(getString(R.string.damaged_body, ModelCatalog.displayName(m.id)))
                        .setPositiveButton(R.string.damaged_redownload) { _, _ ->
                            SdModel.delete(this@GenerateActivity, m.id)
                            JobLog.add("Modelo borrado para descargarlo de nuevo: ${m.id}")
                            refreshModel(); download()
                        }
                        .setNegativeButton(R.string.close, null).show()
                } else if (simple && code != SdNative.CANCELLED) Ui.failed(this@GenerateActivity, if (fellBack) 2 else 1) { generate() }
            }
        }
    }

    /** Text without prompt weights "(x:1.4)", accents or symbols: what any text reader handles. */
    private fun plainText(t: String): String {
        val noWeights = t.replace(Regex(""":\s*[0-9.]+\s*\)"""), ")").replace("(", "").replace(")", "")
        val ascii = java.text.Normalizer.normalize(noWeights, java.text.Normalizer.Form.NFD).replace(Regex("""\p{M}+"""), "")
        return ascii.replace(Regex("""[^A-Za-z0-9 ,.'-]"""), " ").replace(Regex("""\s+"""), " ").trim()
    }

    private fun sampler() =
        if (b.samplerGroup.checkedButtonId == R.id.smpPlms) SdNative.SAMPLER_PLMS else SdNative.SAMPLER_DPM

    // ---------- refine detail ----------

    /**
     * "Hires fix" by tiles: enlarge the last result ×2 with Real-ESRGAN, then redraw it in
     * overlapping 512×512 pieces with the same prompt and little change, and blend the pieces.
     * Each piece gets the model's full resolution, so real detail appears (skin, hair, texture).
     */
    private fun refine() { if (!busyGuard()) withPrompts { p, n -> refine(p, n) } }

    private fun refine(prompt: String, negative0: String) {
        val m = model
        val f = lastImage ?: return
        // Refinar redraws the last result: the same rule as Editar when it is not an AI picture
        val realPhoto = !lastAi
        if (realPhoto && (ImageOrigin.isNude(prompt) || ImageOrigin.isNude(b.prompt.text?.toString().orEmpty()))) {
            JobLog.add("Origen: Refinar rechazado, quitar la ropa no se hace en fotos reales")
            showBlocked(); return
        }
        val negative = safeNegative(negative0, realPhoto)
        val refinedAi = lastAi && ImageOrigin.inheritOn(this)
        if (m.mode == 1) { b.genStatus.text = getString(R.string.sd_refine_editor); return }
        SdNative.loadError?.let { b.genStatus.text = getString(R.string.sd_failed, it.toString()); return }
        val steps = b.steps.value.roundToInt().coerceAtMost(60)
        val guidance = b.guidance.value
        val gpu = b.backendGroup.checkedButtonId != R.id.sdCpu
        val smp = sampler()
        val seed0 = Random.nextInt(1, Int.MAX_VALUE / 2)
        val dynamic = SdModel.isDynamic(this, m.id)
        // SDXL redraws pieces of 768 px: at 1024 its photo reader needs more memory than the phone has
        val T = if (SdModel.isSdxl(this, m.id)) 768 else 512
        val overlap = OVERLAP * T / 512
        // the pieces are 512×512, exactly the NPU's square: redraw them there when NPU is chosen
        val npuDir = if (b.backendGroup.checkedButtonId == R.id.sdNpu && m.mode == 0 && T == 512 &&
            512 to 512 in NpuUnet.sizes(this, m.id).ifEmpty { listOf(512 to 512) }) NpuUnet.dirFor(this, m.id) else null
        if (npuDir == null) NpuUnet.releaseAll()
        cancel = false

        setRefineBusy(true)
        b.genStatus.text = getString(R.string.sd_refine_upscaling)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val t0 = SystemClock.elapsedRealtime()
        startBg(R.string.notif_refining)
        proc.show(getString(R.string.proc_refining), BitmapFactory.decodeFile(f.absolutePath))
        proc.update(getString(R.string.sd_refine_upscaling).trimEnd('…', '.'), 0, 2, 0f, 0f)

        job = BgWork.scope.launch {
            val result = withContext(Dispatchers.Default) {
                try {
                    val src = BitmapFactory.decodeFile(f.absolutePath) ?: return@withContext null
                    // Free the image model's GPU memory first: having it and Real-ESRGAN on the GPU
                    // at the same time can run the phone out of memory.
                    if (SdNative.loadError == null) SdNative.release()
                    System.gc()
                    // 1) enlarge ×2 (Real-ESRGAN, on its own thread for the GPU delegate)
                    var big = java.util.concurrent.Executors.newSingleThreadExecutor().let { ex ->
                        try {
                            ex.submit<Bitmap?> {
                                Upscaler(applicationContext, if (gpu) Engine.GPU else Engine.CPU).use { up ->
                                    up.upscale(src, 2, {}, { cancel })
                                }
                            }.get()
                        } finally { ex.shutdown() }
                    } ?: return@withContext null
                    if (minOf(big.width, big.height) < T) {
                        val k = T.toFloat() / minOf(big.width, big.height)
                        big = Bitmap.createScaledBitmap(big, (big.width * k).roundToInt(), (big.height * k).roundToInt(), true)
                    }
                    val W = big.width; val H = big.height
                    val srcPx = IntArray(W * H); big.getPixels(srcPx, 0, W, 0, 0, W, H)
                    val acc = FloatArray(W * H * 3); val wsum = FloatArray(W * H)
                    val xs = tilePositions(W, T, overlap); val ys = tilePositions(H, T, overlap)
                    val total = xs.size * ys.size
                    var n = 0
                    val tileFile = File(cacheDir, "refine_tile.jpg")
                    val dir = SdModel.dir(this@GenerateActivity, m.id).absolutePath
                    SdModel.ensureEncoder(this@GenerateActivity, m.id)
                    val npu = npuDir?.let { NpuUnet.get(applicationContext, it) }
                    SdNative.setNpu(npu)
                    try { for (ty in ys) for (tx in xs) {
                        if (cancel) return@withContext null
                        n++
                        val el = (SystemClock.elapsedRealtime() - t0) / 1000
                        val txt = getString(R.string.sd_refine_tile, n, total, el)
                        BgWork.update(this@GenerateActivity, txt, (n - 1) * 100 / total)
                        runOnUiThread {
                            b.genStatus.text = txt
                            b.genProgress.progress = ((n - 1) * 1000) / total
                        }
                        val pieceTxt = getString(R.string.proc_piece, n, total)
                        val redraw = getString(R.string.proc_refining)
                        val tile = Bitmap.createBitmap(big, tx, ty, T, T)
                        val code = GpuMeter.track(gpu) { SdNative.generate(
                            dir, cacheDir.absolutePath, if (gpu) SdNative.BACKEND_OPENCL else SdNative.BACKEND_CPU,
                            0, dynamic, T, T, steps, seed0 + n, tileFile.absolutePath, prompt, negative,
                            toModelInput(tile), REFINE_STRENGTH, guidance, 1.5f, null, null, SdNative.PREVIEW_NONE, smp,
                            object : SdNative.Listener {
                                override fun onProgress(pct: Int) {
                                    runOnUiThread { b.genProgress.progress = ((n - 1) * 1000 + pct * 10) / total }
                                    val frac = (n - 1 + pct / 100f) / total
                                    proc.update(redraw, 1, 2, frac, 0.1f + 0.9f * frac, pieceTxt)
                                }
                                override fun onPreview(rgb: ByteArray, width: Int, height: Int) {}
                            }) }
                        if (code == SdNative.CANCELLED || cancel) return@withContext null
                        if (code == 11) throw IllegalStateException("NPU: " + (npu?.lastError ?: ""))
                        if (code != 0) throw IllegalStateException("código $code")
                        val out = BitmapFactory.decodeFile(tileFile.absolutePath) ?: throw IllegalStateException("sin imagen")
                        val px = IntArray(T * T); out.getPixels(px, 0, T, 0, 0, T, T)
                        for (y in 0 until T) for (x in 0 until T) {
                            // feather toward tile edges, except where the tile touches the picture edge
                            val dl = if (tx == 0) 1e4f else x.toFloat()
                            val dr = if (tx + T >= W) 1e4f else (T - 1 - x).toFloat()
                            val dt = if (ty == 0) 1e4f else y.toFloat()
                            val db = if (ty + T >= H) 1e4f else (T - 1 - y).toFloat()
                            val w = (minOf(minOf(dl, dr), minOf(dt, db)) / overlap).coerceIn(0.02f, 1f)
                            val i = (ty + y) * W + (tx + x)
                            val c = px[y * T + x]
                            acc[i * 3] += ((c shr 16) and 0xFF) * w
                            acc[i * 3 + 1] += ((c shr 8) and 0xFF) * w
                            acc[i * 3 + 2] += (c and 0xFF) * w
                            wsum[i] += w
                        }
                        runOnUiThread { b.result.setImageBitmap(out) }   // the piece just redrawn
                        proc.preview(out, true)
                    } } finally { SdNative.setNpu(null) }
                    val outPx = IntArray(W * H)
                    for (i in 0 until W * H) {
                        val w = wsum[i]
                        outPx[i] = if (w <= 0f) srcPx[i] else android.graphics.Color.rgb(
                            (acc[i * 3] / w).roundToInt().coerceIn(0, 255),
                            (acc[i * 3 + 1] / w).roundToInt().coerceIn(0, 255),
                            (acc[i * 3 + 2] / w).roundToInt().coerceIn(0, 255))
                    }
                    val done = Bitmap.createBitmap(outPx, W, H, Bitmap.Config.ARGB_8888)
                    val file = File(cacheDir, "sd_refined_${System.currentTimeMillis()}.jpg")
                    file.outputStream().use { done.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    file to done
                } catch (t: Throwable) {
                    android.util.Log.e("Nitido", "refine failed", t)
                    JobLog.error("Refinar falló", t)
                    runOnUiThread { b.genStatus.text = getString(R.string.sd_refine_failed, t.message ?: t.javaClass.simpleName) }
                    null
                }
            }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            proc.hide()
            setRefineBusy(false)
            b.genProgress.visibility = View.INVISIBLE
            BgWork.finish(this@GenerateActivity, when {
                result != null -> getString(R.string.notif_done_image)
                cancel -> null
                else -> getString(R.string.notif_failed)
            })
            if (result != null) {
                lastImage = result.first
                lastAi = refinedAi
                if (lastAi) withContext(Dispatchers.IO) { ImageOrigin.register(applicationContext, result.first) }
                prefs.edit().putString("last_result", result.first.absolutePath).putBoolean("last_result_ai", lastAi).apply()
                showOrigin(lastAi)
                b.result.setImageBitmap(result.second)
                val secs = (SystemClock.elapsedRealtime() - t0) / 1000
                b.genStatus.text = getString(R.string.sd_refine_done, result.second.width, result.second.height, secs) +
                    if (npuDir != null) " · NPU" else if (gpu) " · GPU" else " · CPU"
            } else if (cancel) {
                b.genStatus.text = getString(R.string.cancelled)
            }
        }
    }

    /** Start positions of [t]-px tiles covering [len] with at least [overlap] px of overlap. */
    private fun tilePositions(len: Int, t: Int, overlap: Int): List<Int> {
        if (len <= t) return listOf(0)
        val n = Math.ceil((len - t).toDouble() / (t - overlap)).toInt() + 1
        return (0 until n).map { ((len - t) * it.toFloat() / (n - 1)).roundToInt() }
    }

    private fun setRefineBusy(busy: Boolean) {
        b.generate.isEnabled = !busy
        b.modelPick.isEnabled = !busy
        b.refine.text = getString(if (busy) R.string.stop else R.string.sd_refine_short)
        b.save.isEnabled = !busy
        b.upscale.isEnabled = !busy
        b.useResult.isEnabled = !busy
        b.genProgress.progress = 0
        b.genProgress.visibility = if (busy) View.VISIBLE else View.INVISIBLE
    }

    private fun save() {
        val f = lastImage ?: return
        val adj = adjust
        if (savedUri != null && adj.isNeutral) { b.genStatus.text = getString(R.string.simple_saved_auto); return }
        val app = applicationContext
        val ai = lastAi
        lifecycleScope.launch {
            val uri = withContext(Dispatchers.IO) {
                val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return@withContext null
                val out = if (adj.isNeutral) bmp else PhotoAdjust.apply(bmp, adj) ?: bmp
                Gallery.saveImage(app, out, "nitido_ia_${System.currentTimeMillis() / 1000}", savedUri, ai = ai)
            }
            if (uri != null && adj.isNeutral) savedUri = uri
            b.genStatus.text = getString(if (uri != null) R.string.saved else R.string.err_save)
        }
    }

    companion object {
        private const val REFINE_STRENGTH = 0.32f
        private const val OVERLAP = 96
        const val EXTRA_MODE = "mode"
        /** Inicio's two tools on this screen: Crear imagen and Editar con palabras. */
        const val MODE_CREATE = "create"
        const val MODE_EDIT = "edit"
        /** The tool of the picture being made now (Inicio shows "Trabajando…" on its tile). */
        @Volatile var runningMode: String? = null
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        intent.getStringExtra(SelfTest.EXTRA)?.let { p -> intent.removeExtra(SelfTest.EXTRA); lifecycleScope.launch { autoTest(p) } }
    }

    /** Autoprueba: a short text (and a made-up photo / painted zone) through the real button. */
    private suspend fun autoTest(arg: String) {
        if (job?.isActive == true || BgWork.busy) { SelfTest.screenDone(this, false, "OMITIDA: había un trabajo en curso"); return }
        if (!SdModel.isReady(this, model.id)) { SelfTest.screenDone(this, false, "OMITIDA: el modelo ${model.id} no está descargado"); return }
        val zone = arg.startsWith("zone:")
        val path = arg.removePrefix("zone:")
        if (tool == MODE_EDIT || zone) {
            loadBase(Uri.fromFile(File(path)))
            if (!SelfTest.waitUntil(20_000) { base != null }) { SelfTest.screenDone(this, false, "no abrió la foto · ${b.genStatus.text}"); return }
        }
        if (zone) {
            val bb = base!!
            val m = Bitmap.createBitmap(bb.width, bb.height, Bitmap.Config.ARGB_8888)
            android.graphics.Canvas(m).drawCircle(bb.width * 0.6f, bb.height * 0.6f, bb.height * 0.2f,
                android.graphics.Paint().apply { color = android.graphics.Color.WHITE })
            zoneMask = m
            updatePhotoUi()
        }
        val old = b.prompt.text?.toString().orEmpty()
        b.prompt.setText(when { tool == MODE_EDIT -> "que esté nevando"; zone -> "un gato sentado"; else -> "una manzana roja sobre una mesa de madera" })
        ideaEnglish = null
        val before = resultBmp
        val t0 = SystemClock.elapsedRealtime()
        b.generate.performClick()
        val started = SelfTest.waitUntil(60_000) { job?.isActive == true }
        if (started) {
            SelfTest.waitUntil(9 * 60_000) { job?.isActive != true }
            if (job?.isActive == true) { stopWork(); SelfTest.waitUntil(20_000) { job?.isActive != true } }
            kotlinx.coroutines.delay(1500)   // the automatic save
        }
        val r = resultBmp?.takeIf { it !== before }
        b.prompt.setText(old)
        val bad = r?.let { SelfTest.pictureProblem(it) }
        val detail = "${model.id} · " + (if (r != null) "${r.width}×${r.height} · " else if (started) "sin imagen · " else "no empezó · ") +
            "${(SystemClock.elapsedRealtime() - t0) / 1000} s · ${b.genStatus.text}" + (bad?.let { " · $it" } ?: "")
        val uri = savedUri.takeIf { r != null }
        if (r != null) { savedUri = null }
        SelfTest.screenDone(this, r != null && bad == null, detail, uri)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPlayback()
        // work keeps going in the background; it can be stopped from the notification
        if (!BgWork.busy) {
            NpuUnet.releaseAll()   // free the NPU's memory when leaving Crear
            if (SdNative.loadError == null && isFinishing) SdNative.release()   // and the model kept on the GPU
        }
    }
}
