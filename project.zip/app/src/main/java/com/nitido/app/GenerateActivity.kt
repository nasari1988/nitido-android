package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityGenerateBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt
import kotlin.random.Random

class GenerateActivity : AppCompatActivity() {

    private lateinit var b: ActivityGenerateBinding
    private var job: Job? = null
    @Volatile private var cancel = false
    @Volatile private var process: Process? = null
    private var lastImage: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityGenerateBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.back.setOnClickListener { finish() }
        b.download.setOnClickListener { if (job?.isActive == true) stop() else download() }
        b.generate.setOnClickListener { if (job?.isActive == true) stop() else generate() }
        b.save.setOnClickListener { save() }
        b.upscale.setOnClickListener {
            val f = lastImage ?: return@setOnClickListener
            startActivity(Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_PATH, f.absolutePath)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        b.steps.addOnChangeListener { _, v, _ -> b.stepsValue.text = v.roundToInt().toString() }
        b.stepsValue.text = b.steps.value.roundToInt().toString()
        b.deleteModel.setOnClickListener {
            if (job?.isActive == true) return@setOnClickListener
            SdModel.delete(this); refreshState()
        }
        b.save.isEnabled = false
        b.upscale.isEnabled = false
        refreshState()
    }

    private fun refreshState() {
        val ready = SdModel.isReady(this)
        b.setupCard.visibility = if (ready) View.GONE else View.VISIBLE
        b.createPanel.visibility = if (ready) View.VISIBLE else View.GONE
        b.deleteModel.visibility = if (ready) View.VISIBLE else View.GONE
        if (!ready) b.dlStatus.text = getString(R.string.sd_dl_intro)
    }

    private fun stop() {
        cancel = true
        process?.destroy()
    }

    private fun download() {
        cancel = false
        b.download.text = getString(R.string.stop)
        b.dlProgress.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        job = lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    SdModel.download(this@GenerateActivity, { cancel }) { done ->
                        runOnUiThread {
                            val p = done.toFloat() / SdModel.TOTAL
                            b.dlProgress.progress = (p * 1000).roundToInt()
                            b.dlStatus.text = getString(R.string.sd_dl_progress, done / 1_000_000, SdModel.TOTAL / 1_000_000)
                        }
                    }
                    null
                } catch (e: InterruptedException) {
                    getString(R.string.sd_dl_paused)
                } catch (t: Throwable) {
                    getString(R.string.sd_dl_error, t.message ?: t.javaClass.simpleName)
                }
            }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.download.text = getString(R.string.sd_download)
            b.dlProgress.visibility = View.INVISIBLE
            if (err != null) b.dlStatus.text = err else refreshState()
        }
    }

    private fun generate() {
        val prompt = b.prompt.text?.toString()?.trim().orEmpty()
        if (prompt.isEmpty()) { b.genStatus.text = getString(R.string.sd_need_prompt); return }
        val steps = b.steps.value.roundToInt()
        val gpu = b.backendGroup.checkedButtonId != R.id.sdCpu
        val seed = Random.nextInt(1, Int.MAX_VALUE)
        val out = File(cacheDir, "sd_${System.currentTimeMillis()}.jpg")
        val exe = File(applicationInfo.nativeLibraryDir, "libsddemo.so")

        cancel = false
        b.generate.text = getString(R.string.stop)
        b.save.isEnabled = false
        b.upscale.isEnabled = false
        b.genProgress.progress = 0
        b.genProgress.visibility = View.VISIBLE
        b.genStatus.text = getString(R.string.sd_loading)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val t0 = SystemClock.elapsedRealtime()

        job = lifecycleScope.launch {
            val log = StringBuilder()
            val ok = withContext(Dispatchers.IO) {
                try {
                    val pb = ProcessBuilder(
                        exe.absolutePath,
                        SdModel.dir(this@GenerateActivity).absolutePath,
                        "0",                       // model type: SD 1.5
                        "1",                       // memory mode: load everything up front
                        if (gpu) "3" else "0",     // MNN_FORWARD_OPENCL = 3, CPU = 0
                        steps.toString(),
                        seed.toString(),
                        out.absolutePath,
                        prompt
                    ).directory(cacheDir).redirectErrorStream(true)
                    pb.environment()["LD_LIBRARY_PATH"] = applicationInfo.nativeLibraryDir
                    val p = pb.start()
                    process = p
                    p.inputStream.bufferedReader().useLines { lines ->
                        lines.forEach { line ->
                            log.appendLine(line)
                            if (log.length > 8000) log.delete(0, log.length - 6000)
                            val m = PROGRESS.find(line)
                            if (m != null) {
                                val pct = m.groupValues[1].toInt()
                                val el = (SystemClock.elapsedRealtime() - t0) / 1000
                                runOnUiThread {
                                    b.genProgress.progress = pct * 10
                                    b.genStatus.text = getString(R.string.sd_progress, pct, el)
                                }
                            }
                        }
                    }
                    val code = p.waitFor()
                    process = null
                    code == 0 && out.exists() && out.length() > 0
                } catch (t: Throwable) {
                    log.appendLine(t.toString())
                    false
                }
            }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            b.generate.text = getString(R.string.sd_generate)
            b.genProgress.visibility = View.INVISIBLE
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000
            if (ok) {
                val bmp = BitmapFactory.decodeFile(out.absolutePath)
                b.result.setImageBitmap(bmp)
                lastImage = out
                b.save.isEnabled = true
                b.upscale.isEnabled = true
                b.genStatus.text = getString(R.string.sd_done, secs, if (gpu) "GPU" else "CPU", seed)
            } else if (cancel) {
                b.genStatus.text = getString(R.string.cancelled)
            } else {
                val tail = log.lines().filter { it.isNotBlank() }.takeLast(6).joinToString("\n")
                b.genStatus.text = getString(R.string.sd_failed, tail)
            }
        }
    }

    private fun save() {
        val f = lastImage ?: return
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return@withContext false
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "nitido_ia_${System.currentTimeMillis() / 1000}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    true
                } catch (t: Throwable) { false }
            }
            b.genStatus.text = getString(if (ok) R.string.saved else R.string.err_save)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cancel = true
        process?.destroy()
    }

    companion object {
        private val PROGRESS = Regex("""Progress:\s*(\d+)""")
    }
}
