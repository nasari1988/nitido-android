package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import java.io.File
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Editar con palabras, second step. The instruction editor (pix2pix) is good at knowing WHAT to change
 * and WHERE, but its own drawing is small and bends bodies. So its result is used only as a draft:
 * the app finds where it changed the photo, and an SDXL model (on the NPU) redraws just that area on
 * the ORIGINAL photo, starting from the editor's colors and shapes there. Outside it, nothing changes.
 * The face stays the original unless the order talks about it.
 */
object EditPolish {

    class Result(val image: Bitmap, val changedPct: Int, val whole: Boolean)

    /** Amount buttons: Suave, Normal, Fuerte. */
    const val SOFT = 0
    const val NORMAL = 1
    const val STRONG = 2

    fun amount(ctx: Context) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE).getInt("edit_amount", NORMAL)
    fun setAmount(ctx: Context, v: Int) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE).edit().putInt("edit_amount", v).apply()

    /** The SDXL model with an NPU version to polish with (photographic and Lightning first), or null. */
    fun pickModel(ctx: Context): String? = Reimagine.models(ctx).firstOrNull()

    private val FACE_WORDS = Regex("""\b(face|faces|eyes|smile|smiling|mouth|lips|makeup|expression|beard|mustache|nose|teeth|older|younger|age)\b""", RegexOption.IGNORE_CASE)

    /** What SDXL should draw, from the order ("turn the dress into sportswear" → "sportswear"). */
    fun describe(order: String): String {
        val o = order.trim().trimEnd('.')
        val rules = listOf(
            Regex("""^(turn|change|transform|convert)\s+.+?\s+(into|to)\s+(.+)$""", RegexOption.IGNORE_CASE) to 3,
            Regex("""^replace\s+.+?\s+with\s+(.+)$""", RegexOption.IGNORE_CASE) to 1,
            Regex("""^make\s+(it|him|her|them|the \w+)\s+(.+)$""", RegexOption.IGNORE_CASE) to 2,
            Regex("""^give\s+(him|her|them|it)\s+(.+)$""", RegexOption.IGNORE_CASE) to 2,
            Regex("""^(add|put)\s+(.+?)(\s+on\s+.+)?$""", RegexOption.IGNORE_CASE) to 2,
        )
        for ((r, g) in rules) r.find(o)?.let { m -> return m.groupValues[g].trim() }
        return o
    }

    /** What was there before, to push away from it ("turn the dress into…" → "dress"). */
    fun before(order: String): String? {
        val o = order.trim()
        Regex("""^(turn|change|transform|convert|replace)\s+(the\s+|his\s+|her\s+|their\s+)?(.+?)\s+(into|to|with)\s+""", RegexOption.IGNORE_CASE)
            .find(o)?.let { return it.groupValues[3].trim() }
        Regex("""^remove\s+(the\s+)?(.+)$""", RegexOption.IGNORE_CASE).find(o)?.let { return it.groupValues[2].trim() }
        return null
    }

    /**
     * [orig] the user's photo (≤ 2560 px), [edited] the editor's result (any size), [order] the English
     * order, [negative] the user's «Qué evitar» in English. Blocking; null when it could not polish
     * (the caller then keeps the plain mix).
     */
    fun run(ctx: Context, orig: Bitmap, edited: Bitmap, order: String, negative: String, amount: Int,
            say: (String, Int) -> Unit, cancelled: () -> Boolean): Result? {
        val modelId = pickModel(ctx) ?: run { JobLog.notice("Pulir con SDXL: no hay un modelo SDXL con versión NPU (RealVisXL Lightning)"); return null }
        val blend = EditBlend.keepUnchanged(ctx, orig, edited, fixFaces = false)
        if (blend.changedPct < 1 || blend.mask == null) { JobLog.add("Pulir con SDXL: el editor casi no cambió nada"); return null }
        val w = orig.width; val h = orig.height
        val draft = blend.image
        // the change map at full size (gray = how much)
        val maskFull = Bitmap.createScaledBitmap(blend.mask, w, h, true)
        val mpx = IntArray(w * h); maskFull.getPixels(mpx, 0, w, 0, 0, w, h)

        // the area to redraw: the changed part with room around it, in the NPU's shape
        val sizes = NpuUnet.sizes(ctx, modelId).ifEmpty { listOf(1024 to 1024) }
        var rect = if (blend.whole) Rect(0, 0, w, h) else changedBox(blend.mask, w, h) ?: return null
        val pad = maxOf(48, (maxOf(rect.width(), rect.height()) * 0.2f).roundToInt())
        rect = Rect(maxOf(0, rect.left - pad), maxOf(0, rect.top - pad), minOf(w, rect.right + pad), minOf(h, rect.bottom + pad))
        val r0 = rect.width().toFloat() / rect.height()
        val (sw, sh) = sizes.minByOrNull { (a, b) -> Math.abs(Math.log((a.toFloat() / b / r0).toDouble())) }!!
        rect = widen(rect, sw.toFloat() / sh, w, h)

        val strength = if (blend.whole) floatArrayOf(0.35f, 0.45f, 0.55f)[amount.coerceIn(0, 2)]
            else floatArrayOf(0.55f, 0.75f, 0.9f)[amount.coerceIn(0, 2)]
        val fast = Reimagine.isFast(modelId)
        val steps = if (fast) 8 else 25
        val guidance = if (fast) 1.8f else 6f
        val what = describe(order)
        val prompt = "$what, photo, realistic, natural light, highly detailed, sharp focus"
        val old = before(order)
        val neg = listOfNotNull(old, negative.ifBlank { null }, "blurry, deformed, bad anatomy, extra limbs").joinToString(", ")
        val faceToo = FACE_WORDS.containsMatchIn(order)
        JobLog.add("Pulir con SDXL: ${ModelCatalog.displayName(modelId)} · zona ${rect.width()}×${rect.height()} → ${sw}×$sh · " +
            "fuerza ${(strength * 100).roundToInt()} % · ${if (blend.whole) "foto completa" else "solo lo que cambió (${blend.changedPct} %)"}")
        JobLog.add("Pulir con SDXL: texto «$prompt»" + (old?.let { " · evitando «$it»" } ?: ""))

        // the model's input: the draft (original + the editor's change), and where it may change
        val crop = Bitmap.createScaledBitmap(Bitmap.createBitmap(draft, rect.left, rect.top, rect.width(), rect.height()), sw, sh, true)
        val latMask = if (blend.whole) null else {
            val mc = Bitmap.createScaledBitmap(Bitmap.createBitmap(maskFull, rect.left, rect.top, rect.width(), rect.height()), sw / 8, sh / 8, true)
            val p = IntArray(mc.width * mc.height); mc.getPixels(p, 0, mc.width, 0, 0, mc.width, mc.height)
            FloatArray(p.size) { minOf(1f, (p[it] and 0xFF) / 255f * 1.8f) }
        }
        val out = File(ctx.cacheDir, "polish_${System.currentTimeMillis()}.jpg")
        val dir = SdModel.dir(ctx, modelId).absolutePath
        val npuDir = NpuUnet.dirFor(ctx, modelId) ?: return null
        var code: Int
        try {
            SdModel.ensureEncoder(ctx, modelId)
            val npu = NpuUnet.get(ctx.applicationContext, npuDir)
            SdNative.setNpu(npu)
            say(ctx.getString(R.string.polish_running, 0), 0)
            code = SdNative.generate(dir, ctx.cacheDir.absolutePath, SdNative.BACKEND_OPENCL, 0, SdModel.isDynamic(ctx, modelId),
                sw, sh, steps, kotlin.random.Random.nextInt(1, Int.MAX_VALUE), out.absolutePath,
                prompt.lowercase(java.util.Locale.ROOT), neg.lowercase(java.util.Locale.ROOT),
                SdDetail.toInput(crop), strength, guidance, 1.5f, null, latMask, SdNative.PREVIEW_NONE, SdNative.SAMPLER_DPM,
                object : SdNative.Listener {
                    override fun onProgress(pct: Int) { say(ctx.getString(R.string.polish_running, pct), pct) }
                    override fun onPreview(rgb: ByteArray, width: Int, height: Int) {}
                })
        } catch (t: Throwable) {
            JobLog.error("Pulir con SDXL", t); return null
        } finally {
            SdNative.setNpu(null)
            try { NpuUnet.releaseAll(); SdNative.release() } catch (_: Throwable) { }
        }
        if (code != 0 || cancelled()) { JobLog.notice("Pulir con SDXL: no terminó (código $code); queda el resultado del editor"); return null }
        val piece = BitmapFactory.decodeFile(out.absolutePath) ?: return null
        out.delete()

        // back into the photo: only where it changed (soft edges); the whole picture for big changes
        val res = draft.copy(Bitmap.Config.ARGB_8888, true)
        val back = Bitmap.createScaledBitmap(piece, rect.width(), rect.height(), true)
        val cw = rect.width(); val ch = rect.height()
        val cur = IntArray(cw * ch); res.getPixels(cur, 0, cw, rect.left, rect.top, cw, ch)
        val neu = IntArray(cw * ch); back.getPixels(neu, 0, cw, 0, 0, cw, ch)
        for (y in 0 until ch) for (x in 0 until cw) {
            val i = y * cw + x
            val t = if (blend.whole) 1f else minOf(1f, (mpx[(rect.top + y) * w + rect.left + x] and 0xFF) / 255f * 1.4f)
            if (t <= 0.004f) continue
            cur[i] = mix(cur[i], neu[i], t)
        }
        res.setPixels(cur, 0, cw, rect.left, rect.top, cw, ch)

        // the face: the original one, unless the order is about the face
        if (!faceToo) {
            val op = IntArray(w * h); orig.getPixels(op, 0, w, 0, 0, w, h)
            val rp = IntArray(w * h); res.getPixels(rp, 0, w, 0, 0, w, h)
            var n = 0
            for (f in SdDetail.faces(orig)) {
                n++
                val cx = f.exactCenterX(); val cy = f.exactCenterY()
                val rx = f.width() * 0.7f; val ry = f.height() * 0.8f
                for (y in maxOf(0, (cy - ry).toInt())..minOf(h - 1, (cy + ry).toInt()))
                    for (x in maxOf(0, (cx - rx).toInt())..minOf(w - 1, (cx + rx).toInt())) {
                        val dx = (x - cx) / rx; val dy = (y - cy) / ry
                        val k = ((1f - sqrt(dx * dx + dy * dy)) / 0.3f).coerceIn(0f, 1f)
                        if (k > 0f) rp[y * w + x] = mix(rp[y * w + x], op[y * w + x], k * k * (3f - 2f * k))
                    }
            }
            res.setPixels(rp, 0, w, 0, 0, w, h)
            if (n > 0) JobLog.add("Pulir con SDXL: $n cara(s) quedan como en tu foto")
        } else {
            val n = EditBlend.fixFaces(ctx, res, orig)
            JobLog.add("Pulir con SDXL: la orden habla de la cara; caras arregladas $n")
        }
        return Result(res, blend.changedPct, blend.whole)
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun c(s: Int) = (((a shr s) and 0xFF) * (1 - t) + ((b shr s) and 0xFF) * t).roundToInt().coerceIn(0, 255)
        return Color.rgb(c(16), c(8), c(0))
    }

    /** Bounding box (full-size pixels) of where the small change map is clearly on. */
    private fun changedBox(mask: Bitmap, w: Int, h: Int): Rect? {
        val mw = mask.width; val mh = mask.height
        val p = IntArray(mw * mh); mask.getPixels(p, 0, mw, 0, 0, mw, mh)
        var x0 = mw; var y0 = mh; var x1 = -1; var y1 = -1
        for (y in 0 until mh) for (x in 0 until mw) if ((p[y * mw + x] and 0xFF) > 40) {
            if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y
        }
        if (x1 < 0) return null
        val kx = w.toFloat() / mw; val ky = h.toFloat() / mh
        return Rect((x0 * kx).toInt(), (y0 * ky).toInt(), minOf(w, ((x1 + 1) * kx).roundToInt()), minOf(h, ((y1 + 1) * ky).roundToInt()))
    }

    /** [r] grown to the shape [want] (width/height), kept inside the photo. */
    private fun widen(r: Rect, want: Float, w: Int, h: Int): Rect {
        var rw = r.width(); var rh = r.height()
        if (rw.toFloat() / rh < want) rw = minOf(w, (rh * want).roundToInt()) else rh = minOf(h, (rw / want).roundToInt())
        if (rw.toFloat() / rh > want * 1.01f) rw = (rh * want).roundToInt() else if (rw.toFloat() / rh < want / 1.01f) rh = (rw / want).roundToInt()
        val l = (r.centerX() - rw / 2).coerceIn(0, w - rw); val t = (r.centerY() - rh / 2).coerceIn(0, h - rh)
        return Rect(l, t, l + rw, t + rh)
    }
}
