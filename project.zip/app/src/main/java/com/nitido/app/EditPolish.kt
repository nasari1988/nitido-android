package com.nitido.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import java.io.File
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Editar con palabras, second step. The instruction editor (pix2pix) is good at knowing WHAT to change
 * and WHERE, but its own drawing is small and bends bodies. So its result is used only as a draft:
 * the app finds where it changed the photo, and an SDXL model (on the NPU) redraws just that area on
 * the ORIGINAL photo, starting from the editor's colors and shapes there. Outside it, nothing changes.
 * The face stays the original unless the order talks about it.
 */
object EditPolish {

    class Result(val image: Bitmap, val changedPct: Int, val whole: Boolean)

    /** Amount buttons: Suave, Normal, Fuerte. */
    const val SOFT = 0
    const val NORMAL = 1
    const val STRONG = 2

    fun amount(ctx: Context) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE).getInt("edit_amount", NORMAL)
    fun setAmount(ctx: Context, v: Int) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE).edit().putInt("edit_amount", v).apply()

    /**
     * Models on the phone that can polish: SDXL and SD 1.5 drawing models with an NPU version (the
     * user's pick included). SDXL first; one entry per NPU version (8 and 16 bits share it).
     */
    fun choices(ctx: Context): List<String> {
        val xl = Reimagine.models(ctx, byChoiceToo = true)
        val seen = xl.mapNotNull { NpuUnet.dirFor(ctx, it)?.path }.toMutableSet()
        val sd = ModelCatalog.imageModels(ctx)
            .filter { it !in xl && SdModel.isReady(ctx, it) && SdModel.byId(ctx, it).mode == 0 && !it.contains("inpaint") }
            .sortedBy { if (it.endsWith("-8")) 1 else 0 }
            .filter { id -> val d = NpuUnet.dirFor(ctx, id); d != null && NpuUnet.isPrecompiled(ctx, id) && seen.add(d.path) }
        return xl + sd
    }

    /** Drawing models on the phone without an NPU version (shown grayed out in «Pulir con»). */
    fun withoutNpu(ctx: Context): List<String> {
        val ok = choices(ctx)
        val okDirs = ok.mapNotNull { NpuUnet.dirFor(ctx, it)?.path }.toSet()
        return ModelCatalog.imageModels(ctx).filter {
            it !in ok && SdModel.isReady(ctx, it) && SdModel.byId(ctx, it).mode == 0 && !it.contains("inpaint") &&
                NpuUnet.dirFor(ctx, it)?.path !in okDirs
        }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE)
    fun chosen(ctx: Context): String? = prefs(ctx).getString("polish_model", null)
    fun choose(ctx: Context, id: String?) = prefs(ctx).edit().putString("polish_model", id).apply()

    /** The model to polish with: the one picked in «Pulir con» if it is still there; else the automatic one. */
    fun pickModel(ctx: Context): String? {
        val all = choices(ctx)
        chosen(ctx)?.let { c -> if (c in all) return c }
        return Reimagine.models(ctx).firstOrNull()
    }

    private val FACE_WORDS = Regex("""\b(face|faces|eyes|smile|smiling|mouth|lips|makeup|expression|beard|mustache|nose|teeth|older|younger|age)\b""", RegexOption.IGNORE_CASE)

    /** What SDXL should draw, from the order ("turn the dress into sportswear" → "sportswear"). */
    fun describe(order: String): String {
        val o = order.trim().trimEnd('.')
        val rules = listOf(
            Regex("""^(turn|change|transform|convert|swap)\s+.+?\s+(into|to|for)\s+(.+)$""", RegexOption.IGNORE_CASE) to 3,
            Regex("""^replace\s+.+?\s+with\s+(.+)$""", RegexOption.IGNORE_CASE) to 1,
            Regex("""^make\s+(it|him|her|them|the \w+)\s+(.+)$""", RegexOption.IGNORE_CASE) to 2,
            Regex("""^give\s+(him|her|them|it)\s+(.+)$""", RegexOption.IGNORE_CASE) to 2,
            Regex("""^(add|put)\s+(.+?)(\s+on\s+.+)?$""", RegexOption.IGNORE_CASE) to 2,
        )
        for ((r, g) in rules) r.find(o)?.let { m -> return m.groupValues[g].trim() }
        return o
    }

    /** What was there before, to push away from it ("turn the dress into…" → "dress"). */
    fun before(order: String): String? {
        val o = order.trim()
        Regex("""^(turn|change|transform|convert|replace|swap)\s+(the\s+|his\s+|her\s+|their\s+)?(.+?)\s+(into|to|with|for)\s+""", RegexOption.IGNORE_CASE)
            .find(o)?.let { return it.groupValues[3].trim() }
        Regex("""^remove\s+(the\s+)?(.+)$""", RegexOption.IGNORE_CASE).find(o)?.let { return it.groupValues[2].trim() }
        return null
    }

    /**
     * [orig] the user's photo (≤ 2560 px), [edited] the editor's result (any size), [order] the English
     * order, [look] «Cómo debe verse» in English (only for this step; null = made from the order),
     * [negative] the user's «Qué evitar» in English. Blocking; null when it could not polish (the caller
     * then keeps the plain mix).
     */
    fun run(ctx: Context, orig: Bitmap, edited: Bitmap, order: String, look: String?, negative: String, amount: Int,
            say: (String, Int) -> Unit, cancelled: () -> Boolean, preview: ((Bitmap) -> Unit)? = null, model: String? = null): Result? {
        val modelId = model ?: pickModel(ctx) ?: run { JobLog.notice("Pulir con SDXL: no hay un modelo SDXL con versión NPU (RealVisXL Lightning)"); return null }
        val blend = EditBlend.keepUnchanged(ctx, orig, edited, fixFaces = false)
        if (blend.changedPct < 1 || blend.mask == null) { JobLog.add("Pulir con SDXL: el editor casi no cambió nada"); return null }
        val w = orig.width; val h = orig.height
        // the change map at full size (gray = how much)
        val maskFull = Bitmap.createScaledBitmap(blend.mask, w, h, true)
        val mpx = IntArray(w * h); maskFull.getPixels(mpx, 0, w, 0, 0, w, h)
        val t = FloatArray(w * h) { (mpx[it] and 0xFF) / 255f }
        // what the editor changed, kept for the draft (where the editor's colors are used)
        val tChange = t.copyOf()
        // an order about clothes redraws the whole body (garment and skin together, so there is no seam
        // between new and old skin), never the background; face, hair and uncovered hands stay yours
        var whole = blend.whole
        var bodyMode = false
        var parts: BodyParts? = null
        if (CLOTHES_WORDS.containsMatchIn(order)) {
            parts = BodyParts.of(ctx, orig)
            val pt = parts
            if (pt != null && pt.share(BodyParts.CLOTHES) > 0.01f) {
                val body = bodyMask(pt, w, h)
                val hands = handsOf(orig, pt, w, h)
                for (k in t.indices) t[k] = body[k] * (1f - hands[k])
                if (whole) for (k in tChange.indices) tChange[k] = minOf(tChange[k], t[k])
                bodyMode = true
                JobLog.notice("Editar: orden de ropa: se redibuja todo el cuerpo (prenda y piel juntas, sin uniones); " +
                    "fondo, cara, pelo" + (if (hands.any { it > 0.5f }) ", manos" else "") + " quedan como en tu foto" +
                    (if (whole) " · el editor había cambiado ${blend.changedPct} % de la foto; fuera del cuerpo no se usa" else ""))
                whole = false
            }
        } else if (!whole) parts = BodyParts.of(ctx, orig)
        val bodyParts = parts
        val op0s = IntArray(w * h).also { orig.getPixels(it, 0, w, 0, 0, w, h) }
        if (!whole && !bodyMode) protectBody(bodyParts, order, t, w, h, op0s)
        // the person's own skin: its color for the new skin, its tone in words for SDXL
        val skin = bodyParts?.let { pt ->
            SeamBlend.stats(op0s) { i -> val c = pt.at((i % w + 0.5f) / w, (i / w + 0.5f) / h); c == BodyParts.BODY_SKIN || c == BodyParts.FACE_SKIN }
        }
        // the draft: the editor's change only where it may change, the original everywhere else
        val op0 = IntArray(w * h); orig.getPixels(op0, 0, w, 0, 0, w, h)
        val ep0 = IntArray(w * h); blend.image.getPixels(ep0, 0, w, 0, 0, w, h)
        for (k in op0.indices) { val d = if (bodyMode) tChange[k] else t[k]; if (d > 0.004f) op0[k] = mix(op0[k], ep0[k], minOf(1f, d)) }
        val draft = Bitmap.createBitmap(op0, w, h, Bitmap.Config.ARGB_8888)
        for (k in mpx.indices) { val v = (t[k] * 255).roundToInt().coerceIn(0, 255); mpx[k] = Color.rgb(v, v, v) }
        maskFull.setPixels(mpx, 0, w, 0, 0, w, h)

        // the area to redraw: the changed part with room around it, in the NPU's shape
        val xlModel = SdModel.isSdxl(ctx, modelId)
        // SD 1.5 on the NPU: its own sizes; a model with a fixed size only works at 512×512
        val sizes = if (xlModel) NpuUnet.sizes(ctx, modelId).ifEmpty { listOf(1024 to 1024) }
            else NpuUnet.sizes(ctx, modelId).let { l -> if (SdModel.isDynamic(ctx, modelId)) l else l.filter { it == 512 to 512 } }.ifEmpty { listOf(512 to 512) }
        var rect = if (whole) Rect(0, 0, w, h) else changedBox(maskFull, w, h) ?: return null
        // room around the change, so the area's own edge (where the mix fades out) never falls on it
        val pad = maxOf(64, (maxOf(rect.width(), rect.height()) * 0.2f).roundToInt())
        rect = Rect(maxOf(0, rect.left - pad), maxOf(0, rect.top - pad), minOf(w, rect.right + pad), minOf(h, rect.bottom + pad))
        val r0 = rect.width().toFloat() / rect.height()
        val (sw, sh) = sizes.minByOrNull { (a, b) -> Math.abs(Math.log((a.toFloat() / b / r0).toDouble())) }!!
        rect = widen(rect, sw.toFloat() / sh, w, h)
        val stretch = (rect.width().toFloat() / rect.height()) / (sw.toFloat() / sh)
        if (stretch < 0.97f || stretch > 1.03f) JobLog.add("Pulir con SDXL: la zona no cabe en la forma de la NPU; se estira %.0f %% y se regresa".format(java.util.Locale.US, Math.abs(1 - stretch) * 100))

        val strength = if (whole) floatArrayOf(0.35f, 0.45f, 0.55f)[amount.coerceIn(0, 2)]
            else if (bodyMode) floatArrayOf(0.45f, 0.55f, 0.65f)[amount.coerceIn(0, 2)]
            else floatArrayOf(0.55f, 0.75f, 0.9f)[amount.coerceIn(0, 2)]
        val fast = Reimagine.isFast(modelId)
        val steps = if (fast) 8 else 25
        val guidance = if (fast) 1.8f else 6f
        val what = describe(look?.takeIf { it.isNotBlank() } ?: order)
        val tone = skin?.let { SeamBlend.toneWords(it) }
        val fabric = if (CLOTHES_WORDS.containsMatchIn(order) || CLOTHES_WORDS.containsMatchIn(look ?: "")) "fabric texture, natural folds, soft shadows" else null
        val prompt = listOfNotNull(what, fabric, tone, "photo, realistic, natural light, highly detailed, sharp focus").joinToString(", ")
        val old = before(order)
        val neg = listOfNotNull(old, negative.ifBlank { null }, "blurry, deformed, bad anatomy, extra limbs").joinToString(", ")
        val faceToo = FACE_WORDS.containsMatchIn(order)
        JobLog.add("Pulir con SDXL: ${ModelCatalog.displayName(modelId)} · zona ${rect.width()}×${rect.height()} → ${sw}×$sh · " +
            "fuerza ${(strength * 100).roundToInt()} % · ${if (whole) "foto completa" else if (bodyMode) "todo el cuerpo" else "solo lo que cambió (${blend.changedPct} %)"}")
        JobLog.add("Pulir con SDXL: texto «$prompt»" + (if (look.isNullOrBlank()) " (armado desde la orden)" else " (de «Cómo debe verse»)") +
            (old?.let { " · evitando «$it»" } ?: ""))

        // the model's input: the draft (original + the editor's change), and where it may change
        val crop = Bitmap.createScaledBitmap(Bitmap.createBitmap(draft, rect.left, rect.top, rect.width(), rect.height()), sw, sh, true)
        val latMask = if (whole) null else {
            val mc = Bitmap.createScaledBitmap(Bitmap.createBitmap(maskFull, rect.left, rect.top, rect.width(), rect.height()), sw / 8, sh / 8, true)
            val p = IntArray(mc.width * mc.height); mc.getPixels(p, 0, mc.width, 0, 0, mc.width, mc.height)
            FloatArray(p.size) { minOf(1f, (p[it] and 0xFF) / 255f * 1.8f) }
        }
        val out = File(ctx.cacheDir, "polish_${System.currentTimeMillis()}.jpg")
        val dir = SdModel.dir(ctx, modelId).absolutePath
        val npuDir = NpuUnet.dirFor(ctx, modelId) ?: return null
        var code: Int
        try {
            SdModel.ensureEncoder(ctx, modelId)
            val npu = NpuUnet.get(ctx.applicationContext, npuDir)
            npu.control = if (xlModel && QuickActionsActivity.on(ctx, "nitido", "q_pose"))
                poseControl(ctx, Bitmap.createBitmap(orig, rect.left, rect.top, rect.width(), rect.height()), sw, sh, say, cancelled) else null
            SdNative.setNpu(npu)
            say(ctx.getString(R.string.polish_running, 0), 0)
            code = SdNative.generate(dir, ctx.cacheDir.absolutePath, SdNative.BACKEND_OPENCL, 0, SdModel.isDynamic(ctx, modelId),
                sw, sh, steps, kotlin.random.Random.nextInt(1, Int.MAX_VALUE), out.absolutePath,
                prompt.lowercase(java.util.Locale.ROOT), neg.lowercase(java.util.Locale.ROOT),
                SdDetail.toInput(crop), strength, guidance, 1.5f, null, latMask, if (preview != null) SdNative.PREVIEW_FAST else SdNative.PREVIEW_NONE, SdNative.SAMPLER_DPM,
                object : SdNative.Listener {
                    override fun onProgress(pct: Int) { say(ctx.getString(R.string.polish_running, pct), pct) }
                    override fun onPreview(rgb: ByteArray, width: Int, height: Int) {
                        // the area being redrawn, on the photo where it goes (smaller, quick)
                        if (preview == null) return
                        try {
                            val k = minOf(1f, 900f / maxOf(w, h))
                            val pw = maxOf(1, (w * k).roundToInt()); val ph = maxOf(1, (h * k).roundToInt())
                            val canvasBmp = Bitmap.createScaledBitmap(draft, pw, ph, true).copy(Bitmap.Config.ARGB_8888, true)
                            val piece = TimelapseVideo.toBitmap(rgb, width, height)
                            val dst = android.graphics.Rect((rect.left * k).roundToInt(), (rect.top * k).roundToInt(), (rect.right * k).roundToInt(), (rect.bottom * k).roundToInt())
                            android.graphics.Canvas(canvasBmp).drawBitmap(piece, null, dst, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                            preview(canvasBmp)
                        } catch (_: Throwable) { }
                    }
                })
        } catch (e: Throwable) {
            JobLog.error("Pulir con SDXL", e); return null
        } finally {
            SdNative.setNpu(null)
            try { NpuUnet.dirFor(ctx, modelId)?.let { NpuUnet.get(ctx.applicationContext, it).control = null } } catch (_: Throwable) { }
            try { NpuUnet.releaseAll(); SdNative.release() } catch (_: Throwable) { }
        }
        if (code != 0 || cancelled()) { JobLog.notice("Pulir con SDXL: no terminó (código $code); queda el resultado del editor"); return null }
        val piece = BitmapFactory.decodeFile(out.absolutePath) ?: return null
        out.delete()

        // back into the photo: only where it changed (soft edges); the whole picture for big changes
        val res = draft.copy(Bitmap.Config.ARGB_8888, true)
        val back = Bitmap.createScaledBitmap(piece, rect.width(), rect.height(), true)
        val cw = rect.width(); val ch = rect.height()
        val cur = IntArray(cw * ch); res.getPixels(cur, 0, cw, rect.left, rect.top, cw, ch)
        val neu = IntArray(cw * ch); back.getPixels(neu, 0, cw, 0, 0, cw, ch)
        val ramp = maxOf(8f, minOf(cw, ch) * 0.06f)
        fun edge(i: Int): Float {
            val x = i % cw; val y = i / cw
            var d = Float.MAX_VALUE
            if (rect.left > 0) d = minOf(d, x.toFloat()); if (rect.right < w) d = minOf(d, (cw - 1 - x).toFloat())
            if (rect.top > 0) d = minOf(d, y.toFloat()); if (rect.bottom < h) d = minOf(d, (ch - 1 - y).toFloat())
            val k = (d / ramp).coerceIn(0f, 1f); return k * k * (3 - 2 * k)
        }
        val tm = FloatArray(cw * ch) { i -> if (whole) 1f else minOf(1f, t[(rect.top + i / cw) * w + rect.left + i % cw] * 1.4f) * edge(i) }
        // skin that SDXL drew (where clothes were): the person's own color, so it doesn't look pasted
        val np = if (skin != null) try { BodyParts.of(ctx, back) } catch (e: Throwable) { null } else null
        if (skin != null) { try {
            if (np != null) {
                fun isNewSkin(i: Int): Float {
                    if (tm[i] <= 0.02f) return 0f
                    val c = np.at((i % cw + 0.5f) / cw, (i / cw + 0.5f) / ch)
                    return if (c == BodyParts.BODY_SKIN) 1f else 0f
                }
                val drawn = SeamBlend.stats(neu) { i -> isNewSkin(i) > 0f }
                if (drawn != null) {
                    var n = 0
                    for (i in neu.indices) { val k = isNewSkin(i); if (k > 0f) { neu[i] = SeamBlend.transfer(neu[i], drawn, skin, 0.85f * k); n++ } }
                    JobLog.add("Pulir con SDXL: piel redibujada igualada a la tuya (${(100.0 * n / neu.size).roundToInt()} %% de la zona) · brillo %.0f→%.0f".format(java.util.Locale.US, drawn.mean[0], skin.mean[0]))
                } else JobLog.add("Pulir con SDXL: casi no hay piel redibujada; color sin cambios")
            } else JobLog.add("Pulir con SDXL: no encontré a la persona en lo redibujado; color sin igualar")
        } catch (e: Throwable) { JobLog.error("Pulir con SDXL: color de piel", e) } }
        else if (!whole) JobLog.add("Pulir con SDXL: no pude medir tu tono de piel; color sin igualar")
        // whole body redrawn: every place of the new skin takes the photo's own color there (legs like
        // your legs, arms like your arms), not one average for all the skin
        if (bodyMode && np != null && bodyParts != null) try {
            val origCrop = IntArray(cw * ch) { i -> op0s[(rect.top + i / cw) * w + rect.left + i % cw] }
            val newSkin = FloatArray(cw * ch) { i ->
                if (tm[i] <= 0.02f) 0f else if (np.at((i % cw + 0.5f) / cw, (i / cw + 0.5f) / ch) == BodyParts.BODY_SKIN) 1f else 0f
            }
            val origSkin = BooleanArray(cw * ch) { i ->
                bodyParts.at((rect.left + i % cw + 0.5f) / w, (rect.top + i / cw + 0.5f) / h) == BodyParts.BODY_SKIN
            }
            val r = SeamBlend.localTone(neu, origCrop, newSkin, origSkin, cw, ch)
            JobLog.add("Pulir con SDXL: color de piel por zonas igual al de tu foto" + (r?.let { " · $it" } ?: ": no hubo piel para medir"))
        } catch (e: Throwable) { JobLog.error("Pulir con SDXL: color de piel por zonas", e) }
        // the seam: fine detail switches over a thin border, color and light over a wide one
        val mixed = if (whole) neu else try { SeamBlend.multiBand(cur, neu, tm, cw, ch) } catch (e: Throwable) {
            JobLog.error("Pulir con SDXL: unión por capas", e)
            IntArray(cur.size) { i -> if (tm[i] <= 0.004f) cur[i] else mix(cur[i], neu[i], tm[i]) }
        }
        // where the new skin meets the original skin: the same tone on both sides of every edge
        if (!whole && np != null && bodyParts != null) try {
            val origCrop = IntArray(cw * ch) { i -> op0s[(rect.top + i / cw) * w + rect.left + i % cw] }
            val newSkin = FloatArray(cw * ch) { i ->
                if (tm[i] <= 0.15f) 0f else if (np.at((i % cw + 0.5f) / cw, (i / cw + 0.5f) / ch) == BodyParts.BODY_SKIN) minOf(1f, tm[i]) else 0f
            }
            val kept = BooleanArray(cw * ch) { i ->
                tm[i] < 0.12f && bodyParts.at((rect.left + i % cw + 0.5f) / w, (rect.top + i / cw + 0.5f) / h).let { it == BodyParts.BODY_SKIN || it == BodyParts.FACE_SKIN }
            }
            val r = SeamBlend.harmonizeSkin(mixed, origCrop, newSkin, kept, cw, ch)
            if (r != null) JobLog.add("Pulir con SDXL: costura de la piel igualada · $r")
        } catch (e: Throwable) { JobLog.error("Pulir con SDXL: costura de la piel", e) }
        res.setPixels(mixed, 0, cw, rect.left, rect.top, cw, ch)

        // the face: the original one, unless the order is about the face
        if (!faceToo) {
            val op = IntArray(w * h); orig.getPixels(op, 0, w, 0, 0, w, h)
            val rp = IntArray(w * h); res.getPixels(rp, 0, w, 0, 0, w, h)
            var n = 0
            for (f in SdDetail.faces(orig)) {
                n++
                val cx = f.exactCenterX(); val cy = f.exactCenterY()
                val rx = f.width() * 0.7f; val ry = f.height() * 0.8f
                for (y in maxOf(0, (cy - ry).toInt())..minOf(h - 1, (cy + ry).toInt()))
                    for (x in maxOf(0, (cx - rx).toInt())..minOf(w - 1, (cx + rx).toInt())) {
                        val dx = (x - cx) / rx; val dy = (y - cy) / ry
                        val k = ((1f - sqrt(dx * dx + dy * dy)) / 0.3f).coerceIn(0f, 1f)
                        if (k > 0f) rp[y * w + x] = mix(rp[y * w + x], op[y * w + x], k * k * (3f - 2f * k))
                    }
            }
            res.setPixels(rp, 0, w, 0, 0, w, h)
            if (n > 0) JobLog.add("Pulir con SDXL: $n cara(s) quedan como en tu foto")
        } else {
            val n = EditBlend.fixFaces(ctx, res, orig)
            JobLog.add("Pulir con SDXL: la orden habla de la cara; caras arregladas $n")
        }
        return Result(res, blend.changedPct, whole)
    }

    /** Realismo al final: 0 no, 1 normal, 2 más (Mis preferencias › Editar). */
    fun realism(ctx: Context) = QuickActionsActivity.pick(ctx, "nitido", "edit_realism")

    /** The inpainting model to fill zones with (Mis preferencias › Modelos), or null when none is on the phone. */
    fun fillModel(ctx: Context): String? {
        val all = Reimagine.fillModels(ctx)
        ctx.getSharedPreferences("nitido", Context.MODE_PRIVATE).getString("fill_model", null)?.let { if (it in all) return it }
        return all.firstOrNull()
    }

    /**
     * Editar with an inpainting model (Lustify Inpainting…): the app decides the exact zone from the
     * order's kind (the garment; the background; the head), and the model fills it seeing the photo
     * around, so the edges match by themselves. Clothes keep the pose and the body's volume (Union).
     * Then Realismo on the filled zone, and the face stays yours (unless the order is about the head).
     * Null when it can't (no person found for a body order, the NPU failed): the caller goes the old way.
     */
    fun runFill(ctx: Context, orig: Bitmap, order: String, look: String?, negative: String, amount: Int, kind: EditKind,
                modelId: String, say: (String, Int) -> Unit, cancelled: () -> Boolean, preview: ((Bitmap) -> Unit)? = null): Result? {
        val w = orig.width; val h = orig.height
        val pt = BodyParts.of(ctx, orig)
        if (pt == null) { JobLog.notice("Rellenar: no encontré a la persona; se usa el método anterior"); return null }
        fun cls(i: Int) = pt.classes[i].toInt() and 0xFF
        val pw = pt.w; val ph = pt.h
        // the zone at the segmenter's size, then soft at full size
        val garment = BooleanArray(pw * ph) { cls(it) == BodyParts.CLOTHES }
        val bg = BooleanArray(pw * ph) { cls(it) == BodyParts.BACKGROUND }
        val headM = BooleanArray(pw * ph) { cls(it) == BodyParts.FACE_SKIN || cls(it) == BodyParts.HAIR }
        val zoneSmall = FloatArray(pw * ph)
        if (kind == EditKind.CLOTHES || kind == EditKind.CLOTHES_BG || kind == EditKind.NUDE) {
            val g = dilate(garment, pw, ph, maxOf(2, ph / 70))
            for (i in g.indices) if (g[i] && !headM[i]) zoneSmall[i] = 1f
        }
        if (kind == EditKind.BACKGROUND || kind == EditKind.CLOTHES_BG) {
            // the background, a little away from the person (their outline stays theirs)
            val person = BooleanArray(pw * ph) { !bg[it] }
            val near = dilate(person, pw, ph, maxOf(1, ph / 150))
            for (i in bg.indices) if (!near[i]) zoneSmall[i] = 1f
        }
        if (kind == EditKind.HEAD) {
            val hd = dilate(headM, pw, ph, maxOf(3, ph / 30))
            // room above the head (hat, crown)
            var top = ph; var x0 = pw; var x1 = -1
            for (i in headM.indices) if (headM[i]) { val y = i / pw; val x = i % pw; if (y < top) top = y; if (x < x0) x0 = x; if (x > x1) x1 = x }
            for (y in maxOf(0, top - ph / 12) until top) for (x in maxOf(0, x0) .. minOf(pw - 1, x1)) hd[y * pw + x] = true
            for (i in hd.indices) if (hd[i]) zoneSmall[i] = 1f
        }
        // the visible hands stay (and the arms, unless the order wants sleeves)
        val keepArms = (kind == EditKind.CLOTHES || kind == EditKind.CLOTHES_BG) && !EditKind.SLEEVES_RX.containsMatchIn(order)
        val zone = upscale(boxBlur(zoneSmall, pw, ph, 1), pw, ph, w, h) { v -> val k = ((v - 0.2f) / 0.6f).coerceIn(0f, 1f); k * k * (3 - 2 * k) }
        if (kind == EditKind.CLOTHES || kind == EditKind.CLOTHES_BG || kind == EditKind.NUDE) {
            val keep = armsOf(orig, pt, w, h, keepArms)
            for (i in zone.indices) zone[i] *= (1f - keep[i])
        }
        val share = zone.count { it > 0.5f } * 100 / zone.size
        if (share < 1) { JobLog.notice("Rellenar: la zona salió vacía (${ctx.getString(kind.label)}); se usa el método anterior"); return null }
        JobLog.add("Rellenar: ${ctx.getString(kind.label)} · zona exacta ${share} % de la foto" + if (keepArms) " · brazos y manos quedan como en tu foto" else "")

        // the area to fill: the zone with room around it, in the NPU's shape
        val sizes = NpuUnet.sizes(ctx, modelId).ifEmpty { listOf(1024 to 1024) }
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (i in zone.indices) if (zone[i] > 0.3f) { val x = i % w; val y = i / w; if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y }
        val pad = maxOf(48, (maxOf(x1 - x0, y1 - y0) * 0.15f).roundToInt())
        var rect = Rect(maxOf(0, x0 - pad), maxOf(0, y0 - pad), minOf(w, x1 + 1 + pad), minOf(h, y1 + 1 + pad))
        val r0 = rect.width().toFloat() / rect.height()
        val (sw, sh) = sizes.minByOrNull { (a, b) -> Math.abs(Math.log((a.toFloat() / b / r0).toDouble())) }!!
        rect = widen(rect, sw.toFloat() / sh, w, h)
        val cw = rect.width(); val ch = rect.height()

        // inputs: the photo, the photo with the zone blanked, the zone at the latent size
        val crop = Bitmap.createScaledBitmap(Bitmap.createBitmap(orig, rect.left, rect.top, cw, ch), sw, sh, true)
        val image = SdDetail.toInput(crop)
        val zoneCrop = FloatArray(sw * sh) { i ->
            val x = rect.left + ((i % sw) + 0.5f) * cw / sw; val y = rect.top + ((i / sw) + 0.5f) * ch / sh
            zone[minOf(h - 1, y.toInt()) * w + minOf(w - 1, x.toInt())]
        }
        val masked = image.copyOf()
        val n = sw * sh
        for (i in 0 until n) if (zoneCrop[i] > 0.5f) { masked[i] = 0f; masked[n + i] = 0f; masked[2 * n + i] = 0f }
        val lw = sw / 8; val lh = sh / 8
        val latMask = FloatArray(lw * lh) { j ->
            var m = 0f
            val bx = (j % lw) * 8; val by = (j / lw) * 8
            for (yy in by until by + 8) for (xx in bx until bx + 8) m = maxOf(m, zoneCrop[yy * sw + xx])
            m
        }

        val strength = floatArrayOf(0.85f, 1f, 1f)[amount.coerceIn(0, 2)]
        val fast = Reimagine.isFast(modelId)
        val steps = if (fast) 8 else if (amount == 2) 25 else 20
        val guidance = if (fast) 1.8f else if (amount == 2) 6f else 4.5f
        val what = describe(look?.takeIf { it.isNotBlank() } ?: order)
        val skin = SeamBlend.stats(IntArray(w * h).also { orig.getPixels(it, 0, w, 0, 0, w, h) }) { i ->
            val c = pt.at((i % w + 0.5f) / w, (i / w + 0.5f) / h); c == BodyParts.BODY_SKIN || c == BodyParts.FACE_SKIN }
        val extra = when (kind) {
            EditKind.CLOTHES, EditKind.CLOTHES_BG -> listOfNotNull("fabric texture, natural folds, soft shadows", skin?.let { SeamBlend.toneWords(it) })
            EditKind.BACKGROUND -> listOf("background, natural perspective, matching light")
            EditKind.HEAD -> listOf("same person, same face")
            EditKind.WHOLE -> emptyList()
            EditKind.NUDE -> listOfNotNull("bare skin, natural body, natural anatomy, soft shadows", skin?.let { SeamBlend.toneWords(it) })
        }
        val prompt = (listOf(what) + extra + "photo, realistic, natural light, highly detailed, sharp focus").joinToString(", ")
        val neg = listOfNotNull(before(order), negative.ifBlank { null }, "blurry, deformed, bad anatomy, extra limbs, extra fingers").joinToString(", ")
        JobLog.add("Rellenar con ${ModelCatalog.displayName(modelId)}: zona ${cw}×$ch → ${sw}×$sh · $steps pasos · guía $guidance · fuerza ${(strength * 100).roundToInt()} %")
        JobLog.add("Rellenar: texto «$prompt» · evitando «$neg»")

        val out = File(ctx.cacheDir, "fill_${System.currentTimeMillis()}.jpg")
        val dir = SdModel.dir(ctx, modelId).absolutePath
        val npuDir = NpuUnet.dirFor(ctx, modelId) ?: run { JobLog.notice("Rellenar: ${ModelCatalog.displayName(modelId)} no tiene versión NPU"); return null }
        val code: Int
        try {
            val npu = NpuUnet.get(ctx.applicationContext, npuDir)
            npu.control = if (kind == EditKind.CLOTHES || kind == EditKind.CLOTHES_BG || kind == EditKind.NUDE) {
                // the old garment's volume is not copied: its depth is smoothed
                val soften = FloatArray(sw * sh) { i ->
                    val x = rect.left + ((i % sw) + 0.5f) * cw / sw; val y = rect.top + ((i / sw) + 0.5f) * ch / sh
                    if (pt.at(x / w, y / h) == BodyParts.CLOTHES) 1f else 0f
                }
                guides(ctx, Bitmap.createBitmap(orig, rect.left, rect.top, cw, ch), sw, sh, soften, say, cancelled)
            } else null
            SdNative.setNpu(npu)
            say(ctx.getString(R.string.fill_running, 0), 0)
            code = SdNative.generate(dir, ctx.cacheDir.absolutePath, SdNative.BACKEND_OPENCL, 2, SdModel.isDynamic(ctx, modelId),
                sw, sh, steps, kotlin.random.Random.nextInt(1, Int.MAX_VALUE), out.absolutePath,
                prompt.lowercase(java.util.Locale.ROOT), neg.lowercase(java.util.Locale.ROOT),
                image, strength, guidance, 1.5f, masked, latMask, if (preview != null) SdNative.PREVIEW_FAST else SdNative.PREVIEW_NONE, SdNative.SAMPLER_DPM,
                object : SdNative.Listener {
                    override fun onProgress(pct: Int) { say(ctx.getString(R.string.fill_running, pct), pct) }
                    override fun onPreview(rgb: ByteArray, width: Int, height: Int) {
                        if (preview == null) return
                        try {
                            val k = minOf(1f, 900f / maxOf(w, h))
                            val canvasBmp = Bitmap.createScaledBitmap(orig, maxOf(1, (w * k).roundToInt()), maxOf(1, (h * k).roundToInt()), true).copy(Bitmap.Config.ARGB_8888, true)
                            val dst = Rect((rect.left * k).roundToInt(), (rect.top * k).roundToInt(), (rect.right * k).roundToInt(), (rect.bottom * k).roundToInt())
                            android.graphics.Canvas(canvasBmp).drawBitmap(TimelapseVideo.toBitmap(rgb, width, height), null, dst, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                            preview(canvasBmp)
                        } catch (_: Throwable) { }
                    }
                })
        } catch (e: Throwable) {
            JobLog.error("Rellenar", e); return null
        } finally {
            SdNative.setNpu(null)
            try { NpuUnet.dirFor(ctx, modelId)?.let { NpuUnet.get(ctx.applicationContext, it).control = null } } catch (_: Throwable) { }
            try { NpuUnet.releaseAll(); SdNative.release() } catch (_: Throwable) { }
        }
        if (code != 0 || cancelled()) { JobLog.notice("Rellenar: no terminó (código $code)"); return null }
        val piece = BitmapFactory.decodeFile(out.absolutePath) ?: return null
        out.delete()

        // back into the photo with the zone's soft edge (fine detail over a thin border, light over a wide one)
        val res = orig.copy(Bitmap.Config.ARGB_8888, true)
        val back = Bitmap.createScaledBitmap(piece, cw, ch, true)
        val cur = IntArray(cw * ch); res.getPixels(cur, 0, cw, rect.left, rect.top, cw, ch)
        val neu = IntArray(cw * ch); back.getPixels(neu, 0, cw, 0, 0, cw, ch)
        val tm = FloatArray(cw * ch) { i -> zone[(rect.top + i / cw) * w + rect.left + i % cw] }
        if (kind == EditKind.CLOTHES || kind == EditKind.CLOTHES_BG || kind == EditKind.NUDE) try {
            // the new skin takes the photo's own color place by place
            val np = BodyParts.of(ctx, back)
            if (np != null) {
                val origCrop = IntArray(cw * ch) { i -> cur[i] }
                val newSkin = FloatArray(cw * ch) { i -> if (tm[i] > 0.02f && np.at((i % cw + 0.5f) / cw, (i / cw + 0.5f) / ch) == BodyParts.BODY_SKIN) 1f else 0f }
                val origSkin = BooleanArray(cw * ch) { i -> pt.at((rect.left + i % cw + 0.5f) / w, (rect.top + i / cw + 0.5f) / h) == BodyParts.BODY_SKIN }
                SeamBlend.localTone(neu, origCrop, newSkin, origSkin, cw, ch)?.let { JobLog.add("Rellenar: color de piel por zonas igual al de tu foto · $it") }
            }
        } catch (e: Throwable) { JobLog.error("Rellenar: color de piel", e) }
        val mixed = try { SeamBlend.multiBand(cur, neu, tm, cw, ch) } catch (e: Throwable) {
            IntArray(cur.size) { i -> if (tm[i] <= 0.004f) cur[i] else mix(cur[i], neu[i], tm[i]) }
        }
        res.setPixels(mixed, 0, cw, rect.left, rect.top, cw, ch)
        finishRealism(ctx, res, rect, zone, cancelled)
        if (kind != EditKind.HEAD) keepFaces(orig, res)
        return Result(res, share, false)
    }

    /**
     * Realismo (PiSA-SR, NPU) over the changed area: real skin and cloth texture where SDXL left it
     * smooth, and one same grain on both sides of the edges. Mixed back through [zone] (grown a little).
     */
    fun finishRealism(ctx: Context, res: Bitmap, rect: Rect, zone: FloatArray, cancelled: () -> Boolean) {
        val level = realism(ctx)
        if (level == 0 || !Realism.isReady(ctx)) {
            if (level != 0) JobLog.add("Realismo al final: no está descargado (Restaurar › Realismo)")
            return
        }
        try {
            val w = res.width; val h = res.height
            val cw = rect.width(); val ch = rect.height()
            val piece = Bitmap.createBitmap(res, rect.left, rect.top, cw, ch)
            val t0 = android.os.SystemClock.elapsedRealtime()
            val real = Realism.run(ctx, piece, if (level == 2) 1.1f else 0.8f, cancelled) { _, _ -> } ?: return
            val r2 = if (real.width != cw || real.height != ch) Bitmap.createScaledBitmap(real, cw, ch, true) else real
            val a = IntArray(cw * ch); piece.getPixels(a, 0, cw, 0, 0, cw, ch)
            val b = IntArray(cw * ch); r2.getPixels(b, 0, cw, 0, 0, cw, ch)
            for (i in a.indices) {
                val k = minOf(1f, zone[(rect.top + i / cw) * w + rect.left + i % cw] * 1.5f)
                if (k > 0.01f) a[i] = mix(a[i], b[i], k)
            }
            res.setPixels(a, 0, cw, rect.left, rect.top, cw, ch)
            JobLog.add("Realismo al final: textura real en la zona cambiada (${android.os.SystemClock.elapsedRealtime() - t0} ms)")
        } catch (e: Throwable) { JobLog.error("Realismo al final", e) }
    }

    /** The original faces back into [res] (soft ellipses). */
    fun keepFaces(orig: Bitmap, res: Bitmap) {
        val w = orig.width; val h = orig.height
        val op = IntArray(w * h); orig.getPixels(op, 0, w, 0, 0, w, h)
        val rp = IntArray(w * h); res.getPixels(rp, 0, w, 0, 0, w, h)
        var n = 0
        for (f in SdDetail.faces(orig)) {
            n++
            val cx = f.exactCenterX(); val cy = f.exactCenterY()
            val rx = f.width() * 0.7f; val ry = f.height() * 0.8f
            for (y in maxOf(0, (cy - ry).toInt())..minOf(h - 1, (cy + ry).toInt()))
                for (x in maxOf(0, (cx - rx).toInt())..minOf(w - 1, (cx + rx).toInt())) {
                    val dx = (x - cx) / rx; val dy = (y - cy) / ry
                    val k = ((1f - sqrt(dx * dx + dy * dy)) / 0.3f).coerceIn(0f, 1f)
                    if (k > 0f) rp[y * w + x] = mix(rp[y * w + x], op[y * w + x], k * k * (3f - 2f * k))
                }
        }
        res.setPixels(rp, 0, w, 0, 0, w, h)
        if (n > 0) JobLog.add("Editar: $n cara(s) quedan como en tu foto")
    }

    /**
     * What stays as in the photo on a body order (1 = keep): the visible hands, and with [wholeArms]
     * the bare arms too (shoulder to wrist), where the photo shows skin.
     */
    private fun armsOf(orig: Bitmap, pt: BodyParts, w: Int, h: Int, wholeArms: Boolean): FloatArray {
        val out = FloatArray(w * h)
        val j = try { PoseImage.joints(orig) } catch (_: Throwable) { null } ?: return out
        fun stamp(cx: Float, cy: Float, rad: Float) {
            for (y in maxOf(0, (cy - rad).toInt())..minOf(h - 1, (cy + rad).toInt()))
                for (x in maxOf(0, (cx - rad).toInt())..minOf(w - 1, (cx + rad).toInt())) {
                    val d = sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / rad
                    if (d >= 1f) continue
                    if (pt.at((x + 0.5f) / w, (y + 0.5f) / h) != BodyParts.BODY_SKIN) continue
                    val k = ((1f - d) / 0.35f).coerceIn(0f, 1f)
                    val i = y * w + x; out[i] = maxOf(out[i], k * k * (3 - 2 * k))
                }
        }
        for ((sh, el, wr) in listOf(Triple(2, 3, 4), Triple(5, 6, 7))) {
            val e = j[el] ?: continue; val r = j[wr] ?: continue
            val ex = e[0] * w; val ey = e[1] * h; val rx = r[0] * w; val ry = r[1] * h
            val fl = sqrt((rx - ex) * (rx - ex) + (ry - ey) * (ry - ey))
            if (fl < 4f) continue
            stamp(rx + (rx - ex) * 0.35f, ry + (ry - ey) * 0.35f, fl * 0.55f)   // the hand
            if (wholeArms) {
                val s = j[sh]
                val segs = listOfNotNull(e to r, s?.let { it to e })
                for ((a, b) in segs) {
                    val ax = a[0] * w; val ay = a[1] * h; val bx = b[0] * w; val by = b[1] * h
                    val len = sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay))
                    val steps = maxOf(2, (len / (fl * 0.15f)).toInt())
                    for (k in 0..steps) { val t = k.toFloat() / steps; stamp(ax + (bx - ax) * t, ay + (by - ay) * t, fl * 0.32f) }
                }
            }
        }
        return out
    }

    private val SKIN_WORDS = Regex("""\b(skin|tan|tanned|tattoo\w*|nude|naked|shirtless|topless|bare\w*|muscl\w*|thin\w*|fat\w*|slim\w*|body)\b""", RegexOption.IGNORE_CASE)
    private val HAIR_WORDS = Regex("""\b(hair\w*|bald|blonde?|brunette|redhead|ponytail|braids?|curls?|curly)\b""", RegexOption.IGNORE_CASE)
    private val CLOTHES_WORDS = Regex("""\b(dress\w*|shirt\w*|t-shirt|pants|trousers|jeans|skirt|jacket|coat|cloth\w*|outfit|suit|sportswear|uniform|sweater|hoodie|shorts|bikini|swimsuit|top|blouse|gown|wear\w*|lingerie|tuxedo|vest|kimono)\b""", RegexOption.IGNORE_CASE)

    /**
     * Where the body must stay as in the photo: skin, face and hair keep the original (tone, shape and
     * pose), unless the order is about them. When the order is about clothes, the whole garment inside
     * the changed area may change (the editor often misses part of it). [t] changed in place.
     */
    private fun protectBody(found: BodyParts?, order: String, t: FloatArray, w: Int, h: Int, op: IntArray) {
        val parts = found ?: run { JobLog.add("Pulir con SDXL: no encontré personas; sin protección del cuerpo"); return }
        val skinOk = SKIN_WORDS.containsMatchIn(order)
        val hairOk = HAIR_WORDS.containsMatchIn(order)
        val faceOk = FACE_WORDS.containsMatchIn(order)
        val clothes = CLOTHES_WORDS.containsMatchIn(order)
        // keep (0..255) and garment (0..255) at the parts' size, smoothed by scaling up
        val keep = IntArray(parts.w * parts.h); val garment = IntArray(parts.w * parts.h)
        for (k in keep.indices) {
            val c = parts.classes[k].toInt() and 0xFF
            val kv = when (c) {
                BodyParts.FACE_SKIN -> if (faceOk) 0f else 1f
                BodyParts.BODY_SKIN -> if (skinOk) 0f else 0.92f
                BodyParts.HAIR -> if (hairOk) 0f else 0.9f
                else -> 0f
            }
            val v = (kv * 255).roundToInt(); keep[k] = Color.rgb(v, v, v)
        }
        // the old garment, grown a little: its edge is often taken for skin, and a protected edge left
        // a thin line of the old dress between the new one and the skin. A wider ring around it is
        // checked pixel by pixel (old garment's color or skin's?).
        val gm = BooleanArray(parts.w * parts.h) { clothes && (parts.classes[it].toInt() and 0xFF) == BodyParts.CLOTHES }
        // light fabric next to skin (a white hem over the thighs, lace at the neckline) is often taken
        // for skin: a wide ring around the garment is sorted by color, pixel by pixel
        val grown = dilate(gm, parts.w, parts.h, 3)
        val ring = dilate(gm, parts.w, parts.h, maxOf(10, parts.h / 40))
        for (k in garment.indices) { val g = if (grown[k]) 255 else if (ring[k]) 128 else 0; garment[k] = Color.rgb(g, g, g) }
        fun big(px: IntArray): IntArray {
            val b = Bitmap.createScaledBitmap(Bitmap.createBitmap(px, parts.w, parts.h, Bitmap.Config.ARGB_8888), w, h, true)
            return IntArray(w * h).also { b.getPixels(it, 0, w, 0, 0, w, h) }
        }
        val kp = big(keep)
        // the garment counts only near what the editor changed (its box, a bit wider)
        val box = run {
            var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
            for (y in 0 until h step 4) for (x in 0 until w step 4) if (t[y * w + x] > 0.25f) {
                if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y
            }
            if (x1 < 0) null else { val m = maxOf(x1 - x0, y1 - y0) / 6; Rect(maxOf(0, x0 - m), maxOf(0, y0 - m), minOf(w, x1 + m), minOf(h, y1 + m)) }
        }
        val gp = if (clothes && box != null) big(garment) else null
        // colors of the old garment and of the skin, to sort the ring's pixels
        val gStats = if (gp != null) SeamBlend.stats(op) { i -> (gp[i] and 0xFF) > 200 && box!!.contains(i % w, i / w) } else null
        val sStats = SeamBlend.stats(op) { i -> (kp[i] and 0xFF) > 200 }
        var kept = 0L; var added = 0L; var cleaned = 0L
        for (y in 0 until h) for (x in 0 until w) {
            val k = y * w + x
            var v = t[k]
            var kv = (kp[k] and 0xFF) / 255f
            if (gp != null && box!!.contains(x, y)) {
                val g = (gp[k] and 0xFF)
                if (g > 190) { v = 1f; kv = 0f; added++ }          // the garment and its grown edge: all new
                else if (g > 20 && gStats != null && sStats != null && nearer(op[k], gStats, sStats)) { v = maxOf(v, 0.95f); kv = 0f; cleaned++ }
            }
            if (kv > 0f && v > 0f) { v *= (1f - kv); kept++ }
            t[k] = v
        }
        if (cleaned > 0) JobLog.add("Pulir con SDXL: orilla de la prenda limpia (${(100.0 * cleaned / t.size).roundToInt()} % de la foto tenía restos del color viejo)")
        JobLog.add("Pulir con SDXL: según la orden «$order»: cuerpo protegido (piel ${if (skinOk) "puede cambiar" else "se conserva"}, pelo ${if (hairOk) "puede cambiar" else "se conserva"}, cara ${if (faceOk) "puede cambiar" else "se conserva"})" +
            (if (gp != null) " · prenda completa: sí" else "") + " · ${(100.0 * kept / t.size).roundToInt()} % de la foto protegido")
    }

    /** [m] grown by [r] cells (square). */
    private fun dilate(m: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val a = BooleanArray(m.size)
        for (y in 0 until h) for (x in 0 until w) if (m[y * w + x]) for (dx in -r..r) { val xx = x + dx; if (xx in 0 until w) a[y * w + xx] = true }
        val b = BooleanArray(m.size)
        for (y in 0 until h) for (x in 0 until w) if (a[y * w + x]) for (dy in -r..r) { val yy = y + dy; if (yy in 0 until h) b[yy * w + x] = true }
        return b
    }

    /** True when [p] looks more like the old garment than like the skin (brightness and color, scaled by spread). */
    private fun nearer(p: Int, g: SeamBlend.Stats, s: SeamBlend.Stats): Boolean {
        val r = ((p shr 16) and 0xFF).toFloat(); val gg = ((p shr 8) and 0xFF).toFloat(); val bb = (p and 0xFF).toFloat()
        val v = floatArrayOf(0.299f * r + 0.587f * gg + 0.114f * bb, 128f - 0.168736f * r - 0.331264f * gg + 0.5f * bb, 128f + 0.5f * r - 0.418688f * gg - 0.081312f * bb)
        var dg = 0f; var ds = 0f
        for (c in 0 until 3) {
            val wgt = if (c == 0) 0.5f else 1f
            dg += wgt * ((v[c] - g.mean[c]) / g.sd[c]).let { it * it }
            ds += wgt * ((v[c] - s.mean[c]) / s.sd[c]).let { it * it }
        }
        return dg < ds
    }

    /**
     * The person's pose in [piece] (the area SDXL redraws) as the ControlNet's input at [w]×[h], so SDXL
     * keeps arms, legs and head where they were. Downloads the ControlNet the first time (on Wi-Fi).
     */
    private fun poseControl(ctx: Context, piece: Bitmap, w: Int, h: Int, say: (String, Int) -> Unit, cancelled: () -> Boolean): NpuUnet.Control? {
        if (!ControlPose.hasSize(ctx, w, h)) {
            if (!Ui.onWifi(ctx)) { JobLog.notice("Pose: el control de pose se baja una vez con Wi-Fi (~1 GB); esta edición va sin él"); return null }
            try {
                JobLog.add("Pose: bajando el control de pose (una sola vez)")
                ControlPose.download(ctx, cancelled) { done, total ->
                    val pct = if (total > 0) (done * 100 / total).toInt() else 0
                    say(ctx.getString(R.string.pose_downloading, pct), pct)
                }
            } catch (t: Throwable) { JobLog.error("Pose: descarga", t); return null }
            if (!ControlPose.hasSize(ctx, w, h)) { JobLog.notice("Pose: todavía no hay control de pose para ${w}×$h"); return null }
        }
        val j = PoseImage.joints(piece) ?: run { JobLog.add("Pose: no encontré un cuerpo en la zona; va sin control de pose"); return null }
        val img = PoseImage.draw(j, w, h)
        try { java.io.FileOutputStream(File(ctx.cacheDir, "pose_last.png")).use { img.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Throwable) { }
        JobLog.add("Pose: ${j.count { it != null }} de 18 articulaciones; SDXL las respeta (fuerza 0.9)")
        return NpuUnet.Control(File(ControlPose.dir(ctx), "control_pose${ControlPose.tag(w, h)}_ctx.onnx"),
            mapOf("controlnet_cond" to PoseImage.toInput(img)), w, h, 0.9f, "Pose")
    }

    /**
     * The guides for SDXL: ControlNet Union (pose + depth: the body keeps its pose AND its volume) when
     * it is on the phone or can be downloaded now (Wi-Fi); else the pose one. [soften] (at [w]×[h]):
     * where the depth is smoothed (the old garment, so its volume isn't copied).
     */
    private fun guides(ctx: Context, piece: Bitmap, w: Int, h: Int, soften: FloatArray?, say: (String, Int) -> Unit, cancelled: () -> Boolean): NpuUnet.Control? {
        if (!QuickActionsActivity.on(ctx, "nitido", "q_pose")) return null
        val wantDepth = QuickActionsActivity.on(ctx, "nitido", "q_depth")
        if (wantDepth && !ControlUnion.hasSize(ctx, w, h) && Ui.onWifi(ctx)) try {
            JobLog.add("Forma del cuerpo: bajando ControlNet Union (una sola vez, ~1 GB)")
            ControlUnion.download(ctx, cancelled) { done, total -> say(ctx.getString(R.string.union_downloading, if (total > 0) (done * 100 / total).toInt() else 0), 0) }
        } catch (t: Throwable) { JobLog.add("Forma del cuerpo: no se pudo bajar ControlNet Union (${t.javaClass.simpleName}); va solo con la pose") }
        if (wantDepth && ControlUnion.hasSize(ctx, w, h)) {
            val j = PoseImage.joints(piece) ?: run { JobLog.add("Pose: no encontré un cuerpo en la zona; va sin guía"); return null }
            val pose = PoseImage.toInput(PoseImage.draw(j, w, h))
            val depth = try { ControlUnion.depth(ctx, piece, w, h, soften) } catch (t: Throwable) { JobLog.error("Profundidad", t); null }
                ?: return poseControl(ctx, piece, w, h, say, cancelled)
            JobLog.add("Guía: pose (${j.count { it != null }} de 18 articulaciones) + forma del cuerpo · ControlNet Union")
            return NpuUnet.Control(ControlUnion.file(ctx, w, h), mapOf("cond_pose" to pose, "cond_depth" to depth), w, h, 0.85f, "Union")
        }
        return poseControl(ctx, piece, w, h, say, cancelled)
    }

    /**
     * The person's body (skin and clothes; not face, hair, background or things like the phone) at
     * full size, 0..1, with a soft edge that stays on the silhouette (half way exactly at the border).
     */
    private fun bodyMask(pt: BodyParts, w: Int, h: Int): FloatArray {
        val m = FloatArray(pt.w * pt.h) { val c = pt.classes[it].toInt() and 0xFF; if (c == BodyParts.BODY_SKIN || c == BodyParts.CLOTHES) 1f else 0f }
        val sm = boxBlur(m, pt.w, pt.h, maxOf(1, pt.h / 200))
        return upscale(sm, pt.w, pt.h, w, h) { v -> val k = ((v - 0.25f) / 0.5f).coerceIn(0f, 1f); k * k * (3 - 2 * k) }
    }

    /**
     * The hands that show skin in the photo (1 = keep the original): around each wrist, a little past
     * it along the forearm, where the photo has skin. Zero everywhere when no body pose is found.
     */
    private fun handsOf(orig: Bitmap, pt: BodyParts, w: Int, h: Int): FloatArray {
        val out = FloatArray(w * h)
        val j = try { PoseImage.joints(orig) } catch (_: Throwable) { null } ?: return out
        var n = 0
        for ((el, wr) in listOf(3 to 4, 6 to 7)) {
            val e = j[el] ?: continue; val r = j[wr] ?: continue
            val ex = e[0] * w; val ey = e[1] * h; val rx = r[0] * w; val ry = r[1] * h
            val fl = sqrt((rx - ex) * (rx - ex) + (ry - ey) * (ry - ey))
            if (fl < 4f) continue
            val cx = rx + (rx - ex) * 0.35f; val cy = ry + (ry - ey) * 0.35f
            val rad = fl * 0.55f
            for (y in maxOf(0, (cy - rad).toInt())..minOf(h - 1, (cy + rad).toInt()))
                for (x in maxOf(0, (cx - rad).toInt())..minOf(w - 1, (cx + rad).toInt())) {
                    val d = sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / rad
                    if (d >= 1f) continue
                    if (pt.at((x + 0.5f) / w, (y + 0.5f) / h) != BodyParts.BODY_SKIN) continue
                    val k = ((1f - d) / 0.35f).coerceIn(0f, 1f)
                    val i = y * w + x; out[i] = maxOf(out[i], k * k * (3 - 2 * k))
                }
            n++
        }
        if (n > 0) JobLog.add("Editar: $n mano(s) quedan como en tu foto")
        return out
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(src.size); val out = FloatArray(src.size)
        for (y in 0 until h) for (x in 0 until w) {
            var sum = 0f; var c = 0
            for (d in -r..r) { val xx = x + d; if (xx in 0 until w) { sum += src[y * w + xx]; c++ } }
            tmp[y * w + x] = sum / c
        }
        for (y in 0 until h) for (x in 0 until w) {
            var sum = 0f; var c = 0
            for (d in -r..r) { val yy = y + d; if (yy in 0 until h) { sum += tmp[yy * w + x]; c++ } }
            out[y * w + x] = sum / c
        }
        return out
    }

    /** Bilinear upscale of a small 0..1 map to [w]×[h], then [f] on each value. */
    private fun upscale(m: FloatArray, mw: Int, mh: Int, w: Int, h: Int, f: (Float) -> Float): FloatArray {
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val fy = ((y + 0.5f) * mh / h - 0.5f).coerceIn(0f, (mh - 1).toFloat())
            val y0 = fy.toInt(); val y1 = minOf(mh - 1, y0 + 1); val ay = fy - y0
            for (x in 0 until w) {
                val fx = ((x + 0.5f) * mw / w - 0.5f).coerceIn(0f, (mw - 1).toFloat())
                val x0 = fx.toInt(); val x1 = minOf(mw - 1, x0 + 1); val ax = fx - x0
                val v = (m[y0 * mw + x0] * (1 - ax) + m[y0 * mw + x1] * ax) * (1 - ay) + (m[y1 * mw + x0] * (1 - ax) + m[y1 * mw + x1] * ax) * ay
                out[y * w + x] = f(v)
            }
        }
        return out
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun c(s: Int) = (((a shr s) and 0xFF) * (1 - t) + ((b shr s) and 0xFF) * t).roundToInt().coerceIn(0, 255)
        return Color.rgb(c(16), c(8), c(0))
    }

    /** Bounding box (full-size pixels) of where the small change map is clearly on. */
    private fun changedBox(mask: Bitmap, w: Int, h: Int): Rect? {
        val mw = mask.width; val mh = mask.height
        val p = IntArray(mw * mh); mask.getPixels(p, 0, mw, 0, 0, mw, mh)
        var x0 = mw; var y0 = mh; var x1 = -1; var y1 = -1
        for (y in 0 until mh) for (x in 0 until mw) if ((p[y * mw + x] and 0xFF) > 40) {
            if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y
        }
        if (x1 < 0) return null
        val kx = w.toFloat() / mw; val ky = h.toFloat() / mh
        return Rect((x0 * kx).toInt(), (y0 * ky).toInt(), minOf(w, ((x1 + 1) * kx).roundToInt()), minOf(h, ((y1 + 1) * ky).roundToInt()))
    }

    /** [r] grown to the shape [want] (width/height), kept inside the photo. */
    private fun widen(r: Rect, want: Float, w: Int, h: Int): Rect {
        // only grows: the changed area is never cut (a cut leaves a straight seam where the change was
        // at full strength). When the photo has no room to reach the NPU's shape, the area is
        // stretched a little to it and back, which shows far less than a seam.
        var rw = r.width(); var rh = r.height()
        if (rw.toFloat() / rh < want) rw = minOf(w, maxOf(rw, (rh * want).roundToInt())) else rh = minOf(h, maxOf(rh, (rw / want).roundToInt()))
        val l = (r.centerX() - rw / 2).coerceIn(0, w - rw); val t = (r.centerY() - rh / 2).coerceIn(0, h - rh)
        return Rect(l, t, l + rw, t + rh)
    }
}
