package com.nitido.app

/** Bridge to the native Stable Diffusion engine (libsdjni.so, built from MNN). */
object SdNative {
    const val BACKEND_CPU = 0
    const val BACKEND_OPENCL = 3

    fun interface Listener { fun onProgress(pct: Int) }

    val loadError: Throwable? = try { System.loadLibrary("sdjni"); null } catch (t: Throwable) { t }

    /**
     * [image] is an optional 3×512×512 RGB float array in [-1, 1] (channel-first) to start from;
     * [strength] 0..1 is how much of it may change.
     * Returns 0 ok, 2 model failed to load, 3 generation failed, 4 photo given but encoder missing.
     */
    @JvmStatic external fun generate(
        dir: String, cacheDir: String, backend: Int, steps: Int, seed: Int, out: String, prompt: String,
        image: FloatArray?, strength: Float, listener: Listener
    ): Int

    @JvmStatic external fun release()
}
