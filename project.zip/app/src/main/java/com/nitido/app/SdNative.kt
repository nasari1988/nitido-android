package com.nitido.app

/** Bridge to the native Stable Diffusion engine (libsdjni.so, built from MNN). */
object SdNative {
    const val BACKEND_CPU = 0
    const val BACKEND_OPENCL = 3

    fun interface Listener { fun onProgress(pct: Int) }

    val loadError: Throwable? = try { System.loadLibrary("sdjni"); null } catch (t: Throwable) { t }

    /** Returns 0 on success; 1 = engine not created, 2 = model failed to load, 3 = generation failed. */
    @JvmStatic external fun generate(dir: String, backend: Int, steps: Int, seed: Int, out: String, prompt: String, listener: Listener): Int

    @JvmStatic external fun release()
}
