package com.nitido.app

/** Bridge to the native Stable Diffusion engine (libsdjni.so, built from MNN). */
object SdNative {
    const val BACKEND_CPU = 0
    const val BACKEND_OPENCL = 3

    interface Listener {
        fun onProgress(pct: Int)
        /** [rgb] is width×height×3 bytes (RGB): a preview of the image at the current step. */
        fun onPreview(rgb: ByteArray, width: Int, height: Int)
        /** Between steps and decoding pieces: may wait here while the phone is too hot. */
        fun onCool() {}
    }

    const val PREVIEW_NONE = 0
    const val PREVIEW_FAST = 1
    const val PREVIEW_FULL = 2

    const val SAMPLER_PLMS = 0
    const val SAMPLER_DPM = 1

    val loadError: Throwable? = try { System.loadLibrary("sdjni"); null } catch (t: Throwable) { t }

    /**
     * [mode] 0 = normal model (text-to-image, or image-to-image when [image] is given), 1 = InstructPix2Pix.
     * [image] optional 3×512×512 RGB floats in [-1, 1], channel-first.
     * [strength] 0..1 how much of the photo may change (mode 0 with a photo).
     * [guidance] how strongly to follow the prompt; [imageGuidance] how strongly to keep the photo (mode 1).
     * Returns 0 ok, 2 model failed to load, 3 generation failed, 4 photo given but encoder missing,
     * 5 size not supported by this model, 6 cancelled. [width]/[height] are multiples of 64.
     */
    @JvmStatic external fun generate(
        dir: String, cacheDir: String, backend: Int, mode: Int, dynamic: Boolean, width: Int, height: Int,
        steps: Int, seed: Int, out: String,
        prompt: String, negative: String, image: FloatArray?, strength: Float, guidance: Float,
        imageGuidance: Float,
        maskedImage: FloatArray?, latMask: FloatArray?, previewMode: Int, sampler: Int, listener: Listener
    ): Int

    /** UNet on the NPU: called once per step with [2,C,h,w] latents; fills [out] ([2,4,h,w]). */
    interface NpuUnet {
        fun run(sample: FloatArray, channels: Int, timestep: Int, h: Int, emb: FloatArray, out: FloatArray): Boolean
        /** The VAE decoder on the NPU: latent [1,4,h,w] -> picture [1,3,8h,8w]; false = decode on the GPU. */
        fun decode(latent: FloatArray, h: Int, w: Int, out: FloatArray): Boolean = false
        /** SDXL's UNet on the NPU: [2,4,h,w] latents, text [2,77,2048], pooled [2,1280], time ids [2,6]. */
        fun runXl(sample: FloatArray, timestep: Int, h: Int, emb: FloatArray, pooled: FloatArray, timeIds: FloatArray, out: FloatArray): Boolean = false
    }

    /** Use [npu] for the UNet in the next generations (null = GPU/CPU as usual). */
    @JvmStatic external fun setNpu(npu: NpuUnet?)

    /** GPU options (tests): [tune] 0 fast / 1 wide kernel tuning; [mem] 0 low / 1 normal memory mode. */
    @JvmStatic external fun setGpuOptions(tune: Int, mem: Int)

    /** Where the last generation's time went (text, UNet load, steps, decode), for the status line. */
    @JvmStatic external fun lastTimings(): String

    /** Stops a running generation at the next step (it then returns 6). */
    @JvmStatic external fun cancel()

    /** True after [cancel] (until the next run). */
    @JvmStatic external fun isCancelled(): Boolean

    @JvmStatic external fun release()

    const val OK = 0
    const val CANCELLED = 6
    const val BAD_TEXT = 7
    const val BAD_UNET = 9
    const val NPU_FAILED = 11
}
