package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/**
 * Mejorar video › Limpiar: RealBasicVSR (Chan et al., CVPR 2022) on the NPU, in the 4 parts made in
 * the server (ci/rbvsr_npu.py): clean, flow (how one frame moved to another), a backward step and a
 * forward step that also makes the picture (4× the low-res frame).
 *
 * Frames come in one by one ([push]); they go out in the same order a few frames later: each block
 * of [BLOCK] frames is first walked backwards (with [AHEAD] frames after it, so the block's end
 * knows what comes next), then forwards making the pictures. The forward state carries on from one
 * block to the next, so there is no jump at the cuts.
 *
 * Every frame is fitted into the low-res size of its orientation (640×360 or 360×640) and the
 * spare space filled with its edge; the picture is cut back and resized to the output size.
 */
class Rbvsr private constructor(
    private val clean: Graph, private val flow: Graph, private val back: Graph, private val fwd: Graph,
    val w: Int, val h: Int, private val outW: Int, private val outH: Int,
) : AutoCloseable {

    /** One frame on its way: its low-res cleaned pixels (3×h×w, 0..1), its time, its used area. */
    private class Item(val lrc: FloatArray, val pts: Long, val vw: Int, val vh: Int)

    private val queue = ArrayList<Item>()
    private var prevLrc: FloatArray? = null
    private val zeroFlow = FloatArray(2 * w * h)
    // Memory: every 64×h×w feature stays as the NPU's own 16-bit numbers, outside the Java heap
    // (29 MB each); the NPU writes its results straight into them (no copies).
    private val n64 = C * w * h
    private var bA = QBuf(n64); private var bB = QBuf(n64)
    private var fA = QBuf(n64); private var fB = QBuf(n64)
    private val feats = Array(BLOCK) { QBuf(n64) }
    private val flowOut = QBuf(2 * w * h)
    private val cleanOut = QBuf(3 * w * h)
    private val img = QBuf(3 * 16 * w * h)
    private var fwdStarted = false
    var lastMs = 0L
        private set
    private var timeClean = 0L; private var timeFlow = 0L; private var timeBack = 0L; private var timeFwd = 0L; private var count = 0

    /** A decoded frame in; finished frames (ARGB, output size, with their time) out, maybe none yet. */
    fun push(px: IntArray, fw: Int, fh: Int, pts: Long): List<Pair<IntArray, Long>> {
        val t0 = SystemClock.elapsedRealtime()
        val (lr, vw, vh) = toLowRes(px, fw, fh)
        clean.run(mapOf("lr" to lr), mapOf("lrc" to cleanOut))
        timeClean += SystemClock.elapsedRealtime() - t0
        queue += Item(cleanOut.toFloats(), pts, vw, vh)
        return if (queue.size >= BLOCK + AHEAD) block(BLOCK) else emptyList()
    }

    /** The frames still waiting, at the end of the video. */
    fun flush(): List<Pair<IntArray, Long>> {
        val out = ArrayList<Pair<IntArray, Long>>()
        while (queue.size > BLOCK) out += block(BLOCK)
        if (queue.isNotEmpty()) out += block(queue.size)
        return out
    }

    /** Backward over the queue (all of it), forward over its first [n] frames, which leave. */
    private fun block(n: Int): List<Pair<IntArray, Long>> {
        val t = queue.size
        // backward: from the last frame to the first, each step seeing the one after it
        bA.zero()
        for (i in t - 1 downTo 0) {
            val tf = SystemClock.elapsedRealtime()
            val fl: Any = if (i < t - 1) { flow.run(mapOf("a" to queue[i].lrc, "b" to queue[i + 1].lrc), mapOf("flow" to flowOut)); flowOut } else zeroFlow
            val tb = SystemClock.elapsedRealtime(); timeFlow += tb - tf
            back.run(mapOf("lrc" to queue[i].lrc, "prop" to bA, "flow" to fl), mapOf("feat" to bB))
            timeBack += SystemClock.elapsedRealtime() - tb
            val x = bA; bA = bB; bB = x   // the new feature is now in bA
            if (i < n) feats[i].copyFrom(bA)
        }
        // forward: frame by frame, making the pictures
        if (!fwdStarted) { fA.zero(); fwdStarted = true }
        val done = ArrayList<Pair<IntArray, Long>>(n)
        for (i in 0 until n) {
            val it = queue[i]
            val t1 = SystemClock.elapsedRealtime()
            val p = prevLrc
            val fl: Any = if (p != null) { flow.run(mapOf("a" to it.lrc, "b" to p), mapOf("flow" to flowOut)); flowOut } else zeroFlow
            val t2 = SystemClock.elapsedRealtime(); timeFlow += t2 - t1
            fwd.run(mapOf("lrc" to it.lrc, "prop" to fA, "flow" to fl, "back" to feats[i]), mapOf("feat" to fB, "img" to img))
            val t3 = SystemClock.elapsedRealtime(); timeFwd += t3 - t2
            val x = fA; fA = fB; fB = x
            prevLrc = it.lrc
            done += toOutput(img, it.vw, it.vh) to it.pts
            lastMs = SystemClock.elapsedRealtime() - t1
            count++
            if (count == 3 || count % 300 == 0) JobLog.add(String.format(Locale.US,
                "Limpiar (NPU) por cuadro: limpiar %d ms · movimiento %d ms · atrás %d ms · adelante+imagen %d ms",
                timeClean / count, timeFlow / count, timeBack / count, timeFwd / count))
        }
        repeat(n) { queue.removeAt(0) }
        return done
    }

    /** The frame fitted into w×h (aspect kept), the rest filled with its edge pixels; 3×h×w 0..1. */
    private fun toLowRes(px: IntArray, fw: Int, fh: Int): Triple<FloatArray, Int, Int> {
        val k = minOf(w.toFloat() / fw, h.toFloat() / fh)
        val vw = (fw * k).toInt().coerceIn(1, w); val vh = (fh * k).toInt().coerceIn(1, h)
        val small = Bitmap.createScaledBitmap(Bitmap.createBitmap(px, fw, fh, Bitmap.Config.ARGB_8888), vw, vh, true)
        val sp = IntArray(vw * vh); small.getPixels(sp, 0, vw, 0, 0, vw, vh)
        val out = FloatArray(3 * w * h)
        val n = w * h
        for (y in 0 until h) {
            val sy = minOf(y, vh - 1)
            for (x in 0 until w) {
                val p = sp[sy * vw + minOf(x, vw - 1)]
                val i = y * w + x
                out[i] = ((p shr 16) and 255) / 255f
                out[n + i] = ((p shr 8) and 255) / 255f
                out[2 * n + i] = (p and 255) / 255f
            }
        }
        return Triple(out, vw, vh)
    }

    /** The 4× picture (3×4h×4w, 16-bit) cut to the frame's area and resized to the output. */
    private fun toOutput(im: QBuf, vw: Int, vh: Int): IntArray {
        val W = 4 * w; val H = 4 * h; val n = W * H
        val cw = 4 * vw; val ch = 4 * vh
        val q = im.q ?: throw IllegalStateException("imagen sin escala")
        val sb = im.buf.asShortBuffer()
        val u = q.type == 0x0416
        val px = IntArray(cw * ch)
        fun c(i: Int): Int { val x = sb.get(i).toInt(); return ((q.scale * ((if (u) x and 0xFFFF else x) + q.offset)) * 255f + 0.5f).toInt().coerceIn(0, 255) }
        for (y in 0 until ch) for (x in 0 until cw) {
            val i = y * W + x
            px[y * cw + x] = (0xFF shl 24) or (c(i) shl 16) or (c(n + i) shl 8) or c(2 * n + i)
        }
        val b = Bitmap.createScaledBitmap(Bitmap.createBitmap(px, cw, ch, Bitmap.Config.ARGB_8888), outW, outH, true)
        val out = IntArray(outW * outH); b.getPixels(out, 0, outW, 0, 0, outW, outH)
        return out
    }

    override fun close() { clean.close(); flow.close(); back.close(); fwd.close() }

    /** 16-bit numbers outside the Java heap, with the scale they are in (q). */
    class QBuf(val size: Int) {
        val buf: ByteBuffer = ByteBuffer.allocateDirect(size * 2).order(ByteOrder.nativeOrder())
        var q: NpuTile.Quant? = null
        /** Real 0 in its scale (set by the graph that reads it). */
        fun zero() { zeroQ = true }
        internal var zeroQ = false
        fun copyFrom(o: QBuf) { o.buf.rewind(); buf.rewind(); buf.put(o.buf); buf.rewind(); o.buf.rewind(); q = o.q; zeroQ = o.zeroQ }
        fun toFloats(): FloatArray {
            val qq = q ?: throw IllegalStateException("sin escala")
            val sb = buf.asShortBuffer(); val u = qq.type == 0x0416
            return FloatArray(size) { i -> val x = sb.get(i).toInt(); qq.scale * ((if (u) x and 0xFFFF else x) + qq.offset) }
        }
    }

    /** A graph compiled in the server: named inputs (floats or 16-bit buffers) and outputs written into 16-bit buffers. */
    class Graph(private val s: OrtSession, private val q: Map<String, NpuTile.Quant>) : AutoCloseable {
        private val env = OrtEnvironment.getEnvironment()
        private val inShapes = s.inputInfo.mapValues { (it.value.info as TensorInfo).shape }
        private val outShapes = s.outputInfo.mapValues { (it.value.info as TensorInfo).shape }
        private val bufs = HashMap<String, ByteBuffer>()

        fun run(ins: Map<String, Any>, outs: Map<String, QBuf>) {
            val tensors = ins.mapValues { (name, v) -> when (v) {
                is FloatArray -> fromFloats(name, v)
                is QBuf -> fromQ(name, v)
                else -> throw IllegalArgumentException("entrada $name")
            } }
            val pinned = outs.mapValues { (name, qb) ->
                qb.q = q[name] ?: throw IllegalStateException("salida $name sin escala")
                qb.zeroQ = false
                qb.buf.rewind()
                OnnxTensor.createTensor(env, qb.buf, outShapes[name], OnnxJavaType.INT16)
            }
            try {
                NpuMeter.begin()
                try { s.run(tensors, pinned).close() } finally { NpuMeter.end() }
            } finally { tensors.values.forEach { it.close() }; pinned.values.forEach { it.close() } }
        }

        private fun inQ(name: String) = q[name] ?: throw IllegalStateException("entrada $name sin escala")

        private fun bufFor(name: String, n: Int) = bufs.getOrPut(name) { ByteBuffer.allocateDirect(n * 2).order(ByteOrder.nativeOrder()) }.also { it.rewind() }

        private fun fromFloats(name: String, data: FloatArray): OnnxTensor {
            val qq = inQ(name)
            val bb = bufFor(name, data.size)
            val sb = bb.asShortBuffer()
            val inv = 1f / qq.scale
            val lo = if (qq.type == 0x0416) 0 else -32768; val hi = if (qq.type == 0x0416) 65535 else 32767
            for (i in data.indices) sb.put(i, (Math.round(data[i] * inv) - qq.offset).coerceIn(lo, hi).toShort())
            return OnnxTensor.createTensor(env, bb, inShapes[name], OnnxJavaType.INT16)
        }

        /** A 16-bit buffer into this input: as is when the scales match, converted when not. */
        private fun fromQ(name: String, v: QBuf): OnnxTensor {
            val qq = inQ(name)
            val lo = if (qq.type == 0x0416) 0 else -32768; val hi = if (qq.type == 0x0416) 65535 else 32767
            if (v.zeroQ) {
                // real 0 in this input's scale
                val bb = bufFor(name, v.size); val sb = bb.asShortBuffer()
                val z = (-qq.offset).coerceIn(lo, hi).toShort()
                for (i in 0 until v.size) sb.put(i, z)
                return OnnxTensor.createTensor(env, bb, inShapes[name], OnnxJavaType.INT16)
            }
            val src = v.q ?: throw IllegalStateException("$name: buffer sin escala")
            if (src.scale == qq.scale && src.offset == qq.offset && src.type == qq.type) {
                v.buf.rewind()
                return OnnxTensor.createTensor(env, v.buf, inShapes[name], OnnxJavaType.INT16)
            }
            val bb = bufFor(name, v.size)
            val sIn = v.buf.asShortBuffer(); val sOut = bb.asShortBuffer()
            val us = src.type == 0x0416
            val k = src.scale / qq.scale
            val add = src.offset * k - qq.offset
            for (i in 0 until v.size) {
                val x = sIn.get(i).toInt()
                sOut.put(i, Math.round((if (us) x and 0xFFFF else x) * k + add).coerceIn(lo, hi).toShort())
            }
            return OnnxTensor.createTensor(env, bb, inShapes[name], OnnxJavaType.INT16)
        }

        override fun close() { try { s.close() } catch (_: Throwable) { } }
    }

    companion object {
        const val PACK = "limpiar-npu"
        const val MODEL = "realbasicvsr"
        private const val C = 64
        private const val BLOCK = 6
        private const val AHEAD = 3

        fun isReady(ctx: Context) = SdModel.isReady(ctx, PACK) &&
            listOf("640x360", "360x640").all { t -> listOf("clean", "flow", "back", "fwd").all { File(SdModel.dir(ctx, PACK), "rb_${it}_${t}_ctx.onnx").exists() } }

        fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
            SdModel.download(ctx, PACK, cancelled, onProgress)

        /** Opens the 4 parts for frames of [fw]×[fh] (landscape or portrait), output [outW]×[outH]. */
        fun open(ctx: Context, fw: Int, fh: Int, outW: Int, outH: Int): Rbvsr? {
            val tag = if (fw >= fh) "640x360" else "360x640"
            val (w, h) = if (fw >= fh) 640 to 360 else 360 to 640
            val dir = SdModel.dir(ctx, PACK)
            NpuUnet.prepareDsp(ctx)
            val opened = ArrayList<Graph>()
            try {
                for (p in listOf("clean", "flow", "back", "fwd")) {
                    val f = File(dir, "rb_${p}_${tag}_ctx.onnx")
                    val t0 = SystemClock.elapsedRealtime()
                    val opts = OrtSession.SessionOptions().apply {
                        setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                        addConfigEntry("session.disable_cpu_ep_fallback", "0")
                        addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
                    }
                    val s = OrtEnvironment.getEnvironment().createSession(f.path, opts)
                    val q = readQuant(File(f.path + ".json"))
                    opened += Graph(s, q)
                    JobLog.add("NPU: rb_$p $tag abierto en ${SystemClock.elapsedRealtime() - t0} ms · entradas ${s.inputNames.joinToString()} · salidas ${s.outputNames.joinToString()}")
                }
            } catch (t: Throwable) {
                opened.forEach { it.close() }
                JobLog.notice("Limpiar: la NPU no abrió las piezas (${t.message?.take(200)})${NpuUnet.qnnLog()}")
                return null
            }
            return Rbvsr(opened[0], opened[1], opened[2], opened[3], w, h, outW, outH)
        }

        private fun readQuant(f: File): Map<String, NpuTile.Quant> = try {
            val j = org.json.JSONObject(f.readText()).optJSONObject("quant")
            if (j == null) emptyMap() else j.keys().asSequence().mapNotNull { k ->
                val o = j.getJSONObject(k)
                if (!o.has("scale")) null else k to NpuTile.Quant(o.getInt("qnn_type"), o.getDouble("scale").toFloat(), o.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }
    }
}
