package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/**
 * Mejorar video › Limpiar: RealBasicVSR (Chan et al., CVPR 2022) on the NPU, in the 4 parts made in
 * the server (ci/rbvsr_npu.py): clean, flow (how one frame moved to another), a backward step and a
 * forward step that also makes the picture (4× the low-res frame).
 *
 * Frames come in one by one ([push]); they go out in the same order a few frames later: each block
 * of [BLOCK] frames is first walked backwards (with [AHEAD] frames after it, so the block's end
 * knows what comes next), then forwards making the pictures. The forward state carries on from one
 * block to the next, so there is no jump at the cuts.
 *
 * Every frame is fitted into the low-res size of its orientation (640×360 or 360×640) and the
 * spare space filled with its edge; the picture is cut back and resized to the output size.
 */
class Rbvsr private constructor(
    private val clean: Graph, private val flow: Graph, private val back: Graph, private val fwd: Graph,
    val w: Int, val h: Int, private val outW: Int, private val outH: Int,
) : AutoCloseable {

    /** One frame on its way: its low-res cleaned pixels (3×h×w, 0..1), its time, its used area. */
    private class Item(val lrc: FloatArray, val pts: Long, val vw: Int, val vh: Int)

    private val queue = ArrayList<Item>()
    private var prevLrc: FloatArray? = null
    private val zeroFlow = FloatArray(2 * w * h)
    // Memory: four feature buffers of 64×h×w floats (59 MB each) reused all the time; the block's
    // backward features wait outside the Java heap as 16-bit numbers (29 MB each).
    private var bufA = FloatArray(C * w * h)
    private var bufB = FloatArray(C * w * h)
    private var fwdProp = FloatArray(C * w * h)
    private var fwdNext = FloatArray(C * w * h)
    private val feats = Array(BLOCK) { ByteBuffer.allocateDirect(C * w * h * 2).order(ByteOrder.nativeOrder()) }
    private var featScale = 1f
    private val flowBuf = FloatArray(2 * w * h)
    private val img = FloatArray(3 * 16 * w * h)
    var lastMs = 0L
        private set
    private var timeClean = 0L; private var timeFlow = 0L; private var timeBack = 0L; private var timeFwd = 0L; private var count = 0

    /** A decoded frame in; finished frames (ARGB, output size, with their time) out, maybe none yet. */
    fun push(px: IntArray, fw: Int, fh: Int, pts: Long): List<Pair<IntArray, Long>> {
        val t0 = SystemClock.elapsedRealtime()
        val (lr, vw, vh) = toLowRes(px, fw, fh)
        val lrc = FloatArray(3 * w * h)
        clean.run(mapOf("lr" to lr), mapOf("lrc" to lrc))
        timeClean += SystemClock.elapsedRealtime() - t0
        queue += Item(lrc, pts, vw, vh)
        return if (queue.size >= BLOCK + AHEAD) block(BLOCK) else emptyList()
    }

    /** The frames still waiting, at the end of the video. */
    fun flush(): List<Pair<IntArray, Long>> {
        val out = ArrayList<Pair<IntArray, Long>>()
        while (queue.size > BLOCK) out += block(BLOCK)
        if (queue.isNotEmpty()) out += block(queue.size)
        return out
    }

    /** Backward over the queue (all of it), forward over its first [n] frames, which leave. */
    private fun block(n: Int): List<Pair<IntArray, Long>> {
        val t = queue.size
        // backward: from the last frame to the first, each step seeing the one after it
        java.util.Arrays.fill(bufA, 0f)
        for (i in t - 1 downTo 0) {
            val tf = SystemClock.elapsedRealtime()
            val fl = if (i < t - 1) { flow.run(mapOf("a" to queue[i].lrc, "b" to queue[i + 1].lrc), mapOf("flow" to flowBuf)); flowBuf } else zeroFlow
            val tb = SystemClock.elapsedRealtime(); timeFlow += tb - tf
            back.run(mapOf("lrc" to queue[i].lrc, "prop" to bufA, "flow" to fl), mapOf("feat" to bufB))
            timeBack += SystemClock.elapsedRealtime() - tb
            val x = bufA; bufA = bufB; bufB = x   // the new feature is now in bufA
            if (i < n) pack(bufA, feats[i])
        }
        // forward: frame by frame, making the pictures
        val done = ArrayList<Pair<IntArray, Long>>(n)
        for (i in 0 until n) {
            val it = queue[i]
            val t1 = SystemClock.elapsedRealtime()
            val p = prevLrc
            val fl = if (p != null) { flow.run(mapOf("a" to it.lrc, "b" to p), mapOf("flow" to flowBuf)); flowBuf } else zeroFlow
            val t2 = SystemClock.elapsedRealtime(); timeFlow += t2 - t1
            unpack(feats[i], bufA)
            fwd.run(mapOf("lrc" to it.lrc, "prop" to fwdProp, "flow" to fl, "back" to bufA), mapOf("feat" to fwdNext, "img" to img))
            val t3 = SystemClock.elapsedRealtime(); timeFwd += t3 - t2
            val x = fwdProp; fwdProp = fwdNext; fwdNext = x
            prevLrc = it.lrc
            done += toOutput(img, it.vw, it.vh) to it.pts
            lastMs = SystemClock.elapsedRealtime() - t1
            count++
            if (count == 3 || count % 300 == 0) JobLog.add(String.format(Locale.US,
                "Limpiar (NPU) por cuadro: limpiar %d ms · movimiento %d ms · atrás %d ms · adelante+imagen %d ms",
                timeClean / count, timeFlow / count, timeBack / count, timeFwd / count))
        }
        repeat(n) { queue.removeAt(0) }
        return done
    }

    /** float features → 16-bit outside the heap (one scale: 1.5× the largest value of the first frame). */
    private fun pack(f: FloatArray, dst: ByteBuffer) {
        if (featScale == 1f) {
            var m = 1e-3f
            for (v in f) { val a = Math.abs(v); if (a > m) m = a }
            featScale = m * 1.5f / 32767f
        }
        val inv = 1f / featScale
        val sb = dst.asShortBuffer()
        for (i in f.indices) sb.put(i, Math.round(f[i] * inv).coerceIn(-32767, 32767).toShort())
    }

    private fun unpack(src: ByteBuffer, out: FloatArray) { val sb = src.asShortBuffer(); for (i in out.indices) out[i] = sb.get(i) * featScale }

    /** The frame fitted into w×h (aspect kept), the rest filled with its edge pixels; 3×h×w 0..1. */
    private fun toLowRes(px: IntArray, fw: Int, fh: Int): Triple<FloatArray, Int, Int> {
        val k = minOf(w.toFloat() / fw, h.toFloat() / fh)
        val vw = (fw * k).toInt().coerceIn(1, w); val vh = (fh * k).toInt().coerceIn(1, h)
        val small = Bitmap.createScaledBitmap(Bitmap.createBitmap(px, fw, fh, Bitmap.Config.ARGB_8888), vw, vh, true)
        val sp = IntArray(vw * vh); small.getPixels(sp, 0, vw, 0, 0, vw, vh)
        val out = FloatArray(3 * w * h)
        val n = w * h
        for (y in 0 until h) {
            val sy = minOf(y, vh - 1)
            for (x in 0 until w) {
                val p = sp[sy * vw + minOf(x, vw - 1)]
                val i = y * w + x
                out[i] = ((p shr 16) and 255) / 255f
                out[n + i] = ((p shr 8) and 255) / 255f
                out[2 * n + i] = (p and 255) / 255f
            }
        }
        return Triple(out, vw, vh)
    }

    /** The 4× picture (3×4h×4w) cut to the frame's area and resized to the output. */
    private fun toOutput(im: FloatArray, vw: Int, vh: Int): IntArray {
        val W = 4 * w; val H = 4 * h; val n = W * H
        val cw = 4 * vw; val ch = 4 * vh
        val px = IntArray(cw * ch)
        for (y in 0 until ch) for (x in 0 until cw) {
            val i = y * W + x
            fun c(v: Float) = (v * 255f + 0.5f).toInt().coerceIn(0, 255)
            px[y * cw + x] = (0xFF shl 24) or (c(im[i]) shl 16) or (c(im[n + i]) shl 8) or c(im[2 * n + i])
        }
        val b = Bitmap.createScaledBitmap(Bitmap.createBitmap(px, cw, ch, Bitmap.Config.ARGB_8888), outW, outH, true)
        val out = IntArray(outW * outH); b.getPixels(out, 0, outW, 0, 0, outW, outH)
        return out
    }

    override fun close() { clean.close(); flow.close(); back.close(); fwd.close() }

    /** A graph compiled in the server, several named inputs and outputs (quantized ones converted). */
    class Graph(private val s: OrtSession, private val q: Map<String, NpuTile.Quant>) : AutoCloseable {
        private val env = OrtEnvironment.getEnvironment()
        private val shapes = s.inputInfo.mapValues { (it.value.info as TensorInfo).shape }
        private val bufs = HashMap<String, ByteBuffer>()

        fun run(ins: Map<String, FloatArray>, outs: Map<String, FloatArray>) {
            val tensors = ins.mapValues { (name, data) -> tensor(name, data) }
            try {
                NpuMeter.begin()
                val r = try { s.run(tensors) } finally { NpuMeter.end() }
                r.use {
                    for ((name, v) in it) {
                        val dst = outs[name] ?: continue
                        val o = v as OnnxTensor
                        val qq = q[name]
                        if (qq == null) o.floatBuffer.get(dst, 0, minOf(dst.size, o.floatBuffer.remaining()))
                        else {
                            val sb = o.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val u = qq.type == 0x0416
                            for (i in 0 until minOf(dst.size, sb.remaining())) {
                                val x = sb.get(i).toInt(); dst[i] = qq.scale * ((if (u) x and 0xFFFF else x) + qq.offset)
                            }
                        }
                    }
                }
            } finally { tensors.values.forEach { it.close() } }
        }

        private fun tensor(name: String, data: FloatArray): OnnxTensor {
            val shape = shapes[name] ?: throw IllegalArgumentException("sin entrada $name")
            val qq = q[name] ?: return OnnxTensor.createTensor(env, java.nio.FloatBuffer.wrap(data), shape)
            val bb = bufs.getOrPut(name) { ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder()) }
            bb.clear()
            val sb = bb.asShortBuffer()
            val inv = 1f / qq.scale
            val lo = if (qq.type == 0x0416) 0 else -32768; val hi = if (qq.type == 0x0416) 65535 else 32767
            for (i in data.indices) sb.put(i, (Math.round(data[i] * inv) - qq.offset).coerceIn(lo, hi).toShort())
            bb.rewind()
            return OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
        }

        override fun close() { try { s.close() } catch (_: Throwable) { } }
    }

    companion object {
        const val PACK = "limpiar-npu"
        const val MODEL = "realbasicvsr"
        private const val C = 64
        private const val BLOCK = 6
        private const val AHEAD = 3

        fun isReady(ctx: Context) = SdModel.isReady(ctx, PACK) &&
            listOf("640x360", "360x640").all { t -> listOf("clean", "flow", "back", "fwd").all { File(SdModel.dir(ctx, PACK), "rb_${it}_${t}_ctx.onnx").exists() } }

        fun download(ctx: Context, cancelled: () -> Boolean, onProgress: (Long, Long) -> Unit) =
            SdModel.download(ctx, PACK, cancelled, onProgress)

        /** Opens the 4 parts for frames of [fw]×[fh] (landscape or portrait), output [outW]×[outH]. */
        fun open(ctx: Context, fw: Int, fh: Int, outW: Int, outH: Int): Rbvsr? {
            val tag = if (fw >= fh) "640x360" else "360x640"
            val (w, h) = if (fw >= fh) 640 to 360 else 360 to 640
            val dir = SdModel.dir(ctx, PACK)
            NpuUnet.prepareDsp(ctx)
            val opened = ArrayList<Graph>()
            try {
                for (p in listOf("clean", "flow", "back", "fwd")) {
                    val f = File(dir, "rb_${p}_${tag}_ctx.onnx")
                    val t0 = SystemClock.elapsedRealtime()
                    val opts = OrtSession.SessionOptions().apply {
                        setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
                        addConfigEntry("session.disable_cpu_ep_fallback", "0")
                        addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
                    }
                    val s = OrtEnvironment.getEnvironment().createSession(f.path, opts)
                    val q = readQuant(File(f.path + ".json"))
                    opened += Graph(s, q)
                    JobLog.add("NPU: rb_$p $tag abierto en ${SystemClock.elapsedRealtime() - t0} ms · entradas ${s.inputNames.joinToString()} · salidas ${s.outputNames.joinToString()}")
                }
            } catch (t: Throwable) {
                opened.forEach { it.close() }
                JobLog.notice("Limpiar: la NPU no abrió las piezas (${t.message?.take(200)})${NpuUnet.qnnLog()}")
                return null
            }
            return Rbvsr(opened[0], opened[1], opened[2], opened[3], w, h, outW, outH)
        }

        private fun readQuant(f: File): Map<String, NpuTile.Quant> = try {
            val j = org.json.JSONObject(f.readText()).optJSONObject("quant")
            if (j == null) emptyMap() else j.keys().asSequence().mapNotNull { k ->
                val o = j.getJSONObject(k)
                if (!o.has("scale")) null else k to NpuTile.Quant(o.getInt("qnn_type"), o.getDouble("scale").toFloat(), o.getInt("offset"))
            }.toMap()
        } catch (t: Throwable) { emptyMap() }
    }
}
