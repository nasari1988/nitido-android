package com.nitido.app

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.View
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityVideoBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * Video: Mejorar a whole video (each frame through Mejorar's enhancer, on the NPU), in parts that
 * survive interruptions, with the original audio; and Más fluido (RIFE: a made-up frame between every
 * two). Restaurar video comes later.
 */
class VideoActivity : AppCompatActivity() {

    private lateinit var b: ActivityVideoBinding
    private lateinit var proc: ProcessScreen
    private lateinit var opts: OptionBar

    private var uri: Uri? = null
    private var name = "video"
    private var size = 0L
    private var durationUs = 0L
    private var plan: VideoEnhancer.Plan? = null
    private var outUri: Uri? = null

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) open(u) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityVideoBinding.inflate(layoutInflater)
        setContentView(b.root)
        proc = ProcessScreen(this) { cancelFlag = true }
        screen = java.lang.ref.WeakReference(this)
        b.back.setOnClickListener { finish() }
        b.pick.setOnClickListener { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }
        b.play.setOnClickListener { play() }
        b.player.onFullscreen = { imp, orig, showImp, pos -> b.player.pause(); FullscreenActivity.video(this, imp, orig, showImp, pos) }
        b.backToVideo.setOnClickListener { showPlayer(true) }
        b.go.setOnClickListener {
            when {
                running -> cancelFlag = true
                simple && uri == null -> picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                else -> start()
            }
        }
        b.test.setOnClickListener { testFrame() }
        val prefs = getSharedPreferences("video", MODE_PRIVATE)
        b.scaleGroup.check(if (prefs.getInt("scale", 2) == 4) R.id.vScale4 else R.id.vScale2)
        b.modelGroup.check(when (prefs.getString("quality", "ultra")) { "detail" -> R.id.vDetail; "fast" -> R.id.vFast; else -> R.id.vUltra })
        b.engineGroup.check(if (prefs.getBoolean("gpu", false)) R.id.vGpu else R.id.vNpu)
        b.framesGroup.check(if (prefs.getBoolean("half", false)) R.id.vHalf else R.id.vAll)
        b.sharpGroup.check(when (prefs.getInt("sharp", 1)) { 0 -> R.id.vSharpNone; 2 -> R.id.vSharpHigh; else -> R.id.vSharpMid })
        b.formatGroup.check(if (prefs.getBoolean("hevc", false)) R.id.vH265 else R.id.vH264)
        b.modeGroup.check(when (prefs.getString("mode", "enhance")) { "fluid" -> R.id.vModeFluid; "both" -> R.id.vModeBoth; else -> R.id.vModeEnhance })
        antiFlicker = prefs.getBoolean("antiflicker", true)
        denoise = prefs.getBoolean("denoise", false)
        for (g in listOf(b.modeGroup, b.scaleGroup, b.modelGroup, b.engineGroup, b.framesGroup, b.sharpGroup, b.formatGroup))
            g.addOnButtonCheckedListener { _, _, checked -> if (checked) { remember(); replan() } }
        buildFragment()
        buildAdjust()
        buildClean()
        setupOptions()
        LogDialog.addTo(this, opts)
        b.go.isEnabled = false
        buildSimple()
        b.play.isEnabled = true
        setStatus(getString(R.string.video_hint))
        if (running) {
            // back to a video that is still being made: show its progress again
            setBusy(true)
            b.compare.before = poster
            proc.show(getString(R.string.video_working), poster, startedAt)
            lastProgress?.let { showProgress(it) }
        } else {
            // an unfinished video from before (stopped, or the app was closed): offer to go on with it
            prefs.getString("uri", null)?.let { s -> if (!BgWork.busy) try { open(Uri.parse(s)) } catch (t: Throwable) { } }
        }
    }

    // ---------- the simple screen: one button, three choices ----------

    private var simple = true
    private lateinit var simpleBox: android.widget.LinearLayout
    private lateinit var simpleSub: android.widget.TextView
    private val modeChips = mutableListOf<Pair<android.widget.TextView, Int>>()
    private lateinit var backSimple: android.widget.TextView

    /** In Modo avanzado: a link back to the simple screen (the switch is also in Ajustes). */
    private fun simpleLink(onBack: () -> Unit) = Ui.text(this, getString(R.string.back_to_simple), 14f, R.color.accent).apply {
        gravity = android.view.Gravity.CENTER
        setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8))
        setOnClickListener { Prefs.setAdvanced(context, false); JobLog.add("Volver a lo sencillo"); onBack() }
    }

    private fun buildSimple() {
        val root = b.root as android.widget.LinearLayout
        simpleBox = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val chips = Ui.chipRow(this)
        for ((label, id) in listOf(R.string.vsimple_both to R.id.vModeBoth, R.string.vsimple_fluid to R.id.vModeFluid, R.string.vsimple_sharp to R.id.vModeEnhance)) {
            val c = Ui.chip(this, getString(label), b.modeGroup.checkedButtonId == id) { if (!running) b.modeGroup.check(id) }
            modeChips += c to id; chips.addView(c)
        }
        simpleBox.addView(chips)
        root.addView(simpleBox, root.indexOfChild(b.optLabels) + 1)
        simpleSub = Ui.text(this, "", 13f, R.color.muted).apply { gravity = android.view.Gravity.CENTER }
        root.addView(simpleSub, root.indexOfChild(b.status))
        backSimple = simpleLink { applyMode(); replan() }
        root.addView(backSimple, root.indexOfChild(b.status) + 1)
        b.modeGroup.addOnButtonCheckedListener { _, _, on -> if (on) syncChips() }
        applyMode()
    }

    private fun applyMode() {
        simple = !Prefs.advanced(this)
        for (v in listOf(b.optPanel, b.optLabels, b.test, b.estimate, b.info)) Ui.gone(v, simple)
        Ui.gone(simpleBox, !simple); Ui.gone(simpleSub, !simple); Ui.gone(backSimple, simple)
        if (simple) {
            // Calidad (Ajustes) picks the enhancer; the rest stays automatic
            b.modelGroup.check(when (Prefs.quality(this)) { "fast" -> R.id.vFast; "max" -> R.id.vDetail; else -> R.id.vUltra })
            b.scaleGroup.check(R.id.vScale2)
            b.framesGroup.check(R.id.vAll)
            b.sharpGroup.check(R.id.vSharpMid)
        }
        syncChips(); renderSimple()
    }

    private fun syncChips() { for ((v, id) in modeChips) Ui.setChip(v, b.modeGroup.checkedButtonId == id) }

    private fun renderSimple() {
        if (!::simpleBox.isInitialized || !simple) return
        if (!running) {
            if (uri == null) { b.go.text = getString(R.string.vsimple_pick); b.go.isEnabled = !BgWork.busy }
            else if (b.go.text == getString(R.string.video_go)) b.go.text = getString(R.string.vsimple_go)
        }
        val p = plan
        simpleSub.text = when {
            uri == null -> getString(R.string.vsimple_intro)
            p == null -> ""
            else -> listOfNotNull(
                when {
                    p.fluid && p.enhance -> getString(R.string.vsimple_will_both, p.outFps.roundToInt())
                    p.fluid -> getString(R.string.vsimple_will_fluid, p.outFps.roundToInt())
                    else -> getString(R.string.vsimple_will_sharp)
                },
                "~" + formatTime(VideoEnhancer.estimateSec(p) * (1f - VideoEnhancer.partsDone(this, p).toFloat() / p.segments)),
            ).joinToString(" · ")
        }
    }

    override fun onResume() {
        super.onResume()
        if (::simpleBox.isInitialized && simple != !Prefs.advanced(this) && !running) { applyMode(); replan() }
    }

    private fun setupOptions() {
        opts = OptionBar(this, b.optLabels, b.optPanel)
        opts.add(getString(R.string.video_mode), { getString(when { !enhance() -> R.string.video_mode_fluid; fluid() -> R.string.video_mode_both; else -> R.string.video_mode_enhance }) },
            listOf(b.modeGroup, b.modeNote), shown = { true })
        opts.add(getString(R.string.video_fragment), {
            if (startUs <= 0 && (endUs <= 0 || endUs >= durationUs)) getString(R.string.video_fragment_all) else "${clock(startUs)}–${clock(endOr())}"
        }, listOf(b.fragmentBox), shown = { true }, closeOnPick = false)
        opts.add(getString(R.string.label_scale), { if (scale() == 4) "×4" else "×2" }, listOf(b.scaleGroup), shown = { enhance() })
        opts.add(getString(R.string.label_model), { getString(when (quality()) { "detail" -> R.string.model_detail; "fast" -> R.string.model_fast; else -> R.string.video_ultra }) },
            listOf(b.modelGroup, b.qualityNote), shown = { enhance() })
        opts.add(getString(R.string.label_engine), { if (engine() == Engine.NPU || quality() == "ultra") "⚡ NPU" else "GPU" }, listOf(b.engineGroup),
            shown = { enhance() && quality() != "ultra" })
        opts.add(getString(R.string.video_frames), { getString(if (half()) R.string.video_frames_half else R.string.video_frames_all) },
            listOf(b.framesGroup, b.framesNote), shown = { !fluid() })
        opts.add(getString(R.string.video_sharp), { getString(when (sharp()) { 0 -> R.string.video_sharp_none_l; 2 -> R.string.video_sharp_high_l; else -> R.string.video_sharp_mid_l }) },
            listOf(b.sharpGroup))
        opts.add(getString(R.string.adjust_title), { getString(R.string.adjust_title) }, listOf(b.adjustBox), on = { !adjust.isNeutral },
            shown = { true }, closeOnPick = false)
        opts.add(getString(R.string.video_clean), {
            val n = listOf(antiFlicker, denoise, deinterlace).count { it }
            if (n == 0) getString(R.string.video_clean_none) else getString(R.string.video_clean_n, n)
        }, listOf(b.cleanBox), on = { antiFlicker || denoise || deinterlace }, shown = { true }, closeOnPick = false)
        opts.add(getString(R.string.video_format), { if (hevc()) "H.265" else "H.264" }, listOf(b.formatGroup, b.formatNote))
    }

    private fun enhance() = b.modeGroup.checkedButtonId != R.id.vModeFluid
    private fun fluid() = b.modeGroup.checkedButtonId != R.id.vModeEnhance
    private fun mode() = when { !enhance() -> "fluid"; fluid() -> "both"; else -> "enhance" }
    private fun scale() = if (b.scaleGroup.checkedButtonId == R.id.vScale4) 4 else 2
    private fun quality() = when (b.modelGroup.checkedButtonId) { R.id.vDetail -> "detail"; R.id.vFast -> "fast"; else -> "ultra" }
    private fun engine() = if (b.engineGroup.checkedButtonId == R.id.vGpu) Engine.GPU else Engine.NPU
    private fun half() = b.framesGroup.checkedButtonId == R.id.vHalf
    private fun sharp() = when (b.sharpGroup.checkedButtonId) { R.id.vSharpNone -> 0; R.id.vSharpHigh -> 2; else -> 1 }
    private fun hevc() = b.formatGroup.checkedButtonId == R.id.vH265
    /** Limpiar (RealBasicVSR on the NPU) in the simple screen, unless Calidad is Rápido. */
    private fun model() = if (simple && Prefs.quality(this) != "fast") Rbvsr.MODEL
        else when (quality()) { "detail" -> Upscaler.MODEL_X4PLUS; "fast" -> Upscaler.MODEL_FILE; else -> Upscaler.MODEL_QSR }
    /** Color adjustments plus the sharpness label (same tools as Restaurar). */
    private fun adjustAll() = adjust.copy(sharpness = when (sharp()) { 0 -> 0; 2 -> 70; else -> 35 })

    private fun remember() = getSharedPreferences("video", MODE_PRIVATE).edit()
        .putInt("scale", scale()).putString("quality", quality()).putBoolean("gpu", engine() == Engine.GPU).putBoolean("half", half())
        .putString("mode", mode()).putInt("sharp", sharp()).putBoolean("hevc", hevc()).putBoolean("antiflicker", antiFlicker).putBoolean("denoise", denoise).apply()

    // ───────── fragment, color adjustments, cleanup ─────────

    private var startUs = 0L
    private var endUs = 0L
    private var adjust = PhotoAdjust.Values()
    private var antiFlicker = true
    private var denoise = false
    private var deinterlace = false
    private var fragSlider: com.google.android.material.slider.RangeSlider? = null
    private var fragText: android.widget.TextView? = null
    private val cleanSwitches = mutableListOf<com.google.android.material.materialswitch.MaterialSwitch>()

    private fun endOr() = if (endUs <= 0) durationUs else endUs
    private fun clock(us: Long): String { val s = (us / 1_000_000).toInt(); return "${s / 60}:%02d".format(s % 60) }
    private fun muted(t: String) = android.widget.TextView(this).apply { text = t; textSize = 12f; setTextColor(getColor(R.color.muted)) }

    private fun buildFragment() {
        val box = b.fragmentBox
        fragText = muted("")
        val sl = com.google.android.material.slider.RangeSlider(this).apply {
            valueFrom = 0f; valueTo = 1f; values = listOf(0f, 1f); stepSize = 0f
            setLabelFormatter { v -> clock((v * 1_000_000).toLong()) }
            addOnChangeListener { s2, _, fromUser ->
                if (!fromUser) return@addOnChangeListener
                startUs = (s2.values[0] * 1_000_000).toLong(); endUs = (s2.values[1] * 1_000_000).toLong()
                showFragment(); opts.refresh()
            }
            addOnSliderTouchListener(object : com.google.android.material.slider.RangeSlider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: com.google.android.material.slider.RangeSlider) {}
                override fun onStopTrackingTouch(slider: com.google.android.material.slider.RangeSlider) { replan() }
            })
        }
        fragSlider = sl
        box.addView(sl)
        box.addView(fragText)
        box.addView(com.google.android.material.button.MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
            text = getString(R.string.video_fragment_all_btn)
            setOnClickListener { startUs = 0; endUs = 0; syncFragment(); replan() }
        })
    }

    private fun syncFragment() {
        val sl = fragSlider ?: return
        val dur = (durationUs / 1e6f).coerceAtLeast(1f)
        sl.valueTo = dur
        sl.values = listOf((startUs / 1e6f).coerceIn(0f, dur), (endOr() / 1e6f).coerceIn(0f, dur))
        showFragment(); opts.refresh()
    }

    private fun showFragment() {
        fragText?.text = getString(R.string.video_fragment_text, clock(startUs), clock(endOr()), clock(endOr() - startUs))
    }

    private fun buildAdjust() {
        val box = b.adjustBox
        val d = resources.displayMetrics.density
        fun row(label: Int, set: (PhotoAdjust.Values, Int) -> PhotoAdjust.Values, get: (PhotoAdjust.Values) -> Int) {
            val r = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            r.addView(android.widget.TextView(this).apply { text = getString(label); setTextColor(getColor(R.color.fg)); textSize = 13f },
                android.widget.LinearLayout.LayoutParams((92 * d).toInt(), -2))
            val shown = android.widget.TextView(this).apply { setTextColor(getColor(R.color.fg)); textSize = 13f; gravity = android.view.Gravity.END; text = "0" }
            val sl = com.google.android.material.slider.Slider(this).apply {
                valueFrom = -100f; valueTo = 100f; stepSize = 1f; value = get(adjust).toFloat()
                addOnChangeListener { _, v, fromUser ->
                    shown.text = v.roundToInt().let { if (it > 0) "+$it" else "$it" }
                    if (fromUser) { adjust = set(adjust, v.roundToInt()); opts.refresh() }
                }
            }
            r.addView(sl, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(shown, android.widget.LinearLayout.LayoutParams((40 * d).toInt(), -2))
            box.addView(r)
        }
        row(R.string.adjust_brightness, { v, x -> v.copy(brightness = x) }, { it.brightness })
        row(R.string.adjust_contrast, { v, x -> v.copy(contrast = x) }, { it.contrast })
        row(R.string.adjust_saturation, { v, x -> v.copy(saturation = x) }, { it.saturation })
        row(R.string.adjust_warmth, { v, x -> v.copy(warmth = x) }, { it.warmth })
        row(R.string.adjust_tint, { v, x -> v.copy(tint = x) }, { it.tint })
        box.addView(muted(getString(R.string.video_adjust_note)))
    }

    private fun buildClean() {
        val box = b.cleanBox
        fun sw(label: Int, note: Int, get: () -> Boolean, set: (Boolean) -> Unit) {
            val s2 = com.google.android.material.materialswitch.MaterialSwitch(this).apply {
                text = getString(label); isChecked = get(); setTextColor(getColor(R.color.fg))
                setOnCheckedChangeListener { _, on -> set(on); remember(); opts.refresh(); replan() }
            }
            cleanSwitches += s2
            box.addView(s2)
            box.addView(muted(getString(note)))
        }
        sw(R.string.video_antiflicker, R.string.video_antiflicker_note, { antiFlicker }) { antiFlicker = it }
        sw(R.string.video_denoise, R.string.video_denoise_note, { denoise }) { denoise = it }
        sw(R.string.video_deinterlace, R.string.video_deinterlace_note, { deinterlace }) { deinterlace = it }
    }

    private fun setStatus(s: String) { b.status.text = s }

    /** A video chosen: its first look (a frame from the middle) and what would be made. */
    private fun open(u: Uri) {
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (t: Throwable) { }
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    var n = "video"; var sz = 0L
                    contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst()) { n = c.getString(0) ?: n; sz = c.getLong(1) }
                    }
                    val mr = MediaMetadataRetriever()
                    mr.setDataSource(this@VideoActivity, u)
                    val dur = (mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
                    val frame = mr.getFrameAtTime(dur / 2, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    mr.release()
                    Triple(n to sz, dur, frame)
                } catch (t: Throwable) { null }
            }
            if (r == null) { setStatus(getString(R.string.video_err_open)); return@launch }
            val newVideo = uri != u
            uri = u; name = r.first.first; size = r.first.second; durationUs = r.second
            if (newVideo) { startUs = 0; endUs = 0; outUri = null }
            syncFragment()
            // an interlaced video (from tape): offer to fix it straight away
            val inter = r.third?.let { VideoEnhancer.looksInterlaced(it) } == true
            if (inter != deinterlace) { deinterlace = inter; cleanSwitches.getOrNull(2)?.isChecked = inter }
            getSharedPreferences("video", MODE_PRIVATE).edit().putString("uri", u.toString()).apply()
            b.compare.after = null
            b.compare.before = r.third
            // the chosen video plays here; with a result of this same video, Mejorado ⇄ Original
            val prefs2 = getSharedPreferences("video", MODE_PRIVATE)
            val lastOut = if (prefs2.getString("last_src", null) == u.toString()) prefs2.getString("last_out", null)?.let(Uri::parse) else null
            if (outUri == null && lastOut != null) outUri = lastOut
            b.player.setVideos(outUri, u)
            showPlayer(true)
            replan()
        }
    }

    /** Works out size, time and space for the chosen options. */
    private fun replan() {
        val u = uri ?: return
        lifecycleScope.launch {
            val p = withContext(Dispatchers.IO) {
                try {
                    VideoEnhancer.plan(this@VideoActivity, u, name, size, scale(), model(), engine(), half(), startUs, endUs,
                        adjustAll(), antiFlicker, denoise, deinterlace, hevc(), enhance(), fluid())
                } catch (t: Throwable) { null }
            }
            if (p == null) { setStatus(getString(R.string.video_err_open)); b.go.isEnabled = false; return@launch }
            plan = p
            val secs = p.durationUs / 1_000_000
            b.info.text = getString(R.string.video_info, p.inW, p.inH, p.outW, p.outH, secs / 60, secs % 60,
                if (p.fluid) "${String.format(Locale.US, "%.0f", p.fps)}→${String.format(Locale.US, "%.0f", p.outFps)}" else String.format(Locale.US, "%.0f", p.fps),
                getString(if (p.hasAudio) R.string.video_with_audio else R.string.video_no_audio))
            val done = VideoEnhancer.partsDone(this@VideoActivity, p)
            val left = VideoEnhancer.estimateSec(p) * (1f - done.toFloat() / p.segments)
            b.estimate.text = getString(R.string.video_estimate, formatTime(left), ModelCatalog.mb(p.spaceBytes)) +
                if (done > 0) " · " + getString(R.string.video_parts_done, done, p.segments) else ""
            b.go.text = getString(if (done > 0) R.string.video_continue else if (simple) R.string.vsimple_go else R.string.video_go)
            b.go.isEnabled = !BgWork.busy
            setStatus(when {
                done > 0 -> getString(R.string.video_can_continue)
                p.enhance && p.littleGain -> getString(R.string.video_little_gain, p.inW, p.inH)
                else -> getString(R.string.video_ready)
            } + if (deinterlace) "\n" + getString(R.string.video_interlaced) else "")
            opts.refresh()
            renderSimple()
        }
    }

    private fun formatTime(sec: Float): String {
        val s = sec.roundToInt().coerceAtLeast(0)
        return when {
            s >= 3600 -> "${s / 3600} h ${(s % 3600 + 30) / 60} min"
            s >= 60 -> "${(s + 30) / 60} min"
            else -> "$s s"
        }
    }

    private fun start() {
        if (BgWork.busy) { setStatus(getString(R.string.busy_body, BgWork.currentTitle())); return }
        val u = uri ?: return
        val p = plan ?: return
        val free = filesDir.usableSpace
        if (free < p.spaceBytes) { setStatus(getString(R.string.video_no_space, ModelCatalog.mb(p.spaceBytes), ModelCatalog.mb(free))); return }
        val app = applicationContext
        cancelFlag = false
        running = true
        startedAt = SystemClock.elapsedRealtime()
        poster = b.compare.before
        lastProgress = null
        b.player.pause()
        setBusy(true)
        BgWork.start(this, getString(R.string.video_notif), VideoActivity::class.java) { cancelFlag = true }
        proc.show(getString(R.string.video_working), poster, startedAt)
        JobLog.save(this)
        val ve = VideoEnhancer(app, u, p)
        ve.onFrame = { f -> screen?.get()?.proc?.preview(f) }
        ve.onProgress = { pr ->
            lastProgress = pr
            screen?.get()?.showProgress(pr)
            BgWork.update(app, pr.text, (pr.done * 100f / pr.total).roundToInt())
        }
        // the job belongs to the app, not to this screen (Android may rebuild the screen while it runs)
        BgWork.scope.launch {
            var err: String? = null
            val out = withContext(thread) {
                try {
                    if (p.fluid && !Interpolator.isReady(app)) {
                        JobLog.add("Descargando el paquete Más fluido")
                        Interpolator.download(app, { cancelFlag }) { got, total ->
                            val pct = if (total > 0) (got * 100 / total).toInt() else 0
                            screen?.get()?.let { s -> s.proc.update(app.getString(R.string.video_fluid_download, pct), 0, 1, pct / 100f, 0f) }
                        }
                        if (!cancelFlag && !Interpolator.isReady(app)) throw IllegalStateException(app.getString(R.string.video_fluid_failed, "paquete incompleto"))
                    }
                    if (p.model == Rbvsr.MODEL && !Rbvsr.isReady(app)) {
                        JobLog.add("Descargando el paquete Limpiar (una sola vez)")
                        Rbvsr.download(app, { cancelFlag }) { got, total ->
                            val pct = if (total > 0) (got * 100 / total).toInt() else 0
                            screen?.get()?.let { s -> s.proc.update(app.getString(R.string.video_clean_download, pct), 0, 1, pct / 100f, 0f) }
                        }
                        if (!cancelFlag && !Rbvsr.isReady(app)) JobLog.notice("El paquete Limpiar no quedó completo: se usa el mejorador normal")
                    }
                    if (cancelFlag) null else ve.make { cancelFlag }
                } catch (t: Throwable) {
                    if (!cancelFlag) { err = t.message ?: t.javaClass.simpleName; JobLog.error("Video falló", t) }
                    null
                }
            }
            val secs = (SystemClock.elapsedRealtime() - startedAt) / 1000f
            val msg = when {
                out != null -> app.getString(R.string.video_done, formatTime(secs), p.outW, p.outH)
                cancelFlag -> app.getString(R.string.video_stopped)
                else -> app.getString(R.string.video_failed, err ?: "?")
            }
            if (out != null) app.getSharedPreferences("video", MODE_PRIVATE).edit().remove("uri").putString("last_out", out.toString())
                .putString("last_src", u.toString()).apply()
            running = false
            BgWork.finish(app, msg)
            screen?.get()?.jobDone(out, msg, p)
        }
    }

    private fun showProgress(pr: VideoEnhancer.Progress) {
        val frac = pr.done.toFloat() / pr.total
        // one step name (the log gets a line per step, not per frame); the frame count goes below it
        val step = if (pr.paused) pr.text else getString(R.string.video_working)
        proc.update(step, 0, 1, frac, frac, if (pr.paused) null else pr.text, pr.leftSec)
    }

    /** "Probar un cuadro": the middle frame of the chosen piece, with every option, into the before/after. */
    private fun testFrame() {
        if (running || testing) return
        val u = uri ?: return
        val p = plan ?: return
        testing = true
        b.test.isEnabled = false; b.go.isEnabled = false
        setStatus(getString(R.string.video_testing))
        lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            var err: String? = null
            val pair = withContext(thread) {
                try {
                    val mr = MediaMetadataRetriever()
                    mr.setDataSource(this@VideoActivity, u)
                    val at = (p.startUs + p.endUs) / 2
                    var f = mr.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST) ?: mr.getFrameAtTime(at)
                    mr.release()
                    f ?: throw IllegalStateException("no se pudo leer el cuadro")
                    // the retriever gives the frame turned upright; the job works on it as stored
                    if (p.rotation != 0) f = Bitmap.createBitmap(f, 0, 0, f.width, f.height, android.graphics.Matrix().apply { postRotate(-p.rotation.toFloat()) }, true)
                    if (f.width != p.inW || f.height != p.inH) f = Bitmap.createScaledBitmap(f, p.inW, p.inH, true)
                    val px = IntArray(p.inW * p.inH); f.getPixels(px, 0, p.inW, 0, 0, p.inW, p.inH)
                    val out = VideoEnhancer.openUpscaler(applicationContext, p).use { up ->
                        VideoEnhancer.Filters(p).process(VideoEnhancer.Frame(px, p.inW, p.inH), up) { false }
                    } ?: throw IllegalStateException("sin resultado")
                    fun upright(x: Bitmap) = if (p.rotation == 0) x else
                        Bitmap.createBitmap(x, 0, 0, x.width, x.height, android.graphics.Matrix().apply { postRotate(p.rotation.toFloat()) }, true)
                    val before = Bitmap.createScaledBitmap(f, p.outW, p.outH, true)
                    upright(before) to upright(Bitmap.createBitmap(out, p.outW, p.outH, Bitmap.Config.ARGB_8888))
                } catch (t: Throwable) { err = t.message ?: t.javaClass.simpleName; null }
            }
            testing = false
            b.test.isEnabled = true; b.go.isEnabled = !BgWork.busy
            if (pair == null) { setStatus(getString(R.string.video_test_failed, err ?: "?")); return@launch }
            b.compare.before = pair.first
            b.compare.after = pair.second
            showPlayer(false)
            setStatus(getString(R.string.video_tested, (SystemClock.elapsedRealtime() - t0) / 1000f))
        }
    }

    private var testing = false

    private fun jobDone(out: Uri?, msg: String, p: VideoEnhancer.Plan) {
        proc.hide()
        setBusy(false)
        if (out != null) {
            outUri = out
            b.play.isEnabled = true
            b.player.setVideos(out, uri)
            showPlayer(true)
            // the frame from the middle, enhanced, to compare
            lifecycleScope.launch {
                val after = withContext(Dispatchers.IO) {
                    try {
                        MediaMetadataRetriever().run {
                            setDataSource(File(cacheDir, VideoEnhancer.LAST_FILE).path)
                            val f = getFrameAtTime(p.durationUs / 2, MediaMetadataRetriever.OPTION_CLOSEST_SYNC); release(); f
                        }
                    } catch (t: Throwable) { null }
                }
                if (after != null) b.compare.after = after
            }
        }
        setStatus(msg)
        replan()
        if (out == null && !cancelFlag && simple) Ui.failed(this, 1) { start() }
    }

    private fun setBusy(busy: Boolean) {
        b.go.text = getString(if (busy) R.string.stop else if (simple) R.string.vsimple_go else R.string.video_go)
        b.pick.isEnabled = !busy
        b.test.isEnabled = !busy
        for (g in listOf(b.modeGroup, b.scaleGroup, b.modelGroup, b.engineGroup, b.framesGroup, b.sharpGroup, b.formatGroup))
            for (i in 0 until g.childCount) g.getChildAt(i).isEnabled = !busy
    }

    /** Ver: the last made video, full screen, in Nítido's own player (with the original to compare). */
    private fun play() {
        val prefs = getSharedPreferences("video", MODE_PRIVATE)
        val u = outUri ?: prefs.getString("last_out", null)?.let { Uri.parse(it) } ?: newestInGallery()
        if (u == null) { setStatus(getString(R.string.video_none_yet)); return }
        val src = uri ?: prefs.getString("last_src", null)?.let { Uri.parse(it) }
        b.player.pause()
        FullscreenActivity.video(this, u, src, true, if (b.player.visibility == View.VISIBLE) b.player.position() else 0)
    }

    /** The stage shows the playing video, or the before/after of the test frame. */
    private fun showPlayer(on: Boolean) {
        val has = b.player.hasVideo()
        b.player.visibility = if (on && has) View.VISIBLE else View.GONE
        if (!on || !has) b.player.pause()
        b.backToVideo.visibility = if (!on && has) View.VISIBLE else View.GONE
    }

    override fun onPause() { super.onPause(); b.player.pause() }

    /** The newest video in Movies/Nitido (when the app lost track of the last one). */
    private fun newestInGallery(): Uri? = try {
        contentResolver.query(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(android.provider.MediaStore.Video.Media._ID),
            "${android.provider.MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/Nitido%"),
            "${android.provider.MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            if (c.moveToFirst()) android.content.ContentUris.withAppendedId(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0)) else null
        }
    } catch (t: Throwable) { null }

    override fun onDestroy() {
        super.onDestroy()
        if (screen?.get() === this) screen = null
    }

    companion object {
        /** The running video job lives here, outside the screen. */
        @Volatile var running = false
        @Volatile var cancelFlag = false
        @Volatile private var startedAt = 0L
        @Volatile private var lastProgress: VideoEnhancer.Progress? = null
        @Volatile private var poster: Bitmap? = null
        @Volatile private var screen: java.lang.ref.WeakReference<VideoActivity>? = null
        /** Model work on one thread (the GPU delegate requires it), shared by every screen instance. */
        private val thread = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    }
}
