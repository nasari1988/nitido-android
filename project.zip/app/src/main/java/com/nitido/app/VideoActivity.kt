package com.nitido.app

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.View
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityVideoBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * Video: Mejorar a whole video (each frame through Mejorar's enhancer, on the NPU), in parts that
 * survive interruptions, with the original audio. Restaurar video and Más fluido come later.
 */
class VideoActivity : AppCompatActivity() {

    private lateinit var b: ActivityVideoBinding
    private lateinit var proc: ProcessScreen
    private lateinit var opts: OptionBar
    /** Model work on one thread (the GPU delegate requires it). */
    private val aiThread = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    private var uri: Uri? = null
    private var name = "video"
    private var size = 0L
    private var durationUs = 0L
    private var plan: VideoEnhancer.Plan? = null
    private var outUri: Uri? = null
    private var job: Job? = null
    @Volatile private var cancel = false

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) open(u) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityVideoBinding.inflate(layoutInflater)
        setContentView(b.root)
        proc = ProcessScreen(this) { cancel = true }
        b.back.setOnClickListener { finish() }
        b.pick.setOnClickListener { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }
        b.play.setOnClickListener { play() }
        b.go.setOnClickListener { if (job?.isActive == true) cancel = true else start() }
        val prefs = getSharedPreferences("video", MODE_PRIVATE)
        b.scaleGroup.check(if (prefs.getInt("scale", 2) == 4) R.id.vScale4 else R.id.vScale2)
        b.modelGroup.check(if (prefs.getBoolean("detail", false)) R.id.vDetail else R.id.vFast)
        b.engineGroup.check(if (prefs.getBoolean("gpu", false)) R.id.vGpu else R.id.vNpu)
        b.framesGroup.check(if (prefs.getBoolean("half", false)) R.id.vHalf else R.id.vAll)
        for (g in listOf(b.scaleGroup, b.modelGroup, b.engineGroup, b.framesGroup))
            g.addOnButtonCheckedListener { _, _, checked -> if (checked) { remember(); replan() } }
        setupOptions()
        LogDialog.addTo(this, opts)
        b.go.isEnabled = false
        b.play.isEnabled = getSharedPreferences("video", MODE_PRIVATE).getString("last_out", null) != null
        setStatus(getString(R.string.video_hint))
        // an unfinished video from before (stopped, or the app was closed): offer to go on with it
        prefs.getString("uri", null)?.let { s -> if (!BgWork.busy) try { open(Uri.parse(s)) } catch (t: Throwable) { } }
    }

    private fun setupOptions() {
        opts = OptionBar(this, b.optLabels, b.optPanel)
        opts.add(getString(R.string.video_mode), { getString(R.string.video_mode_enhance) }, listOf(b.modeGroup, b.modeNote), shown = { true })
        opts.add(getString(R.string.label_scale), { if (scale() == 4) "×4" else "×2" }, listOf(b.scaleGroup))
        opts.add(getString(R.string.label_model), { getString(if (detail()) R.string.model_detail else R.string.model_fast) }, listOf(b.modelGroup))
        opts.add(getString(R.string.label_engine), { if (engine() == Engine.NPU) "⚡ NPU" else "GPU" }, listOf(b.engineGroup))
        opts.add(getString(R.string.video_frames), { getString(if (half()) R.string.video_frames_half else R.string.video_frames_all) },
            listOf(b.framesGroup, b.framesNote))
    }

    private fun scale() = if (b.scaleGroup.checkedButtonId == R.id.vScale4) 4 else 2
    private fun detail() = b.modelGroup.checkedButtonId == R.id.vDetail
    private fun engine() = if (b.engineGroup.checkedButtonId == R.id.vGpu) Engine.GPU else Engine.NPU
    private fun half() = b.framesGroup.checkedButtonId == R.id.vHalf
    private fun model() = if (detail()) Upscaler.MODEL_X4PLUS else Upscaler.MODEL_FILE

    private fun remember() = getSharedPreferences("video", MODE_PRIVATE).edit()
        .putInt("scale", scale()).putBoolean("detail", detail()).putBoolean("gpu", engine() == Engine.GPU).putBoolean("half", half()).apply()

    private fun setStatus(s: String) { b.status.text = s }

    /** A video chosen: its first look (a frame from the middle) and what would be made. */
    private fun open(u: Uri) {
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (t: Throwable) { }
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    var n = "video"; var sz = 0L
                    contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst()) { n = c.getString(0) ?: n; sz = c.getLong(1) }
                    }
                    val mr = MediaMetadataRetriever()
                    mr.setDataSource(this@VideoActivity, u)
                    val dur = (mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
                    val frame = mr.getFrameAtTime(dur / 2, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    mr.release()
                    Triple(n to sz, dur, frame)
                } catch (t: Throwable) { null }
            }
            if (r == null) { setStatus(getString(R.string.video_err_open)); return@launch }
            uri = u; name = r.first.first; size = r.first.second; durationUs = r.second
            getSharedPreferences("video", MODE_PRIVATE).edit().putString("uri", u.toString()).apply()
            b.compare.after = null
            b.compare.before = r.third
            replan()
        }
    }

    /** Works out size, time and space for the chosen options. */
    private fun replan() {
        val u = uri ?: return
        lifecycleScope.launch {
            val p = withContext(Dispatchers.IO) {
                try { VideoEnhancer.plan(this@VideoActivity, u, name, size, scale(), model(), engine(), half()) } catch (t: Throwable) { null }
            }
            if (p == null) { setStatus(getString(R.string.video_err_open)); b.go.isEnabled = false; return@launch }
            plan = p
            val secs = p.durationUs / 1_000_000
            b.info.text = getString(R.string.video_info, p.inW, p.inH, p.outW, p.outH, secs / 60, secs % 60,
                String.format(Locale.US, "%.0f", p.fps), getString(if (p.hasAudio) R.string.video_with_audio else R.string.video_no_audio))
            val done = VideoEnhancer.partsDone(this@VideoActivity, p)
            val left = VideoEnhancer.estimateSec(p) * (1f - done.toFloat() / p.segments)
            b.estimate.text = getString(R.string.video_estimate, formatTime(left), ModelCatalog.mb(p.spaceBytes)) +
                if (done > 0) " · " + getString(R.string.video_parts_done, done, p.segments) else ""
            b.go.text = getString(if (done > 0) R.string.video_continue else R.string.video_go)
            b.go.isEnabled = !BgWork.busy
            setStatus(if (done > 0) getString(R.string.video_can_continue) else getString(R.string.video_ready))
            opts.refresh()
        }
    }

    private fun formatTime(sec: Float): String {
        val s = sec.roundToInt().coerceAtLeast(0)
        return when {
            s >= 3600 -> "${s / 3600} h ${(s % 3600 + 30) / 60} min"
            s >= 60 -> "${(s + 30) / 60} min"
            else -> "$s s"
        }
    }

    private fun start() {
        if (BgWork.busy) { setStatus(getString(R.string.busy_body, BgWork.currentTitle())); return }
        val u = uri ?: return
        val p = plan ?: return
        val free = filesDir.usableSpace
        if (free < p.spaceBytes) { setStatus(getString(R.string.video_no_space, ModelCatalog.mb(p.spaceBytes), ModelCatalog.mb(free))); return }
        cancel = false
        setBusy(true)
        BgWork.start(this, getString(R.string.video_notif), VideoActivity::class.java) { cancel = true }
        proc.show(getString(R.string.video_working), b.compare.before)
        JobLog.save(this)
        val t0 = SystemClock.elapsedRealtime()
        val ve = VideoEnhancer(applicationContext, u, p)
        ve.onFrame = { proc.preview(it) }
        ve.onProgress = { pr ->
            val frac = pr.done.toFloat() / pr.total
            proc.update(pr.text, 0, 1, frac, frac, null, pr.leftSec)
            BgWork.update(this, pr.text, (frac * 100).roundToInt())
        }
        job = lifecycleScope.launch {
            var err: String? = null
            val out = withContext(aiThread) {
                try { ve.make { cancel } } catch (t: Throwable) {
                    if (!cancel) { err = t.message ?: t.javaClass.simpleName; JobLog.error("Video falló", t) }
                    null
                }
            }
            proc.hide()
            setBusy(false)
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000f
            val msg = when {
                out != null -> getString(R.string.video_done, formatTime(secs), p.outW, p.outH)
                cancel -> getString(R.string.video_stopped)
                else -> getString(R.string.video_failed, err ?: "?")
            }
            if (out != null) {
                outUri = out
                getSharedPreferences("video", MODE_PRIVATE).edit().remove("uri").putString("last_out", out.toString()).apply()
                b.play.isEnabled = true
                // the frame from the middle, enhanced, to compare
                lifecycleScope.launch {
                    val after = withContext(Dispatchers.IO) {
                        try {
                            MediaMetadataRetriever().run {
                                setDataSource(File(cacheDir, VideoEnhancer.LAST_FILE).path)
                                val f = getFrameAtTime(p.durationUs / 2, MediaMetadataRetriever.OPTION_CLOSEST_SYNC); release(); f
                            }
                        } catch (t: Throwable) { null }
                    }
                    if (after != null) b.compare.after = after
                }
            }
            setStatus(msg)
            BgWork.finish(this@VideoActivity, msg)
            replan()
        }
    }

    private fun setBusy(busy: Boolean) {
        b.go.text = getString(if (busy) R.string.stop else R.string.video_go)
        b.pick.isEnabled = !busy
        for (g in listOf(b.scaleGroup, b.modelGroup, b.engineGroup, b.framesGroup))
            for (i in 0 until g.childCount) g.getChildAt(i).isEnabled = !busy
    }

    /** Opens the last made video (in the gallery) in the phone's player. */
    private fun play() {
        val u = outUri ?: getSharedPreferences("video", MODE_PRIVATE).getString("last_out", null)?.let { Uri.parse(it) } ?: return
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (t: Throwable) { setStatus(getString(R.string.video_no_player)) }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (job?.isActive != true) aiThread.close()
    }
}
