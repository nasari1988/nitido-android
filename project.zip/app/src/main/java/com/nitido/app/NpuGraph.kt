package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * One graph compiled for the phone's NPU (QAIRT context: <name>_ctx.onnx + .bin + .json with the
 * integer scales of its inputs and outputs). Floats in, floats out; the conversion to the NPU's
 * integers happens here.
 */
class NpuGraph(ctxOnnx: File, private val profileDir: File? = null, perfMode: String? = "burst") : AutoCloseable {
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private class Quant(val type: Int, val scale: Float, val offset: Int)
    private val quant: Map<String, Quant>
    val session: OrtSession

    init {
        quant = try {
            val j = org.json.JSONObject(File(ctxOnnx.path + ".json").readText()).optJSONObject("quant")
            j?.keys()?.asSequence()?.mapNotNull { k ->
                val q = j.getJSONObject(k)
                if (!q.has("scale")) null else k to Quant(q.getInt("qnn_type"), q.getDouble("scale").toFloat(), q.getInt("offset"))
            }?.toMap() ?: emptyMap()
        } catch (t: Throwable) { emptyMap() }
        val o = OrtSession.SessionOptions().apply {
            setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
            addConfigEntry("session.disable_cpu_ep_fallback", "0")
            addQnn(if (perfMode == null) mapOf("backend_path" to "libQnnHtp.so") else mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to perfMode))
            if (profileDir != null) enableProfiling(File(profileDir, "npu_prof").path)
        }
        session = env.createSession(ctxOnnx.path, o)
    }

    fun run(feeds: Map<String, FloatArray>): Map<String, FloatArray> {
        val tensors = HashMap<String, OnnxTensor>()
        try {
            for ((n, data) in feeds) {
                val info = session.inputInfo[n]?.info as? TensorInfo ?: throw IllegalStateException("el modelo no tiene la entrada $n")
                val q = quant[n]
                tensors[n] = when {
                    q != null -> toInts(q, data, info.shape)
                    info.type == OnnxJavaType.INT64 -> OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(LongArray(data.size) { data[it].toLong() }), info.shape)
                    info.type == OnnxJavaType.FLOAT16 -> {
                        val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
                        val sb = bb.asShortBuffer(); for (v in data) sb.put(android.util.Half.toHalf(v))
                        OnnxTensor.createTensor(env, bb, info.shape, OnnxJavaType.FLOAT16)
                    }
                    else -> OnnxTensor.createTensor(env, FloatBuffer.wrap(data), info.shape)
                }
            }
            NpuMeter.begin()
            val r = try { session.run(tensors) } finally { NpuMeter.end() }
            r.use {
                val out = HashMap<String, FloatArray>()
                for ((n, v) in it) {
                    val t = v as OnnxTensor
                    val shp = (t.info as TensorInfo).shape
                    val size = shp.fold(1L) { a, b -> a * b }.toInt()
                    val arr = FloatArray(size)
                    val q = quant[n]
                    when {
                        q != null -> fromInts(q, t, arr)
                        (t.info as TensorInfo).type == OnnxJavaType.FLOAT16 -> {
                            val sb = t.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                            for (i in 0 until size) arr[i] = android.util.Half.toFloat(sb.get(i))
                        }
                        else -> t.floatBuffer.get(arr, 0, size)
                    }
                    out[n] = arr
                }
                return out
            }
        } finally { tensors.values.forEach { it.close() } }
    }

    private fun toInts(q: Quant, data: FloatArray, shape: LongArray): OnnxTensor {
        val inv = 1f / q.scale
        return if (q.type == 0x0408 || q.type == 0x0308) {
            val bb = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
            val lo = if (q.type == 0x0408) 0 else -128; val hi = if (q.type == 0x0408) 255 else 127
            for (v in data) bb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toByte())
            bb.rewind()
            OnnxTensor.createTensor(env, bb, shape, if (q.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
        } else {
            val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
            val sb = bb.asShortBuffer()
            val lo = if (q.type == 0x0416) 0 else -32768; val hi = if (q.type == 0x0416) 65535 else 32767
            for (v in data) sb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toShort())
            OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
        }
    }

    private fun fromInts(q: Quant, o: OnnxTensor, out: FloatArray) {
        val bb = o.byteBuffer.order(ByteOrder.nativeOrder())
        if (q.type == 0x0408 || q.type == 0x0308) {
            for (i in out.indices) { val b = bb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0408) b and 0xFF else b) + q.offset) }
        } else {
            val sb = bb.asShortBuffer()
            for (i in out.indices) { val v = sb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0416) v and 0xFFFF else v) + q.offset) }
        }
    }

    /**
     * Where the runs so far spent their time: on the NPU or on the processor (parts the NPU could not
     * take), and the heaviest processor operations. Only when made with [profileDir].
     */
    fun profileReport(): String? {
        if (profileDir == null) return null
        return try {
            val f = File(session.endProfiling())
            val arr = org.json.JSONArray(f.readText()); f.delete()
            var npu = 0L; var cpu = 0L; var nNpu = 0; var nCpu = 0
            val ops = HashMap<String, Long>()
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                if (e.optString("cat") != "Node" || !e.optString("name").endsWith("_kernel_time")) continue
                val a = e.optJSONObject("args") ?: continue
                val d = e.optLong("dur")
                if (a.optString("provider").startsWith("QNN")) { npu += d; nNpu++ } else {
                    cpu += d; nCpu++; val op = a.optString("op_name"); ops[op] = (ops[op] ?: 0L) + d
                }
            }
            val tot = (npu + cpu).coerceAtLeast(1)
            "NPU ${npu * 100 / tot} % ($nNpu partes, ${npu / 1000} ms) · procesador ${cpu * 100 / tot} % ($nCpu partes, ${cpu / 1000} ms)" +
                ops.entries.sortedByDescending { it.value }.take(5).joinToString(", ", prefix = if (ops.isEmpty()) "" else " · ") { "${it.key} ${it.value / 1000} ms" }
        } catch (t: Throwable) { "sin medición (${t.message})" }
    }

    override fun close() { try { session.close() } catch (_: Throwable) { } }
}
