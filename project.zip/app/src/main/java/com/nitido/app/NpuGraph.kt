package com.nitido.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtLoggingLevel
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * One graph compiled for the phone's NPU (QAIRT context: <name>_ctx.onnx + .bin + .json with the
 * integer scales of its inputs and outputs). Floats in, floats out; the conversion to the NPU's
 * integers happens here.
 */
class NpuGraph(ctxOnnx: File) : AutoCloseable {
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private class Quant(val type: Int, val scale: Float, val offset: Int)
    private val quant: Map<String, Quant>
    val session: OrtSession

    init {
        quant = try {
            val j = org.json.JSONObject(File(ctxOnnx.path + ".json").readText()).optJSONObject("quant")
            j?.keys()?.asSequence()?.mapNotNull { k ->
                val q = j.getJSONObject(k)
                if (!q.has("scale")) null else k to Quant(q.getInt("qnn_type"), q.getDouble("scale").toFloat(), q.getInt("offset"))
            }?.toMap() ?: emptyMap()
        } catch (t: Throwable) { emptyMap() }
        val o = OrtSession.SessionOptions().apply {
            setSessionLogLevel(OrtLoggingLevel.ORT_LOGGING_LEVEL_WARNING)
            addConfigEntry("session.disable_cpu_ep_fallback", "0")
            addQnn(mapOf("backend_path" to "libQnnHtp.so", "htp_performance_mode" to "burst"))
        }
        session = env.createSession(ctxOnnx.path, o)
    }

    fun run(feeds: Map<String, FloatArray>): Map<String, FloatArray> {
        val tensors = HashMap<String, OnnxTensor>()
        try {
            for ((n, data) in feeds) {
                val info = session.inputInfo[n]?.info as? TensorInfo ?: throw IllegalStateException("el modelo no tiene la entrada $n")
                val q = quant[n]
                tensors[n] = when {
                    q != null -> toInts(q, data, info.shape)
                    info.type == OnnxJavaType.INT64 -> OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(LongArray(data.size) { data[it].toLong() }), info.shape)
                    info.type == OnnxJavaType.FLOAT16 -> {
                        val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
                        val sb = bb.asShortBuffer(); for (v in data) sb.put(android.util.Half.toHalf(v))
                        OnnxTensor.createTensor(env, bb, info.shape, OnnxJavaType.FLOAT16)
                    }
                    else -> OnnxTensor.createTensor(env, FloatBuffer.wrap(data), info.shape)
                }
            }
            NpuMeter.begin()
            val r = try { session.run(tensors) } finally { NpuMeter.end() }
            r.use {
                val out = HashMap<String, FloatArray>()
                for ((n, v) in it) {
                    val t = v as OnnxTensor
                    val shp = (t.info as TensorInfo).shape
                    val size = shp.fold(1L) { a, b -> a * b }.toInt()
                    val arr = FloatArray(size)
                    val q = quant[n]
                    when {
                        q != null -> fromInts(q, t, arr)
                        (t.info as TensorInfo).type == OnnxJavaType.FLOAT16 -> {
                            val sb = t.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                            for (i in 0 until size) arr[i] = android.util.Half.toFloat(sb.get(i))
                        }
                        else -> t.floatBuffer.get(arr, 0, size)
                    }
                    out[n] = arr
                }
                return out
            }
        } finally { tensors.values.forEach { it.close() } }
    }

    private fun toInts(q: Quant, data: FloatArray, shape: LongArray): OnnxTensor {
        val inv = 1f / q.scale
        return if (q.type == 0x0408 || q.type == 0x0308) {
            val bb = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
            val lo = if (q.type == 0x0408) 0 else -128; val hi = if (q.type == 0x0408) 255 else 127
            for (v in data) bb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toByte())
            bb.rewind()
            OnnxTensor.createTensor(env, bb, shape, if (q.type == 0x0408) OnnxJavaType.UINT8 else OnnxJavaType.INT8)
        } else {
            val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
            val sb = bb.asShortBuffer()
            val lo = if (q.type == 0x0416) 0 else -32768; val hi = if (q.type == 0x0416) 65535 else 32767
            for (v in data) sb.put((Math.round(v * inv) - q.offset).coerceIn(lo, hi).toShort())
            OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.INT16)
        }
    }

    private fun fromInts(q: Quant, o: OnnxTensor, out: FloatArray) {
        val bb = o.byteBuffer.order(ByteOrder.nativeOrder())
        if (q.type == 0x0408 || q.type == 0x0308) {
            for (i in out.indices) { val b = bb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0408) b and 0xFF else b) + q.offset) }
        } else {
            val sb = bb.asShortBuffer()
            for (i in out.indices) { val v = sb.get(i).toInt(); out[i] = q.scale * ((if (q.type == 0x0416) v and 0xFFFF else v) + q.offset) }
        }
    }

    override fun close() { try { session.close() } catch (_: Throwable) { } }
}
