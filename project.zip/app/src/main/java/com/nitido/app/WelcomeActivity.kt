package com.nitido.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Bienvenida (only the first time): the four tools in one line each, and "Empezar", which
 * downloads the basic pack (Restaurar) in the background — the rest comes when it is first used.
 */
class WelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 20), Ui.dp(context, 36), Ui.dp(context, 20), Ui.dp(context, 20))
        }
        col.addView(Ui.text(this, getString(R.string.home_title), 34f, bold = true).apply { gravity = Gravity.CENTER })
        col.addView(Ui.text(this, getString(R.string.home_sub), 14f, R.color.muted).apply { gravity = Gravity.CENTER }, Ui.lp(this, 6))
        fun tool(icon: String, title: Int, sub: Int) {
            val r = Ui.row(this).apply {
                setPadding(Ui.dp(context, 16), Ui.dp(context, 14), Ui.dp(context, 16), Ui.dp(context, 14))
                background = Ui.round(context, Ui.color(context, R.color.stage), 14, Ui.color(context, R.color.line))
            }
            r.addView(Ui.text(this, icon, 26f, R.color.accent).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(Ui.dp(this, 44), -2))
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(context, 8), 0, 0, 0) }
            t.addView(Ui.text(this, getString(title), 16f, bold = true))
            t.addView(Ui.text(this, getString(sub), 13f, R.color.muted))
            r.addView(t)
            col.addView(r, Ui.lp(this, 10))
        }
        col.addView(android.view.View(this), LinearLayout.LayoutParams(1, Ui.dp(this, 18)))
        tool("✧", R.string.home_restore, R.string.welcome_restore)
        tool("▶", R.string.home_video, R.string.home_video_sub)
        tool("✦", R.string.home_create, R.string.home_create_sub)
        tool("✎", R.string.home_edit, R.string.welcome_edit)
        val note = Ui.text(this, getString(R.string.welcome_note) + "\n" +
            getString(if (Ui.onWifi(this)) R.string.dl_ask_wifi else R.string.dl_ask_data), 13f, R.color.fg2).apply { gravity = Gravity.CENTER }
        col.addView(note, Ui.lp(this, 22))
        col.addView(Ui.bigButton(this, getString(R.string.welcome_start)) { start(true) }, Ui.lp(this, 14))
        col.addView(Ui.text(this, getString(R.string.welcome_later), 14f, R.color.accent).apply {
            gravity = Gravity.CENTER; setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 8))
            setOnClickListener { start(false) }
        }, Ui.lp(this, 4))
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.color(context, R.color.bg)); fitsSystemWindows = true; addView(col)
        })
    }

    private fun start(download: Boolean) {
        Prefs.setWelcomed(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (download && !RestorePack.isReady(this) && !BgWork.downloading()) downloadBasics()
        finish()
    }

    /** The Restaurar pack, in the background with its own notification (Inicio shows its bar). */
    private fun downloadBasics() {
        val app = applicationContext
        val stop = java.util.concurrent.atomic.AtomicBoolean(false)
        BgWork.startDownload(app, RestorePack.ID, app.getString(R.string.welcome_dl_title), HomeActivity::class.java) { stop.set(true) }
        JobLog.add("Bienvenida: descargando el paquete de Restaurar")
        BgWork.scope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    RestorePack.download(app, { stop.get() }) { done, total ->
                        if (total > 0) BgWork.updateDownload(app, app.getString(R.string.sd_dl_progress, done / 1_000_000, total / 1_000_000),
                            (done * 100 / total).toInt())
                    }
                    null
                } catch (t: Throwable) { t.message ?: t.javaClass.simpleName }
            }
            if (err != null) JobLog.notice("Bienvenida: la descarga no terminó ($err); se pedirá al usar Restaurar")
            BgWork.finishDownload(app, if (err == null) app.getString(R.string.welcome_dl_done) else null)
        }
    }
}
