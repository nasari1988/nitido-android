package com.nitido.app

import android.content.Context

/**
 * «Qué evitar» in the simple screens: a Spanish list the user can edit (remembered per tool),
 * turned into the English the models read. Known items get tuned English with weights; anything
 * else typed goes through the translator.
 */
object Negative {
    private const val PREFS = "nitido"

    /** Spanish item → English for the model (the factory items and the quick-add ones). */
    private val KNOWN = linkedMapOf(
        "baja calidad" to "(worst quality, low quality:1.4)",
        "manos deformes" to "(deformed hands, mutated fingers:1.3)",
        "dedos de más" to "(extra digits, missing fingers:1.3)",
        "ojos chuecos" to "(cross-eyed, asymmetrical eyes, distorted face:1.3)",
        "extremidades de más" to "(extra limbs, fused limbs, detached limbs:1.3)",
        "piel de plástico" to "(plastic skin, CGI, 3D render:1.2)",
        "caras repetidas" to "(cloned face, multiple people:1.2)",
        "texto" to "text",
        "marca de agua" to "watermark, signature",
        "desfigurado" to "disfigured, malformed, mutation, gross proportions",
        "cuerpo deforme" to "(deformed body, bad anatomy, long torso:1.3)",
        "borroso" to "blurry, out of focus",
        "ropa rara" to "(malformed clothes, messy clothing:1.2)",
        "oscuro" to "underexposed, too dark",
    )

    /** Quick-add chips shown under the text. */
    val QUICK = listOf("cuerpo deforme", "borroso", "ropa rara", "caras repetidas", "oscuro")

    private fun key(tool: String) = "neg_$tool"

    fun factory(ctx: Context): String = ctx.getString(R.string.neg_default_es)

    /** The user's list for this tool (the factory one if never changed). */
    fun text(ctx: Context, tool: String): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key(tool), null) ?: factory(ctx)

    fun isFactory(ctx: Context, tool: String) = norm(text(ctx, tool)) == norm(factory(ctx))

    fun save(ctx: Context, tool: String, s: String) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (norm(s) == norm(factory(ctx))) e.remove(key(tool)) else e.putString(key(tool), s.trim())
        e.apply()
    }

    fun reset(ctx: Context, tool: String) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key(tool)).apply()

    fun items(s: String) = s.split(',', ';', '\n').map { it.trim() }.filter { it.isNotEmpty() }

    private fun norm(s: String) = items(s.lowercase()).joinToString(",")

    /** English for the model. Call from a background thread (it may translate). */
    fun english(ctx: Context, tool: String): String {
        val parts = items(text(ctx, tool))
        val out = mutableListOf<String>()
        val unknown = mutableListOf<String>()
        for (p in parts) {
            val k = KNOWN[p.lowercase()]
            if (k != null) out += k else unknown += p
        }
        if (unknown.isNotEmpty()) {
            val en = Translate.toEnglish(unknown.joinToString(", "))
            if (en.isNotBlank()) out += en
        }
        val r = out.joinToString(", ")
        JobLog.add("Qué evitar: ${if (isFactory(ctx, tool)) "de fábrica" else "«${text(ctx, tool)}»"}")
        return r
    }
}
