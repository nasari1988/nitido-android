package com.nitido.app

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.lifecycle.lifecycleScope
import com.nitido.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    /** All model work happens on this one thread (the GPU delegate requires it). */
    private val aiThread = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private var upscaler: Upscaler? = null

    private var source: Bitmap? = null
    private var result: Bitmap? = null
    private var sourceName = "foto"
    private var job: Job? = null
    @Volatile private var cancel = false

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.pick.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        b.go.setOnClickListener { if (job?.isActive == true) cancel = true else enhance() }
        b.save.setOnClickListener { save() }
        b.engineGroup.addOnButtonCheckedListener { _, _, checked -> if (checked) prepareEngine() }

        b.save.isEnabled = false
        b.go.isEnabled = false
        setStatus(getString(R.string.hint_pick))
        prepareEngine()
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** Photos shared from the gallery ("Compartir → Nítido"). */
    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val uri = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java) ?: return
        loadImage(uri)
    }

    private fun selectedEngine(): Engine = when (b.engineGroup.checkedButtonId) {
        R.id.engNpu -> Engine.NPU
        R.id.engCpu -> Engine.CPU
        else -> Engine.GPU
    }

    private fun selectedScale(): Int = if (b.scaleGroup.checkedButtonId == R.id.scale4) 4 else 2

    private fun prepareEngine() {
        val want = selectedEngine()
        b.engineState.text = getString(R.string.engine_loading)
        b.go.isEnabled = false
        lifecycleScope.launch {
            val used = withContext(aiThread) {
                try {
                    upscaler?.close()
                    upscaler = Upscaler(applicationContext, want)
                    upscaler!!.engine
                } catch (t: Throwable) {
                    upscaler = null
                    null
                }
            }
            if (used == null) {
                b.engineState.text = getString(R.string.engine_failed)
                return@launch
            }
            b.engineState.text = if (used == want) getString(R.string.engine_ready, used.label)
            else getString(R.string.engine_fallback, want.label, used.label)
            b.go.isEnabled = source != null
        }
    }

    private fun loadImage(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val src = ImageDecoder.createSource(contentResolver, uri)
                    ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val long = max(info.size.width, info.size.height)
                        if (long > MAX_PREVIEW) {
                            val k = MAX_PREVIEW.toFloat() / long
                            dec.setTargetSize((info.size.width * k).roundToInt(), (info.size.height * k).roundToInt())
                        }
                    }
                } catch (t: Throwable) { null }
            }
            if (bmp == null) { setStatus(getString(R.string.err_open)); return@launch }
            sourceName = queryName(uri)
            source = bmp
            result = null
            b.compare.after = null
            b.compare.before = bmp
            b.save.isEnabled = false
            b.go.isEnabled = upscaler != null
            b.info.text = getString(R.string.info_in, bmp.width, bmp.height)
            setStatus(getString(R.string.hint_ready))
        }
    }

    private fun enhance() {
        val src0 = source ?: return
        val up = upscaler ?: return
        val scale = selectedScale()
        val src = fitForScale(src0, scale)
        if (src !== src0) b.compare.before = src
        b.compare.after = null
        cancel = false
        setBusy(true)
        b.progress.progress = 0
        val note = if (src !== src0) getString(R.string.note_resized, src.width, src.height) + " " else ""
        setStatus(note + getString(R.string.working))
        val t0 = SystemClock.elapsedRealtime()

        job = lifecycleScope.launch {
            val out = withContext(aiThread) {
                try {
                    up.upscale(src, scale, { p ->
                        val el = (SystemClock.elapsedRealtime() - t0) / 1000f
                        val left = if (p > 0.03f) ((el / p) - el).roundToInt() else -1
                        runOnUiThread {
                            b.progress.progress = (p * 1000).roundToInt()
                            if (left >= 0) b.eta.text = getString(R.string.eta, (p * 100).roundToInt(), left)
                        }
                    }, { cancel })
                } catch (t: OutOfMemoryError) {
                    null
                } catch (t: Throwable) {
                    null
                }
            }
            setBusy(false)
            if (out == null) {
                setStatus(getString(if (cancel) R.string.cancelled else R.string.err_run))
                return@launch
            }
            val secs = (SystemClock.elapsedRealtime() - t0) / 1000f
            result = out
            b.compare.after = out
            b.save.isEnabled = true
            b.info.text = getString(R.string.info_out, src.width, src.height, out.width, out.height)
            b.eta.text = getString(R.string.took, secs, up.engine.label)
            setStatus(getString(R.string.done))
        }
    }

    private fun fitForScale(src: Bitmap, scale: Int): Bitmap {
        val cap = if (scale == 4) MAX_IN_X4 else MAX_IN_X2
        val long = max(src.width, src.height)
        if (long <= cap) return src
        val k = cap.toFloat() / long
        return Bitmap.createScaledBitmap(src, (src.width * k).roundToInt(), (src.height * k).roundToInt(), true)
    }

    private fun save() {
        val bmp = result ?: return
        b.save.isEnabled = false
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "${sourceName}_nitido_${System.currentTimeMillis() / 1000}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nitido")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    true
                } catch (t: Throwable) { false }
            }
            b.save.isEnabled = true
            setStatus(getString(if (ok) R.string.saved else R.string.err_save))
        }
    }

    private fun queryName(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0).substringBeforeLast('.') else null
        } ?: "foto"
    } catch (t: Throwable) { "foto" }

    private fun setBusy(busy: Boolean) {
        b.go.text = getString(if (busy) R.string.stop else R.string.enhance)
        b.pick.isEnabled = !busy
        b.save.isEnabled = !busy && result != null
        for (i in 0 until b.scaleGroup.childCount) b.scaleGroup.getChildAt(i).isEnabled = !busy
        for (i in 0 until b.engineGroup.childCount) b.engineGroup.getChildAt(i).isEnabled = !busy
        b.progress.visibility = if (busy) View.VISIBLE else View.INVISIBLE
        if (busy) b.eta.text = ""
    }

    private fun setStatus(s: String) { b.status.text = s }

    override fun onDestroy() {
        super.onDestroy()
        cancel = true
        val u = upscaler
        upscaler = null
        aiThread.executor.execute { u?.close() }
        aiThread.close()
    }

    companion object {
        private const val MAX_PREVIEW = 4096
        private const val MAX_IN_X4 = 1024
        private const val MAX_IN_X2 = 2048
    }
}
