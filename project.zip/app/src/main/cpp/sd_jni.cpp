// Stable Diffusion 1.5 on MNN, text-to-image and image-to-image, called from Kotlin via JNI.
// Pipeline follows MNN 3.4.0 transformers/diffusion/engine/src/stable_diffusion.cpp,
// plus a VAE encoder so a photo can be used as the starting point.
#include <jni.h>
#include <cmath>
#include <cstring>
#include <memory>
#include <mutex>
#include <random>
#include <string>
#include <functional>
#include <vector>
#include <unistd.h>
#include <sys/stat.h>
#include <android/log.h>

#include <MNN/expr/Module.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/ExecutorScope.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <cv/cv.hpp>
#include "tokenizer.hpp"
#include "scheduler.hpp"

using namespace MNN;
using namespace MNN::Express;
using namespace MNN::DIFFUSION;
using namespace CV;

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NitidoSD", __VA_ARGS__)

namespace {

constexpr int kTextLen = 77;
constexpr int kLatent = 4 * 64 * 64;
constexpr int kPixels = 3 * 512 * 512;

class Pipeline {
public:
    bool load(const std::string& dir, int backend) {
        ScheduleConfig config;
        BackendConfig backendConfig;
        config.type = (MNNForwardType)backend;
        if (config.type == MNN_FORWARD_CPU) {
            config.numThread = 4;
        } else if (config.type == MNN_FORWARD_OPENCL) {
            config.mode = MNN_GPU_MEMORY_BUFFER | MNN_GPU_TUNING_FAST;
        } else {
            config.numThread = 1;
        }
        backendConfig.memory = BackendConfig::Memory_Low;
        backendConfig.precision = BackendConfig::Precision_Low;
        config.backendConfig = &backendConfig;

        auto exe = ExecutorScope::Current();
        exe->lazyEval = false;
        exe->setGlobalExecutorConfig(config.type, backendConfig, config.numThread);

        Module::Config mc;
        mc.shapeMutable = false;
        rt_.reset(Executor::RuntimeManager::createRuntimeManager(config));
        if (config.type == MNN_FORWARD_OPENCL) rt_->setCache(".tempcache");
        if (config.type == MNN_FORWARD_CPU) rt_->setHint(Interpreter::DYNAMIC_QUANT_OPTIONS, 2);

        latentVar_ = _Input({1, 4, 64, 64}, NCHW, halide_type_of<float>());
        promptVar_ = _Input({2, kTextLen}, NCHW, halide_type_of<int>());
        timestepVar_ = _Input({1}, NCHW, halide_type_of<int>());
        latentVar_->writeMap<int8_t>();
        promptVar_->writeMap<int8_t>();
        timestepVar_->writeMap<int8_t>();

        te_.reset(Module::load({"input_ids"}, {"last_hidden_state", "pooler_output"}, (dir + "/text_encoder.mnn").c_str(), rt_, &mc));
        unet_.reset(Module::load({"sample", "timestep", "encoder_hidden_states"}, {"out_sample"}, (dir + "/unet.mnn").c_str(), rt_, &mc));
        dec_.reset(Module::load({"latent_sample"}, {"sample"}, (dir + "/vae_decoder.mnn").c_str(), rt_, &mc));
        if (!te_ || !unet_ || !dec_) return false;

        std::string encPath = dir + "/vae_encoder.mnn";
        struct stat st;
        if (stat(encPath.c_str(), &st) == 0) {
            enc_.reset(Module::load({"sample"}, {"latent"}, encPath.c_str(), rt_, &mc));
        }

        tok_.reset(new CLIPTokenizer);
        if (!tok_->load(dir)) return false;

        std::unique_ptr<Scheduler> sch(new PNDMScheduler);
        alphas_ = sch->get_alphas();

        te_->traceOrOptimize(Interpreter::Session_Resize_Fix);
        unet_->traceOrOptimize(Interpreter::Session_Resize_Fix);
        dec_->traceOrOptimize(Interpreter::Session_Resize_Fix);
        if (enc_) enc_->traceOrOptimize(Interpreter::Session_Resize_Fix);

        // Warm up every model once so the first real run doesn't pay for shape setup.
        auto emb = _Convert(te_->onForward({promptVar_})[0], NCHW);
        auto u = _Convert(unet_->onForward({_Concat({latentVar_, latentVar_}, 0), timestepVar_, emb})[0], NCHW);
        u->readMap<float>();
        auto d = _Convert(dec_->onForward({latentVar_})[0], NCHW);
        d->readMap<float>();
        return true;
    }

    bool hasEncoder() const { return (bool)enc_; }

    bool run(const std::string& prompt, const std::string& out, int iterNum, int seed,
             const float* image, float strength, const std::function<void(int)>& progress) {
        if (iterNum > 50) iterNum = 50;
        if (iterNum < 1) iterNum = 10;
        std::vector<int> full(iterNum);
        int step = 1000 / iterNum;
        for (int i = iterNum - 1; i >= 0; i--) full[i] = 1 + (iterNum - 1 - i) * step;

        bool img2img = image != nullptr && enc_;
        int start = 0;
        if (img2img) {
            int n = (int)std::lround(iterNum * strength);
            n = std::max(1, std::min(iterNum, n));
            start = iterNum - n;
        }
        ts_.assign(full.begin() + start, full.end());
        ets_.clear();
        int total = (int)ts_.size();

        // text
        auto ids = tok_->encode(prompt, kTextLen);
        if ((int)ids.size() < 2 * kTextLen) return false;
        ::memcpy(promptVar_->writeMap<int>(), ids.data(), 2 * kTextLen * sizeof(int));
        auto emb = _Convert(te_->onForward({promptVar_})[0], NCHW);
        emb.fix(VARP::CONSTANT);
        progress(100 / (total + 3));

        // starting latent
        std::mt19937 rng((unsigned)(seed < 0 ? std::random_device()() : seed));
        std::normal_distribution<float> normal(0, 1);
        std::vector<float> noise(kLatent);
        for (auto& v : noise) v = normal(rng);

        float* dst = latentVar_->writeMap<float>();
        if (img2img) {
            auto in = _Input({1, 3, 512, 512}, NCHW, halide_type_of<float>());
            ::memcpy(in->writeMap<float>(), image, kPixels * sizeof(float));
            auto lat = _Convert(enc_->onForward({in})[0], NCHW);
            const float* lp = lat->readMap<float>();
            if (!lp) return false;
            float a = alphas_[ts_[0]];
            float sa = std::sqrt(a), sb = std::sqrt(1.f - a);
            dst = latentVar_->writeMap<float>();
            for (int i = 0; i < kLatent; i++) dst[i] = sa * lp[i] * 0.18215f + sb * noise[i];
        } else {
            ::memcpy(dst, noise.data(), kLatent * sizeof(float));
        }

        // denoise
        auto scale = _Input({1}, NCHW, halide_type_of<float>());
        scale->writeMap<float>()[0] = 7.5f;
        auto floatVar = _Input({1}, NCHW, halide_type_of<float>());
        float* tp = floatVar->writeMap<float>();
        VARP plms = latentVar_;
        for (int i = 0; i < total; i++) {
            tp[0] = (float)ts_[i];
            timestepVar_->input(_Cast(floatVar, halide_type_of<int>()));
            auto sample = _Concat({plms, plms}, 0);
            auto pred = _Convert(unet_->onForward({sample, timestepVar_, emb})[0], NCHW);
            auto parts = _Split(pred, {2}, 0);
            auto guided = scale * (parts[1] - parts[0]) + parts[0];
            plms = stepPlms(plms, guided, i);
            progress((2 + i) * 100 / (total + 3));
        }
        plms.fix(VARP::CONSTANT);

        // decode
        auto latent = plms * _Const(1.f / 0.18215f);
        auto img = _Convert(dec_->onForward({latent})[0], NCHW);
        img = _Relu6(img * _Const(0.5f) + _Const(0.5f), 0, 1);
        img = _Squeeze(_Transpose(img, {0, 2, 3, 1}));
        img = _Cast(_Round(img * _Const(255.f)), halide_type_of<uint8_t>());
        img = cvtColor(img, COLOR_BGR2RGB);
        img.fix(VARP::CONSTANT);
        bool ok = imwrite(out, img);
        progress(100);
        return ok;
    }

private:
    VARP stepPlms(VARP sample, VARP out, int index) {
        int timestep = ts_[index];
        int prev = index + 1 < (int)ts_.size() ? ts_[index + 1] : 0;
        if (index != 1) {
            if (ets_.size() >= 4) ets_[ets_.size() - 4] = nullptr;
            ets_.push_back(out);
        } else {
            timestep = ts_[0];
            prev = ts_.size() > 1 ? ts_[1] : 0;
        }
        int e = (int)ets_.size() - 1;
        if (index == 0) {
            keep_ = sample;
        } else if (index == 1) {
            out = (out + ets_[e]) * _Const(0.5f);
            sample = keep_;
        } else if (e == 1) {
            out = (_Const(3.f) * ets_[e] - ets_[e - 1]) * _Const(0.5f);
        } else if (e == 2) {
            out = (_Const(23.f) * ets_[e] - _Const(16.f) * ets_[e - 1] + _Const(5.f) * ets_[e - 2]) * _Const(1.f / 12.f);
        } else if (e >= 3) {
            out = _Const(1.f / 24.f) * (_Const(55.f) * ets_[e] - _Const(59.f) * ets_[e - 1] + _Const(37.f) * ets_[e - 2] - _Const(9.f) * ets_[e - 3]);
        }
        float at = alphas_[timestep], ap = alphas_[prev];
        float bt = 1 - at, bp = 1 - ap;
        float sc = std::sqrt(ap / at);
        float denom = at * std::sqrt(bp) + std::sqrt(at * bt * ap);
        return _Scalar(sc) * sample - _Scalar((ap - at) / denom) * out;
    }

    std::shared_ptr<Executor::RuntimeManager> rt_;
    std::shared_ptr<Module> te_, unet_, dec_, enc_;
    std::unique_ptr<CLIPTokenizer> tok_;
    VARP latentVar_, promptVar_, timestepVar_, keep_;
    std::vector<float> alphas_;
    std::vector<int> ts_;
    std::vector<VARP> ets_;
};

std::mutex gLock;
std::unique_ptr<Pipeline> gPipe;
std::string gPath;
int gBackend = -1;

std::string str(JNIEnv* env, jstring s) {
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

} // namespace

// Returns 0 ok, 2 model failed to load, 3 generation failed, 4 photo given but no encoder.
extern "C" JNIEXPORT jint JNICALL
Java_com_nitido_app_SdNative_generate(JNIEnv* env, jclass, jstring jdir, jstring jcache, jint backend,
                                      jint steps, jint seed, jstring jout, jstring jprompt,
                                      jfloatArray jimage, jfloat strength, jobject listener) {
    std::lock_guard<std::mutex> lock(gLock);
    std::string dir = str(env, jdir), out = str(env, jout), prompt = str(env, jprompt);
    std::string cache = str(env, jcache);
    if (!cache.empty()) chdir(cache.c_str());   // OpenCL tuning cache is written to the working dir

    if (!gPipe || dir != gPath || backend != gBackend) {
        gPipe.reset();
        LOGI("loading model from %s backend %d", dir.c_str(), backend);
        std::unique_ptr<Pipeline> p(new Pipeline);
        if (!p->load(dir, backend)) return 2;
        gPipe = std::move(p);
        gPath = dir;
        gBackend = backend;
    }

    std::vector<float> image;
    if (jimage) {
        if (!gPipe->hasEncoder()) return 4;
        if (env->GetArrayLength(jimage) != kPixels) return 3;
        image.resize(kPixels);
        env->GetFloatArrayRegion(jimage, 0, kPixels, image.data());
    }

    jclass cls = env->GetObjectClass(listener);
    jmethodID onProgress = env->GetMethodID(cls, "onProgress", "(I)V");
    auto cb = [&](int pct) {
        if (onProgress) env->CallVoidMethod(listener, onProgress, (jint)pct);
        if (env->ExceptionCheck()) env->ExceptionClear();
    };
    bool ok = gPipe->run(prompt, out, steps, seed, image.empty() ? nullptr : image.data(), strength, cb);
    return ok ? 0 : 3;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nitido_app_SdNative_release(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(gLock);
    gPipe.reset();
    gBackend = -1;
}
