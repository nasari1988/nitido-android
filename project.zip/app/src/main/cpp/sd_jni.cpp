// Stable Diffusion 1.5 family on MNN, called from Kotlin via JNI.
// Modes:
//   0 = standard SD 1.5 model: text-to-image, or image-to-image when a photo is given
//   1 = InstructPix2Pix: edits a photo following an instruction
// Pipeline follows MNN 3.4.0 transformers/diffusion/engine/src/stable_diffusion.cpp,
// extended with a VAE encoder, negative prompts and InstructPix2Pix guidance.
#include <jni.h>
#include <cmath>
#include <cstring>
#include <functional>
#include <memory>
#include <mutex>
#include <random>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/stat.h>
#include <android/log.h>

#include <MNN/expr/Module.hpp>
#include <MNN/expr/Executor.hpp>
#include <MNN/expr/ExecutorScope.hpp>
#include <MNN/expr/ExprCreator.hpp>
#include <cv/cv.hpp>
#include "tokenizer.hpp"
#include "scheduler.hpp"

using namespace MNN;
using namespace MNN::Express;
using namespace MNN::DIFFUSION;
using namespace CV;

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NitidoSD", __VA_ARGS__)

namespace {

constexpr int kTextLen = 77;
constexpr int kLatent = 4 * 64 * 64;
constexpr int kPixels = 3 * 512 * 512;

bool exists(const std::string& p) { struct stat st; return stat(p.c_str(), &st) == 0; }

class Pipeline {
public:
    bool load(const std::string& dir, int backend, int mode) {
        mode_ = mode;
        ScheduleConfig config;
        BackendConfig backendConfig;
        config.type = (MNNForwardType)backend;
        if (config.type == MNN_FORWARD_CPU) {
            config.numThread = 4;
        } else if (config.type == MNN_FORWARD_OPENCL) {
            config.mode = MNN_GPU_MEMORY_BUFFER | MNN_GPU_TUNING_FAST;
        } else {
            config.numThread = 1;
        }
        backendConfig.memory = BackendConfig::Memory_Low;
        backendConfig.precision = BackendConfig::Precision_Low;
        config.backendConfig = &backendConfig;

        auto exe = ExecutorScope::Current();
        exe->lazyEval = false;
        exe->setGlobalExecutorConfig(config.type, backendConfig, config.numThread);

        Module::Config mc;
        mc.shapeMutable = false;
        rt_.reset(Executor::RuntimeManager::createRuntimeManager(config));
        if (config.type == MNN_FORWARD_OPENCL) rt_->setCache(".tempcache");
        if (config.type == MNN_FORWARD_CPU) rt_->setHint(Interpreter::DYNAMIC_QUANT_OPTIONS, 2);

        latentVar_ = _Input({1, 4, 64, 64}, NCHW, halide_type_of<float>());
        promptVar_ = _Input({2, kTextLen}, NCHW, halide_type_of<int>());
        timestepVar_ = _Input({1}, NCHW, halide_type_of<int>());
        latentVar_->writeMap<int8_t>();
        promptVar_->writeMap<int8_t>();
        timestepVar_->writeMap<int8_t>();

        te_.reset(Module::load({"input_ids"}, {"last_hidden_state", "pooler_output"}, (dir + "/text_encoder.mnn").c_str(), rt_, &mc));
        unet_.reset(Module::load({"sample", "timestep", "encoder_hidden_states"}, {"out_sample"}, (dir + "/unet.mnn").c_str(), rt_, &mc));
        dec_.reset(Module::load({"latent_sample"}, {"sample"}, (dir + "/vae_decoder.mnn").c_str(), rt_, &mc));
        if (!te_ || !unet_ || !dec_) return false;
        if (exists(dir + "/vae_encoder.mnn")) {
            enc_.reset(Module::load({"sample"}, {"latent"}, (dir + "/vae_encoder.mnn").c_str(), rt_, &mc));
        }
        if (mode_ == 1 && !enc_) return false;

        tok_.reset(new CLIPTokenizer);
        if (!tok_->load(dir)) return false;

        std::unique_ptr<Scheduler> sch(new PNDMScheduler);
        alphas_ = sch->get_alphas();

        te_->traceOrOptimize(Interpreter::Session_Resize_Fix);
        unet_->traceOrOptimize(Interpreter::Session_Resize_Fix);
        dec_->traceOrOptimize(Interpreter::Session_Resize_Fix);
        if (enc_) enc_->traceOrOptimize(Interpreter::Session_Resize_Fix);

        // Warm up once so the first real run doesn't pay for shape setup.
        auto emb = _Convert(te_->onForward({promptVar_})[0], NCHW);
        VARP u;
        if (mode_ == 1) {
            auto parts = _Split(emb, {2}, 0);
            auto emb3 = _Concat({parts[1], parts[0], parts[0]}, 0);
            auto x = _Concat({latentVar_, latentVar_}, 1);
            u = unet_->onForward({_Concat({x, x, x}, 0), timestepVar_, emb3})[0];
        } else {
            u = unet_->onForward({_Concat({latentVar_, latentVar_}, 0), timestepVar_, emb})[0];
        }
        _Convert(u, NCHW)->readMap<float>();
        _Convert(dec_->onForward({latentVar_})[0], NCHW)->readMap<float>();
        return true;
    }

    bool hasEncoder() const { return (bool)enc_; }

    bool run(const std::string& prompt, const std::string& negative, const std::string& out,
             int iterNum, int seed, const float* image, float strength,
             float guidance, float imageGuidance, const std::function<void(int)>& progress,
             int previewMode, const std::function<void(const uint8_t*, int)>& preview) {
        if (iterNum > 50) iterNum = 50;
        if (iterNum < 1) iterNum = 10;
        std::vector<int> full(iterNum);
        int step = 1000 / iterNum;
        for (int i = iterNum - 1; i >= 0; i--) full[i] = 1 + (iterNum - 1 - i) * step;

        bool pix2pix = mode_ == 1;
        if (pix2pix && !image) return false;
        bool img2img = !pix2pix && image != nullptr && enc_;
        int start = 0;
        if (img2img) {
            int n = (int)std::lround(iterNum * strength);
            n = std::max(1, std::min(iterNum, n));
            start = iterNum - n;
        }
        ts_.assign(full.begin() + start, full.end());
        ets_.clear();
        int total = (int)ts_.size();

        // Text: row 0 = negative (or empty), row 1 = prompt.
        auto ids = tok_->encode(prompt, kTextLen);
        if ((int)ids.size() < 2 * kTextLen) return false;
        if (!negative.empty()) {
            auto nids = tok_->encode(negative, kTextLen);
            if ((int)nids.size() >= 2 * kTextLen) std::copy(nids.begin() + kTextLen, nids.begin() + 2 * kTextLen, ids.begin());
        }
        ::memcpy(promptVar_->writeMap<int>(), ids.data(), 2 * kTextLen * sizeof(int));
        auto emb = _Convert(te_->onForward({promptVar_})[0], NCHW);
        emb.fix(VARP::CONSTANT);
        progress(100 / (total + 3));

        // Encode the photo, if any.
        VARP photoLatent;
        if (image && enc_) {
            auto in = _Input({1, 3, 512, 512}, NCHW, halide_type_of<float>());
            ::memcpy(in->writeMap<float>(), image, kPixels * sizeof(float));
            photoLatent = _Convert(enc_->onForward({in})[0], NCHW);
            photoLatent.fix(VARP::CONSTANT);
        }

        // Starting latent.
        std::mt19937 rng((unsigned)(seed < 0 ? std::random_device()() : seed));
        std::normal_distribution<float> normal(0, 1);
        std::vector<float> noise(kLatent);
        for (auto& v : noise) v = normal(rng);
        float* dst = latentVar_->writeMap<float>();
        if (img2img) {
            const float* lp = photoLatent->readMap<float>();
            if (!lp) return false;
            float a = alphas_[ts_[0]];
            float sa = std::sqrt(a), sb = std::sqrt(1.f - a);
            dst = latentVar_->writeMap<float>();
            for (int i = 0; i < kLatent; i++) dst[i] = sa * lp[i] * 0.18215f + sb * noise[i];
        } else {
            ::memcpy(dst, noise.data(), kLatent * sizeof(float));
        }

        // Conditioning for InstructPix2Pix: batch = [text, image-only, unconditional].
        VARP emb3, zeros;
        if (pix2pix) {
            auto parts = _Split(emb, {2}, 0);
            emb3 = _Concat({parts[1], parts[0], parts[0]}, 0);
            emb3.fix(VARP::CONSTANT);
            zeros = _Const(0.f, {1, 4, 64, 64}, NCHW);
        }

        auto gScale = _Scalar<float>(guidance);
        auto iScale = _Scalar<float>(imageGuidance);
        auto floatVar = _Input({1}, NCHW, halide_type_of<float>());
        float* tp = floatVar->writeMap<float>();
        VARP plms = latentVar_;
        for (int i = 0; i < total; i++) {
            tp[0] = (float)ts_[i];
            timestepVar_->input(_Cast(floatVar, halide_type_of<int>()));
            VARP guided;
            if (pix2pix) {
                auto withImg = _Concat({plms, photoLatent}, 1);
                auto noImg = _Concat({plms, zeros}, 1);
                auto sample = _Concat({withImg, withImg, noImg}, 0);
                auto pred = _Convert(unet_->onForward({sample, timestepVar_, emb3})[0], NCHW);
                auto p = _Split(pred, {3}, 0);   // text, image, uncond
                guided = p[2] + gScale * (p[0] - p[1]) + iScale * (p[1] - p[2]);
            } else {
                auto sample = _Concat({plms, plms}, 0);
                auto pred = _Convert(unet_->onForward({sample, timestepVar_, emb})[0], NCHW);
                auto p = _Split(pred, {2}, 0);   // uncond/negative, text
                guided = p[0] + gScale * (p[1] - p[0]);
            }
            if (previewMode > 0) sendPreview(plms, guided, ts_[i], previewMode, preview);
            plms = stepPlms(plms, guided, i);
            progress((2 + i) * 100 / (total + 3));
        }
        plms.fix(VARP::CONSTANT);

        auto rgb = decodeRgb(plms);
        if (previewMode > 0) {
            const uint8_t* p = rgb->readMap<uint8_t>();
            if (p) preview(p, 512);
        }
        auto img = cvtColor(rgb, COLOR_BGR2RGB);   // imwrite expects BGR
        img.fix(VARP::CONSTANT);
        bool ok = imwrite(out, img);
        progress(100);
        return ok;
    }

private:
    // Turn a latent (model space, already ×0.18215) into 512×512 RGB with the VAE decoder.
    VARP decodeRgb(VARP latent) {
        auto img = _Convert(dec_->onForward({latent * _Const(1.f / 0.18215f)})[0], NCHW);
        img = _Relu6(img * _Const(0.5f) + _Const(0.5f), 0, 1);
        img = _Squeeze(_Transpose(img, {0, 2, 3, 1}));
        return _Cast(_Round(img * _Const(255.f)), halide_type_of<uint8_t>());
    }

    // Preview of what the image will look like: the model's current estimate of the clean
    // latent, shown either with a cheap linear color approximation (64×64) or fully decoded.
    void sendPreview(VARP sample, VARP eps, int t, int mode, const std::function<void(const uint8_t*, int)>& cb) {
        float a = alphas_[t];
        auto x0 = (sample - _Scalar(std::sqrt(1.f - a)) * eps) * _Scalar(1.f / std::sqrt(a));
        if (mode == 2) {
            auto rgb = decodeRgb(x0);
            const uint8_t* p = rgb->readMap<uint8_t>();
            if (p) cb(p, 512);
            return;
        }
        const float* l = _Convert(x0, NCHW)->readMap<float>();
        if (!l) return;
        // SD 1.5 latent -> RGB approximation
        static const float F[4][3] = {{0.3512f, 0.2297f, 0.3227f}, {0.3250f, 0.4974f, 0.2350f},
                                      {-0.2829f, 0.1762f, 0.2721f}, {-0.2120f, -0.2616f, -0.7177f}};
        std::vector<uint8_t> rgb(64 * 64 * 3);
        for (int i = 0; i < 64 * 64; i++) {
            for (int c = 0; c < 3; c++) {
                float v = 0;
                for (int k = 0; k < 4; k++) v += l[k * 4096 + i] * F[k][c];
                v = (v + 1.f) * 127.5f;
                rgb[i * 3 + c] = (uint8_t)std::max(0.f, std::min(255.f, v));
            }
        }
        cb(rgb.data(), 64);
    }

    VARP stepPlms(VARP sample, VARP out, int index) {
        int timestep = ts_[index];
        int prev = index + 1 < (int)ts_.size() ? ts_[index + 1] : 0;
        if (index != 1) {
            if (ets_.size() >= 4) ets_[ets_.size() - 4] = nullptr;
            ets_.push_back(out);
        } else {
            timestep = ts_[0];
            prev = ts_.size() > 1 ? ts_[1] : 0;
        }
        int e = (int)ets_.size() - 1;
        if (index == 0) {
            keep_ = sample;
        } else if (index == 1) {
            out = (out + ets_[e]) * _Const(0.5f);
            sample = keep_;
        } else if (e == 1) {
            out = (_Const(3.f) * ets_[e] - ets_[e - 1]) * _Const(0.5f);
        } else if (e == 2) {
            out = (_Const(23.f) * ets_[e] - _Const(16.f) * ets_[e - 1] + _Const(5.f) * ets_[e - 2]) * _Const(1.f / 12.f);
        } else if (e >= 3) {
            out = _Const(1.f / 24.f) * (_Const(55.f) * ets_[e] - _Const(59.f) * ets_[e - 1] + _Const(37.f) * ets_[e - 2] - _Const(9.f) * ets_[e - 3]);
        }
        float at = alphas_[timestep], ap = alphas_[prev];
        float bt = 1 - at, bp = 1 - ap;
        float sc = std::sqrt(ap / at);
        float denom = at * std::sqrt(bp) + std::sqrt(at * bt * ap);
        return _Scalar(sc) * sample - _Scalar((ap - at) / denom) * out;
    }

    int mode_ = 0;
    std::shared_ptr<Executor::RuntimeManager> rt_;
    std::shared_ptr<Module> te_, unet_, dec_, enc_;
    std::unique_ptr<CLIPTokenizer> tok_;
    VARP latentVar_, promptVar_, timestepVar_, keep_;
    std::vector<float> alphas_;
    std::vector<int> ts_;
    std::vector<VARP> ets_;
};

std::mutex gLock;
std::unique_ptr<Pipeline> gPipe;
std::string gPath;
int gBackend = -1, gMode = -1;

std::string str(JNIEnv* env, jstring s) {
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

} // namespace

// Returns 0 ok, 2 model failed to load, 3 generation failed, 4 photo given but no encoder.
extern "C" JNIEXPORT jint JNICALL
Java_com_nitido_app_SdNative_generate(JNIEnv* env, jclass, jstring jdir, jstring jcache, jint backend, jint mode,
                                      jint steps, jint seed, jstring jout, jstring jprompt, jstring jnegative,
                                      jfloatArray jimage, jfloat strength, jfloat guidance, jfloat imageGuidance,
                                      jint previewMode, jobject listener) {
    std::lock_guard<std::mutex> lock(gLock);
    std::string dir = str(env, jdir), out = str(env, jout), prompt = str(env, jprompt), negative = str(env, jnegative);
    std::string cache = str(env, jcache);
    if (!cache.empty()) chdir(cache.c_str());   // OpenCL tuning cache is written to the working dir

    if (!gPipe || dir != gPath || backend != gBackend || mode != gMode) {
        gPipe.reset();
        LOGI("loading model from %s backend %d mode %d", dir.c_str(), backend, mode);
        std::unique_ptr<Pipeline> p(new Pipeline);
        if (!p->load(dir, backend, mode)) return 2;
        gPipe = std::move(p);
        gPath = dir;
        gBackend = backend;
        gMode = mode;
    }

    std::vector<float> image;
    if (jimage) {
        if (!gPipe->hasEncoder()) return 4;
        if (env->GetArrayLength(jimage) != kPixels) return 3;
        image.resize(kPixels);
        env->GetFloatArrayRegion(jimage, 0, kPixels, image.data());
    }

    jclass cls = env->GetObjectClass(listener);
    jmethodID onProgress = env->GetMethodID(cls, "onProgress", "(I)V");
    auto cb = [&](int pct) {
        if (onProgress) env->CallVoidMethod(listener, onProgress, (jint)pct);
        if (env->ExceptionCheck()) env->ExceptionClear();
    };
    jmethodID onPreview = env->GetMethodID(cls, "onPreview", "([BI)V");
    if (env->ExceptionCheck()) { env->ExceptionClear(); onPreview = nullptr; }
    auto pv = [&](const uint8_t* rgb, int size) {
        if (!onPreview) return;
        jsize n = size * size * 3;
        jbyteArray arr = env->NewByteArray(n);
        if (!arr) { env->ExceptionClear(); return; }
        env->SetByteArrayRegion(arr, 0, n, reinterpret_cast<const jbyte*>(rgb));
        env->CallVoidMethod(listener, onPreview, arr, (jint)size);
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(arr);
    };
    bool ok = gPipe->run(prompt, negative, out, steps, seed, image.empty() ? nullptr : image.data(),
                         strength, guidance, imageGuidance, cb, previewMode, pv);
    return ok ? 0 : 3;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nitido_app_SdNative_release(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(gLock);
    gPipe.reset();
    gBackend = -1;
    gMode = -1;
}
