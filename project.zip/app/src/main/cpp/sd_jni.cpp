// JNI bridge to MNN's Stable Diffusion 1.5 engine (runs in the app process).
#include <jni.h>
#include <memory>
#include <mutex>
#include <string>
#include <android/log.h>
#include "diffusion/diffusion.hpp"

using namespace MNN::DIFFUSION;

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NitidoSD", __VA_ARGS__)

static std::mutex gLock;
static std::unique_ptr<Diffusion> gModel;
static std::string gPath;
static int gBackend = -1;

static std::string str(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_nitido_app_SdNative_generate(JNIEnv* env, jclass, jstring jdir, jint backend, jint steps,
                                      jint seed, jstring jout, jstring jprompt, jobject listener) {
    std::lock_guard<std::mutex> lock(gLock);
    std::string dir = str(env, jdir), out = str(env, jout), prompt = str(env, jprompt);

    if (!gModel || dir != gPath || backend != gBackend) {
        gModel.reset();
        LOGI("loading model from %s backend %d", dir.c_str(), backend);
        gModel.reset(Diffusion::createDiffusion(dir, STABLE_DIFFUSION_1_5, (MNNForwardType)backend, 1));
        if (!gModel) return 1;
        if (!gModel->load()) { gModel.reset(); return 2; }
        gPath = dir;
        gBackend = backend;
    }

    jclass cls = env->GetObjectClass(listener);
    jmethodID onProgress = env->GetMethodID(cls, "onProgress", "(I)V");
    auto cb = [&](int pct) {
        if (onProgress) env->CallVoidMethod(listener, onProgress, (jint)pct);
    };
    bool ok = gModel->run(prompt, out, steps, seed, cb);
    if (env->ExceptionCheck()) env->ExceptionClear();
    return ok ? 0 : 3;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nitido_app_SdNative_release(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(gLock);
    gModel.reset();
    gBackend = -1;
}
