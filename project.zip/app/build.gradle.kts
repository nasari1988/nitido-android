plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// QNN 2.51 (same version the NPU models are compiled with), downloaded by ci/build.sh
val qnn251 = file("src/main/qnnskel/.qnn251").exists()

android {
    namespace = "com.nitido.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nitido.app"
        minSdk = 29
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    signingConfigs {
        create("personal") {
            storeFile = file("nitido.keystore")
            storePassword = "nitido123"
            keyAlias = "nitido"
            keyPassword = "nitido123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("personal")
        }
        debug {
            signingConfig = signingConfigs.getByName("personal")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    androidResources { noCompress += listOf("tflite", "mnn") }
    packaging {
        jniLibs {
            useLegacyPackaging = true
            pickFirsts += listOf("**/libc++_shared.so")
            // Hexagon (NPU) code and unused QNN back ends: not ARM code, not 16 KB aligned
            excludes += listOf("**/libQnnHtpV*Skel.so", "**/libQnnDsp*.so", "**/libQnnGpu.so", "**/libQnnHtpV68Stub.so", "**/libQnnHtpV69Stub.so", "**/libQnnHtpV81Stub.so")
        }
    }
    buildFeatures { viewBinding = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // LiteRT = the new name of TensorFlow Lite; these builds are aligned to 16 KB pages
    implementation("com.google.ai.edge.litert:litert:1.4.0")
    // UNet on the Qualcomm NPU (QNN execution provider; brings the QNN runtime libraries)
    // with QNN 2.51 downloaded (ci/build.sh) the app ships those instead of the 2.42 in this package
    implementation("com.microsoft.onnxruntime:onnxruntime-android-qnn:1.29.0") {
        if (qnn251) exclude(group = "com.qualcomm.qti", module = "qnn-runtime")
    }
    implementation("com.google.ai.edge.litert:litert-gpu:1.4.0")
    implementation("com.google.ai.edge.litert:litert-gpu-api:1.4.0")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.android.gms:play-services-mlkit-subject-segmentation:16.0.0-beta1")
    implementation("com.google.android.gms:play-services-base:18.5.0")
    implementation("com.google.mediapipe:tasks-vision:0.10.26")
}

// The NPU-side QNN libraries (Hexagon "Skel" files) are not ARM code and are not 16 KB aligned,
// so they don't go in lib/: they ship as assets and the app copies them out (NpuUnet.prepareDsp).
val qnnRuntime by configurations.creating
dependencies { qnnRuntime("com.qualcomm.qti:qnn-runtime:2.42.0@aar") }
val qnnAssets = layout.buildDirectory.dir("generated/qnnassets")
val extractQnnSkel by tasks.registering(Copy::class) {
    from({ qnnRuntime.resolve().map { zipTree(it) } }) {
        include("jni/arm64-v8a/libQnnHtpV73Skel.so", "jni/arm64-v8a/libQnnHtpV75Skel.so", "jni/arm64-v8a/libQnnHtpV79Skel.so")
        eachFile { path = "qnn/" + name }
        includeEmptyDirs = false
    }
    into(qnnAssets)
}
if (qnn251) {
    android.sourceSets.getByName("main").assets.srcDir(file("src/main/qnnskel"))
} else {
    android.sourceSets.getByName("main").assets.srcDir(qnnAssets.get().asFile)
}
tasks.matching { (it.name.startsWith("merge") && it.name.endsWith("Assets")) || it.name.contains("Lint") || it.name.contains("lint") }.configureEach { dependsOn(extractQnnSkel) }

// The Stable Diffusion engine and VAE encoder are built from source (ci/native.sh)
// whenever they are missing, so every build of the APK includes them.
val nativeLib = file("src/main/jniLibs/arm64-v8a/libsdjni.so")
val vaeEncoder = file("src/main/assets/vae_encoder.mnn")
val buildNative by tasks.registering(Exec::class) {
    onlyIf { !nativeLib.exists() || !vaeEncoder.exists() }
    workingDir = rootDir
    commandLine("bash", "ci/native.sh")
}
val checkNative by tasks.registering {
    dependsOn(buildNative)
    doLast {
        if (!nativeLib.exists()) throw GradleException("Falta libsdjni.so")
        if (!vaeEncoder.exists()) throw GradleException("Falta vae_encoder.mnn")
    }
}
tasks.named("preBuild") { dependsOn(checkNative) }
