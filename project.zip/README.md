# Nítido (Android)

App para mejorar resolución y nitidez de fotos con IA, 100% en el teléfono.

- Modelo: Real-ESRGAN General x4v3 (versión TFLite optimizada por Qualcomm AI Hub), licencia BSD-3-Clause de xinntao/Real-ESRGAN.
- Motor: TensorFlow Lite con GPU, NPU (NNAPI) o CPU.
- Escala ×2 o ×4, comparación antes/después con zoom, guarda en Galería › Pictures/Nitido.
- También aparece en "Compartir" desde la galería.

## Cómo se compila

Cada vez que se sube un cambio a `main`, GitHub Actions descarga el modelo, compila el APK y lo publica en **Releases** como `Nitido.apk`.

## Instalar

En el teléfono: Releases → la versión más nueva → `Nitido.apk` → instalar (permite "instalar apps desconocidas" para el navegador si lo pide).

## Reglas de diseño (obligatorias en toda pantalla)

1. **La imagen o el video manda.** Toda foto o video, cargado o en proceso, se ajusta al espacio disponible para verse lo más grande posible (sin recortar; horizontal llena el ancho, vertical llena el alto). Nada lo hace más pequeño.
2. **Lo demás flota o queda en una franja delgada.** Opciones, texto, detalles del proceso y registro se abren flotando encima (máximo 40 % de la pantalla) o en una franja corta; nunca empujan la imagen.
3. **⤢ Pantalla completa** en toda imagen o video, también con el teléfono girado.
4. **Los videos se reproducen dentro de Nítido** (sin abrir otra app), con Mejorado ⇄ Original.
5. **Privacidad:** Inicio no muestra miniaturas de fotos ni videos; "Mis resultados" abre la galería.
6. Todo texto visible, en español latinoamericano. Maqueta aprobada antes de cualquier pantalla nueva.
